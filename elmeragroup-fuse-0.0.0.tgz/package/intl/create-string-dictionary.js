import { LocalizedStringDictionary } from "@internationalized/string";
// src/intl/create-string-dictionary.ts
/**
* Builds a component's four-locale dictionary.
*
* Every component owns its own rows, but the assembly was byte-identical in thirteen
* `intl/index.ts` modules; this factory is that assembly. Naming the four locales as
* named arguments rather than a `Record<SupportedLocale, …>` keeps a missing locale a
* type error at the call site instead of a runtime lookup miss, and the shared `K`/`T`
* parameters make the four row modules prove they carry the same keys.
*/
function createStringDictionary(locales) {
	return new LocalizedStringDictionary({
		"en-US": locales.enUS,
		"fi-FI": locales.fiFI,
		"nb-NO": locales.nbNO,
		"sv-SE": locales.svSE
	});
}
export { createStringDictionary };

//# sourceMappingURL=create-string-dictionary.js.map