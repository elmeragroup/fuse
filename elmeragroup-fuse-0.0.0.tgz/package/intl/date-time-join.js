import { cached, dateTimeFormat } from "../internal/intl-cache.js";
// src/intl/date-time-join.ts
/**
* A date-time that Fuse joins itself. Each engine's CLDR joins a date and a time in its own way.
* Node 26 prints an en-US medium date-time as `Oct 18, 2026, 12:00 AM` where WebKit prints
* `Oct 18, 2026 at 12:00 AM`, so a server-rendered label would fail hydration in Safari. Fuse
* formats each half through Intl and joins them with CLDR 48's pattern, as it already owns the
* range separator.
*/
/**
* The text between the date and the time in CLDR 48's `dateTimeFormats-atTime` standard patterns,
* which all take the form `{1}…{0}` with the date as `{1}` and the time as `{0}`. en writes
* `{1} 'at' {0}` at full and long and `{1}, {0}` at medium and short. nb writes `{1} 'kl'. {0}`
* and `{1}, {0}`, and sv writes `{1} 'kl'. {0}` and `{1} {0}`. fi writes `{1} 'klo' {0}` at every
* length. A quoted run is literal text. Full and long share one separator in every language here,
* and so do medium and short, so a mutant that swaps the two lengths of a pair prints the same
* text and survives mutation testing by the data, not by a missing test.
*/
const AT_TIME_SEPARATORS = /* @__PURE__ */ new Map([
	["en", {
		full: " at ",
		long: " at ",
		medium: ", ",
		short: ", "
	}],
	["nb", {
		full: " kl. ",
		long: " kl. ",
		medium: ", ",
		short: ", "
	}],
	["sv", {
		full: " kl. ",
		long: " kl. ",
		medium: " ",
		short: " "
	}],
	["fi", {
		full: " klo ",
		long: " klo ",
		medium: " klo ",
		short: " klo "
	}]
]);
/** The options that ask for a date field. */
const DATE_FIELDS = /* @__PURE__ */ new Set([
	"dateStyle",
	"weekday",
	"era",
	"year",
	"month",
	"day"
]);
/** The options that ask for a time field. */
const TIME_FIELDS = /* @__PURE__ */ new Set([
	"timeStyle",
	"hour",
	"minute",
	"second",
	"fractionalSecondDigits",
	"dayPeriod"
]);
/** The options whose keys pass `keep` and whose values are set. */
function half(options, keep) {
	return Object.fromEntries(Object.entries(options).filter(([key, value]) => keep(key) && value !== void 0));
}
/**
* The join length UTS #35 picks from the date half. A `dateStyle` names it. Otherwise a wide month
* with a weekday is full, a wide month alone is long, an abbreviated month is medium, and anything
* else is short.
*/
function joinLength(date) {
	if (date.dateStyle !== void 0) return date.dateStyle;
	if (date.month === "long") return date.weekday === void 0 ? "long" : "full";
	return date.month === "short" ? "medium" : "short";
}
/**
* Format an instant with Intl date-time options, joining a date half and a time half with
* CLDR 48's pattern in en, nb, sv and fi. Options with only date fields or only time fields, a
* weekday alone with a time, which CLDR prints through one skeleton, and every other language print
* Intl's own output. The result keeps Intl's spaces, so a caller that
* needs one string on every engine maps them with `canonicalSpaces`.
*
* @param locale - The BCP 47 locale.
* @param options - The date and time format options, including any `timeZone`.
* @param instant - The instant, in epoch milliseconds.
* @returns The formatted date-time.
* @throws {RangeError} When `options.timeZone` is not an IANA zone.
* @throws {TypeError} When Intl rejects the options together, such as `dateStyle` beside `hour`.
*/
function formatDateTime(locale, options, instant) {
	const { whole, join } = planOf(locale, options);
	if (join === void 0) return whole.format(instant);
	return `${join.date.format(instant)}${join.separator}${join.time.format(instant)}`;
}
/**
* `formatToParts` of an instant, joined as {@link formatDateTime} joins it: the date half's parts,
* a literal part holding Fuse's CLDR 48 separator, then the time half's parts, or Intl's own parts
* where Fuse takes Intl's output. A field laying out segments uses it, so its literals match the
* text the field's validation copy prints in every engine.
*
* @param locale - The BCP 47 locale.
* @param options - The date and time format options, including any `timeZone`.
* @param instant - The instant, in epoch milliseconds.
* @returns The parts.
* @throws {RangeError} When `options.timeZone` is not an IANA zone.
*/
function formatDateTimeToParts(locale, options, instant) {
	const { whole, join } = planOf(locale, options);
	if (join === void 0) return whole.formatToParts(instant);
	return [
		...join.date.formatToParts(instant),
		{
			type: "literal",
			value: join.separator
		},
		...join.time.formatToParts(instant)
	];
}
/** The plans by locale and options, which app code bounds as it bounds Intl's own formatters. */
const plans = /* @__PURE__ */ new Map();
/** The plan of a locale and options, split and resolved once. */
function planOf(locale, options) {
	return cached(plans, locale, options, () => buildPlan(locale, options));
}
/** Split and resolve the plan of a locale and options. */
function buildPlan(locale, options) {
	const whole = dateTimeFormat(locale, options);
	const date = half(options, (key) => !TIME_FIELDS.has(key) && key !== "timeZoneName");
	const time = half(options, (key) => !DATE_FIELDS.has(key));
	const separators = AT_TIME_SEPARATORS.get(new Intl.Locale(whole.resolvedOptions().locale).language);
	const hasDate = Object.keys(date).some((key) => DATE_FIELDS.has(key) && key !== "weekday");
	const hasTime = Object.keys(time).some((key) => TIME_FIELDS.has(key));
	return separators === void 0 || !hasDate || !hasTime ? { whole } : {
		whole,
		join: {
			date: dateTimeFormat(locale, date),
			time: dateTimeFormat(locale, time),
			separator: separators[joinLength(date)]
		}
	};
}
export { formatDateTime, formatDateTimeToParts };

//# sourceMappingURL=date-time-join.js.map