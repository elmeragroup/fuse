import { numberFormat, pluralRules } from "../internal/intl-cache.js";
import { canonicalSpaces } from "./canonical-spaces.js";
// src/intl/count-of.ts
/**
* The singular and plural forms of a counted word, the one picker that chooses between them
* through `Intl.PluralRules`, and the count written with its word.
*/
/**
* The form of a word a count takes in a locale.
*
* @param locale - The active supported locale.
* @param count - The count the word follows.
* @param word - The word's forms.
* @param options - The digits the count prints with, which decide its plural category.
* @returns The singular for the locale's "one" category, else the plural.
*/
function inflect(locale, count, word, options = {}) {
	return pluralRules(locale, options).select(count) === "one" ? word.one : word.other;
}
/**
* A count in words, such as `25 timer`, `1 day` or `52 punkter`, joined by a no-break space so the
* number never wraps away from its word.
*
* @param locale - The active supported locale.
* @param count - The number of things.
* @param word - The word's forms, such as a slot interval's or the points' word.
* @returns The count and its word in the locale's plural form.
*/
function countOf(locale, count, word) {
	return `${canonicalSpaces(numberFormat(locale, {}).format(count))}\u00a0${inflect(locale, count, word)}`;
}
export { countOf, inflect };

//# sourceMappingURL=count-of.js.map