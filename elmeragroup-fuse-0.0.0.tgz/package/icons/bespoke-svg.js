// src/icons/bespoke-svg.ts
/**
* Accessible name is only a nonempty `title` prop (role=img + a prop-driven
* `<title>`). Omitted or empty title renders decorative (`aria-hidden`).
* Never ship a static `<title>`.
* Fixed-palette artwork is permitted for illustrations (multi-color hex or
* theme fill classes). Bespoke assets are server-safe: no hooks, no
* "use client". Referenced clip-path / mask / gradient ids are namespaced
* statically per asset (e.g. `signing-clip`); two instances of the SAME asset
* share identical defs by construction, so first-in-DOM wins harmlessly —
* the namespace exists to prevent CROSS-asset collisions.
*/
function decorativeSvgProps(title) {
	if (title) return { role: "img" };
	return {
		"aria-hidden": true,
		focusable: false
	};
}
export { decorativeSvgProps };

//# sourceMappingURL=bespoke-svg.js.map