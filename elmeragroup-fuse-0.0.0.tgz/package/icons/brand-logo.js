import { cn } from "../styles/cn.js";
import { BRANDS } from "../theme/theme-input.js";
import { FjordkraftForetagLogo } from "./bespoke/fjordkraft-foretag-logo.js";
import { FjordkraftLogo } from "./bespoke/fjordkraft-logo.js";
import { GudbrandsdalEnergiLogo } from "./bespoke/gudbrandsdal-energi-logo.js";
import { NordicGreenEnergyLogo } from "./bespoke/nordic-green-energy-logo.js";
import { TelinetLogo } from "./bespoke/telinet-logo.js";
import { TrondelagkraftLogo } from "./bespoke/trondelagkraft-logo.js";
import { jsx } from "react/jsx-runtime";
// src/icons/brand-logo.tsx
const BRAND_MARKS = {
	fkas: FjordkraftLogo,
	fkab: FjordkraftForetagLogo,
	tkas: TrondelagkraftLogo,
	guen: GudbrandsdalEnergiLogo,
	fkse: TelinetLogo,
	elma: null,
	ngfi: NordicGreenEnergyLogo
};
const MARK_FALLBACK_SIZES = {
	fkas: null,
	fkab: null,
	tkas: null,
	guen: null,
	fkse: {
		width: 83.397,
		height: 64.796
	},
	elma: null,
	ngfi: {
		width: 203,
		height: 199
	}
};
/**
* A brand's logo in a span named as an image. A brand without artwork renders its display name.
*
* A `size-*` class in `className` sizes a mark. An unsized mark takes the icon size of the menu
* row or button it sits in, and its artwork size elsewhere. A full logo keeps an inline span that
* a size class can't reach, so size it through a class that targets its svg.
*
* @param props - The brand, the variant, the accessible name, and props for the span.
* @returns The logo, named by `aria-label`, then `title`, then the brand display name.
* @throws When a JavaScript caller passes a brand code outside {@link BrandCode}.
*/
function BrandLogo({ brand, variant = "full", title, "aria-label": ariaLabel, className, ...rest }) {
	const displayName = BRANDS[brand]?.displayName;
	if (displayName === void 0) throw new Error(`Unhandled brand: ${String(brand)}`);
	const Mark = BRAND_MARKS[brand];
	const drawsMark = Mark !== null && variant === "mark";
	const markProps = drawsMark ? {
		className: "max-h-full min-h-full max-w-full min-w-full",
		...MARK_FALLBACK_SIZES[brand]
	} : null;
	return /* @__PURE__ */ jsx("span", {
		"aria-label": ariaLabel ?? title ?? displayName,
		className: cn(drawsMark && "inline-flex shrink-0 [&[hidden]:not([hidden=until-found])]:hidden", className),
		...rest,
		"data-variant": variant,
		role: "img",
		children: Mark === null ? displayName : /* @__PURE__ */ jsx(Mark, {
			variant,
			...markProps
		})
	});
}
export { BrandLogo };

//# sourceMappingURL=brand-logo.js.map