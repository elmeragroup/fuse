import { createElement } from "react";
// src/icons/create-logo.ts
function createLogo(Full, Mark, name) {
	function Logo({ variant = "full", ...props }) {
		return createElement(variant === "mark" ? Mark : Full, props);
	}
	Logo.displayName = name;
	return Logo;
}
export { createLogo };

//# sourceMappingURL=create-logo.js.map