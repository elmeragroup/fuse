import { createElmeraIcon } from "../create-elmera-icon.js";
import { DeviceMobile as DeviceMobile$1 } from "@phosphor-icons/react/dist/ssr/DeviceMobile";
// src/icons/generated/device-mobile.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const DeviceMobile = createElmeraIcon(DeviceMobile$1, "DeviceMobile");
export { DeviceMobile };

//# sourceMappingURL=device-mobile.js.map