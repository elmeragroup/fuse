import { createElmeraIcon } from "../create-elmera-icon.js";
import { Confetti as Confetti$1 } from "@phosphor-icons/react/dist/ssr/Confetti";
// src/icons/generated/confetti.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const Confetti = createElmeraIcon(Confetti$1, "Confetti");
export { Confetti };

//# sourceMappingURL=confetti.js.map