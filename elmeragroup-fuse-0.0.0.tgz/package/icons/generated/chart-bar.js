import { createElmeraIcon } from "../create-elmera-icon.js";
import { ChartBar as ChartBar$1 } from "@phosphor-icons/react/dist/ssr/ChartBar";
// src/icons/generated/chart-bar.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const ChartBar = createElmeraIcon(ChartBar$1, "ChartBar");
export { ChartBar };

//# sourceMappingURL=chart-bar.js.map