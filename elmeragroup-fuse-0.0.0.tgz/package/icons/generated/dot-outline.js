import { createElmeraIcon } from "../create-elmera-icon.js";
import { DotOutline as DotOutline$1 } from "@phosphor-icons/react/dist/ssr/DotOutline";
// src/icons/generated/dot-outline.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const DotOutline = createElmeraIcon(DotOutline$1, "DotOutline");
export { DotOutline };

//# sourceMappingURL=dot-outline.js.map