import { createElmeraIcon } from "../create-elmera-icon.js";
import { FileMagnifyingGlass as FileMagnifyingGlass$1 } from "@phosphor-icons/react/dist/ssr/FileMagnifyingGlass";
// src/icons/generated/file-magnifying-glass.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const FileMagnifyingGlass = createElmeraIcon(FileMagnifyingGlass$1, "FileMagnifyingGlass");
export { FileMagnifyingGlass };

//# sourceMappingURL=file-magnifying-glass.js.map