import { createElmeraIcon } from "../create-elmera-icon.js";
import { CalendarBlank as CalendarBlank$1 } from "@phosphor-icons/react/dist/ssr/CalendarBlank";
// src/icons/generated/calendar-blank.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const CalendarBlank = createElmeraIcon(CalendarBlank$1, "CalendarBlank");
export { CalendarBlank };

//# sourceMappingURL=calendar-blank.js.map