import { createElmeraIcon } from "../create-elmera-icon.js";
import { Download as Download$1 } from "@phosphor-icons/react/dist/ssr/Download";
// src/icons/generated/download.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const Download = createElmeraIcon(Download$1, "Download");
export { Download };

//# sourceMappingURL=download.js.map