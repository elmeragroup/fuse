import { createElmeraIcon } from "../create-elmera-icon.js";
import { ChartLine as ChartLine$1 } from "@phosphor-icons/react/dist/ssr/ChartLine";
// src/icons/generated/chart-line.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const ChartLine = createElmeraIcon(ChartLine$1, "ChartLine");
export { ChartLine };

//# sourceMappingURL=chart-line.js.map