import { createElmeraIcon } from "../create-elmera-icon.js";
import { CurrencyCircleDollar as CurrencyCircleDollar$1 } from "@phosphor-icons/react/dist/ssr/CurrencyCircleDollar";
// src/icons/generated/currency-circle-dollar.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const CurrencyCircleDollar = createElmeraIcon(CurrencyCircleDollar$1, "CurrencyCircleDollar");
export { CurrencyCircleDollar };

//# sourceMappingURL=currency-circle-dollar.js.map