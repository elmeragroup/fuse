import { createElmeraIcon } from "../create-elmera-icon.js";
import { ChatCircle as ChatCircle$1 } from "@phosphor-icons/react/dist/ssr/ChatCircle";
// src/icons/generated/chat-circle.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const ChatCircle = createElmeraIcon(ChatCircle$1, "ChatCircle");
export { ChatCircle };

//# sourceMappingURL=chat-circle.js.map