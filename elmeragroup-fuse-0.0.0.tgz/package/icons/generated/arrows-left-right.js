import { createElmeraIcon } from "../create-elmera-icon.js";
import { ArrowsLeftRight as ArrowsLeftRight$1 } from "@phosphor-icons/react/dist/ssr/ArrowsLeftRight";
// src/icons/generated/arrows-left-right.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const ArrowsLeftRight = createElmeraIcon(ArrowsLeftRight$1, "ArrowsLeftRight");
export { ArrowsLeftRight };

//# sourceMappingURL=arrows-left-right.js.map