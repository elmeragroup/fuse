import { createElmeraIcon } from "../create-elmera-icon.js";
import { Buildings as Buildings$1 } from "@phosphor-icons/react/dist/ssr/Buildings";
// src/icons/generated/buildings.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const Buildings = createElmeraIcon(Buildings$1, "Buildings");
export { Buildings };

//# sourceMappingURL=buildings.js.map