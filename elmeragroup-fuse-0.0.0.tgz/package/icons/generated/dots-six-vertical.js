import { createElmeraIcon } from "../create-elmera-icon.js";
import { DotsSixVertical as DotsSixVertical$1 } from "@phosphor-icons/react/dist/ssr/DotsSixVertical";
// src/icons/generated/dots-six-vertical.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const DotsSixVertical = createElmeraIcon(DotsSixVertical$1, "DotsSixVertical");
export { DotsSixVertical };

//# sourceMappingURL=dots-six-vertical.js.map