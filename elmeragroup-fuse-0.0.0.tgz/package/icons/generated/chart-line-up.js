import { createElmeraIcon } from "../create-elmera-icon.js";
import { ChartLineUp as ChartLineUp$1 } from "@phosphor-icons/react/dist/ssr/ChartLineUp";
// src/icons/generated/chart-line-up.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const ChartLineUp = createElmeraIcon(ChartLineUp$1, "ChartLineUp");
export { ChartLineUp };

//# sourceMappingURL=chart-line-up.js.map