import { createElmeraIcon } from "../create-elmera-icon.js";
import { Calculator as Calculator$1 } from "@phosphor-icons/react/dist/ssr/Calculator";
// src/icons/generated/calculator.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const Calculator = createElmeraIcon(Calculator$1, "Calculator");
export { Calculator };

//# sourceMappingURL=calculator.js.map