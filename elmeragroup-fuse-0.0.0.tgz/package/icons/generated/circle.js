import { createElmeraIcon } from "../create-elmera-icon.js";
import { Circle as Circle$1 } from "@phosphor-icons/react/dist/ssr/Circle";
// src/icons/generated/circle.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const Circle = createElmeraIcon(Circle$1, "Circle");
export { Circle };

//# sourceMappingURL=circle.js.map