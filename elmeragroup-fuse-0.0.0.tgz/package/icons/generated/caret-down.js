import { createElmeraIcon } from "../create-elmera-icon.js";
import { CaretDown as CaretDown$1 } from "@phosphor-icons/react/dist/ssr/CaretDown";
// src/icons/generated/caret-down.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const CaretDown = createElmeraIcon(CaretDown$1, "CaretDown");
export { CaretDown };

//# sourceMappingURL=caret-down.js.map