import { createElmeraIcon } from "../create-elmera-icon.js";
import { Checks as Checks$1 } from "@phosphor-icons/react/dist/ssr/Checks";
// src/icons/generated/checks.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const Checks = createElmeraIcon(Checks$1, "Checks");
export { Checks };

//# sourceMappingURL=checks.js.map