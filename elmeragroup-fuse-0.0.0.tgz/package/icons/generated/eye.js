import { createElmeraIcon } from "../create-elmera-icon.js";
import { Eye as Eye$1 } from "@phosphor-icons/react/dist/ssr/Eye";
// src/icons/generated/eye.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const Eye = createElmeraIcon(Eye$1, "Eye");
export { Eye };

//# sourceMappingURL=eye.js.map