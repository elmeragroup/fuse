import { createElmeraIcon } from "../create-elmera-icon.js";
import { DotsThreeVertical as DotsThreeVertical$1 } from "@phosphor-icons/react/dist/ssr/DotsThreeVertical";
// src/icons/generated/dots-three-vertical.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const DotsThreeVertical = createElmeraIcon(DotsThreeVertical$1, "DotsThreeVertical");
export { DotsThreeVertical };

//# sourceMappingURL=dots-three-vertical.js.map