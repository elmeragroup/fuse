import { createElmeraIcon } from "../create-elmera-icon.js";
import { FileArrowUp as FileArrowUp$1 } from "@phosphor-icons/react/dist/ssr/FileArrowUp";
// src/icons/generated/file-arrow-up.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const FileArrowUp = createElmeraIcon(FileArrowUp$1, "FileArrowUp");
export { FileArrowUp };

//# sourceMappingURL=file-arrow-up.js.map