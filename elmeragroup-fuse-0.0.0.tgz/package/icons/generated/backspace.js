import { createElmeraIcon } from "../create-elmera-icon.js";
import { Backspace as Backspace$1 } from "@phosphor-icons/react/dist/ssr/Backspace";
// src/icons/generated/backspace.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const Backspace = createElmeraIcon(Backspace$1, "Backspace");
export { Backspace };

//# sourceMappingURL=backspace.js.map