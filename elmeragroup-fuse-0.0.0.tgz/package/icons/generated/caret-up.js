import { createElmeraIcon } from "../create-elmera-icon.js";
import { CaretUp as CaretUp$1 } from "@phosphor-icons/react/dist/ssr/CaretUp";
// src/icons/generated/caret-up.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const CaretUp = createElmeraIcon(CaretUp$1, "CaretUp");
export { CaretUp };

//# sourceMappingURL=caret-up.js.map