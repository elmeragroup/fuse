import { createElmeraIcon } from "../create-elmera-icon.js";
import { ClockCounterClockwise as ClockCounterClockwise$1 } from "@phosphor-icons/react/dist/ssr/ClockCounterClockwise";
// src/icons/generated/clock-counter-clockwise.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const ClockCounterClockwise = createElmeraIcon(ClockCounterClockwise$1, "ClockCounterClockwise");
export { ClockCounterClockwise };

//# sourceMappingURL=clock-counter-clockwise.js.map