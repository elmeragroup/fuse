import { createElmeraIcon } from "../create-elmera-icon.js";
import { ArrowsClockwise as ArrowsClockwise$1 } from "@phosphor-icons/react/dist/ssr/ArrowsClockwise";
// src/icons/generated/arrows-clockwise.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const ArrowsClockwise = createElmeraIcon(ArrowsClockwise$1, "ArrowsClockwise");
export { ArrowsClockwise };

//# sourceMappingURL=arrows-clockwise.js.map