import { createElmeraIcon } from "../create-elmera-icon.js";
import { Dot as Dot$1 } from "@phosphor-icons/react/dist/ssr/Dot";
// src/icons/generated/dot.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const Dot = createElmeraIcon(Dot$1, "Dot");
export { Dot };

//# sourceMappingURL=dot.js.map