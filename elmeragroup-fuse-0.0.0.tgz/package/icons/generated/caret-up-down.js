import { createElmeraIcon } from "../create-elmera-icon.js";
import { CaretUpDown as CaretUpDown$1 } from "@phosphor-icons/react/dist/ssr/CaretUpDown";
// src/icons/generated/caret-up-down.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const CaretUpDown = createElmeraIcon(CaretUpDown$1, "CaretUpDown");
export { CaretUpDown };

//# sourceMappingURL=caret-up-down.js.map