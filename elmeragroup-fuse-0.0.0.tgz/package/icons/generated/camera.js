import { createElmeraIcon } from "../create-elmera-icon.js";
import { Camera as Camera$1 } from "@phosphor-icons/react/dist/ssr/Camera";
// src/icons/generated/camera.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const Camera = createElmeraIcon(Camera$1, "Camera");
export { Camera };

//# sourceMappingURL=camera.js.map