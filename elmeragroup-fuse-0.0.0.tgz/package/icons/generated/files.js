import { createElmeraIcon } from "../create-elmera-icon.js";
import { Files as Files$1 } from "@phosphor-icons/react/dist/ssr/Files";
// src/icons/generated/files.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const Files = createElmeraIcon(Files$1, "Files");
export { Files };

//# sourceMappingURL=files.js.map