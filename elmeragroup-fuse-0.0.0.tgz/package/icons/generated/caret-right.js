import { createElmeraIcon } from "../create-elmera-icon.js";
import { CaretRight as CaretRight$1 } from "@phosphor-icons/react/dist/ssr/CaretRight";
// src/icons/generated/caret-right.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const CaretRight = createElmeraIcon(CaretRight$1, "CaretRight");
export { CaretRight };

//# sourceMappingURL=caret-right.js.map