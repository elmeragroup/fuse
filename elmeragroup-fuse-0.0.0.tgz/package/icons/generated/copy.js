import { createElmeraIcon } from "../create-elmera-icon.js";
import { Copy as Copy$1 } from "@phosphor-icons/react/dist/ssr/Copy";
// src/icons/generated/copy.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const Copy = createElmeraIcon(Copy$1, "Copy");
export { Copy };

//# sourceMappingURL=copy.js.map