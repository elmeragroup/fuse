import { createElmeraIcon } from "../create-elmera-icon.js";
import { Envelope as Envelope$1 } from "@phosphor-icons/react/dist/ssr/Envelope";
// src/icons/generated/envelope.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const Envelope = createElmeraIcon(Envelope$1, "Envelope");
export { Envelope };

//# sourceMappingURL=envelope.js.map