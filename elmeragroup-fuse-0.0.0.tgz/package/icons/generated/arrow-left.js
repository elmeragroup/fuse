import { createElmeraIcon } from "../create-elmera-icon.js";
import { ArrowLeft as ArrowLeft$1 } from "@phosphor-icons/react/dist/ssr/ArrowLeft";
// src/icons/generated/arrow-left.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const ArrowLeft = createElmeraIcon(ArrowLeft$1, "ArrowLeft");
export { ArrowLeft };

//# sourceMappingURL=arrow-left.js.map