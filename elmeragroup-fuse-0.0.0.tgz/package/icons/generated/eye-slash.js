import { createElmeraIcon } from "../create-elmera-icon.js";
import { EyeSlash as EyeSlash$1 } from "@phosphor-icons/react/dist/ssr/EyeSlash";
// src/icons/generated/eye-slash.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const EyeSlash = createElmeraIcon(EyeSlash$1, "EyeSlash");
export { EyeSlash };

//# sourceMappingURL=eye-slash.js.map