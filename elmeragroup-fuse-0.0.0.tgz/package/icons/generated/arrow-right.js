import { createElmeraIcon } from "../create-elmera-icon.js";
import { ArrowRight as ArrowRight$1 } from "@phosphor-icons/react/dist/ssr/ArrowRight";
// src/icons/generated/arrow-right.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const ArrowRight = createElmeraIcon(ArrowRight$1, "ArrowRight");
export { ArrowRight };

//# sourceMappingURL=arrow-right.js.map