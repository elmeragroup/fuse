import { createElmeraIcon } from "../create-elmera-icon.js";
import { DotsThree as DotsThree$1 } from "@phosphor-icons/react/dist/ssr/DotsThree";
// src/icons/generated/dots-three.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const DotsThree = createElmeraIcon(DotsThree$1, "DotsThree");
export { DotsThree };

//# sourceMappingURL=dots-three.js.map