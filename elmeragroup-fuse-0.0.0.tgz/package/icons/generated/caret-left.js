import { createElmeraIcon } from "../create-elmera-icon.js";
import { CaretLeft as CaretLeft$1 } from "@phosphor-icons/react/dist/ssr/CaretLeft";
// src/icons/generated/caret-left.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const CaretLeft = createElmeraIcon(CaretLeft$1, "CaretLeft");
export { CaretLeft };

//# sourceMappingURL=caret-left.js.map