import { createElmeraIcon } from "../create-elmera-icon.js";
import { ChatText as ChatText$1 } from "@phosphor-icons/react/dist/ssr/ChatText";
// src/icons/generated/chat-text.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const ChatText = createElmeraIcon(ChatText$1, "ChatText");
export { ChatText };

//# sourceMappingURL=chat-text.js.map