import { createElmeraIcon } from "../create-elmera-icon.js";
import { CaretDoubleRight as CaretDoubleRight$1 } from "@phosphor-icons/react/dist/ssr/CaretDoubleRight";
// src/icons/generated/caret-double-right.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const CaretDoubleRight = createElmeraIcon(CaretDoubleRight$1, "CaretDoubleRight");
export { CaretDoubleRight };

//# sourceMappingURL=caret-double-right.js.map