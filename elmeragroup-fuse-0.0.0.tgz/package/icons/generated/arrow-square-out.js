import { createElmeraIcon } from "../create-elmera-icon.js";
import { ArrowSquareOut as ArrowSquareOut$1 } from "@phosphor-icons/react/dist/ssr/ArrowSquareOut";
// src/icons/generated/arrow-square-out.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const ArrowSquareOut = createElmeraIcon(ArrowSquareOut$1, "ArrowSquareOut");
export { ArrowSquareOut };

//# sourceMappingURL=arrow-square-out.js.map