import { createElmeraIcon } from "../create-elmera-icon.js";
import { ArrowsDownUp as ArrowsDownUp$1 } from "@phosphor-icons/react/dist/ssr/ArrowsDownUp";
// src/icons/generated/arrows-down-up.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const ArrowsDownUp = createElmeraIcon(ArrowsDownUp$1, "ArrowsDownUp");
export { ArrowsDownUp };

//# sourceMappingURL=arrows-down-up.js.map