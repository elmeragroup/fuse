import { createElmeraIcon } from "../create-elmera-icon.js";
import { CreditCard as CreditCard$1 } from "@phosphor-icons/react/dist/ssr/CreditCard";
// src/icons/generated/credit-card.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const CreditCard = createElmeraIcon(CreditCard$1, "CreditCard");
export { CreditCard };

//# sourceMappingURL=credit-card.js.map