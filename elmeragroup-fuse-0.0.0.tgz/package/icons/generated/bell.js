import { createElmeraIcon } from "../create-elmera-icon.js";
import { Bell as Bell$1 } from "@phosphor-icons/react/dist/ssr/Bell";
// src/icons/generated/bell.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const Bell = createElmeraIcon(Bell$1, "Bell");
export { Bell };

//# sourceMappingURL=bell.js.map