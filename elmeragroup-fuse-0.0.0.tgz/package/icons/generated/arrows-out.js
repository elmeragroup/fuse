import { createElmeraIcon } from "../create-elmera-icon.js";
import { ArrowsOut as ArrowsOut$1 } from "@phosphor-icons/react/dist/ssr/ArrowsOut";
// src/icons/generated/arrows-out.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const ArrowsOut = createElmeraIcon(ArrowsOut$1, "ArrowsOut");
export { ArrowsOut };

//# sourceMappingURL=arrows-out.js.map