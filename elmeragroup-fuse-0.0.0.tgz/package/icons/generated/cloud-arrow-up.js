import { createElmeraIcon } from "../create-elmera-icon.js";
import { CloudArrowUp as CloudArrowUp$1 } from "@phosphor-icons/react/dist/ssr/CloudArrowUp";
// src/icons/generated/cloud-arrow-up.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const CloudArrowUp = createElmeraIcon(CloudArrowUp$1, "CloudArrowUp");
export { CloudArrowUp };

//# sourceMappingURL=cloud-arrow-up.js.map