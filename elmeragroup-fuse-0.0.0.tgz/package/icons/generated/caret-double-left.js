import { createElmeraIcon } from "../create-elmera-icon.js";
import { CaretDoubleLeft as CaretDoubleLeft$1 } from "@phosphor-icons/react/dist/ssr/CaretDoubleLeft";
// src/icons/generated/caret-double-left.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const CaretDoubleLeft = createElmeraIcon(CaretDoubleLeft$1, "CaretDoubleLeft");
export { CaretDoubleLeft };

//# sourceMappingURL=caret-double-left.js.map