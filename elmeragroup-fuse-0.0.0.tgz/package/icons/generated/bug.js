import { createElmeraIcon } from "../create-elmera-icon.js";
import { Bug as Bug$1 } from "@phosphor-icons/react/dist/ssr/Bug";
// src/icons/generated/bug.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const Bug = createElmeraIcon(Bug$1, "Bug");
export { Bug };

//# sourceMappingURL=bug.js.map