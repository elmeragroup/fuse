import { createElmeraIcon } from "../create-elmera-icon.js";
import { Cloud as Cloud$1 } from "@phosphor-icons/react/dist/ssr/Cloud";
// src/icons/generated/cloud.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const Cloud = createElmeraIcon(Cloud$1, "Cloud");
export { Cloud };

//# sourceMappingURL=cloud.js.map