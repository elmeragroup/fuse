import { createElmeraIcon } from "../create-elmera-icon.js";
import { CheckCircle as CheckCircle$1 } from "@phosphor-icons/react/dist/ssr/CheckCircle";
// src/icons/generated/check-circle.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const CheckCircle = createElmeraIcon(CheckCircle$1, "CheckCircle");
export { CheckCircle };

//# sourceMappingURL=check-circle.js.map