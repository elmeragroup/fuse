import { createElmeraIcon } from "../create-elmera-icon.js";
import { Check as Check$1 } from "@phosphor-icons/react/dist/ssr/Check";
// src/icons/generated/check.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const Check = createElmeraIcon(Check$1, "Check");
export { Check };

//# sourceMappingURL=check.js.map