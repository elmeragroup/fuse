import { createElmeraIcon } from "../create-elmera-icon.js";
import { Equals as Equals$1 } from "@phosphor-icons/react/dist/ssr/Equals";
// src/icons/generated/equals.ts
/**
* AUTO-GENERATED FILE — DO NOT EDIT DIRECTLY.
*
* Generated from the curated Phosphor roster in roster.ts.
*/
const Equals = createElmeraIcon(Equals$1, "Equals");
export { Equals };

//# sourceMappingURL=equals.js.map