import { decorativeSvgProps } from "./bespoke-svg.js";
import { createElement } from "react";
// src/icons/create-elmera-icon.ts
/**
* Wrap a Phosphor SSR icon in the public icon adapter.
*
* @param Icon - The Phosphor SSR icon to render.
* @param name - The public display name.
* @returns A server-safe icon component that follows the titled-or-decorative SVG contract.
*/
function createElmeraIcon(Icon, name) {
	function ElmeraIcon({ title, weight = "bold", ...props }) {
		return createElement(Icon, {
			...decorativeSvgProps(title),
			...props,
			alt: title,
			weight
		});
	}
	ElmeraIcon.displayName = name;
	return ElmeraIcon;
}
export { createElmeraIcon };

//# sourceMappingURL=create-elmera-icon.js.map