import { decorativeSvgProps } from "../bespoke-svg.js";
import { jsx, jsxs } from "react/jsx-runtime";
// src/icons/bespoke/elmera-group-logo-mark.tsx
function ElmeraGroupLogoMark({ title, ...props }) {
	return /* @__PURE__ */ jsxs("svg", {
		width: "33",
		height: "37",
		viewBox: "0 0 33 37",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		...decorativeSvgProps(title),
		...props,
		children: [
			title ? /* @__PURE__ */ jsx("title", { children: title }) : null,
			/* @__PURE__ */ jsx("path", {
				d: "M32.9882 0H0V7.90127H32.9882V0Z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ jsx("path", {
				d: "M18.746 14.2121H0V22.1134H18.746V14.2121Z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ jsx("path", {
				d: "M32.9882 18.1596H25.0703V28.4243H0V36.3193H32.9882V28.4243V18.1596Z",
				fill: "currentColor"
			})
		]
	});
}
export { ElmeraGroupLogoMark };

//# sourceMappingURL=elmera-group-logo-mark.js.map