import { createLogo } from "../create-logo.js";
import { ElmeraGroupLogoFull } from "./elmera-group-logo-full.js";
import { ElmeraGroupLogoMark } from "./elmera-group-logo-mark.js";
// src/icons/bespoke/elmera-group-logo.tsx
const ElmeraGroupLogo = createLogo(ElmeraGroupLogoFull, ElmeraGroupLogoMark, "ElmeraGroupLogo");
export { ElmeraGroupLogo };

//# sourceMappingURL=elmera-group-logo.js.map