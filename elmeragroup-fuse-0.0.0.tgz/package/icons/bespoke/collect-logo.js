import { decorativeSvgProps } from "../bespoke-svg.js";
import { jsx, jsxs } from "react/jsx-runtime";
// src/icons/bespoke/collect-logo.tsx
function CollectLogo({ title, ...props }) {
	return /* @__PURE__ */ jsxs("svg", {
		width: "80",
		height: "80",
		viewBox: "0 0 80 80",
		fill: "none",
		xmlns: "http://www.w3.org/2000/svg",
		...decorativeSvgProps(title),
		...props,
		children: [
			title ? /* @__PURE__ */ jsx("title", { children: title }) : null,
			/* @__PURE__ */ jsx("path", {
				d: "M55.7798 73.0124C55.7798 76.7611 52.7403 79.8 48.9908 79.8C45.2414 79.8 42.2018 76.7611 42.2018 73.0124C42.2018 69.2637 45.2414 66.2248 48.9908 66.2248C52.7403 66.2248 55.7798 69.2637 55.7798 73.0124Z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ jsx("path", {
				d: "M37.7982 73.0124C37.7982 76.7611 34.7586 79.8 31.0092 79.8C27.2597 79.8 24.2202 76.7611 24.2202 73.0124C24.2202 69.2637 27.2597 66.2248 31.0092 66.2248C34.7586 66.2248 37.7982 69.2637 37.7982 73.0124Z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ jsx("path", {
				d: "M55.7798 55.0345C55.7798 58.7832 52.7403 61.8221 48.9908 61.8221C45.2414 61.8221 42.2018 58.7832 42.2018 55.0345C42.2018 51.2858 45.2414 48.2469 48.9908 48.2469C52.7403 48.2469 55.7798 51.2858 55.7798 55.0345Z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ jsx("path", {
				d: "M37.7982 55.0345C37.7982 58.7832 34.7586 61.8221 31.0092 61.8221C27.2597 61.8221 24.2202 58.7832 24.2202 55.0345C24.2202 51.2858 27.2597 48.2469 31.0092 48.2469C34.7586 48.2469 37.7982 51.2858 37.7982 55.0345Z",
				fill: "currentColor"
			}),
			/* @__PURE__ */ jsx("path", {
				d: "M0 0C0 22.0868 17.9086 39.9917 40 39.9917C62.0914 39.9917 80 22.0868 80 0H62.3853C62.3853 12.3605 52.3631 22.3807 40 22.3807C27.6369 22.3807 17.6147 12.3605 17.6147 0H0Z",
				fill: "currentColor"
			})
		]
	});
}
export { CollectLogo };

//# sourceMappingURL=collect-logo.js.map