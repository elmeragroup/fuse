import { cn } from "../../styles/cn.js";
import { Button } from "../button/button.js";
import { Info } from "../../icons/generated/info.js";
import { WarningOctagon } from "../../icons/generated/warning-octagon.js";
import { CheckCircle } from "../../icons/generated/check-circle.js";
import { Warning } from "../../icons/generated/warning.js";
import { ITEM_DESCRIPTION_CLASSES } from "../item/item-description-classes.js";
import { ITEM_TITLE_CLASSES } from "../item/item-title-classes.js";
import { ItemActions, ItemContent, ItemMedia, ItemRootElement } from "../item/item-markup.js";
import { alertVariants } from "./alert-variants.js";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/alert/alert.tsx
const ALERT_ICONS = {
	default: Info,
	warning: Warning,
	destructive: WarningOctagon,
	success: CheckCircle,
	info: Info
};
/**
* Status alert composite over the library Item family. Server —
* it owns no state, effects, or browser APIs; `onAction` is a forwarded consumer
* handler.
*/
function AlertRoot({ children, className, variant = "default", onAction, actionLabel, role = "alert", ...props }) {
	const { base, media, button } = alertVariants({ variant });
	return /* @__PURE__ */ jsxs(ItemRootElement, {
		...props,
		role,
		"data-alert": "",
		variant: "outline",
		size: "sm",
		className: cn(base(), className),
		children: [
			/* @__PURE__ */ jsx(ItemMedia, {
				variant: "icon",
				className: media(),
				children: /* @__PURE__ */ jsx(AlertIcon, { variant })
			}),
			/* @__PURE__ */ jsx(ItemContent, { children }),
			hasAction(onAction, actionLabel) ? /* @__PURE__ */ jsx(ItemActions, { children: /* @__PURE__ */ jsx(Button, {
				className: button(),
				size: "sm",
				type: "button",
				onClick: onAction,
				children: actionLabel
			}) }) : null
		]
	});
}
function AlertIcon({ variant, className, ...props }) {
	const { icon } = alertVariants({ variant });
	const Glyph = ALERT_ICONS[variant];
	return /* @__PURE__ */ jsx(Glyph, {
		"data-slot": "alert-icon",
		className: cn(icon(), className),
		...props,
		"aria-hidden": "true"
	});
}
/**
* The alert's heading, an `h3` unless `level` says otherwise. Its text follows document density,
* 14px dense and 16px comfortable, at `font-medium` so it stands apart from the body. Render it
* as a direct child of `Alert.Root`: the density catalog finds the alert's text parts there.
*/
function AlertTitle({ children, className, level = 3, ...props }) {
	const TitleTag = `h${level}`;
	const { title } = alertVariants();
	return /* @__PURE__ */ jsx(TitleTag, {
		"data-slot": "item-title",
		className: cn(ITEM_TITLE_CLASSES, title(), className),
		...props,
		children
	});
}
/**
* Renders the alert body as a `div` without Item.Description's two-line clamp, so it can
* hold full instructions, paragraphs and lists. Its text follows document density, 14px dense
* and 16px comfortable, at regular weight, and takes the variant's text colour from
* `Alert.Root`, the same colour as the title. Render it as a direct child of `Alert.Root`, as
* `Alert.Title`.
*/
function AlertDescription({ className, ...props }) {
	const { description } = alertVariants();
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "item-description",
		className: cn(ITEM_DESCRIPTION_CLASSES, description(), className),
		...props
	});
}
function hasAction(onAction, actionLabel) {
	return onAction != null && actionLabel != null && actionLabel !== false && actionLabel !== "";
}
AlertRoot.displayName = "Alert.Root";
AlertIcon.displayName = "Alert.Icon";
AlertTitle.displayName = "Alert.Title";
AlertDescription.displayName = "Alert.Description";
const Alert = {
	Root: AlertRoot,
	Icon: AlertIcon,
	Title: AlertTitle,
	Description: AlertDescription
};
export { Alert };

//# sourceMappingURL=alert.js.map