import { tv } from "../../styles/tv.js";
// src/components/alert/alert-variants.ts
/**
* Module-private slot recipe. Not exported from the public entry, since there is no proven
* recipe-borrowing use; the workspace-only recipe catalog re-exports it for the Figma component
* sync.
*
* `variant` is the status axis only. Item supplies `variant="outline"` / `size="sm"`
* underneath; this recipe is not a control size. The `media` and `title` slots add to Item.Media's
* and Item.Title's own classes.
*/
const alertVariants = tv({
	slots: {
		base: "relative",
		media: "item-described:[--item-media-line:calc(var(--label-text)*var(--leading-snug))]",
		icon: "block size-5 shrink-0 text-foreground",
		title: "text-(length:--label-text)/snug",
		description: "text-(length:--label-text)/normal text-inherit rich-text-block:my-0 rich-text-gap:mt-2",
		button: ""
	},
	variants: { variant: {
		default: {
			base: "bg-background text-foreground",
			icon: "text-foreground",
			button: "bg-transparent text-foreground enabled-hover:bg-muted"
		},
		destructive: {
			base: "border-error bg-error/5 text-error",
			icon: "text-error",
			button: "bg-error text-error-foreground hover:bg-error/90"
		},
		warning: {
			base: "border-warning bg-warning-soft text-warning-soft-foreground [--ring:var(--warning-soft-foreground)]",
			icon: "text-warning",
			button: "bg-warning text-warning-foreground hover:bg-warning/90"
		},
		success: {
			base: "border-success bg-success/5 text-foreground",
			icon: "text-success",
			button: "bg-success text-success-foreground hover:bg-success/90"
		},
		info: {
			base: "border-info bg-info-soft text-info-soft-foreground [--ring:var(--info-soft-foreground)]",
			icon: "text-info",
			button: "bg-info text-info-foreground hover:bg-info/90"
		}
	} },
	defaultVariants: { variant: "default" }
});
export { alertVariants };

//# sourceMappingURL=alert-variants.js.map