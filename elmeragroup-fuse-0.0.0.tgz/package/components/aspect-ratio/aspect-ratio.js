import { cn } from "../../styles/cn.js";
import { aspectRatioVariants } from "./aspect-ratio-variants.js";
import { jsx } from "react/jsx-runtime";
// src/components/aspect-ratio/aspect-ratio.tsx
/**
* A `div` that keeps one of seven fixed ratios as its width changes, written to `data-ratio`.
* It is positioned, so an absolutely placed child fills it, and `size-full` sizes an `img` or
* `video` child to the frame. It is a server component and takes no `render` prop.
*/
function AspectRatio({ ratio, className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "aspect-ratio",
		"data-ratio": ratio,
		className: cn(aspectRatioVariants({ ratio }), className),
		...props
	});
}
AspectRatio.displayName = "AspectRatio";
export { AspectRatio };

//# sourceMappingURL=aspect-ratio.js.map