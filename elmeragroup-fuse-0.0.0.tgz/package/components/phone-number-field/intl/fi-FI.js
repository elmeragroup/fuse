// src/components/phone-number-field/intl/fi-FI.ts
/** Default localized copy for phoneNumberField.* keys. */
const fiFI = {
	selectCountry: "Valitse maa",
	searchCountries: "Hae maita",
	noCountries: "Maita ei löytynyt.",
	selectedCountry: (vars) => `${String(vars?.dialCode)} ${String(vars?.country)}`
};
export { fiFI };

//# sourceMappingURL=fi-FI.js.map