// src/components/phone-number-field/intl/en-US.ts
/** Default localized copy for phoneNumberField.* keys. */
const enUS = {
	selectCountry: "Select country",
	searchCountries: "Search countries",
	noCountries: "No countries found.",
	selectedCountry: (vars) => `${String(vars?.dialCode)} ${String(vars?.country)}`
};
export { enUS };

//# sourceMappingURL=en-US.js.map