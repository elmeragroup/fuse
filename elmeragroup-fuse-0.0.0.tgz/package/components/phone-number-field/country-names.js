// src/components/phone-number-field/country-names.ts
const localeCountryNames = /* @__PURE__ */ new Map();
function resolveDisplayNames(locale) {
	try {
		return new Intl.DisplayNames([locale], { type: "region" });
	} catch {
		return new Intl.DisplayNames(["en-US"], { type: "region" });
	}
}
function localeEntry(locale) {
	const cached = localeCountryNames.get(locale);
	if (cached) return cached;
	const entry = {
		displayNames: resolveDisplayNames(locale),
		names: /* @__PURE__ */ new Map()
	};
	localeCountryNames.set(locale, entry);
	return entry;
}
/**
* Per-locale country display names, filled on first lookup and shared across
* PhoneNumberField instances. Creating the resolver does not construct
* `Intl.DisplayNames` or call `.of`.
*/
function countryNameResolver(locale) {
	return (countryCode) => {
		const entry = localeEntry(locale);
		const cached = entry.names.get(countryCode);
		if (cached !== void 0) return cached;
		const name = entry.displayNames.of(countryCode) ?? countryCode;
		entry.names.set(countryCode, name);
		return name;
	};
}
function resolveCollator(locale) {
	try {
		return new Intl.Collator([locale]);
	} catch {
		return new Intl.Collator(["en-US"]);
	}
}
/**
* A copy of `countries` in the alphabetical order of their display names in `locale`, by
* that locale's collation, so "Åland" follows "Sydafrika" in Swedish. Resolves every name,
* so the picker calls it only once it has opened.
*/
function sortByCountryName(countries, locale) {
	const nameOf = countryNameResolver(locale);
	const entry = localeEntry(locale);
	entry.collator ??= resolveCollator(locale);
	const { collator } = entry;
	return countries.map((country) => ({
		country,
		name: nameOf(country.code)
	})).sort((left, right) => collator.compare(left.name, right.name)).map(({ country }) => country);
}
/** Drops cached locale formatters so a later mount is a cold start. */
function resetCountryNameCache() {
	localeCountryNames.clear();
}
export { countryNameResolver, resetCountryNameCache, sortByCountryName };

//# sourceMappingURL=country-names.js.map