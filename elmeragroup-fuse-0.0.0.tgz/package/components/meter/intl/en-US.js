// src/components/meter/intl/en-US.ts
/** Default localized copy for `meter.warning` / `meter.success`. */
const enUS = {
	warning: "Warning",
	success: "Success"
};
export { enUS };

//# sourceMappingURL=en-US.js.map