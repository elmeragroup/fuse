// src/components/meter/intl/fi-FI.ts
/** Default localized copy for `meter.warning` / `meter.success`. */
const fiFI = {
	warning: "Varoitus",
	success: "Onnistui"
};
export { fiFI };

//# sourceMappingURL=fi-FI.js.map