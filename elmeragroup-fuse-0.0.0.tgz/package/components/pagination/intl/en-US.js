// src/components/pagination/intl/en-US.ts
/** Default localized copy for the `pagination.*` rows. */
const enUS = {
	landmark: "Pagination",
	previous: "Previous",
	next: "Next",
	goToPrevious: "Go to previous page",
	goToNext: "Go to next page",
	morePages: "More pages"
};
export { enUS };

//# sourceMappingURL=en-US.js.map