// src/components/pagination/intl/fi-FI.ts
/** Default localized copy for the `pagination.*` rows. */
const fiFI = {
	landmark: "Sivutus",
	previous: "Edellinen",
	next: "Seuraava",
	goToPrevious: "Siirry edelliselle sivulle",
	goToNext: "Siirry seuraavalle sivulle",
	morePages: "Lisää sivuja"
};
export { fiFI };

//# sourceMappingURL=fi-FI.js.map