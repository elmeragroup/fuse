"use client";
import { Button } from "../button/button.js";
import { isTextNode } from "../../internal/is-text-node.js";
import { confirmButtonVariants } from "./confirm-button-variants.js";
import { useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/confirm-button/confirm-button.tsx
/**
* Two-press confirm wrapper over the library Button.
* Client — owns armed state.
*
* Turning `disabled` or `isPending` on disarms it, so re-enabling never restores a stale armed state.
* Escape disarms without confirming; while armed the button consumes the key, so inside a Dialog,
* Sheet or Popover the first Escape disarms and a second one closes the overlay.
*/
function ConfirmButton({ onConfirm, armedChildren, armedAriaLabel, disabled, isPending, isVisuallyDisabled, variant, className, children, "aria-label": ariaLabel, onKeyDown, onBlur, ...rest }) {
	const [isArmedRaw, setIsArmedRaw] = useState(false);
	const inert = disabled === true || isPending === true || isVisuallyDisabled === true;
	if (inert && isArmedRaw) setIsArmedRaw(false);
	const isArmed = isArmedRaw && !inert;
	function handlePress() {
		if (inert) return;
		if (isArmed) {
			setIsArmedRaw(false);
			onConfirm();
		} else setIsArmedRaw(true);
	}
	const announcement = armedAriaLabel ?? (isTextNode(armedChildren) ? armedChildren : ariaLabel);
	const resolvedAriaLabel = isArmed ? announcement : ariaLabel;
	const visibleChildren = isArmed && armedChildren !== void 0 ? armedChildren : children;
	const buttonProps = {
		...rest,
		variant,
		disabled,
		isPending,
		isVisuallyDisabled,
		className: confirmButtonVariants({
			variant,
			className
		}),
		"aria-label": resolvedAriaLabel,
		onKeyDown: (event) => {
			if (event.key === "Escape" && isArmed) {
				event.preventDefault();
				event.stopPropagation();
				setIsArmedRaw(false);
			}
			onKeyDown?.(event);
		},
		onBlur: (event) => {
			if (isArmed) setIsArmedRaw(false);
			onBlur?.(event);
		},
		onClick: handlePress
	};
	return /* @__PURE__ */ jsxs(Button, {
		...buttonProps,
		"data-armed": isArmed ? "true" : void 0,
		children: [visibleChildren, isArmed && announcement ? /* @__PURE__ */ jsx("span", {
			className: "sr-only",
			"aria-live": "polite",
			children: announcement
		}) : null]
	});
}
ConfirmButton.displayName = "ConfirmButton";
export { ConfirmButton };

//# sourceMappingURL=confirm-button.js.map