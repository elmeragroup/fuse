import { tv } from "../../styles/tv.js";
// src/components/confirm-button/confirm-button-variants.ts
/**
* Module-private recipe. Empty keys exist so
* `VariantProps` aligns with Button's variant axis; only destructive/success
* add armed styling. No recipe default — undefined variant adds nothing.
*/
const confirmButtonVariants = tv({
	variants: { variant: {
		default: "",
		outline: "",
		secondary: "",
		ghost: "",
		link: "",
		destructive: "data-[armed=true]:bg-error data-[armed=true]:text-error-foreground",
		success: "data-[armed=true]:bg-success data-[armed=true]:text-success-foreground"
	} },
	defaultVariants: {}
});
export { confirmButtonVariants };

//# sourceMappingURL=confirm-button-variants.js.map