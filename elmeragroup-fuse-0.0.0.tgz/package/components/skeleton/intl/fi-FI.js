// src/components/skeleton/intl/fi-FI.ts
/** Default localized copy for the `skeleton-reveal.*` rows. */
const fiFI = { loading: "Ladataan" };
export { fiFI };

//# sourceMappingURL=fi-FI.js.map