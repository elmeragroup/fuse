// src/components/skeleton/intl/en-US.ts
/** Default localized copy for the `skeleton-reveal.*` rows. */
const enUS = { loading: "Loading" };
export { enUS };

//# sourceMappingURL=en-US.js.map