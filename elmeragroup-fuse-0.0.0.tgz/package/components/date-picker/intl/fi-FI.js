// src/components/date-picker/intl/fi-FI.ts
/** fi-FI copy for the date pickers; see `en-US.ts`. */
const fiFI = {
	calendar: "Kalenteri",
	presets: "Päivämäärän pikavalinnat",
	startDate: "Alkamispäivä",
	endDate: "Päättymispäivä",
	time: "Aika",
	startTime: "Alkamisaika",
	endTime: "Päättymisaika",
	rangeReversed: "Aloituspäivän on oltava ennen lopetuspäivää."
};
export { fiFI };

//# sourceMappingURL=fi-FI.js.map