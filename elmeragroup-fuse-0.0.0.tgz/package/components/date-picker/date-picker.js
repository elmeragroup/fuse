"use client";
import { cn } from "../../styles/cn.js";
import { definedProps } from "../../internal/defined-props.js";
import { createChangeEventDetails } from "../calendar/calendar-change-details.js";
import { useTemporalProp } from "../calendar/calendar-input.js";
import { CalendarRoot } from "../calendar/calendar.js";
import { valueError } from "../date-field/date-input-validation.js";
import { useValueKind } from "../date-field/use-value-kind.js";
import { useStableCallback } from "../../hooks/use-stable-callback.js";
import { datePickerVariants } from "./date-picker-variants.js";
import { presetDate } from "./picker-value.js";
import { EMPTY_END, clearEndTime, editEndTime, endAwaitsTime, endDay, endOfValue, endValue, pickEndDay, pickedEndValue } from "./picker-draft.js";
import { DefaultCalendarChildren, usePresetRegistry } from "./picker-shell.js";
import { PickerDateInput } from "./picker-input.js";
import { useCalendarViewKey, usePickerRoot, usePickerRootElement, usePickerRules, usePresetReader } from "./picker-root.js";
import { PickerTimeInput, usePickerTimeBinding } from "./picker-time-input.js";
import { usePickerSession } from "./use-picker-session.js";
import { createContext, use, useLayoutEffect, useMemo, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { useFieldRootContext } from "@base-ui/react/internals/field-root-context";
import { DEFAULT_VALIDITY_STATE } from "@base-ui/react/internals/field-constants";
import { useLabelableContext } from "@base-ui/react/internals/labelable-provider";
// src/components/date-picker/date-picker.tsx
const styles = datePickerVariants();
const DatePickerRootContext = createContext(void 0);
function useDatePickerRootContext(part) {
	const value = use(DatePickerRootContext);
	if (value === void 0) throw new Error(`${part} must be rendered inside DatePicker.Root.`);
	return value;
}
/** The Root its prop errors name. */
const OWNER = "DatePicker.Root";
/**
* A date picker: a segmented input and a calendar in a popup, over one value. It holds the value
* and the open state; its parts are `Group` (the field box), `Input` (a bound `DateInput.Root`),
* `Trigger`, `Popup`, `Calendar`, `TimeInput` (the value's time in the popup) and the preset pane
* (`Presets`, `PresetItem`).
*
* Inside a Base UI Field (`Field.Root`, or the `DatePickerField` composite) the input is the
* Field's control: `Field.Label` names the group, the segments, the trigger ("Calendar Start date")
* and the popup, a `Form` focuses the first segment for an error, and the ISO value submits under
* the Field's `name`. Values are Temporal values, as DateInput's: the picker reads
* `globalThis.Temporal`, so a host without native Temporal imports `@elmeragroup/fuse/temporal-polyfill`.
*
* Picking a day keeps the value's time and zone. Typing in the input never opens the popup, and
* opening it never commits a half-typed value.
*
* @template P - The props, inferred: only their `granularity` and `timeZone` count.
* @template T - The value's kind, inferred as `DateInput.Root`'s is.
* @throws TypeError naming the prop and the fix when `value`, `defaultValue`, `minValue` or
*   `maxValue` is a string rather than a Temporal object, or a time `granularity` meets a
*   PlainDate value: host defects.
*/
function DatePickerRoot(props) {
	const { value: valueProp, defaultValue, onValueChange, open: openProp, defaultOpen = false, onOpenChange, shouldCloseOnSelect = true, minValue, maxValue, isDateUnavailable, granularity, hourCycle, hideTimeZone = false, timeZone, firstDayOfWeek, visibleMonths = 1, pageBehavior = "visible", disabled: disabledProp = false, readOnly = false, required = false, invalid: invalidProp = false, name, form, size = "default", "aria-label": ariaLabel, onFocusLeave, className, render, children, ...elementProps } = props;
	const labelable = useLabelableContext();
	const field = useFieldRootContext();
	const controlled = valueProp !== void 0;
	const parsedValue = useTemporalProp(valueProp, OWNER, "value");
	const parsedDefault = useTemporalProp(defaultValue, OWNER, "defaultValue");
	const [own, setOwn] = useState(parsedDefault);
	const value = controlled ? parsedValue : own;
	const iso = value === null ? "" : value.toString();
	const [inputInvalid, setInputInvalid] = useState(false);
	const unavailable = isDateUnavailable;
	const [viewKey, markPicked] = useCalendarViewKey(iso);
	const rules = usePickerRules(OWNER, minValue, maxValue, unavailable);
	const resolvedKind = useValueKind({
		value,
		defaultValue: parsedDefault,
		granularity,
		timeZone
	}, OWNER);
	const { kind } = resolvedKind;
	const published = {
		value,
		onValueChange,
		controlled,
		shouldCloseOnSelect,
		parsedDefault
	};
	const latest = useRef(published);
	useLayoutEffect(() => {
		latest.current = published;
	});
	const presetPanes = usePresetRegistry();
	/** Report a new value and apply it unless canceled; returns whether it applied. */
	function commit(next, reason, event, trigger) {
		const state = latest.current;
		const details = createChangeEventDetails(reason, event, trigger, { getValidationError: () => next === null ? null : valueError(next, rules) });
		state.onValueChange?.(next, details);
		if (details.isCanceled) return false;
		if (!state.controlled) setOwn(next);
		latest.current = {
			...state,
			value: next
		};
		if (reason !== "preset-press") presetPanes.valueCommitted();
		return true;
	}
	const valueDraft = useMemo(() => endOfValue(value), [value]);
	const session = usePickerSession({
		open: openProp,
		defaultOpen,
		onOpenChange,
		basis: iso,
		finalize(held, origin) {
			const next = endValue(held, kind);
			if (next === null) return true;
			if (!commit(next, origin.reason, origin.event, origin.trigger)) return false;
			markPicked(next.toString());
			return true;
		},
		onReset() {
			if (!latest.current.controlled) setOwn(latest.current.parsedDefault);
			presetPanes.valueCommitted();
			field.setValidityData((data) => ({
				...data,
				state: DEFAULT_VALIDITY_STATE,
				error: "",
				errors: []
			}));
			field.setTouched(false);
			field.setDirty(false);
		}
	});
	const { held, generation, hold } = session;
	const draft = held?.value ?? valueDraft;
	const readPreset = usePresetReader(presetDate, kind, (preset, event, trigger) => commit(preset, "preset-press", event, trigger));
	const root = usePickerRoot({
		props: {
			granularity,
			hourCycle,
			hideTimeZone,
			timeZone,
			firstDayOfWeek,
			visibleMonths,
			pageBehavior,
			disabled: disabledProp,
			readOnly,
			required,
			form,
			size,
			ariaLabel,
			onFocusLeave
		},
		rules,
		kind: resolvedKind,
		session,
		labelledBy: labelable.labelId,
		describedBy: labelable.getDescriptionProps({})["aria-describedby"],
		invalid: invalidProp || inputInvalid,
		range: false,
		registerPresets: presetPanes.registerPresets,
		readPreset
	});
	/**
	* What a gesture edits: the value as it is now, or, while the picker is empty, what it holds. A
	* held draft belongs to the empty value, so a value committed earlier in the same gesture wins.
	*/
	function currentDraft() {
		const { value: now } = latest.current;
		return now === null ? held?.value ?? EMPTY_END : endOfValue(now);
	}
	const inputChange = useStableCallback((next, details) => {
		if (!commit(next, details.reason, details.event, details.trigger)) details.cancel();
	});
	const selectDay = useStableCallback((day, details) => {
		const state = latest.current;
		const next = pickEndDay(currentDraft(), day, kind);
		if (kind.kind !== "PlainDate" && endAwaitsTime(next) && !state.shouldCloseOnSelect) {
			hold(next, {
				reason: details.reason,
				event: details.event,
				trigger: details.trigger
			});
			return;
		}
		const value = pickedEndValue(next, kind);
		if (!commit(value, details.reason, details.event, details.trigger)) {
			details.cancel();
			return;
		}
		markPicked(value.toString());
		if (state.shouldCloseOnSelect) root.requestOpen(false, details.reason, details.event, details.trigger);
	});
	const timeChange = useStableCallback((time, details) => {
		const current = currentDraft();
		if (time === null) {
			const cleared = clearEndTime(current);
			if (cleared === void 0) details.cancel();
			else if (held !== null) hold(cleared, held.finalizeOnClose);
			return;
		}
		const next = editEndTime(current, time, kind);
		const value = endValue(next, kind);
		if (value === null) {
			hold(next, null);
			return;
		}
		if (!commit(value, details.reason, details.event, details.trigger)) {
			details.cancel();
			return;
		}
		markPicked(value.toString());
	});
	const { inputSettings, calendarSettings, timeSettings } = root;
	const timeBinding = usePickerTimeBinding(draft, kind, timeChange);
	const context = useMemo(() => ({
		value,
		calendarDay: endDay(draft),
		calendarKey: `${generation}:${viewKey}`,
		inputKey: generation,
		inputSettings,
		calendarSettings,
		timeSettings,
		timeBinding,
		invalid: invalidProp,
		name,
		ariaLabel,
		inputChange,
		selectDay,
		reportInputInvalid: setInputInvalid
	}), [
		value,
		draft,
		generation,
		viewKey,
		inputSettings,
		calendarSettings,
		timeSettings,
		timeBinding,
		invalidProp,
		name,
		ariaLabel,
		inputChange,
		selectDay
	]);
	const element = usePickerRootElement({
		root,
		slot: "date-picker",
		className,
		classes: styles.root(),
		render,
		elementProps,
		children,
		resetRef: session.resetRef
	});
	return /* @__PURE__ */ jsx(DatePickerRootContext, {
		value: context,
		children: element
	});
}
/**
* The picker's segments: a `DateInput.Root` bound to the picker's value, inside the group. The
* group is the field box and the named `group`, so the input itself is presentational and paints
* no box. Typing reports through `onValueChange` with the input's reasons.
*/
function DatePickerInput(props) {
	const root = useDatePickerRootContext("DatePicker.Input");
	return /* @__PURE__ */ jsx(PickerDateInput, {
		...definedProps(props),
		onInvalidChange: root.reportInputInvalid,
		value: root.value,
		onValueChange: root.inputChange,
		...root.inputSettings,
		...definedProps({
			name: root.name,
			"aria-label": props["aria-label"] ?? root.ariaLabel
		}),
		invalid: root.invalid
	}, root.inputKey);
}
/**
* The picker's calendar, a `Calendar.Root` on the picker's day: the value's own wall-clock day,
* which picking a day replaces while keeping the time. A picked day reports `"day-press"` or
* `"keyboard"` and closes the popup unless `shouldCloseOnSelect` is off. Its view follows a value
* set from elsewhere, such as a preset. Without children it renders the month buttons, the visible
* months' heading and the months; with them, compose `Calendar`'s parts.
*/
function DatePickerCalendar({ className, children, ...props }) {
	const root = useDatePickerRootContext("DatePicker.Calendar");
	return /* @__PURE__ */ jsx(CalendarRoot, {
		...definedProps(props),
		value: root.calendarDay,
		onValueChange: root.selectDay,
		...root.calendarSettings,
		className: cn(styles.calendar(), className),
		children: children ?? /* @__PURE__ */ jsx(DefaultCalendarChildren, {})
	}, root.calendarKey);
}
/**
* DatePickerField's popup column: the calendar, and the time input under it while the picker's
* values have a time. A date-only picker's popup holds the calendar alone, with no column around it.
* Private to the composite: a composition places `DatePicker.TimeInput` itself.
*/
function DatePickerFieldCalendar({ shouldForceLeadingZeros }) {
	if (useDatePickerRootContext("DatePickerField").timeSettings === null) return /* @__PURE__ */ jsx(DatePickerCalendar, {});
	return /* @__PURE__ */ jsxs("div", {
		className: styles.timeColumn(),
		children: [/* @__PURE__ */ jsx(DatePickerCalendar, {}), /* @__PURE__ */ jsx(DatePickerTimeInput, { shouldForceLeadingZeros })]
	});
}
/**
* The time of the picker's value, edited in the popup under the calendar, as React Spectrum's
* picker edits it: a `DateInput.Root` showing only the hour onwards, named "Time". It renders
* nothing while the picker's values have no time (a PlainDate, or `granularity="day"`). A time
* typed in a picker with a value changes that value's time; in an empty picker it waits for a day,
* and a day picked then (with `shouldCloseOnSelect={false}`, or before it) commits at that time
* rather than at midnight. A time waiting for a day is a wall-clock time: it takes the picker's
* zone and kind as they are when the day comes, so a `timeZone` changed meanwhile applies. Typing
* reports through the Root's `onValueChange` with the input's reasons. It is a Field of its own: it
* submits nothing, and a half-typed time marks only itself.
*/
function DatePickerTimeInput(props) {
	const root = useDatePickerRootContext("DatePicker.TimeInput");
	return /* @__PURE__ */ jsx(PickerTimeInput, {
		...props,
		binding: root.timeBinding,
		settings: root.timeSettings,
		label: "time",
		resetKey: root.inputKey
	});
}
export { DatePickerCalendar, DatePickerFieldCalendar, DatePickerInput, DatePickerRoot, DatePickerTimeInput };

//# sourceMappingURL=date-picker.js.map