import { definedProps } from "../../internal/defined-props.js";
import { FieldFrame } from "../field/field-frame.js";
import { DatePickerGroup, DatePickerPopup, DatePickerTrigger, PickerPopupPane } from "./picker-shell.js";
import { DatePickerFieldCalendar, DatePickerInput, DatePickerRoot } from "./date-picker.js";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/date-picker/date-picker-field.tsx
/**
* Labeled date picker composite over Field and `DatePicker`'s parts, with the interim React Aria
* DatePicker's prop names: a label, the field box with the segments and the calendar trigger, the
* error, the description, and the calendar popup with an optional preset pane. Values are Temporal
* values, which a client component builds. The composite itself holds no state, so a server
* component can render it without a value.
*
* @template P - The props, inferred: only their `granularity` and `timeZone` count.
* @template T - The value's kind, inferred as `DateInput.Root`'s is.
*/
function DatePickerField({ label, description, errorMessage, onChange, presetGroup, triggerPlacement = "end", shouldForceLeadingZeros = true, isOpen, onBlur, name, isDisabled = false, isReadOnly = false, isRequired = false, isInvalid = false, size = "default", container, className, ...props }) {
	const trigger = /* @__PURE__ */ jsx(DatePickerTrigger, {});
	return /* @__PURE__ */ jsx(FieldFrame, {
		className,
		name,
		invalid: isInvalid,
		disabled: isDisabled,
		label,
		description,
		errorMessage,
		isErrorMessageAlwaysShown: isInvalid,
		children: /* @__PURE__ */ jsxs(DatePickerRoot, {
			...definedProps({
				...props,
				onValueChange: onChange,
				open: isOpen,
				onFocusLeave: onBlur
			}),
			readOnly: isReadOnly,
			disabled: isDisabled,
			required: isRequired,
			invalid: isInvalid,
			size,
			children: [/* @__PURE__ */ jsxs(DatePickerGroup, { children: [
				triggerPlacement === "start" ? trigger : null,
				/* @__PURE__ */ jsx(DatePickerInput, { shouldForceLeadingZeros }),
				triggerPlacement === "end" ? trigger : null
			] }), /* @__PURE__ */ jsx(DatePickerPopup, {
				...definedProps({ container }),
				children: /* @__PURE__ */ jsx(PickerPopupPane, {
					presets: presetGroup,
					children: /* @__PURE__ */ jsx(DatePickerFieldCalendar, { shouldForceLeadingZeros })
				})
			})]
		})
	});
}
DatePickerField.displayName = "DatePickerField";
export { DatePickerField };

//# sourceMappingURL=date-picker-field.js.map