"use client";
import { cn } from "../../styles/cn.js";
import { useMergedRefs } from "../../hooks/use-merged-refs.js";
import { definedProps } from "../../internal/defined-props.js";
import { numberFormat } from "../../internal/intl-cache.js";
import { Input } from "../input/input.js";
import { InputGroupAddon, InputGroupInput, InputGroupRoot } from "../input-group/input-group.js";
import { FieldLabel, FieldRoot } from "../field/field.js";
import { useMediaQuery } from "../../hooks/use-media-query.js";
import { ComboboxCollection, ComboboxEmpty, ComboboxGroup, ComboboxInput, ComboboxItem, ComboboxList, ComboboxRoot, ComboboxSeparator } from "../combobox/combobox.js";
import { MagnifyingGlass } from "../../icons/generated/magnifying-glass.js";
import { isBackspaceOnEmpty } from "../../internal/is-backspace-on-empty.js";
import { Kbd } from "../kbd/kbd.js";
import { ToggleGroupItem, ToggleGroupRoot } from "../toggle-group/toggle-group.js";
import { ValueListContext, useFilterInternals, useFocusRequest } from "./data-table-filter-context.js";
import { NumberField } from "../number-field/number-field.js";
import { Slider } from "../slider/slider.js";
import { useKindEditor } from "./data-table-filter-editor-context.js";
import { dataTableFilterSlots } from "./data-table-filter-variants.js";
import { DEFAULT_DATE_PRESETS, datePresetRange, isOneDayPreset } from "./date-presets.js";
import { allowedOperators, isFiniteNumber, isIsoDate, isOperatorOf, targetOf } from "./filter-model.js";
import { LIST_KINDS, listSource, matchOptions, pickedValues, snapshotOrder } from "./option-list.js";
import { completeValues, draftSays, stepBounds } from "./editor-draft.js";
import { calendarDateIn } from "./filter-match.js";
import { useContains } from "./use-contains.js";
import { useEffect, useId, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/data-table-filter/data-table-filter-editors.tsx
/**
* How many rows hold an option, beside its label in a list. Hidden from assistive technology, so
* the option's name stays "Paid".
*/
function OptionCount({ count }) {
	const { meta } = useFilterInternals("DataTableFilter.OptionCount");
	return /* @__PURE__ */ jsx("span", {
		"aria-hidden": true,
		"data-slot": "data-table-filter-count",
		className: dataTableFilterSlots.count(),
		children: numberFormat(meta.locale).format(count)
	});
}
/**
* Edits an option, multi-option or boolean filter. Renders nothing for other kinds. Its children
* render below its list, outside the scrolling rows, such as a `DataTableFilter.ValuesFooter`.
*/
function DataTableFilterOptionEditor(props) {
	const editor = useKindEditor("DataTableFilter.OptionEditor", LIST_KINDS);
	return editor === null ? null : /* @__PURE__ */ jsx(OptionEditorBody, {
		editor,
		...props
	});
}
function OptionEditorBody({ editor, className, children, ...props }) {
	const { actions, meta } = useFilterInternals("DataTableFilter.OptionEditor");
	const { field, fieldId, filter } = editor;
	const counts = meta.facets.counts(fieldId);
	const picked = pickedValues(field, filter);
	const source = listSource(field, {
		yes: meta.format("yes"),
		no: meta.format("no")
	});
	const [order] = useState(() => snapshotOrder(source, picked, counts));
	const [query, setQuery] = useState("");
	const contains = useContains(meta.locale);
	const matches = matchOptions(order, query, contains, 50);
	const inputRef = useFocusRequest(editor.focusKey);
	const groups = [...order.pinned.length > 0 ? [{
		value: "pinned",
		items: order.pinned
	}] : [], {
		value: "rest",
		items: order.rest
	}];
	const shown = [...matches.pinned.length > 0 ? [{
		value: "pinned",
		items: matches.pinned
	}] : [], ...matches.rest.length > 0 ? [{
		value: "rest",
		items: matches.rest
	}] : []];
	const pickedSet = new Set(picked);
	const selected = source.options.filter((option) => pickedSet.has(option.value));
	const searchLabel = meta.format("searchValues", { field: field.label });
	return /* @__PURE__ */ jsxs("div", {
		"data-slot": "data-table-filter-option-editor",
		className: cn(dataTableFilterSlots.optionEditor(), className),
		...props,
		children: [
			/* @__PURE__ */ jsxs(ComboboxRoot, {
				inline: true,
				open: true,
				multiple: true,
				autoHighlight: true,
				items: groups,
				filteredItems: shown,
				value: selected,
				inputValue: query,
				onInputValueChange: (next, details) => {
					if (details.isItemPress !== true) setQuery(next);
				},
				isItemEqualToValue: (item, value) => item.value === value.value,
				itemToStringLabel: (option) => option.label,
				itemToStringValue: (option) => option.value,
				onValueChange: (next) => {
					const after = new Set(next.map((option) => option.value));
					const changed = next.find((option) => !pickedSet.has(option.value)) ?? selected.find((option) => !after.has(option.value));
					if (changed !== void 0) actions.toggle(fieldId, changed.value);
				},
				children: [
					/* @__PURE__ */ jsx("div", {
						className: cn(dataTableFilterSlots.search(), dataTableFilterSlots.editorSearch()),
						children: /* @__PURE__ */ jsx(ComboboxInput, {
							ref: inputRef,
							showTrigger: false,
							"aria-label": searchLabel,
							placeholder: searchLabel,
							"data-dtf-initial-focus": "",
							children: /* @__PURE__ */ jsx(InputGroupAddon, {
								align: "inline-start",
								children: /* @__PURE__ */ jsx(MagnifyingGlass, { "aria-hidden": true })
							})
						})
					}),
					/* @__PURE__ */ jsx(ComboboxEmpty, {
						className: dataTableFilterSlots.editorEmpty(),
						children: meta.format("noValues")
					}),
					/* @__PURE__ */ jsx(ComboboxList, { children: (group) => /* @__PURE__ */ jsxs(ComboboxGroup, {
						items: group.items,
						"data-group": group.value,
						children: [/* @__PURE__ */ jsx(ComboboxCollection, { children: (option) => {
							const count = counts === void 0 ? void 0 : counts.get(option.value) ?? 0;
							return /* @__PURE__ */ jsxs(ComboboxItem, {
								value: option,
								"data-value": option.value,
								"data-pinned": group.value === "pinned" || void 0,
								"data-zero": count === 0 || void 0,
								className: dataTableFilterSlots.editorOption(),
								children: [
									option.icon === void 0 ? null : /* @__PURE__ */ jsx("span", {
										"aria-hidden": true,
										className: "contents",
										children: option.icon
									}),
									/* @__PURE__ */ jsx("span", {
										className: "min-w-0 truncate",
										children: option.label
									}),
									count === void 0 ? null : /* @__PURE__ */ jsx(OptionCount, { count })
								]
							}, option.value);
						} }), group.value === "pinned" && matches.rest.length > 0 ? /* @__PURE__ */ jsx(ComboboxSeparator, {}) : null]
					}, group.value) })
				]
			}),
			/* @__PURE__ */ jsx("p", {
				role: "status",
				"data-slot": "data-table-filter-narrow",
				className: dataTableFilterSlots.editorNarrowHint(),
				children: matches.more ? meta.format("narrowHint") : null
			}),
			/* @__PURE__ */ jsx(ValueListContext, {
				value: {
					fieldId,
					field,
					order,
					query,
					contains
				},
				children
			})
		]
	});
}
/** How long the text editor waits after the last keystroke before it applies. */
const TEXT_PAUSE_MS = 300;
/** Edits a text filter. Renders nothing for other kinds. */
function DataTableFilterTextEditor(props) {
	const editor = useKindEditor("DataTableFilter.TextEditor", ["text"]);
	return editor === null ? null : /* @__PURE__ */ jsx(TextEditorBody, {
		editor,
		...props
	});
}
function TextEditorBody({ editor, className, ...props }) {
	const { actions, meta } = useFilterInternals("DataTableFilter.TextEditor");
	const { draft, settle, isComposing } = editor;
	const applied = editor.filter?.kind === "text" ? editor.filter.values[0] : "";
	const text = String(draft.values[0] ?? "");
	const inputRef = useFocusRequest(editor.focusKey);
	const hintId = useId();
	const [composing, setComposing] = useState(false);
	useEffect(() => {
		if (composing || text.trim() === applied) return;
		const timer = setTimeout(settle, TEXT_PAUSE_MS);
		return () => {
			clearTimeout(timer);
		};
	}, [
		composing,
		text,
		applied,
		settle
	]);
	return /* @__PURE__ */ jsxs("div", {
		"data-slot": "data-table-filter-text",
		"data-dirty": text.trim() !== applied || void 0,
		className: cn(dataTableFilterSlots.body(), className),
		...props,
		children: [/* @__PURE__ */ jsx(InputGroupRoot, { children: /* @__PURE__ */ jsx(InputGroupInput, {
			ref: inputRef,
			value: text,
			"aria-label": editor.field.label,
			"aria-describedby": hintId,
			placeholder: editor.field.placeholder ?? meta.format("textPlaceholder"),
			"data-dtf-initial-focus": "",
			onChange: (event) => {
				editor.setDraft({
					operator: draft.operator,
					values: [event.currentTarget.value]
				});
			},
			onCompositionStart: () => {
				setComposing(true);
			},
			onCompositionEnd: () => {
				setComposing(false);
			},
			onKeyDown: (event) => {
				if (isComposing(event)) return;
				if (event.key === "Enter") {
					event.preventDefault();
					settle();
					actions.close();
				} else if (event.key === "Escape") settle();
				else if (editor.back !== void 0 && !event.repeat && isBackspaceOnEmpty(event)) {
					event.preventDefault();
					editor.back();
				}
			}
		}) }), /* @__PURE__ */ jsxs("p", {
			id: hintId,
			className: dataTableFilterSlots.hint(),
			children: [/* @__PURE__ */ jsx(Kbd, { children: "↵" }), meta.format("closeHint")]
		})]
	});
}
/** Edits a number filter. Renders nothing for other kinds. */
function DataTableFilterNumberEditor(props) {
	const editor = useKindEditor("DataTableFilter.NumberEditor", ["number"]);
	return editor === null ? null : /* @__PURE__ */ jsx(NumberEditorBody, {
		editor,
		...props
	});
}
/** One number per position the operator takes, with NaN for a position not yet set. */
function numberPositions(values, count) {
	return Array.from({ length: count }, (_, index) => {
		const value = values[index];
		return isFiniteNumber(value) ? value : NaN;
	});
}
function NumberEditorBody({ editor, className, ...props }) {
	const { actions, meta } = useFilterInternals("DataTableFilter.NumberEditor");
	const { field, fieldId, draft, settle } = editor;
	const step = field.step ?? 1;
	const range = meta.facets.range(fieldId);
	const bounds = range === void 0 ? void 0 : stepBounds(range, step);
	const target = targetOf("number", draft.operator);
	const count = target === "range" ? 2 : 1;
	const [low, high] = numberPositions(draft.values, count);
	const invalid = target === "range" && low !== void 0 && high !== void 0 && low > high;
	const firstRef = useFocusRequest(editor.focusKey);
	const [lastEdited, setLastEdited] = useState(1);
	/** The latest draft with one position set. */
	const withAt = (index, value) => (current) => {
		const next = numberPositions(current.values, targetOf("number", current.operator) === "range" ? 2 : 1);
		next[index] = value;
		return {
			operator: current.operator,
			values: next
		};
	};
	/** A person's change to one position. */
	const setAt = (index, value) => {
		setLastEdited(index);
		editor.updateDraft(withAt(index, value));
	};
	/** A control's commit of one position, which settles it within the current session. */
	const commitAt = (index, value) => {
		editor.commitDraft(withAt(index, value));
	};
	const names = target === "range" ? [meta.format("minimum"), meta.format("maximum")] : [field.label];
	return /* @__PURE__ */ jsxs("div", {
		"data-slot": "data-table-filter-number",
		"data-invalid": invalid || void 0,
		className: cn(dataTableFilterSlots.body(), className),
		...props,
		children: [bounds === void 0 ? null : target === "range" ? /* @__PURE__ */ jsx(Slider, {
			"aria-label": field.label,
			thumbLabels: names,
			minValue: bounds[0],
			maxValue: bounds[1],
			step,
			largeStep: step * 10,
			...definedProps({ formatOptions: field.format }),
			value: [Number.isNaN(low) ? bounds[0] : low ?? bounds[0], Number.isNaN(high) ? bounds[1] : high ?? bounds[1]],
			onChange: (next) => {
				editor.setDraft({
					operator: draft.operator,
					values: [next[0], next[1]]
				});
			},
			onValueCommitted: (next) => {
				editor.commitDraft((current) => ({
					operator: current.operator,
					values: [next[0], next[1]]
				}));
			}
		}) : /* @__PURE__ */ jsx(Slider, {
			"aria-label": field.label,
			minValue: bounds[0],
			maxValue: bounds[1],
			step,
			largeStep: step * 10,
			...definedProps({ formatOptions: field.format }),
			value: low === void 0 || Number.isNaN(low) ? bounds[0] : low,
			onChange: (next) => {
				setAt(0, next);
			},
			onValueCommitted: (next) => {
				commitAt(0, next);
			}
		}), /* @__PURE__ */ jsx("div", {
			ref: firstRef,
			role: "group",
			"aria-label": field.label,
			"data-dtf-initial-focus": "",
			className: dataTableFilterSlots.numberStack(),
			onKeyDown: (event) => {
				if (event.key === "Enter" && !editor.isComposing(event)) {
					event.preventDefault();
					settle();
					actions.close();
				}
			},
			children: names.map((name, index) => /* @__PURE__ */ jsx(NumberField, {
				label: name,
				value: [low, high][index] ?? NaN,
				onChange: (next) => {
					setAt(index, next);
				},
				onValueCommitted: (next) => {
					commitAt(index, next);
				},
				step,
				...definedProps({ formatOptions: field.format }),
				isInvalid: invalid && index === lastEdited,
				errorMessage: invalid && index === lastEdited ? meta.format("invalidRange") : void 0
			}, name))
		})]
	});
}
/**
* The filter a preset writes, in an operator the field allows: `isBetween` over its range, or `is`
* on its day for a one-day preset when the field allows no range. A preset the field cannot
* express writes nothing, and the editor leaves it out.
*/
function presetWrite(key, range, allowed) {
	if (allowed.includes("isBetween")) return {
		operator: "isBetween",
		values: range
	};
	if (isOneDayPreset(key) && allowed.includes("is")) return {
		operator: "is",
		values: [range[0]]
	};
}
/**
* The viewports wide enough for the presets beside a slot, Tailwind's `sm`. It is a viewport query
* because the popup sizes to this layout, so a query on the popup would be circular. It drives the
* layout and the presets' arrow-key axis together, so the two never disagree.
*/
const PRESETS_BESIDE_QUERY = "(min-width: 40rem)";
/**
* Edits a date filter with presets and date inputs. Renders nothing for other kinds. The presets
* are the field's `presets`, and each writes `isBetween` over its range. On a field whose operators
* leave out `isBetween`, the one-day presets, Today and Yesterday, write `is` if the field allows
* it, and the editor leaves the other presets out. Beside a function child they form a column,
* from a 40rem viewport up.
*/
function DataTableFilterDateEditor(props) {
	const editor = useKindEditor("DataTableFilter.DateEditor", ["date"]);
	return editor === null ? null : /* @__PURE__ */ jsx(DateEditorBody, {
		editor,
		...props
	});
}
/** The date in a draft position, or an empty string while it is not set. */
function dateAt(values, index) {
	const value = values[index];
	return isIsoDate(value) ? value : String(value ?? "");
}
function DateEditorBody({ editor, className, children, ref, ...props }) {
	const { actions, meta } = useFilterInternals("DataTableFilter.DateEditor");
	const { field, filter, draft } = editor;
	const [openedAt] = useState(() => /* @__PURE__ */ new Date());
	const today = calendarDateIn(openedAt, meta.timeZone);
	const target = targetOf("date", draft.operator) === "range" ? "range" : "single";
	const allowed = allowedOperators(field);
	const presets = [...new Set(field.presets ?? DEFAULT_DATE_PRESETS)].flatMap((key) => {
		const write = presetWrite(key, datePresetRange(key, today, meta.locale), allowed);
		return write === void 0 ? [] : [{
			key,
			write
		}];
	});
	const pressed = presets.find(({ write }) => draftSays("date", write, filter))?.key;
	const focusRef = useFocusRequest(editor.focusKey);
	const bodyRef = useMergedRefs(ref, focusRef);
	const operator = isOperatorOf("date", draft.operator) ? draft.operator : "isBetween";
	const wide = useMediaQuery(PRESETS_BESIDE_QUERY);
	let layout;
	if (presets.length > 0) layout = children !== void 0 && wide ? "beside" : "above";
	const beside = layout === "beside";
	const complete = completeValues("date", draft);
	const state = {
		field,
		operator,
		target,
		values: complete === void 0 ? [] : complete.filter(isIsoDate),
		onValueChange: (next) => {
			editor.setDraft({
				operator: draft.operator,
				values: next
			});
			if (completeValues("date", {
				operator: draft.operator,
				values: next
			}) !== void 0) {
				editor.settle();
				if (target === "single") actions.close();
			}
		}
	};
	return /* @__PURE__ */ jsxs("div", {
		ref: bodyRef,
		"data-slot": "data-table-filter-date",
		"data-target": target,
		...definedProps({ "data-presets": layout }),
		className: cn(beside ? dataTableFilterSlots.dateBeside() : dataTableFilterSlots.body(), className),
		...props,
		children: [presets.length === 0 ? null : /* @__PURE__ */ jsx(ToggleGroupRoot, {
			variant: beside ? "default" : "outline",
			size: "sm",
			orientation: beside ? "vertical" : "horizontal",
			"aria-label": meta.format("datePresets"),
			value: pressed === void 0 ? [] : [pressed],
			className: beside ? dataTableFilterSlots.presetsBeside() : dataTableFilterSlots.presets(),
			onValueChange: (next) => {
				const key = next[0] ?? pressed;
				const preset = presets.find((item) => item.key === key);
				if (preset !== void 0) {
					editor.setDraft({
						operator: preset.write.operator,
						values: preset.write.values
					});
					editor.settle();
					actions.close();
				}
			},
			children: presets.map((preset) => /* @__PURE__ */ jsx(ToggleGroupItem, {
				value: preset.key,
				...definedProps({
					className: beside ? dataTableFilterSlots.presetBeside() : void 0,
					"data-dtf-initial-focus": preset.key === (pressed ?? presets[0]?.key) ? "" : void 0
				}),
				children: meta.format(preset.key)
			}, preset.key))
		}), children === void 0 ? /* @__PURE__ */ jsx(DateInputs, {
			editor,
			target
		}) : /* @__PURE__ */ jsx("div", {
			className: beside ? dataTableFilterSlots.dateSlotBeside() : dataTableFilterSlots.dateSlot(),
			children: children(state)
		})]
	});
}
/**
* The default body: one or two native date inputs over the editor's one draft, From and To each in
* its own position. Typing changes the draft, and a blur settles it, which writes only once every
* date is set, so an incomplete range survives between blurs. Each input is a Fuse Field, so Field
* wires its label.
*/
function DateInputs({ editor, target }) {
	const { meta } = useFilterInternals("DataTableFilter.DateEditor");
	const names = target === "range" ? [meta.format("from"), meta.format("to")] : [editor.field.label];
	return /* @__PURE__ */ jsx("div", {
		className: target === "range" ? dataTableFilterSlots.dateFields() : void 0,
		children: names.map((name, index) => /* @__PURE__ */ jsxs(FieldRoot, {
			className: dataTableFilterSlots.dateField(),
			children: [/* @__PURE__ */ jsx(FieldLabel, { children: name }), /* @__PURE__ */ jsx(Input, {
				type: "date",
				value: dateAt(editor.draft.values, index),
				onChange: (event) => {
					const { value } = event.currentTarget;
					editor.updateDraft((current) => ({
						operator: current.operator,
						values: names.map((_, at) => at === index ? value : dateAt(current.values, at))
					}));
				},
				onBlur: editor.settle
			})]
		}, name))
	});
}
DataTableFilterOptionEditor.displayName = "DataTableFilter.OptionEditor";
DataTableFilterTextEditor.displayName = "DataTableFilter.TextEditor";
DataTableFilterNumberEditor.displayName = "DataTableFilter.NumberEditor";
DataTableFilterDateEditor.displayName = "DataTableFilter.DateEditor";
export { DataTableFilterDateEditor, DataTableFilterNumberEditor, DataTableFilterOptionEditor, DataTableFilterTextEditor, OptionCount };

//# sourceMappingURL=data-table-filter-editors.js.map