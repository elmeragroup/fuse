// src/components/data-table-filter/filter-model.ts
/**
* The operator graph: each operator's target, its negation, whether it is negated and, for option
* kinds, its sibling when the value count crosses one. An `optIn` operator is offered only to a
* field that lists it. Key order is menu order. `satisfies` makes a missing operator, a sibling
* from another kind or an unknown target a type error.
*/
const OPERATORS = {
	option: {
		is: {
			target: "single",
			plural: "isAnyOf",
			negation: "isNot",
			negated: false
		},
		isNot: {
			target: "single",
			plural: "isNoneOf",
			negation: "is",
			negated: true
		},
		isAnyOf: {
			target: "multiple",
			singular: "is",
			negation: "isNoneOf",
			negated: false
		},
		isNoneOf: {
			target: "multiple",
			singular: "isNot",
			negation: "isAnyOf",
			negated: true
		}
	},
	multiOption: {
		includes: {
			target: "single",
			plural: "includesAnyOf",
			negation: "excludes",
			negated: false
		},
		excludes: {
			target: "single",
			plural: "excludesAnyOf",
			negation: "includes",
			negated: true
		},
		includesAnyOf: {
			target: "multiple",
			singular: "includes",
			negation: "excludesAnyOf",
			negated: false
		},
		includesAllOf: {
			target: "multiple",
			singular: "includes",
			negation: "excludesAllOf",
			negated: false
		},
		excludesAnyOf: {
			target: "multiple",
			singular: "excludes",
			negation: "includesAnyOf",
			negated: true
		},
		excludesAllOf: {
			target: "multiple",
			singular: "excludes",
			negation: "includesAllOf",
			negated: true
		}
	},
	text: {
		contains: {
			target: "single",
			negation: "doesNotContain",
			negated: false
		},
		doesNotContain: {
			target: "single",
			negation: "contains",
			negated: true
		},
		startsWith: {
			target: "single",
			negation: "doesNotStartWith",
			negated: false,
			optIn: true
		},
		doesNotStartWith: {
			target: "single",
			negation: "startsWith",
			negated: true,
			optIn: true
		}
	},
	number: {
		is: {
			target: "single",
			negation: "isNot",
			negated: false
		},
		isNot: {
			target: "single",
			negation: "is",
			negated: true
		},
		isGreaterThan: {
			target: "single",
			negation: "isLessThanOrEqual",
			negated: false
		},
		isGreaterThanOrEqual: {
			target: "single",
			negation: "isLessThan",
			negated: false
		},
		isLessThan: {
			target: "single",
			negation: "isGreaterThanOrEqual",
			negated: false
		},
		isLessThanOrEqual: {
			target: "single",
			negation: "isGreaterThan",
			negated: false
		},
		isBetween: {
			target: "range",
			negation: "isNotBetween",
			negated: false
		},
		isNotBetween: {
			target: "range",
			negation: "isBetween",
			negated: true
		}
	},
	date: {
		is: {
			target: "single",
			negation: "isNot",
			negated: false
		},
		isNot: {
			target: "single",
			negation: "is",
			negated: true
		},
		isBefore: {
			target: "single",
			negation: "isOnOrAfter",
			negated: false
		},
		isOnOrAfter: {
			target: "single",
			negation: "isBefore",
			negated: false
		},
		isAfter: {
			target: "single",
			negation: "isOnOrBefore",
			negated: false
		},
		isOnOrBefore: {
			target: "single",
			negation: "isAfter",
			negated: false
		},
		isBetween: {
			target: "range",
			negation: "isNotBetween",
			negated: false
		},
		isNotBetween: {
			target: "range",
			negation: "isBetween",
			negated: true
		}
	},
	boolean: {
		is: {
			target: "single",
			negation: "isNot",
			negated: false
		},
		isNot: {
			target: "single",
			negation: "is",
			negated: true,
			optIn: true
		}
	}
};
/** The same table read by a runtime string. Widening is safe, because every spec is a subtype. */
const OPERATOR_SPECS = OPERATORS;
/**
* Whether an untyped value is a non-null object. Unlike `instanceof Object`, it holds for an
* object from another realm, such as an iframe.
*
* @param value - The value to check.
* @returns Whether it is an object.
*/
function isObject(value) {
	return typeof value === "object" && value !== null;
}
/**
* Whether an untyped value is a string.
*
* @param value - The value to check.
* @returns Whether it is a string.
*/
function isString(value) {
	return typeof value === "string";
}
/**
* Whether an untyped value is a finite number.
*
* @param value - The value to check.
* @returns Whether it is a finite number.
*/
function isFiniteNumber(value) {
	return typeof value === "number" && Number.isFinite(value);
}
/**
* Whether an untyped value is a boolean.
*
* @param value - The value to check.
* @returns Whether it is `true` or `false`.
*/
function isBoolean(value) {
	return typeof value === "boolean";
}
/**
* Whether a value names one of the six kinds.
*
* @param kind - The value to check.
* @returns Whether it is a filter kind.
*/
function isFilterKind(kind) {
	return isString(kind) && Object.hasOwn(OPERATOR_SPECS, kind);
}
/**
* Every operator of a kind, in menu order.
*
* @template K - The filter kind.
* @param kind - The kind whose operators to list.
* @returns The kind's operators.
*/
function operatorsFor(kind) {
	return Object.keys(OPERATORS[kind]);
}
/**
* The operators a field of a kind gets when it lists none: every operator but the opt-in ones, in
* menu order.
*
* @param kind - The kind.
* @returns The kind's default operators.
*/
function defaultOperatorsFor(kind) {
	return operatorsFor(kind).filter((operator) => OPERATOR_SPECS[kind][operator]?.optIn !== true);
}
/**
* Whether a value is one of a kind's operators.
*
* @template K - The filter kind.
* @param kind - The kind.
* @param operator - The value to check.
* @returns Whether it is an operator of `kind`.
*/
function isOperatorOf(kind, operator) {
	return isString(operator) && Object.hasOwn(OPERATOR_SPECS[kind], operator);
}
/**
* The number of values an operator takes.
*
* @param kind - The operator's kind.
* @param operator - The operator.
* @returns `single`, `multiple` or `range`.
*/
function targetOf(kind, operator) {
	return OPERATOR_SPECS[kind][operator]?.target ?? "single";
}
/**
* Whether an operator inverts its match, so a missing cell passes it.
*
* @param kind - The operator's kind.
* @param operator - The operator.
* @returns Whether the operator is negated.
*/
function isNegated(kind, operator) {
	return OPERATOR_SPECS[kind][operator]?.negated ?? false;
}
/**
* The values a field offers as options.
*
* @param field - The field.
* @returns Its option values, empty for a field without options.
*/
function optionValues(field) {
	return new Set((field.options ?? []).map((option) => option.value));
}
/**
* Whether a field admits a filter value: the kinds match, the field allows the operator, an
* option value is one of the field's options, and a toggle's value is `true`. The parse and every
* reducer read this one rule, so a value an action writes is one the Root shows as a chip.
*
* @param field - The field.
* @param value - The filter value.
* @returns Whether the field admits it.
*/
function fieldAdmits(field, value) {
	if (value.kind !== field.kind || !allowedOperators(field).includes(value.operator)) return false;
	if (value.kind === "boolean") return field.toggle !== true || value.values[0];
	if (value.kind !== "option" && value.kind !== "multiOption") return true;
	const known = optionValues(field);
	return value.values.every((item) => known.has(item));
}
/**
* Whether a boolean toggle is on: the field is a toggle, and it admits its filter, which is then
* `is` `true`. A toggle's filter from before the config changed, such as `is` `false`, is not on,
* so its chip still states it in full.
*
* @param field - The field.
* @param value - The field's filter, if any.
* @returns Whether the toggle is on.
*/
function isToggleOn(field, value) {
	return field.toggle === true && value !== void 0 && fieldAdmits(field, value);
}
/** Upserts a value only when the field admits it, and otherwise leaves the state as it was. */
function upsertAdmitted(state, id, field, value) {
	return value === null || !fieldAdmits(field, value) ? [...state] : upsertFilter(state, id, value);
}
/**
* The operators a field allows, in menu order: its own list, else its kind's defaults, without the
* opt-in operators. A listed multi-value option operator also allows its one-value sibling,
* because a filter starts from one tick and `isAnyOf` cannot hold one value. So `["isAnyOf"]`
* allows `is` too, while `["is", "isNot"]` stays single-select. A boolean toggle allows `is` alone,
* whatever it lists. The parse, every reducer and every editor read this one list, so every filter
* an action writes survives the parse.
*
* @param field - The field.
* @returns The allowed operators.
*/
function allowedOperators(field) {
	if (field.kind === "boolean" && field.toggle === true) return ["is"];
	const listed = field.operators ?? defaultOperatorsFor(field.kind);
	const allowed = [...listed];
	for (const operator of listed) {
		const singular = OPERATOR_SPECS[field.kind][operator]?.singular;
		if (singular !== void 0 && !allowed.includes(singular)) allowed.push(singular);
	}
	return allowed;
}
/**
* The allowed operator an option filter takes at a value count, starting from `base`. Past one
* value it is the base's plural, else another allowed multi-value operator whose one-value sibling
* is the base, such as `includesAllOf` for `includes`. At one value it is the base's singular.
* Otherwise it is the base itself.
*
* @param field - The field.
* @param base - The current operator, or the one a new filter starts with.
* @param count - The value count after the change.
* @returns The operator, or undefined when the field allows none for that count.
*/
function operatorForCount(field, base, count) {
	const allowed = allowedOperators(field);
	const specs = OPERATOR_SPECS[field.kind];
	const spec = specs[base];
	if (spec === void 0) return;
	if (count >= 2 && spec.target === "single") {
		const siblings = allowed.filter((operator) => {
			const sibling = specs[operator];
			return sibling?.target === "multiple" && sibling.singular === base;
		});
		return [spec.plural, ...siblings].find((operator) => operator !== void 0 && allowed.includes(operator));
	}
	if (count === 1 && spec.target === "multiple") return spec.singular !== void 0 && allowed.includes(spec.singular) ? spec.singular : void 0;
	return allowed.includes(base) ? base : void 0;
}
/**
* The operators a chip's operator menu offers: the field's allowed operators, and for option
* kinds only those that take the current value count, so the operator never disagrees with it.
*
* @param field - The field.
* @param current - The applied filter, if any.
* @returns The operators to offer.
*/
function operatorChoices(field, current) {
	const allowed = allowedOperators(field);
	const all = current === void 0 || allowed.includes(current.operator) ? allowed : [current.operator, ...allowed];
	const { kind } = field;
	if ((kind === "option" || kind === "multiOption") && current !== void 0) {
		const target = targetOf(kind, current.operator);
		return all.filter((operator) => targetOf(kind, operator) === target);
	}
	return all;
}
const ISO_DATE = /^(\d{4})-(\d{2})-(\d{2})$/u;
/**
* Whether a value is a real calendar date written `YYYY-MM-DD`. `2026-13-01` and `2026-02-30`
* fail.
*
* @param value - The value to check.
* @returns Whether it is an ISO calendar date.
*/
function isIsoDate(value) {
	if (!isString(value)) return false;
	const match = ISO_DATE.exec(value);
	if (match === null) return false;
	const [year = 0, month = 0, day = 0] = match.slice(1).map(Number);
	return new Date(Date.UTC(year, month - 1, day)).toISOString().slice(0, 10) === value;
}
function valuesFit(kind, values) {
	switch (kind) {
		case "number": return values.every(isFiniteNumber);
		case "date": return values.every(isIsoDate);
		case "text": return values.every((value) => isString(value) && value.trim() !== "");
		case "option":
		case "multiOption": return values.every(isString) && new Set(values).size === values.length;
		case "boolean": return values.every(isBoolean);
	}
}
function countFits(target, count) {
	switch (target) {
		case "single": return count === 1;
		case "multiple": return count >= 2;
		case "range": return count === 2;
	}
}
/**
* Builds a filter value when the operator belongs to the kind, the value count fits the
* operator, every value has the kind's type, and a range runs low to high. This is the one place
* a runtime array becomes a typed tuple.
*
* @param kind - The filter kind.
* @param operator - The operator, any string.
* @param values - The values, any type.
* @returns The value, or `null` when any check fails.
*/
function toFilterValue(kind, operator, values) {
	const spec = OPERATOR_SPECS[kind][operator];
	if (spec === void 0 || !countFits(spec.target, values.length) || !valuesFit(kind, values)) return null;
	if (spec.target === "range") {
		const [low, high] = values;
		if (!(isFiniteNumber(low) && isFiniteNumber(high) ? low <= high : isString(low) && isString(high) && low <= high)) return null;
	}
	return {
		kind,
		operator,
		values: [...values]
	};
}
/**
* Whether an unknown value is a well-formed filter value, checked from scratch.
*
* @param value - The value to check.
* @returns Whether it is a `FilterValue`.
*/
function isFilterValue(value) {
	if (!isObject(value) || !("kind" in value && "operator" in value && "values" in value)) return false;
	const { kind, operator, values } = value;
	return isFilterKind(kind) && isString(operator) && Array.isArray(values) && toFilterValue(kind, operator, values) !== null;
}
/**
* Whether two filter values say the same thing: the same kind, operator and values, position by
* position. Order counts for every kind. A text, number or date value is positional, a range's
* start before its end, and an option list keeps the order the chip's summary shows it in, so a
* reordered list is a change the host made. A host that parses its filters again, such as from the
* URL, hands over equal copies, which this treats as no change.
*
* @param left - One filter value, or undefined for none.
* @param right - The other.
* @returns Whether they are equal.
*/
function filterValuesEqual(left, right) {
	if (left === void 0 || right === void 0) return left === right;
	return left.kind === right.kind && left.operator === right.operator && left.values.length === right.values.length && left.values.every((value, index) => value === right.values[index]);
}
/**
* A field's filter.
*
* @param state - The filter state.
* @param id - The column id.
* @returns The filter, or undefined.
*/
function findFilter(state, id) {
	return state.find((entry) => entry.id === id)?.value;
}
/**
* Puts `value` at `id` in its place, or last when new. A `null` value removes the entry.
*
* @param state - The filter state.
* @param id - The column id.
* @param value - The new value, or `null` to remove it.
* @returns The next state.
*/
function upsertFilter(state, id, value) {
	if (value === null) return state.filter((entry) => entry.id !== id);
	const index = state.findIndex((entry) => entry.id === id);
	if (index === -1) return [...state, {
		id,
		value
	}];
	return state.map((entry, at) => at === index ? {
		id,
		value
	} : entry);
}
/**
* Removes a field's filter.
*
* @param state - The filter state.
* @param id - The column id.
* @returns The next state.
*/
function removeFilter(state, id) {
	return upsertFilter(state, id, null);
}
/**
* Ticks or unticks one option. The first tick creates the filter from `start`. The operator then
* follows the count among the operators the field allows, and unticking the last value removes
* the filter. A field that allows no multi-value operator for the current one is single-select:
* a second tick replaces the first, and an untick that leaves values no allowed operator holds,
* such as a multi-selection applied before the field turned single-select, removes the filter.
*
* @param state - The filter state.
* @param id - The column id.
* @param field - The field's kind, `option` or `multiOption`, and its operators.
* @param optionValue - The option to tick or untick.
* @param start - The operator a new filter starts from, the field's first.
* @returns The next state.
*/
function toggleOption(state, id, field, optionValue, start) {
	const { kind } = field;
	const current = admittedPart(field, findFilter(state, id));
	const values = current?.values.filter(isString) ?? [];
	const adding = !values.includes(optionValue);
	const next = adding ? [...values, optionValue] : values.filter((value) => value !== optionValue);
	if (next.length === 0) return removeFilter(state, id);
	const base = current?.operator ?? start;
	const operator = operatorForCount(field, base, next.length);
	if (operator !== void 0) return upsertAdmitted(state, id, field, toFilterValue(kind, operator, next));
	if (!adding) return removeFilter(state, id);
	const single = operatorForCount(field, base, 1);
	return single === void 0 ? [...state] : upsertAdmitted(state, id, field, toFilterValue(kind, single, [optionValue]));
}
/**
* Sets an option or multi-option filter's values in one write, as a list's Select all does. Values
* the field does not offer and repeats drop out. The operator then follows the count from the
* current one, or from `start` for a new filter, as a tick's does: `is` becomes `isAnyOf`, a
* negated operator stays negated, and `includesAllOf` stays itself. An empty list removes the
* filter, and a count no allowed operator holds, such as two values on a single-select field,
* leaves the state as it was.
*
* @param state - The filter state.
* @param id - The column id.
* @param field - The field's kind, `option` or `multiOption`, its operators and its options.
* @param values - The values the filter holds after the write.
* @param start - The operator a new filter starts from, the field's first.
* @returns The next state.
*/
function setOptionValues(state, id, field, values, start) {
	const known = optionValues(field);
	const next = [...new Set(values)].filter((value) => known.has(value));
	if (next.length === 0) return removeFilter(state, id);
	const operator = optionOperatorFor(state, id, field, next.length, start);
	return operator === void 0 ? [...state] : upsertAdmitted(state, id, field, toFilterValue(field.kind, operator, next));
}
/**
* The operator `setOptionValues` writes for a count of values: the count's form of the current
* operator, or of `start` for a new filter.
*/
function optionOperatorFor(state, id, field, count, start) {
	return operatorForCount(field, admittedPart(field, findFilter(state, id))?.operator ?? start, count);
}
/**
* Whether `setOptionValues` can write the filter's admitted values plus `added` new ones, under
* the field's current operator, or `start` for a new filter. Under `isNot` on a field that allows
* `isAnyOf` but not `isNoneOf`, a second value cannot be added, though the same field can hold it
* under `is`. A list's Select all asks this before it offers a press.
*
* @param state - The filter state.
* @param id - The column id.
* @param field - The field's kind, `option` or `multiOption`, its operators and its options.
* @param added - How many values the write would add, none of them picked yet.
* @param start - The operator a new filter starts from, the field's first.
* @returns Whether some allowed operator holds that many values.
*/
function canAddOptionValues(state, id, field, added, start) {
	return optionOperatorFor(state, id, field, (admittedPart(field, findFilter(state, id))?.values.length ?? 0) + added, start) !== void 0;
}
/**
* Whether a field allows an operator that holds two or more values, so a list of its values can
* pick many at once. A single-select option field and every boolean field allow none.
*
* @param field - The field.
* @returns Whether it allows a multi-value operator.
*/
function allowsManyValues(field) {
	return allowedOperators(field).some((operator) => targetOf(field.kind, operator) === "multiple");
}
/**
* Picks `true` or `false` on a boolean field. On a toggle, a pick of `true` turns it off when it
* is on, and otherwise writes `is` `true`, which also replaces a value the toggle no longer
* admits. A toggle ignores `false`, since off means no filter. On any other boolean field, a pick
* of the applied value removes the filter, and a pick of the other value replaces it in place,
* keeping the operator.
*
* @param state - The filter state.
* @param id - The column id.
* @param field - The boolean field's operators and whether it is a toggle.
* @param picked - The value picked.
* @param start - The operator a new filter starts from, the field's first.
* @returns The next state.
*/
function toggleBoolean(state, id, field, picked, start) {
	const current = findFilter(state, id);
	if (field.toggle === true) {
		if (!picked) return [...state];
		return isToggleOn(field, current) ? removeFilter(state, id) : upsertAdmitted(state, id, field, toFilterValue("boolean", "is", [true]));
	}
	const admitted = admittedPart(field, current);
	if (admitted?.values[0] === picked) return removeFilter(state, id);
	return upsertAdmitted(state, id, field, toFilterValue("boolean", admitted?.operator ?? start, [picked]));
}
/**
* Sets a filter's operator and values. An empty list removes the filter, and an operator the
* field does not allow or an invalid combination leaves the state as it was.
*
* @param state - The filter state.
* @param id - The column id.
* @param field - The field's kind and operators.
* @param operator - The operator.
* @param values - The values.
* @returns The next state.
*/
function setFilterValues(state, id, field, operator, values) {
	if (values.length === 0) return removeFilter(state, id);
	const write = findFilter(state, id)?.operator === operator && !allowedOperators(field).includes(operator) ? reconcileOperator(field, operator, values) : {
		operator,
		values
	};
	return write === void 0 ? [...state] : upsertAdmitted(state, id, field, toFilterValue(field.kind, write.operator, write.values));
}
/**
* Converts values when the operator's target changes. A single value becomes `[v, upper]`, with
* `upper` the known maximum when it is above `v`, else `[v, v]`. A range becomes its first value.
* The same target keeps the values.
*
* @template T - The values' type.
* @param kind - The field's kind.
* @param from - The current operator.
* @param to - The new operator.
* @param values - The current values.
* @param upper - The known maximum, for a range.
* @returns The converted values.
*/
function convertValues(kind, from, to, values, upper) {
	const fromTarget = targetOf(kind, from);
	const toTarget = targetOf(kind, to);
	const first = values[0];
	if (fromTarget === toTarget || first === void 0) return values;
	if (toTarget === "range") return [first, upper !== void 0 && upper > first ? upper : first];
	if (toTarget === "single") return [first];
	return values;
}
/**
* Sets a filter's operator and converts its values to the new target.
*
* @param state - The filter state.
* @param id - The column id.
* @param field - The field's kind and operators.
* @param operator - The new operator.
* @param upper - The known maximum, for a change to a range.
* @returns The next state, unchanged when the field has no filter or does not allow `operator`, and
*   without the filter when none of its values is still an option.
*/
function setFilterOperator(state, id, field, operator, upper) {
	const current = admittedPart(field, findFilter(state, id));
	if (current === void 0 || !allowedOperators(field).includes(operator)) return [...state];
	if (current.values.length === 0) return removeFilter(state, id);
	const values = convertValues(field.kind, current.applied, operator, current.values, upper);
	const counted = field.kind === "option" || field.kind === "multiOption" ? operatorForCount(field, operator, values.length) ?? operator : operator;
	return upsertAdmitted(state, id, field, toFilterValue(field.kind, counted, values));
}
/**
* The part of an applied filter its field still admits, which an edit starts from: its option
* values that are still options, and its operator when the field still allows it. A filter
* applied before the config changed stays visible until a person edits it, and then the edit
* drops what the config left out, all in that edit's one write.
*
* @param field - The field.
* @param current - The applied filter, if any.
* @returns Its admitted values and operator, or undefined without a filter of the field's kind.
*/
function admittedPart(field, current) {
	if (current?.kind !== field.kind) return;
	const known = optionValues(field);
	const values = current.kind === "option" || current.kind === "multiOption" ? current.values.filter((value) => known.has(value)) : current.values;
	return {
		operator: allowedOperators(field).includes(current.operator) ? current.operator : void 0,
		applied: current.operator,
		values
	};
}
/**
* An allowed operator for values written under one the field has left out: the first allowed
* operator that takes that many values, else the field's first allowed operator with the values
* converted to its form.
*
* @param field - The field.
* @param operator - The operator the field has left out.
* @param values - The values.
* @returns The write, or undefined when the field allows nothing.
*/
function reconcileOperator(field, operator, values) {
	const allowed = allowedOperators(field);
	const fitting = allowed.find((candidate) => countFits(OPERATOR_SPECS[field.kind][candidate]?.target ?? "single", values.length));
	if (fitting !== void 0) return {
		operator: fitting,
		values
	};
	const [first] = allowed;
	return first === void 0 ? void 0 : {
		operator: first,
		values: convertValues(field.kind, operator, first, values)
	};
}
export { OPERATORS, allowedOperators, allowsManyValues, canAddOptionValues, convertValues, fieldAdmits, filterValuesEqual, findFilter, isBoolean, isFilterValue, isFiniteNumber, isIsoDate, isNegated, isObject, isOperatorOf, isString, isToggleOn, operatorChoices, removeFilter, setFilterOperator, setFilterValues, setOptionValues, targetOf, toFilterValue, toggleBoolean, toggleOption };

//# sourceMappingURL=filter-model.js.map