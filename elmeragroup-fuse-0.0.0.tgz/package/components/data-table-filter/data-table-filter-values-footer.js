"use client";
import { cn } from "../../styles/cn.js";
import { definedProps } from "../../internal/defined-props.js";
import { Button } from "../button/button.js";
import { DataTableFilterCompositionError } from "./data-table-filter-error.js";
import { useFilterInternals, useValueList } from "./data-table-filter-context.js";
import { dataTableFilterSlots } from "./data-table-filter-variants.js";
import { allowsManyValues, canAddOptionValues, findFilter } from "./filter-model.js";
import { firstOperator } from "./filter-fields.js";
import { currentOrder, pickedValues, unpickedMatches } from "./option-list.js";
import { chain } from "./chain-handlers.js";
import { jsx } from "react/jsx-runtime";
// src/components/data-table-filter/data-table-filter-values-footer.tsx
/**
* A row of actions at the foot of a value list, below its scrolling rows and always in view.
* Render it in `DataTableFilter.FieldList`'s children for the add menu's value submenus and in
* `DataTableFilter.OptionEditor`'s children for a chip's value popover, as one shared component.
* Its children are the actions: `SelectAllValues`, `ClearValues` and `Done`.
*
* @throws DataTableFilterCompositionError outside a value list, or when `fields` lists an id the
*   Root's fields do not have.
*/
function DataTableFilterValuesFooter({ fields, className, ...props }) {
	const { meta } = useFilterInternals("DataTableFilter.ValuesFooter");
	const list = useValueList("DataTableFilter.ValuesFooter");
	if (fields?.some((fieldId) => !Object.hasOwn(meta.fields, fieldId)) === true) throw new DataTableFilterCompositionError("DataTableFilter.ValuesFooter", "unknown-field");
	if (fields !== void 0 && !fields.includes(list.fieldId)) return null;
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "data-table-filter-values-footer",
		className: cn(dataTableFilterSlots.valuesFooter(), className),
		...props
	});
}
/**
* Picks every option the list's field offers now, past the 50 rows the list shows, beside the
* values already picked, including options the host added while the list is open. With a search
* it picks every option the search matches. It is disabled, and stays focusable, once every option
* in its scope is picked, and while the chip's operator cannot hold that many values, such as
* `is not` on a field that allows `is any of` but not `is none of`. It renders nothing on a boolean
* or a single-select field. Children replace its label, "Select all".
*/
function DataTableFilterSelectAllValues({ children, disabled = false, onClick, ...props }) {
	const { state, actions, meta } = useFilterInternals("DataTableFilter.SelectAllValues");
	const { field, fieldId, order, query, contains } = useValueList("DataTableFilter.SelectAllValues");
	if (field.kind === "boolean" || !allowsManyValues(field)) return null;
	const picked = pickedValues(field, findFilter(state.filters, fieldId));
	const pickedSet = new Set(picked);
	const scope = currentOrder(order, field.options);
	const sample = unpickedMatches(scope, query, contains, pickedSet, 2);
	const writable = sample.length > 0 && canAddOptionValues(state.filters, fieldId, field, sample.length, firstOperator(field));
	return /* @__PURE__ */ jsx(Button, {
		"data-slot": "data-table-filter-select-all",
		variant: "ghost",
		size: "sm",
		focusableWhenDisabled: true,
		disabled: disabled || !writable,
		onClick: chain(() => {
			const added = unpickedMatches(scope, query, contains, pickedSet, Number.POSITIVE_INFINITY);
			actions.setOptions(fieldId, [...picked, ...added.map((option) => option.value)]);
		}, onClick),
		...definedProps(props),
		children: children ?? meta.format("selectAll")
	});
}
/**
* Removes the filter of the list's field only, and the list stays open with focus on it. It is
* disabled while the field has no filter, and stays focusable. `DataTableFilter.Clear` removes
* every filter instead. Children replace its label, "Clear all".
*/
function DataTableFilterClearValues({ children, disabled = false, onClick, ...props }) {
	const { state, actions, meta } = useFilterInternals("DataTableFilter.ClearValues");
	const { fieldId } = useValueList("DataTableFilter.ClearValues");
	const empty = findFilter(state.filters, fieldId) === void 0;
	return /* @__PURE__ */ jsx(Button, {
		"data-slot": "data-table-filter-clear-values",
		variant: "ghost",
		size: "sm",
		focusableWhenDisabled: true,
		disabled: disabled || empty,
		onClick: chain(() => {
			actions.clearValues(fieldId);
		}, onClick),
		...definedProps(props),
		children: children ?? meta.format("clearValues")
	});
}
/**
* Closes the list's overlay, the add menu or the value popover, and focus goes where that overlay
* returns it: the Trigger, or the chip's Value. Picks have applied already. It sits at the
* footer's inline end. Disabled, it stays focusable, as the other actions do. Children replace its
* label, "Done".
*/
function DataTableFilterDone({ className, children, onClick, ...props }) {
	const { actions, meta } = useFilterInternals("DataTableFilter.Done");
	useValueList("DataTableFilter.Done");
	return /* @__PURE__ */ jsx(Button, {
		"data-slot": "data-table-filter-done",
		variant: "ghost",
		size: "sm",
		focusableWhenDisabled: true,
		className: cn(dataTableFilterSlots.done(), className),
		onClick: chain(actions.close, onClick),
		...definedProps(props),
		children: children ?? meta.format("done")
	});
}
DataTableFilterValuesFooter.displayName = "DataTableFilter.ValuesFooter";
DataTableFilterSelectAllValues.displayName = "DataTableFilter.SelectAllValues";
DataTableFilterClearValues.displayName = "DataTableFilter.ClearValues";
DataTableFilterDone.displayName = "DataTableFilter.Done";
export { DataTableFilterClearValues, DataTableFilterDone, DataTableFilterSelectAllValues, DataTableFilterValuesFooter };

//# sourceMappingURL=data-table-filter-values-footer.js.map