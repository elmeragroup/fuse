import { isFilterValue, isObject } from "./filter-model.js";
import { matchesFilter } from "./filter-match.js";
// src/components/data-table-filter/filter-fn.ts
/**
* Creates the filter function. Register it once, as `filterFns: { dataTableFilter }` in the
* table's features and `defaultColumn: { filterFn: "dataTableFilter" }`, and no column definition
* changes. A row passes a malformed value, which `autoRemove` then drops from state.
*
* @param options - The zone date cells compare in. Use the server's zone too.
* @returns The filter function.
*/
function createDataTableFilterFn(options = {}) {
	const parsed = /* @__PURE__ */ new WeakMap();
	const isParsed = (filterValue) => {
		if (!isObject(filterValue)) return false;
		let valid = parsed.get(filterValue);
		if (valid === void 0) {
			valid = isFilterValue(filterValue);
			parsed.set(filterValue, valid);
		}
		return valid;
	};
	const filterFn = (row, columnId, filterValue) => isParsed(filterValue) ? matchesFilter(filterValue, row.getValue(columnId), options) : true;
	const autoRemove = (filterValue) => !isParsed(filterValue);
	return Object.assign(filterFn, { autoRemove });
}
export { createDataTableFilterFn };

//# sourceMappingURL=filter-fn.js.map