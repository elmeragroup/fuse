import { isFiniteNumber, isIsoDate, targetOf } from "./filter-model.js";
import { firstOperator } from "./filter-fields.js";
import { isListField, isListKind } from "./option-list.js";
// src/components/data-table-filter/editor-draft.ts
/**
* A facet range widened out to whole steps: the slider's bounds, and the draft a new range starts
* from, which must agree so the draft sits inside the slider.
*
* @param range - The facet's lowest and highest values.
* @param step - The field's step.
* @returns The range's low end floored and its high end ceiled to a multiple of `step`.
*/
function stepBounds(range, step) {
	return [Math.floor(range[0] / step) * step, Math.ceil(range[1] / step) * step];
}
/**
* The draft an editor starts from: the applied filter, else the field's first operator with no
* values. A new number range over a known facet range starts at that range, so the slider shows
* it. A one-value operator starts empty, whatever the range.
*
* @param field - The edited field.
* @param filter - The applied filter, if any.
* @param range - The field's known number range, if any.
* @returns The draft.
*/
function draftFor(field, filter, range) {
	if (filter !== void 0) return {
		operator: filter.operator,
		values: isListField(filter) ? [] : filter.values,
		edited: false
	};
	const operator = firstOperator(field);
	if (field.kind === "number" && range !== void 0 && targetOf("number", operator) === "range") return {
		operator,
		values: stepBounds(range, field.step ?? 1),
		edited: false
	};
	return {
		operator,
		values: field.kind === "text" ? [""] : [],
		edited: false
	};
}
/**
* Whether a draft already says what a filter says: the same operator and the same values, with a
* text draft trimmed as it applies. No filter matches a draft with nothing to apply.
*
* @param kind - The field's kind.
* @param draft - The draft.
* @param filter - The applied filter, if any.
* @returns Whether the draft says it.
*/
function draftSays(kind, draft, filter) {
	const values = kind === "text" ? draft.values.map((value) => String(value).trim()) : draft.values;
	if (filter === void 0) return values.every((value) => value === "" || kind === "number" && !isFiniteNumber(value));
	return draft.operator === filter.operator && values.join("\0") === filter.values.join("\0");
}
/**
* The values a draft holds in the positions its operator takes, when each is complete: a non-empty
* trimmed text, a finite number, an ISO date. A position never moves, so a range's end typed
* first stays the end.
*
* @param kind - The field's kind.
* @param draft - The draft.
* @returns The values, or undefined while a position is incomplete.
*/
function completeValues(kind, draft) {
	const count = targetOf(kind, draft.operator) === "range" ? 2 : 1;
	const used = Array.from({ length: count }, (_, index) => draft.values[index]);
	switch (kind) {
		case "text": {
			const text = String(used[0] ?? "").trim();
			return text === "" ? void 0 : [text];
		}
		case "number": {
			const numbers = used.filter(isFiniteNumber);
			return numbers.length === count ? numbers : void 0;
		}
		case "date": {
			const dates = used.filter(isIsoDate);
			return dates.length === count ? dates : void 0;
		}
		case "option":
		case "multiOption":
		case "boolean": return;
	}
}
/**
* The one write a draft settles into against the applied filter, or undefined when it writes
* nothing. A draft nobody edited writes nothing without an applied filter. An emptied text
* removes the filter. An incomplete or reversed range writes nothing, so
* the last valid filter stays. A new number range across the whole known range filters nothing,
* so it makes no filter. A draft that already says what is applied writes nothing.
*
* @param kind - The field's kind. Option and boolean kinds commit on each pick and never settle a
*   draft.
* @param draft - The draft.
* @param applied - The applied filter, if any.
* @param range - The field's known number range, if any.
* @returns The write, an operator and its values or no values to remove the filter, or undefined.
*/
function draftWrite(kind, draft, applied, range) {
	if (isListKind(kind) || applied === void 0 && !draft.edited) return;
	if (kind === "text" && String(draft.values[0] ?? "").trim() === "") return applied === void 0 ? void 0 : {
		operator: draft.operator,
		values: []
	};
	const values = completeValues(kind, draft);
	if (values === void 0) return;
	const [low, high] = values;
	if (low !== void 0 && high !== void 0 && low > high) return;
	if (kind === "number" && applied === void 0 && draft.operator === "isBetween" && range !== void 0 && isFiniteNumber(low) && isFiniteNumber(high) && low <= range[0] && high >= range[1]) return;
	const write = {
		operator: draft.operator,
		values
	};
	return draftSays(kind, write, applied) ? void 0 : write;
}
export { completeValues, draftFor, draftSays, draftWrite, stepBounds };

//# sourceMappingURL=editor-draft.js.map