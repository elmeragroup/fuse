// src/components/data-table-filter/data-table-filter-error.ts
/**
* What each composition rule tells the consumer after the name of the part that threw. Each
* message states the rule, then the fix.
*/
const MESSAGES = {
	"outside-root": "must be used within DataTableFilter.Root. Wrap the filter's parts in DataTableFilter.Root.",
	"outside-chip": "must be used within DataTableFilter.Chip, under DataTableFilter.Chips. Render it in the chip template.",
	"outside-overlay": "must be used within DataTableFilter.Content or DataTableFilter.ValueContent. Render it in either overlay.",
	"outside-editor": "must be used within DataTableFilter.Editor. Render it in the editor of either overlay.",
	"outside-value-list": "must be used within a value list. Render it in DataTableFilter.FieldList's or DataTableFilter.OptionEditor's children.",
	"unknown-field": "lists a field id that DataTableFilter.Root's fields do not have. List only ids of the fields map.",
	"no-content": "opens DataTableFilter.Content, but this DataTableFilter.Root renders none. Render <DataTableFilter.Content /> beside the Bar.",
	"no-value-content": "opens DataTableFilter.ValueContent, but this DataTableFilter.Root renders none. Render <DataTableFilter.ValueContent /> beside the Bar."
};
/**
* A part throws it when the consumer composes the filter's parts in a way that cannot work, such
* as `DataTableFilter.Value` outside a chip. Its message starts with the part that threw and names
* the fix. A Trigger or a Value whose overlay is missing throws it in development only.
*/
var DataTableFilterCompositionError = class extends Error {
	part;
	rule;
	name = "DataTableFilterCompositionError";
	_tag = "DataTableFilterCompositionError";
	/**
	* @param part - The part that threw, such as `DataTableFilter.Value`.
	* @param rule - The composition rule the tree breaks.
	*/
	constructor(part, rule) {
		super(`${part} ${MESSAGES[rule]}`);
		this.part = part;
		this.rule = rule;
	}
};
export { DataTableFilterCompositionError };

//# sourceMappingURL=data-table-filter-error.js.map