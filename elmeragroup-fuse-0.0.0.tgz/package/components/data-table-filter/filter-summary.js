import { dateTimeFormat, listFormat, numberFormat } from "../../internal/intl-cache.js";
import { optionsOf } from "./filter-fields.js";
import { booleanLabel } from "./option-list.js";
// src/components/data-table-filter/filter-summary.ts
/** Option labels a summary shows before "+N". */
const VISIBLE_OPTIONS = 2;
function utcDay(iso) {
	return /* @__PURE__ */ new Date(`${iso}T00:00:00Z`);
}
/**
* Summarizes a filter value for its chip.
*
* @param value - The filter.
* @param field - Its field, for option labels, boolean labels and the number format.
* @param locale - The locale to format in.
* @param strings - The locale's `moreValues`, `quoted`, `yes` and `no` rows.
* @returns The summary.
*/
function summarize(value, field, locale, strings) {
	switch (value.kind) {
		case "option":
		case "multiOption": {
			const labelOf = /* @__PURE__ */ new Map();
			for (const option of optionsOf(field)) if (!labelOf.has(option.value)) labelOf.set(option.value, option.label);
			const labels = value.values.map((item) => labelOf.get(item) ?? item);
			const list = listFormat(locale, {
				type: "unit",
				style: "short"
			});
			const shown = labels.slice(0, VISIBLE_OPTIONS);
			const rest = labels.length - shown.length;
			return {
				text: rest > 0 ? `${list.format(shown)} ${strings.moreValues(numberFormat(locale).format(rest))}` : list.format(shown),
				full: list.format(labels)
			};
		}
		case "text": {
			const text = strings.quoted(value.values[0]);
			return {
				text,
				full: text
			};
		}
		case "number": {
			const numbers = numberFormat(locale, field.kind === "number" ? field.format : void 0);
			const text = value.values.length === 2 ? numbers.formatRange(value.values[0], value.values[1]) : numbers.format(value.values[0]);
			return {
				text,
				full: text
			};
		}
		case "date": {
			const dates = dateTimeFormat(locale, {
				dateStyle: "medium",
				timeZone: "UTC"
			});
			const text = value.values.length === 2 ? dates.formatRange(utcDay(value.values[0]), utcDay(value.values[1])) : dates.format(utcDay(value.values[0]));
			return {
				text,
				full: text
			};
		}
		case "boolean": {
			const text = booleanLabel(field.kind === "boolean" ? field : {}, value.values[0], strings);
			return {
				text,
				full: text
			};
		}
	}
}
export { summarize };

//# sourceMappingURL=filter-summary.js.map