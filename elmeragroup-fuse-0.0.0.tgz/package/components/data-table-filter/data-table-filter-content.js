"use client";
import { cn } from "../../styles/cn.js";
import { selfFocusRingClass } from "../../styles/utils.js";
import { useMergedRefs } from "../../hooks/use-merged-refs.js";
import { mergeClassName } from "../../styles/merge-class-name.js";
import { definedProps } from "../../internal/defined-props.js";
import { overlayPositionerClass, overlayTimedPopupClass } from "../overlay/overlay-classes.js";
import { OverlayPortal } from "../overlay/overlay-portal.js";
import { InputGroupAddon, InputGroupPlainInput, InputGroupRoot } from "../input-group/input-group.js";
import { menuGroupLabelClass, menuItemClass, menuItemIndicatorClass, menuItemIndicatorRoomClass, menuSeparatorClass } from "../overlay/menu-row-classes.js";
import { Check } from "../../icons/generated/check.js";
import { CaretRight } from "../../icons/generated/caret-right.js";
import { MagnifyingGlass } from "../../icons/generated/magnifying-glass.js";
import { menuPopupShellClass } from "../../styles/inner-corner/menu.js";
import { switchVariants } from "../switch/switch-variants.js";
import { EditorTargetContext, ValueListContext, useFilterInternals, useOverlayRef } from "./data-table-filter-context.js";
import { dataTableFilterSlots } from "./data-table-filter-variants.js";
import { findFilter, isToggleOn } from "./filter-model.js";
import { isListField, listSource, matchOptions, pickedValues, snapshotOrder } from "./option-list.js";
import { useContains } from "./use-contains.js";
import { OptionCount } from "./data-table-filter-editors.js";
import { DefaultEditor } from "./data-table-filter-value-content.js";
import { SearchableMenu, closeSubmenuOnBackspace, keepKeysFromToolbar } from "./searchable-menu.js";
import { createContext, use, useCallback, useLayoutEffect, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { Menu } from "@base-ui/react/menu";
// src/components/data-table-filter/data-table-filter-content.tsx
const switchSlots = switchVariants({ size: "sm" });
/** The menu's query, which `Content` owns beside its filter provider and `FieldList` reads. */
const MenuQueryContext = createContext("");
/** Quick search lists option values across fields from this many characters on. */
const QUICK_SEARCH_MIN = 2;
/** The popup's two morphed dimensions. */
const MORPHED = ["width", "height"];
/** Whether the morph has pinned either dimension inline. */
function pinned(popup) {
	return MORPHED.some((dimension) => popup.style[dimension] !== "");
}
/**
* Morphs the popup's width and height when its step changes, from the field list to an editor and
* back, and only then, so a keystroke that grows or shrinks the list snaps. Base UI measures a popup
* only when its payload changes (`usePopupViewport.tsx`), and the menu has none, so this measures
* the step change itself. A CSS transition, so a change mid-flight retargets. A dimension the
* central reduced-motion rule leaves out of the transition list is never pinned.
*
* @param step - The current step.
* @returns A ref for the popup and its `transitionend` handler.
*/
function useStepMorph(step) {
	const lastSize = useRef(null);
	const lastStep = useRef(step);
	const popupRef = useRef(null);
	const ref = useCallback((popup) => {
		popupRef.current = popup;
		lastSize.current = null;
		if (popup === null) return;
		const observer = new ResizeObserver(() => {
			if (!pinned(popup)) lastSize.current = {
				width: popup.offsetWidth,
				height: popup.offsetHeight
			};
		});
		observer.observe(popup);
		return () => {
			observer.disconnect();
		};
	}, []);
	useLayoutEffect(() => {
		const popup = popupRef.current;
		const changed = lastStep.current !== step;
		lastStep.current = step;
		if (popup === null || !changed) return;
		const transitioned = getComputedStyle(popup).transitionProperty.split(",").map((property) => property.trim());
		const ownProperty = popup.style.transitionProperty;
		popup.style.transitionProperty = transitioned.filter((property) => !MORPHED.some((dimension) => dimension === property)).join(", ") || "none";
		const from = pinned(popup) ? popup.getBoundingClientRect() : lastSize.current;
		for (const dimension of MORPHED) popup.style[dimension] = "";
		const to = {
			width: popup.offsetWidth,
			height: popup.offsetHeight
		};
		lastSize.current = to;
		const start = from ?? to;
		const morphing = MORPHED.filter((dimension) => transitioned.includes(dimension) && Math.abs(start[dimension] - to[dimension]) >= .5);
		for (const dimension of morphing) popup.style[dimension] = `${String(start[dimension])}px`;
		popup.getBoundingClientRect();
		popup.style.transitionProperty = ownProperty;
		for (const dimension of morphing) popup.style[dimension] = `${String(to[dimension])}px`;
	}, [step]);
	const onTransitionEnd = (event) => {
		const dimension = MORPHED.find((name) => name === event.propertyName);
		if (event.target === event.currentTarget && dimension !== void 0) event.currentTarget.style[dimension] = "";
	};
	return {
		ref,
		onTransitionEnd
	};
}
/**
* The add menu the Trigger opens, named "Add filter". Its field list filters by the search and
* caps every value list at 50 rows. An option or boolean field opens a submenu of its values,
* ticked live, and a boolean toggle's row ticks it on and off. A text, number or date field drills
* in place: its editor replaces the search and the list, values apply live, and Back, Escape or a
* fresh Backspace in an empty text input return to the list with the search kept and the field
* highlighted. The table stays scrollable while it is open.
*/
function DataTableFilterContent({ className, children, onKeyDown, onTransitionEnd, ref, ...props }) {
	const { state, actions, meta } = useFilterInternals("DataTableFilter.Content");
	const { registerContent } = actions;
	useLayoutEffect(registerContent, [registerContent]);
	const [query, setQuery] = useState("");
	const morph = useStepMorph(state.drilled ?? "");
	const popupRef = useRef(null);
	const drilledField = state.drilled === null ? void 0 : meta.fields[state.drilled];
	const target = {
		place: "menu",
		fieldId: state.drilled,
		back: () => {
			if (state.drillOrigin === "edit" && drilledField !== void 0) setQuery(drilledField.label);
			actions.back();
		}
	};
	const { ref: morphRef } = morph;
	const attachPopup = useCallback((popup) => {
		popupRef.current = popup;
		return morphRef(popup);
	}, [morphRef]);
	const overlayRef = useOverlayRef(actions.registerOverlay, "menu");
	const popupRefs = useMergedRefs(ref, useMergedRefs(attachPopup, overlayRef));
	return /* @__PURE__ */ jsx(SearchableMenu.Provider, {
		filter: null,
		value: query,
		onValueChange: setQuery,
		autoHighlight: true,
		children: /* @__PURE__ */ jsx(Menu.Root, {
			handle: meta.menuHandle,
			modal: false,
			onOpenChange: (open) => {
				if (open) actions.noteOpen("menu");
				else actions.applyDrafts();
			},
			onOpenChangeComplete: (open) => {
				if (!open) actions.settleMenu();
			},
			children: /* @__PURE__ */ jsx(OverlayPortal, {
				portal: Menu.Portal,
				children: /* @__PURE__ */ jsx(Menu.Positioner, {
					"data-slot": "data-table-filter-content-positioner",
					side: "bottom",
					align: "start",
					sideOffset: 4,
					collisionPadding: 8,
					className: overlayPositionerClass,
					children: /* @__PURE__ */ jsx(Menu.Popup, {
						ref: popupRefs,
						"data-slot": "data-table-filter-content",
						"data-step": state.drilled === null ? "fields" : "editor",
						"aria-label": meta.format("addFilter"),
						finalFocus: () => !meta.focusLeft("menu", popupRef.current),
						className: mergeClassName(className, selfFocusRingClass, overlayTimedPopupClass, menuPopupShellClass, dataTableFilterSlots.menu()),
						onKeyDown: (event) => {
							onKeyDown?.(event);
							keepKeysFromToolbar(event);
						},
						onTransitionEnd: (event) => {
							onTransitionEnd?.(event);
							morph.onTransitionEnd(event);
						},
						...props,
						children: /* @__PURE__ */ jsx(MenuQueryContext, {
							value: query,
							children: /* @__PURE__ */ jsx(EditorTargetContext, {
								value: target,
								children: children ?? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(DataTableFilterFieldList, {}), /* @__PURE__ */ jsx(DefaultEditor, {})] })
							})
						})
					})
				})
			})
		})
	});
}
/** The search group: Fuse's InputGroup around Base UI's Menu.Input, as Command.Input does. */
function MenuSearch({ label, placeholder, hidden = false, onKeyDown, inputRef }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "data-table-filter-search",
		hidden,
		className: dataTableFilterSlots.search(),
		children: /* @__PURE__ */ jsxs(InputGroupRoot, { children: [/* @__PURE__ */ jsx(InputGroupAddon, {
			align: "inline-start",
			children: /* @__PURE__ */ jsx(MagnifyingGlass, { "aria-hidden": true })
		}), /* @__PURE__ */ jsx(SearchableMenu.Input, {
			ref: inputRef,
			"aria-label": label,
			placeholder,
			render: /* @__PURE__ */ jsx(InputGroupPlainInput, {}),
			...definedProps({ onKeyDown })
		})] })
	});
}
/**
* The add menu's field step: the field search, one row per field and, from two characters on, a
* "Values" group of option values across fields, "Status › Pending". Field rows are menu items,
* and value rows are `menuitemcheckbox` with `aria-checked`. While a field is drilled into, only
* its search stays mounted, hidden, so the query and Base UI's highlight survive until Back. Its
* children render at the foot of each value submenu, outside the scrolling list.
*/
function DataTableFilterFieldList({ children }) {
	const { state, actions, meta } = useFilterInternals("DataTableFilter.FieldList");
	const query = use(MenuQueryContext);
	const contains = useContains(meta.locale);
	const searchRef = useRef(null);
	const attachSearch = useCallback((input) => {
		searchRef.current = input;
	}, []);
	const { returnTo, drillOrigin } = state;
	const { clearReturnTo } = actions;
	useLayoutEffect(() => {
		const search = searchRef.current;
		if (returnTo === null || search === null) return;
		search.focus({ preventScroll: true });
		if (drillOrigin === "edit") search.select();
		clearReturnTo();
	}, [
		returnTo,
		drillOrigin,
		clearReturnTo
	]);
	const drilled = state.drilled !== null;
	const needle = query.trim();
	const fieldIds = Object.keys(meta.fields).filter((fieldId) => {
		const field = meta.fields[fieldId];
		return field !== void 0 && (needle === "" || contains(field.label, needle));
	});
	const quick = [];
	let more = false;
	if (!drilled && needle.length >= QUICK_SEARCH_MIN) for (const [fieldId, field] of Object.entries(meta.fields)) {
		if (more || field.kind !== "option" && field.kind !== "multiOption") continue;
		for (const option of field.options) {
			if (!contains(option.label, needle)) continue;
			if (quick.length === 50) {
				more = true;
				break;
			}
			quick.push({
				fieldId,
				field,
				option
			});
		}
	}
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(MenuSearch, {
		label: meta.format("searchFields"),
		placeholder: meta.format("searchFieldsPlaceholder"),
		hidden: drilled,
		inputRef: attachSearch
	}), drilled ? null : /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx(SearchableMenu.Empty, {
			className: dataTableFilterSlots.empty(),
			children: meta.format("noFields")
		}),
		/* @__PURE__ */ jsxs(SearchableMenu.List, {
			"data-slot": "data-table-filter-fields",
			className: dataTableFilterSlots.list(),
			children: [fieldIds.map((fieldId) => {
				const field = meta.fields[fieldId];
				if (field === void 0) return null;
				const active = findFilter(state.filters, fieldId) !== void 0;
				if (field.kind === "boolean" && field.toggle === true) return /* @__PURE__ */ jsx(ToggleItem, {
					fieldId,
					field
				}, fieldId);
				return isListField(field) ? /* @__PURE__ */ jsx(FieldSubmenu, {
					fieldId,
					field,
					active,
					children
				}, fieldId) : /* @__PURE__ */ jsx(FieldItem, {
					fieldId,
					field,
					active
				}, fieldId);
			}), quick.length > 0 ? /* @__PURE__ */ jsxs(Menu.Group, {
				"data-slot": "data-table-filter-quick",
				children: [/* @__PURE__ */ jsx(Menu.GroupLabel, {
					className: menuGroupLabelClass,
					children: meta.format("valuesGroup")
				}), quick.map(({ fieldId, field, option }) => /* @__PURE__ */ jsx(ValueItem, {
					fieldId,
					field,
					option,
					path: true
				}, `${fieldId}:${option.value}`))]
			}) : null]
		}),
		/* @__PURE__ */ jsx("p", {
			role: "status",
			"data-slot": "data-table-filter-narrow",
			className: dataTableFilterSlots.narrowHint(),
			children: more ? meta.format("narrowHint") : null
		})
	] })] });
}
/** A field row's icon, label and the dot that says the field already has a filter. */
function FieldRowContent({ field, active }) {
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		field.icon === void 0 ? null : /* @__PURE__ */ jsx("span", {
			"aria-hidden": true,
			className: "contents text-muted-foreground",
			children: field.icon
		}),
		/* @__PURE__ */ jsx("span", {
			className: "min-w-0 truncate",
			children: field.label
		}),
		active ? /* @__PURE__ */ jsx("span", {
			"aria-hidden": true,
			className: dataTableFilterSlots.activeDot()
		}) : null
	] });
}
/**
* A text, number or date field: an item that drills into the field's editor in place. It keeps
* the menu open, since `closeOnClick` defaults to true on Menu.Item (`MenuItem.tsx`). It ends with
* a caret like a submenu row, because it leads to a further step.
*/
function FieldItem({ fieldId, field, active }) {
	const { actions, meta } = useFilterInternals("DataTableFilter.FieldList");
	return /* @__PURE__ */ jsxs(Menu.Item, {
		"data-slot": "data-table-filter-field",
		"data-field": fieldId,
		"data-active": active || void 0,
		label: field.label,
		"aria-description": active ? meta.format("filtered") : void 0,
		className: cn(menuItemClass, dataTableFilterSlots.row()),
		closeOnClick: false,
		onClick: () => {
			actions.drill(fieldId);
		},
		children: [/* @__PURE__ */ jsx(FieldRowContent, {
			field,
			active
		}), /* @__PURE__ */ jsx(CaretRight, {
			"aria-hidden": true,
			className: active ? "text-muted-foreground" : dataTableFilterSlots.caret()
		})]
	});
}
/**
* A boolean toggle: one checkbox row that ticks the filter on and off, and keeps the menu open, as
* Menu.CheckboxItem does. A small switch in Switch's look ends the row, in the column where the
* other rows end with their caret, and the count sits just before it. The switch is a picture of
* the row's own checked state: two kept-mounted checkbox indicators, the track and the thumb,
* which carry the item's `data-checked` or `data-unchecked` and are hidden from assistive
* technology. The row stays the one `menuitemcheckbox`, so the switch has no role, focus or
* handler. The count is the rows the toggle keeps, also hidden, so the row's name stays the
* field's.
*/
function ToggleItem({ fieldId, field }) {
	const { state, actions, meta } = useFilterInternals("DataTableFilter.FieldList");
	const counts = meta.facets.counts(fieldId);
	const count = counts === void 0 ? void 0 : counts.get("true") ?? 0;
	return /* @__PURE__ */ jsxs(Menu.CheckboxItem, {
		"data-slot": "data-table-filter-field",
		"data-field": fieldId,
		"data-toggle": "",
		label: field.label,
		checked: isToggleOn(field, findFilter(state.filters, fieldId)),
		onCheckedChange: () => {
			actions.toggle(fieldId, "true");
		},
		className: cn(menuItemClass, dataTableFilterSlots.row()),
		children: [
			/* @__PURE__ */ jsx(FieldRowContent, {
				field,
				active: false
			}),
			count === void 0 ? null : /* @__PURE__ */ jsx(OptionCount, { count }),
			/* @__PURE__ */ jsx(Menu.CheckboxItemIndicator, {
				keepMounted: true,
				"data-slot": "data-table-filter-toggle-switch",
				className: cn(switchSlots.root(), count === void 0 ? "ms-auto" : void 0),
				children: /* @__PURE__ */ jsx(Menu.CheckboxItemIndicator, {
					keepMounted: true,
					className: switchSlots.thumb()
				})
			})
		]
	});
}
/**
* An option, multi-option or boolean field: a filterable submenu of its values with its own query
* and the shared cap. On a narrow viewport neither inline side fits, so it falls back below its row
* through `fallbackAxisSide: "end"`, level with the menu's edge and as wide, covering only the
* rows after its own.
*/
function FieldSubmenu({ fieldId, field, active, children }) {
	const { actions, meta } = useFilterInternals("DataTableFilter.FieldList");
	const [query, setQuery] = useState("");
	const overlayRef = useOverlayRef(actions.registerOverlay, "menu");
	return /* @__PURE__ */ jsx(SearchableMenu.Provider, {
		filter: null,
		value: query,
		onValueChange: setQuery,
		autoHighlight: true,
		children: /* @__PURE__ */ jsxs(Menu.SubmenuRoot, {
			onOpenChange: (open) => {
				actions.setSubmenuOpen(fieldId, open);
			},
			children: [/* @__PURE__ */ jsxs(Menu.SubmenuTrigger, {
				"data-slot": "data-table-filter-field",
				"data-field": fieldId,
				"data-active": active || void 0,
				label: field.label,
				"aria-description": active ? meta.format("filtered") : void 0,
				className: cn(menuItemClass, dataTableFilterSlots.row(), dataTableFilterSlots.fieldRow()),
				children: [/* @__PURE__ */ jsx(FieldRowContent, {
					field,
					active
				}), /* @__PURE__ */ jsx(CaretRight, {
					"aria-hidden": true,
					className: active ? "text-muted-foreground" : dataTableFilterSlots.caret()
				})]
			}), /* @__PURE__ */ jsx(OverlayPortal, {
				portal: Menu.Portal,
				children: /* @__PURE__ */ jsx(Menu.Positioner, {
					"data-slot": "data-table-filter-submenu-positioner",
					sideOffset: ({ side }) => side === "top" || side === "bottom" ? 2 : 4,
					alignOffset: -4,
					collisionPadding: 8,
					collisionAvoidance: {
						side: "flip",
						align: "shift",
						fallbackAxisSide: "end"
					},
					className: overlayPositionerClass,
					children: /* @__PURE__ */ jsx(Menu.Popup, {
						ref: overlayRef,
						"data-slot": "data-table-filter-options-menu",
						"data-field": fieldId,
						"aria-label": field.label,
						className: cn(selfFocusRingClass, overlayTimedPopupClass, menuPopupShellClass, dataTableFilterSlots.menu()),
						onKeyDown: keepKeysFromToolbar,
						children: /* @__PURE__ */ jsx(OptionMenuBody, {
							fieldId,
							field,
							query,
							children
						})
					})
				})
			})]
		})
	});
}
/**
* The submenu's body. Its order is taken as the submenu opens, so a tick never moves a row, and
* picked values sit first under a separator. Each tick applies at once, and the chip appears in
* the bar under the open menu. The FieldList's children follow the list, in its value list context.
*/
function OptionMenuBody({ fieldId, field, query, children }) {
	const { state, meta } = useFilterInternals("DataTableFilter.FieldList");
	const picked = pickedValues(field, findFilter(state.filters, fieldId));
	const counts = meta.facets.counts(fieldId);
	const [order] = useState(() => snapshotOrder(listSource(field, {
		yes: meta.format("yes"),
		no: meta.format("no")
	}), picked, counts));
	const contains = useContains(meta.locale);
	const matches = matchOptions(order, query, contains, 50);
	const searchLabel = meta.format("searchValues", { field: field.label });
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsx(MenuSearch, {
			label: searchLabel,
			placeholder: searchLabel,
			onKeyDown: closeSubmenuOnBackspace
		}),
		/* @__PURE__ */ jsx(SearchableMenu.Empty, {
			className: dataTableFilterSlots.empty(),
			children: meta.format("noValues")
		}),
		/* @__PURE__ */ jsxs(SearchableMenu.List, {
			"data-slot": "data-table-filter-options",
			className: dataTableFilterSlots.list(),
			children: [matches.pinned.length > 0 ? /* @__PURE__ */ jsxs(Menu.Group, {
				"data-group": "pinned",
				children: [matches.pinned.map((option) => /* @__PURE__ */ jsx(ValueItem, {
					fieldId,
					field,
					option,
					pinned: true
				}, option.value)), matches.rest.length > 0 ? /* @__PURE__ */ jsx(Menu.Separator, { className: menuSeparatorClass }) : null]
			}) : null, matches.rest.map((option) => /* @__PURE__ */ jsx(ValueItem, {
				fieldId,
				field,
				option
			}, option.value))]
		}),
		/* @__PURE__ */ jsx("p", {
			role: "status",
			"data-slot": "data-table-filter-narrow",
			className: dataTableFilterSlots.narrowHint(),
			children: matches.more ? meta.format("narrowHint") : null
		}),
		/* @__PURE__ */ jsx(ValueListContext, {
			value: {
				fieldId,
				field,
				order,
				query,
				contains
			},
			children
		})
	] });
}
/**
* One option value, a `menuitemcheckbox` with `aria-checked`. A checkbox and not a radio, because
* a second pick adds a value, `is` becoming `is any of`, and never replaces the first. It stays
* open on a press, Menu.CheckboxItem's default. The count is hidden from assistive technology, so
* the row's name stays "Paid".
*/
function ValueItem({ fieldId, field, option, pinned = false, path = false }) {
	const { state, actions, meta } = useFilterInternals("DataTableFilter.FieldList");
	const picked = pickedValues(field, findFilter(state.filters, fieldId));
	const counts = meta.facets.counts(fieldId);
	const count = counts === void 0 ? void 0 : counts.get(option.value) ?? 0;
	return /* @__PURE__ */ jsxs(Menu.CheckboxItem, {
		"data-slot": "data-table-filter-option",
		"data-quick": path || void 0,
		"data-field": fieldId,
		"data-value": option.value,
		"data-pinned": pinned || void 0,
		"data-zero": count === 0 || void 0,
		label: path ? `${field.label} ${option.label}` : option.label,
		checked: picked.includes(option.value),
		onCheckedChange: () => {
			actions.toggle(fieldId, option.value);
		},
		className: cn(menuItemClass, menuItemIndicatorRoomClass, dataTableFilterSlots.row(), dataTableFilterSlots.option()),
		children: [
			/* @__PURE__ */ jsx("span", {
				className: menuItemIndicatorClass,
				children: /* @__PURE__ */ jsx(Menu.CheckboxItemIndicator, { children: /* @__PURE__ */ jsx(Check, { "aria-hidden": true }) })
			}),
			option.icon === void 0 ? null : /* @__PURE__ */ jsx("span", {
				"aria-hidden": true,
				className: "contents",
				children: option.icon
			}),
			/* @__PURE__ */ jsxs("span", {
				className: "min-w-0 truncate",
				children: [path ? /* @__PURE__ */ jsxs(Fragment$1, { children: [
					/* @__PURE__ */ jsx("span", {
						className: dataTableFilterSlots.pathSeparator(),
						children: field.label
					}),
					/* @__PURE__ */ jsx("span", {
						"aria-hidden": true,
						className: dataTableFilterSlots.pathSeparator(),
						children: " ›"
					}),
					" "
				] }) : null, option.label]
			}),
			count === void 0 ? null : /* @__PURE__ */ jsx(OptionCount, { count })
		]
	});
}
DataTableFilterContent.displayName = "DataTableFilter.Content";
DataTableFilterFieldList.displayName = "DataTableFilter.FieldList";
export { DataTableFilterContent, DataTableFilterFieldList };

//# sourceMappingURL=data-table-filter-content.js.map