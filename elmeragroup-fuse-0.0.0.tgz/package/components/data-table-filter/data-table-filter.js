"use client";
import { useLocale } from "../../intl/locale-context.js";
import { useLocalizedStrings } from "../../hooks/use-localized-strings.js";
import { focusEdge, focusMovedElsewhere } from "./filter-focus.js";
import { DataTableFilterContext, DataTableFilterInternalContext, drillKey, editKey } from "./data-table-filter-context.js";
import { findFilter, isToggleOn, removeFilter, setFilterOperator, setFilterValues, setOptionValues, toggleBoolean, toggleOption } from "./filter-model.js";
import { firstOperator } from "./filter-fields.js";
import { isListField } from "./option-list.js";
import { createFacetReader } from "./filter-facets.js";
import { viewColumnFilters } from "./filter-parse.js";
import { dataTableFilterStrings } from "./intl/index.js";
import { useCallback, useEffect, useId, useLayoutEffect, useRef, useState, useSyncExternalStore } from "react";
import { jsx } from "react/jsx-runtime";
import { Menu } from "@base-ui/react/menu";
import { Popover } from "@base-ui/react/popover";
// src/components/data-table-filter/data-table-filter.tsx
/**
* The intent once the add menu opens, whatever came before: the menu shows a field, so that field
* is active. A menu record that is not queued is a drill asked for with this open, so it stays.
* Otherwise a drill the menu still shows from before, such as one its interrupted exit kept,
* becomes active, and with no drill the field list shows and no field is active. A queued editor,
* a cleared record and another chip's open editor all give way.
*
* @param current - The intent before the menu opened.
* @param drilled - The drill the menu shows, if any.
* @returns The intent.
*/
function intentOnMenuOpen(current, drilled) {
	if (current?.owner === "menu" && !current.queued) return current;
	return drilled === null ? null : {
		field: drilled,
		owner: "menu",
		queued: false
	};
}
/**
* The focus request once the add menu opens. A drill's request that is already there stays, a
* fresh drill's included. A drill the menu still shows from before asks for focus again, since a
* chip's editor opened during the menu's exit replaced its request. With no drill, the field list
* shows, and Base UI focuses its search. A drill's other state needs no restoring: `drillOrigin`
* changes only with `drilled`, and `returnTo` is null whenever `drilled` is set.
*
* @param current - The focus request before the menu opened.
* @param drilled - The drill the menu shows, if any.
* @returns The focus request.
*/
function focusOnMenuOpen(current, drilled) {
	if (current?.startsWith("drill:") === true || drilled === null) return current;
	return drillKey(drilled);
}
/**
* Where focus goes when a chip goes: the next chip's first segment, else the previous chip's last,
* else the Trigger.
*/
function neighbourTarget(list, index) {
	const next = list[index + 1];
	if (next !== void 0) return {
		chip: next.id,
		edge: "first"
	};
	const previous = list[index - 1];
	return previous === void 0 ? { trigger: true } : {
		chip: previous.id,
		edge: "last"
	};
}
function moveTo(entries, id, index) {
	const entry = entries.find((item) => item.id === id);
	if (entry === void 0) return entries;
	const rest = entries.filter((item) => item.id !== id);
	rest.splice(Math.min(index, rest.length), 0, entry);
	return rest;
}
/**
* The filter's state, which renders no element. It reads and writes the table's `columnFilters`
* through `table.setColumnFilters`, so controlled and uncontrolled state come from the table's own
* options. Render the Bar, `Content` and `ValueContent` inside it as siblings, and anything else
* that reads the filter, such as a `Clear` in the table's empty state.
*
* @template TFields - The fields map, from `defineFilterFields`.
*/
function DataTableFilterRoot({ table, fields, facets, timeZone, formatOperator, onActiveFieldChange, children }) {
	const strings = useLocalizedStrings(dataTableFilterStrings);
	const { locale } = useLocale();
	const filtersAtom = table.atoms.columnFilters;
	const subscribe = useCallback((onChange) => {
		const subscription = filtersAtom.subscribe(() => {
			onChange();
		});
		return () => {
			subscription.unsubscribe();
		};
	}, [filtersAtom]);
	const getSnapshot = useCallback(() => filtersAtom.get(), [filtersAtom]);
	const columnFilters = useSyncExternalStore(subscribe, getSnapshot, getSnapshot);
	const filters = viewColumnFilters(columnFilters, fields);
	const knownFacets = facets;
	const [menuHandle] = useState(() => Menu.createHandle());
	const [valueHandle] = useState(() => Popover.createHandle());
	const [editing, setEditing] = useState(null);
	const [ghost, setGhost] = useState(null);
	const [intent, setIntent] = useState(null);
	const [focusRequest, setFocusRequest] = useState(null);
	const [drilled, setDrilled] = useState(null);
	const [drillOrigin, setDrillOrigin] = useState("list");
	const [returnTo, setReturnTo] = useState(null);
	const pendingFocus = useRef(null);
	const segments = useRef(/* @__PURE__ */ new Map());
	const registerSegment = useCallback((fieldId, element) => {
		const set = segments.current.get(fieldId) ?? /* @__PURE__ */ new Set();
		set.add(element);
		segments.current.set(fieldId, set);
		return () => {
			set.delete(element);
		};
	}, []);
	const drafts = useRef(/* @__PURE__ */ new Map());
	const registerDraft = useCallback((key, owner) => {
		drafts.current.set(key, owner);
		return () => {
			if (drafts.current.get(key) === owner) drafts.current.delete(key);
		};
	}, []);
	const applyDrafts = () => {
		for (const owner of [...drafts.current.values()]) owner.settle();
	};
	const discardDrafts = (keys) => {
		for (const [key, owner] of drafts.current) if (keys === null || keys.includes(key)) owner.discard();
	};
	const keysOf = (fieldId) => fieldId === null ? null : [editKey(fieldId), drillKey(fieldId)];
	/**
	* A press on Clear, or on a chip's Remove, ends the editing sessions it is about to remove, in
	* the button's own capture handlers. That runs before the press blurs the editor, before Base UI
	* dismisses the overlay, and before any settle, so the button's click makes the one write. A
	* press that slides off before its click therefore drops the unapplied draft, and the applied
	* filter stays as it was.
	*/
	const discardEditors = (fieldId) => {
		discardDrafts(keysOf(fieldId));
		setIntent((current) => current !== null && (fieldId === null || current.field === fieldId) ? null : current);
		if (fieldId === null || drilled === fieldId) menuHandle.close();
		if (fieldId === null || editing === fieldId) valueHandle.close();
	};
	const [openCount, setOpenCount] = useState(0);
	const rootId = useId();
	const contentRegistered = useRef(false);
	const valueContentRegistered = useRef(false);
	const registerContent = useCallback(() => {
		contentRegistered.current = true;
		return () => {
			contentRegistered.current = false;
		};
	}, []);
	const registerValueContent = useCallback(() => {
		valueContentRegistered.current = true;
		return () => {
			valueContentRegistered.current = false;
		};
	}, []);
	const chipElements = useRef(/* @__PURE__ */ new Map());
	const triggerRef = useRef(null);
	const registerChip = useCallback((fieldId, element) => {
		if (element === null) chipElements.current.delete(fieldId);
		else chipElements.current.set(fieldId, element);
	}, []);
	const registerTrigger = useCallback((element) => {
		triggerRef.current = element;
	}, []);
	const overlays = useRef({
		menu: /* @__PURE__ */ new Set(),
		value: /* @__PURE__ */ new Set()
	});
	const registerOverlay = useCallback((kind, element) => {
		const set = overlays.current[kind];
		set.add(element);
		return () => {
			set.delete(element);
		};
	}, []);
	const chipElement = useCallback((fieldId) => chipElements.current.get(fieldId) ?? null, []);
	const valueElement = useCallback((fieldId) => chipElement(fieldId)?.querySelector("[data-slot=data-table-filter-value]") ?? null, [chipElement]);
	const triggerElement = useCallback(() => triggerRef.current, []);
	const valueId = useCallback((fieldId) => `${rootId}value-${fieldId}`, [rootId]);
	const triggerId = `${rootId}trigger`;
	const chips = filters.flatMap((entry) => {
		const field = fields[entry.id];
		return field === void 0 ? [] : [{
			id: entry.id,
			value: entry.value,
			field,
			ghost: false
		}];
	});
	if (editing !== null && ghost?.id === editing && !chips.some((chip) => chip.id === editing)) {
		const field = fields[ghost.id];
		if (field !== void 0) chips.splice(Math.min(ghost.index, chips.length), 0, {
			id: ghost.id,
			value: ghost.value,
			field,
			ghost: true
		});
	}
	/**
	* One user decision, one `setColumnFilters` call. The updater reads TanStack's latest state, so
	* two quick toggles never lose one. Entries for columns that are not fields stay as they are.
	*/
	const commit = (reducer) => {
		const preview = reducer(filters);
		if (editing !== null) {
			const index = filters.findIndex((entry) => entry.id === editing);
			const kept = preview.some((entry) => entry.id === editing);
			const before = filters[index];
			if (before !== void 0 && !kept) setGhost({
				id: editing,
				value: before.value,
				index
			});
			else if (index === -1 && kept && ghost?.id === editing) setGhost(null);
		}
		const refill = editing !== null && ghost?.id === editing ? ghost : null;
		table.setColumnFilters((previous) => {
			const foreign = previous.filter((entry) => !Object.hasOwn(fields, entry.id));
			let next = reducer(viewColumnFilters(previous, fields));
			if (refill !== null && !previous.some((entry) => entry.id === refill.id)) next = moveTo(next, refill.id, refill.index);
			return [...foreign, ...next];
		});
	};
	const facetReader = createFacetReader(table, fields, knownFacets);
	const focusTarget = (target) => "trigger" in target ? focusEdge(void 0, "first", triggerElement()) : focusEdge(segments.current.get(target.chip), target.edge, triggerElement());
	const neighbourOf = (list, index) => focusTarget(neighbourTarget(list, index));
	useLayoutEffect(() => {
		const target = pendingFocus.current;
		if (target === null) return;
		pendingFocus.current = null;
		focusTarget(target);
	});
	/**
	* The one way into a chip's editor, for a press on its Value and for `edit()` alike. The editor it
	* leaves settles its draft, the field becomes the intent, a ghost of another field goes, and the
	* new editor takes focus: through the popover's `initialFocus` on an opening, and through a focus
	* request when the open popover moves to another chip, since Base UI does not run initial focus
	* again for a new trigger. A press opens or moves the popover through Base UI. From code, the
	* chip scrolls into view first, because the popover anchors to it and the bar's strip may hide
	* it, and then the handle opens on it. `handle.open(id)` throws for a trigger id nothing
	* registered (`popupHandle.ts`), so code enters only a chip whose Value is mounted.
	*/
	const enterEditor = (fieldId, via) => {
		if (via === "code" && valueElement(fieldId) === null) return;
		applyDrafts();
		setEditing(fieldId);
		setIntent({
			field: fieldId,
			owner: "value",
			queued: false
		});
		setGhost((current) => current?.id === fieldId ? current : null);
		setFocusRequest(valueHandle.isOpen ? editKey(fieldId) : null);
		if (via === "code") {
			chipElement(fieldId)?.scrollIntoView({
				block: "nearest",
				inline: "nearest"
			});
			valueHandle.open(valueId(fieldId));
		}
	};
	const activeField = intent?.field ?? null;
	const activeFieldListener = useRef(onActiveFieldChange);
	useLayoutEffect(() => {
		activeFieldListener.current = onActiveFieldChange;
	});
	const reportedField = useRef(activeField);
	useEffect(() => {
		if (reportedField.current !== activeField) {
			reportedField.current = activeField;
			activeFieldListener.current?.(activeField);
		}
	}, [activeField]);
	/**
	* The add menu's field list gives way to a field's editor, which takes focus as it mounts. An
	* open value submenu unmounts with the field list without reporting a close.
	*/
	const drill = (fieldId, origin) => {
		setDrilled(fieldId);
		setDrillOrigin(origin);
		setReturnTo(null);
		setIntent({
			field: fieldId,
			owner: "menu",
			queued: false
		});
		setFocusRequest(drillKey(fieldId));
	};
	const value = {
		state: {
			filters,
			chips,
			editing,
			drilled
		},
		actions: {
			toggle: (fieldId, optionValue) => {
				const field = fields[fieldId];
				if (field?.kind === "boolean") {
					if (optionValue === "true" || optionValue === "false") {
						const picked = optionValue === "true";
						commit((state) => toggleBoolean(state, fieldId, field, picked, firstOperator(field)));
					}
					return;
				}
				if (field?.kind !== "option" && field?.kind !== "multiOption") return;
				commit((state) => toggleOption(state, fieldId, field, optionValue, firstOperator(field)));
			},
			setValues: (fieldId, operator, values) => {
				const field = fields[fieldId];
				if (field === void 0) return;
				commit((state) => setFilterValues(state, fieldId, field, operator, values));
			},
			setOperator: (fieldId, operator) => {
				const field = fields[fieldId];
				if (field === void 0) return;
				const upper = field.kind === "number" ? facetReader.range(fieldId)?.[1] : void 0;
				const after = findFilter(setFilterOperator(filters, fieldId, field, operator, upper), fieldId);
				if (findFilter(filters, fieldId) !== void 0 && after === void 0) {
					value.actions.remove(fieldId);
					return;
				}
				if (isToggleOn(field, after)) pendingFocus.current = {
					chip: fieldId,
					edge: "last"
				};
				commit((state) => setFilterOperator(state, fieldId, field, operator, upper));
			},
			remove: (fieldId) => {
				discardEditors(fieldId);
				if (findFilter(filters, fieldId) === void 0) return;
				pendingFocus.current = neighbourTarget(chips, chips.findIndex((chip) => chip.id === fieldId));
				commit((state) => removeFilter(state, fieldId));
			},
			clear: () => {
				pendingFocus.current = { trigger: true };
				discardDrafts(null);
				setIntent(null);
				menuHandle.close();
				valueHandle.close();
				commit(() => []);
			},
			edit: (fieldId) => {
				const field = fields[fieldId];
				if (field === void 0 || isToggleOn(field, findFilter(filters, fieldId))) return;
				applyDrafts();
				if (chips.some((chip) => chip.id === fieldId)) {
					if (menuHandle.isOpen || intent?.queued === true) {
						setIntent({
							field: fieldId,
							owner: "value",
							queued: true
						});
						menuHandle.close();
						return;
					}
					enterEditor(fieldId, "code");
					return;
				}
				if (isListField(field)) return;
				drill(fieldId, "edit");
				if (!menuHandle.isOpen) menuHandle.open(triggerId);
			},
			close: () => {
				applyDrafts();
				setIntent(null);
				menuHandle.close();
				valueHandle.close();
			}
		},
		meta: {
			fields,
			facets: facetReader,
			timeZone,
			formatOperator: (operator, kind, fieldId) => formatOperator?.(operator, kind, fieldId) ?? strings.format(`${kind}.${operator}`)
		}
	};
	const internals = {
		state: {
			...value.state,
			focusRequest,
			drillOrigin,
			returnTo,
			openCount
		},
		actions: {
			...value.actions,
			beginEdit: (fieldId) => {
				enterEditor(fieldId, "press");
			},
			drill: (fieldId) => {
				drill(fieldId, "list");
			},
			back: () => {
				applyDrafts();
				setReturnTo(drilled);
				setDrilled(null);
				setIntent((current) => current?.owner === "menu" ? null : current);
				setFocusRequest(null);
			},
			clearReturnTo: () => {
				setReturnTo(null);
			},
			setOptions: (fieldId, values) => {
				const field = fields[fieldId];
				if (field?.kind !== "option" && field?.kind !== "multiOption") return;
				commit((state) => setOptionValues(state, fieldId, field, values, firstOperator(field)));
			},
			clearValues: (fieldId) => {
				commit((state) => removeFilter(state, fieldId));
			},
			setSubmenuOpen: (fieldId, open) => {
				if (open) {
					setIntent({
						field: fieldId,
						owner: "menu",
						queued: false
					});
					return;
				}
				setIntent((current) => current?.owner === "menu" && current.field === fieldId ? null : current);
			},
			settleMenu: () => {
				setDrilled(null);
				setReturnTo(null);
				setFocusRequest((current) => current?.startsWith("drill:") === true ? null : current);
				setIntent((current) => current?.owner === "menu" || current?.queued === true ? null : current);
				if (intent?.queued === true) enterEditor(intent.field, "code");
			},
			settleValue: () => {
				setIntent((current) => current?.owner === "value" && !current.queued && current.field === editing ? null : current);
				setEditing(null);
				setGhost(null);
				setFocusRequest(null);
			},
			applyDrafts,
			discardEditors,
			noteOpen: (overlay) => {
				setOpenCount((count) => count + 1);
				if (overlay === "menu") {
					setIntent((current) => intentOnMenuOpen(current, drilled));
					setFocusRequest((current) => focusOnMenuOpen(current, drilled));
				}
			},
			registerDraft,
			registerSegment,
			registerContent,
			registerValueContent,
			registerChip,
			registerTrigger,
			registerOverlay
		},
		meta: {
			...value.meta,
			menuHandle,
			valueHandle,
			locale,
			format: (key, vars) => strings.format(key, vars),
			triggerId,
			valueId,
			chipElement,
			hasContent: () => contentRegistered.current,
			hasValueContent: () => valueContentRegistered.current,
			neighbourOf,
			focusChipEdge: (chip, edge) => focusTarget({
				chip,
				edge
			}),
			focusLeft: (kind, popup) => focusMovedElsewhere(popup, [...overlays.current[kind], ...chips.flatMap((chip) => {
				const element = chip.ghost ? chipElement(chip.id) : null;
				return element === null ? [] : [element];
			})])
		}
	};
	return /* @__PURE__ */ jsx(DataTableFilterContext, {
		value,
		children: /* @__PURE__ */ jsx(DataTableFilterInternalContext, {
			value: internals,
			children
		})
	});
}
DataTableFilterRoot.displayName = "DataTableFilter.Root";
export { DataTableFilterRoot };

//# sourceMappingURL=data-table-filter.js.map