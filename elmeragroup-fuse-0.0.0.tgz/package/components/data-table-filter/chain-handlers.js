// src/components/data-table-filter/chain-handlers.ts
/**
* Runs the part's own handler after the consumer's, unless the consumer prevented it.
*
* @param own - The part's handler.
* @param theirs - The consumer's handler, if any.
* @returns The chained handler.
*/
function chain(own, theirs) {
	return (event) => {
		theirs?.(event);
		if (!event.defaultPrevented) own(event);
	};
}
export { chain };

//# sourceMappingURL=chain-handlers.js.map