"use client";
import { CaretDown } from "../../icons/generated/caret-down.js";
import { cn } from "../../styles/cn.js";
import { selfFocusRingClass } from "../../styles/utils.js";
import { useMergedRefs } from "../../hooks/use-merged-refs.js";
import { mergeClassName } from "../../styles/merge-class-name.js";
import { definedProps } from "../../internal/defined-props.js";
import { Button } from "../button/button.js";
import { overlayPositionerClass, overlayTimedPopupClass } from "../overlay/overlay-classes.js";
import { OverlayPortal } from "../overlay/overlay-portal.js";
import { CaretLeft } from "../../icons/generated/caret-left.js";
import { DataTableFilterCompositionError } from "./data-table-filter-error.js";
import { resolveFocusTarget } from "./filter-focus.js";
import { EditorTargetContext, drillKey, editKey, useFilterInternals, useOverlayRef } from "./data-table-filter-context.js";
import { EditorContext, useCompositionGuard } from "./data-table-filter-editor-context.js";
import { dataTableFilterSlots } from "./data-table-filter-variants.js";
import { convertValues, filterValuesEqual, findFilter, isToggleOn } from "./filter-model.js";
import { isListField } from "./option-list.js";
import { draftFor, draftSays, draftWrite } from "./editor-draft.js";
import { DataTableFilterDateEditor, DataTableFilterNumberEditor, DataTableFilterOptionEditor, DataTableFilterTextEditor } from "./data-table-filter-editors.js";
import { popoverShellClass } from "../../styles/inner-corner/popover.js";
import { SelectRoot as SelectRoot$1 } from "../select/select.js";
import { OperatorOptions, useOperatorItems } from "./operator-options.js";
import { use, useCallback, useId, useLayoutEffect, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { Popover } from "@base-ui/react/popover";
import { Select } from "@base-ui/react/select";
// src/components/data-table-filter/data-table-filter-value-content.tsx
/**
* The value popover every chip's Value opens, anchored below the whole chip at a fixed width. It
* is named by the editor's title. Focus moves to the editor's first control as it opens and back
* to the chip's Value as it closes. A ghost chip's focus goes to its neighbour instead, since the
* ghost leaves. A press on another chip's Value moves the popover there: it glides, its height
* morphs and the editors cross-fade.
*/
function DataTableFilterValueContent({ className, children, ref, ...props }) {
	const { state, actions, meta } = useFilterInternals("DataTableFilter.ValueContent");
	const { registerValueContent } = actions;
	useLayoutEffect(registerValueContent, [registerValueContent]);
	const popupRef = useRef(null);
	const overlayRef = useOverlayRef(actions.registerOverlay, "value");
	const popupRefs = useMergedRefs(ref, useMergedRefs(popupRef, overlayRef));
	const field = state.editing === null ? void 0 : meta.fields[state.editing];
	const anchor = state.editing === null ? null : meta.chipElement(state.editing);
	const target = {
		place: "popover",
		fieldId: state.editing
	};
	return /* @__PURE__ */ jsx(Popover.Root, {
		handle: meta.valueHandle,
		onOpenChange: (open) => {
			if (open) actions.noteOpen("value");
			else actions.applyDrafts();
		},
		onOpenChangeComplete: (open) => {
			if (!open) actions.settleValue();
		},
		children: /* @__PURE__ */ jsx(OverlayPortal, {
			portal: Popover.Portal,
			children: /* @__PURE__ */ jsx(Popover.Positioner, {
				"data-slot": "data-table-filter-positioner",
				side: "bottom",
				align: "start",
				sideOffset: 4,
				collisionPadding: 8,
				...definedProps({ anchor: anchor ?? void 0 }),
				className: cn(overlayPositionerClass, dataTableFilterSlots.positioner()),
				children: /* @__PURE__ */ jsx(Popover.Popup, {
					ref: popupRefs,
					"data-slot": "data-table-filter-value-content",
					"data-kind": field?.kind,
					initialFocus: () => {
						const popup = popupRef.current;
						if (popup === null) return true;
						const current = popup.querySelector("[data-current]") ?? popup;
						return resolveFocusTarget(current) ?? true;
					},
					finalFocus: () => {
						if (meta.focusLeft("value", popupRef.current)) return false;
						const index = state.chips.findIndex((chip) => chip.ghost);
						if (index !== -1) return meta.neighbourOf(state.chips, index) ?? true;
						const edited = state.chips.find((chip) => chip.id === state.editing);
						return edited !== void 0 && isToggleOn(edited.field, edited.value) ? meta.focusChipEdge(edited.id, "last") ?? true : true;
					},
					className: mergeClassName(className, selfFocusRingClass, overlayTimedPopupClass, popoverShellClass, dataTableFilterSlots.content()),
					...props,
					children: /* @__PURE__ */ jsx(Popover.Viewport, {
						"data-slot": "data-table-filter-viewport",
						className: dataTableFilterSlots.viewport(),
						children: /* @__PURE__ */ jsx(EditorTargetContext, {
							value: target,
							children: children ?? /* @__PURE__ */ jsx(DefaultEditor, {})
						})
					})
				})
			})
		})
	});
}
/** What `<DataTableFilter.ValueContent />` renders without children. */
function DefaultEditor() {
	return /* @__PURE__ */ jsxs(DataTableFilterEditor, { children: [
		/* @__PURE__ */ jsx(DataTableFilterOptionEditor, {}),
		/* @__PURE__ */ jsx(DataTableFilterTextEditor, {}),
		/* @__PURE__ */ jsx(DataTableFilterNumberEditor, {}),
		/* @__PURE__ */ jsx(DataTableFilterDateEditor, {})
	] });
}
/**
* A field's editor in whichever overlay renders it: the value popover for a chip, or the add menu
* in place of its field list. Its header holds the field's name and, for text, number and date
* fields, the operator. In the add menu it also starts with a Back button, it is a group named by
* its title, and it keeps every key but Tab from the menu. The kind editors are its children, and
* each renders only for its own kinds. A move to another field mounts it fresh.
*/
function DataTableFilterEditor({ className, children, ...props }) {
	const { state, meta } = useFilterInternals("DataTableFilter.Editor");
	const target = use(EditorTargetContext);
	if (target === null) throw new DataTableFilterCompositionError("DataTableFilter.Editor", "outside-overlay");
	const { fieldId } = target;
	const field = fieldId === null ? void 0 : meta.fields[fieldId];
	if (fieldId === null || field === void 0) return null;
	const key = target.place === "menu" ? drillKey(fieldId) : editKey(fieldId);
	return /* @__PURE__ */ jsx(EditorFrame, {
		fieldId,
		field,
		focusKey: key,
		target,
		className,
		...props,
		children
	}, `${key}:${String(state.openCount)}`);
}
/**
* Keeps keys typed in the menu's in-place editor inside it. The menu popup's own handlers would
* take them otherwise. Its list navigation prevents Home and End and moves its highlight on the
* arrows (`useListNavigation.ts`), its dismissal closes the whole menu on Escape
* (`useDismiss.ts`), and the toolbar relay takes the rest. All of them sit on the popup or the
* document, so a stop at the editor reaches them first. A popup inside the editor, such as the
* operator's Select, stops its own Escape before this sees it. Escape goes back to the field list.
* Tab passes, so focus moves on and leaves the menu as it does from the search.
*/
function keepKeysInEditor(event, back, composing) {
	if (event.key === "Tab") return;
	if (event.key === "Escape" && !composing) {
		event.preventDefault();
		back();
	}
	event.stopPropagation();
}
function EditorFrame({ fieldId, field, focusKey, target, className, children, onKeyDown, onCompositionStart, onCompositionEnd, ...props }) {
	const { state, actions, meta } = useFilterInternals("DataTableFilter.Editor");
	const titleId = useId();
	const filter = findFilter(state.filters, fieldId);
	const range = meta.facets.range(fieldId);
	const [draft, setDraftState] = useState(() => draftFor(field, filter, range));
	const [seenFilter, setSeenFilter] = useState(filter);
	if (!filterValuesEqual(seenFilter, filter)) {
		setSeenFilter(filter);
		if (!draftSays(field.kind, draft, filter)) setDraftState(draftFor(field, filter, range));
	}
	const latest = useRef({
		draft,
		filter,
		range
	});
	useLayoutEffect(() => {
		latest.current = {
			draft,
			filter,
			range
		};
	});
	const settled = useRef(null);
	const ended = useRef(false);
	const write = useCallback((next) => {
		latest.current = {
			...latest.current,
			draft: next
		};
		setDraftState(next);
	}, []);
	const setDraft = useCallback((next) => {
		if (ended.current) return;
		write({
			operator: next.operator,
			values: next.values,
			edited: true
		});
	}, [write]);
	const updateDraft = useCallback((change) => {
		setDraft(change(latest.current.draft));
	}, [setDraft]);
	const { registerDraft } = actions;
	const setValues = useRef(actions.setValues);
	useLayoutEffect(() => {
		setValues.current = actions.setValues;
	});
	const settle = useCallback(() => {
		const current = latest.current;
		if (ended.current || settled.current === current.draft) return;
		settled.current = current.draft;
		const next = draftWrite(field.kind, current.draft, current.filter, current.range);
		if (next !== void 0) setValues.current(fieldId, next.operator, next.values);
	}, [field.kind, fieldId]);
	const commitDraft = useCallback((change) => {
		updateDraft(change);
		settle();
	}, [updateDraft, settle]);
	const discard = useCallback(() => {
		ended.current = true;
		settled.current = latest.current.draft;
	}, []);
	useLayoutEffect(() => registerDraft(focusKey, {
		settle,
		discard
	}), [
		registerDraft,
		focusKey,
		settle,
		discard
	]);
	const changeOperator = (operator) => {
		const current = latest.current;
		const upper = field.kind === "number" ? current.range?.[1] : void 0;
		const values = convertValues(field.kind, current.draft.operator, operator, current.draft.values, upper);
		if (ended.current) return;
		write({
			operator,
			values,
			edited: current.draft.edited
		});
		settle();
	};
	const back = target.place === "menu" ? target.back : void 0;
	const composition = useCompositionGuard();
	const editor = {
		fieldId,
		field,
		filter,
		draft,
		setDraft,
		updateDraft,
		commitDraft,
		settle,
		changeOperator,
		focusKey,
		back,
		isComposing: composition.isComposing
	};
	const operatorInHeader = !isListField(field);
	const title = /* @__PURE__ */ jsxs(Fragment$1, { children: [field.icon === void 0 ? null : /* @__PURE__ */ jsx("span", {
		"aria-hidden": true,
		className: "contents",
		children: field.icon
	}), /* @__PURE__ */ jsx("span", {
		className: dataTableFilterSlots.titleText(),
		children: field.label
	})] });
	return /* @__PURE__ */ jsx(EditorContext, {
		value: editor,
		children: /* @__PURE__ */ jsxs("div", {
			"data-slot": "data-table-filter-editor",
			"data-kind": field.kind,
			"data-place": target.place,
			role: "group",
			...definedProps({ "aria-labelledby": back === void 0 ? void 0 : titleId }),
			className: cn(dataTableFilterSlots.editor(), back === void 0 ? void 0 : dataTableFilterSlots.menuEditor(), className),
			onCompositionStart: (event) => {
				onCompositionStart?.(event);
				composition.onCompositionStart();
			},
			onCompositionEnd: (event) => {
				onCompositionEnd?.(event);
				composition.onCompositionEnd();
			},
			onKeyDown: (event) => {
				onKeyDown?.(event);
				if (back !== void 0 && !event.isPropagationStopped()) keepKeysInEditor(event, back, composition.isComposing(event));
			},
			...props,
			children: [/* @__PURE__ */ jsxs("div", {
				"data-slot": "data-table-filter-header",
				className: dataTableFilterSlots.header(),
				children: [back === void 0 ? /* @__PURE__ */ jsx(Popover.Title, {
					className: dataTableFilterSlots.title(),
					children: title
				}) : /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(Button, {
					"data-slot": "data-table-filter-back",
					variant: "ghost",
					size: "icon-sm",
					"aria-label": meta.format("back"),
					className: dataTableFilterSlots.back(),
					onClick: back,
					onKeyDown: (event) => {
						if (event.key === "Tab" && event.shiftKey) {
							event.preventDefault();
							actions.close();
						}
					},
					children: /* @__PURE__ */ jsx(CaretLeft, { "aria-hidden": true })
				}), /* @__PURE__ */ jsx("span", {
					id: titleId,
					className: dataTableFilterSlots.title(),
					children: title
				})] }), operatorInHeader ? /* @__PURE__ */ jsx(EditorOperator, {
					editor,
					host: target.place === "menu" ? "menu" : "value"
				}) : null]
			}), /* @__PURE__ */ jsx("div", {
				"data-slot": "data-table-filter-editor-body",
				className: dataTableFilterSlots.editorBody(),
				children
			})]
		})
	});
}
/**
* The header's operator for text, number and date fields. It lists the operators the field
* allows, and the operator decides the editor's shape, one value or a range. A pick converts the
* editor's current draft, typed text included, and applies the pair in one write. An untouched
* draft only changes shape. Its trigger has the chip operator's face, a ghost Fuse Button.
*/
function EditorOperator({ editor, host }) {
	const { actions, meta } = useFilterInternals("DataTableFilter.Editor");
	const overlayRef = useOverlayRef(actions.registerOverlay, host);
	const { field, draft } = editor;
	const items = useOperatorItems("DataTableFilter.Editor", field, editor.fieldId, editor.filter, draft.operator);
	return /* @__PURE__ */ jsxs(SelectRoot$1, {
		items,
		value: draft.operator,
		modal: false,
		onValueChange: (operator) => {
			if (operator !== null) editor.changeOperator(operator);
		},
		children: [/* @__PURE__ */ jsxs(Select.Trigger, {
			"data-slot": "data-table-filter-editor-operator",
			"aria-label": meta.format("operatorLabel", { field: field.label }),
			render: /* @__PURE__ */ jsx(Button, {
				variant: "ghost",
				size: "sm"
			}),
			className: dataTableFilterSlots.headerOperator(),
			children: [/* @__PURE__ */ jsx(Select.Value, {}), /* @__PURE__ */ jsx(CaretDown, {
				"data-icon": "inline-end",
				"aria-hidden": true
			})]
		}), /* @__PURE__ */ jsx(OperatorOptions, {
			ref: overlayRef,
			items,
			align: "end"
		})]
	});
}
DataTableFilterValueContent.displayName = "DataTableFilter.ValueContent";
DataTableFilterEditor.displayName = "DataTableFilter.Editor";
export { DataTableFilterEditor, DataTableFilterValueContent, DefaultEditor };

//# sourceMappingURL=data-table-filter-value-content.js.map