"use client";
import { DataTableFilterCompositionError } from "./data-table-filter-error.js";
import { createContext, use, useCallback, useEffect, useRef } from "react";
// src/components/data-table-filter/data-table-filter-editor-context.ts
/**
* Tracks IME composition inside the editor. A key pressed while composing confirms the
* composition, not the editor. Safari fires `compositionend` before the keydown that ends the
* composition, with `isComposing` already false, so the guard stays up for 5 ms after it, as Base
* UI's dismissal does (`useDismiss.ts`).
*
* @returns The composition handlers for the editor's element, and the key test.
*/
function useCompositionGuard() {
	const composing = useRef(false);
	const timer = useRef(void 0);
	useEffect(() => () => {
		clearTimeout(timer.current);
	}, []);
	return {
		onCompositionStart: useCallback(() => {
			clearTimeout(timer.current);
			composing.current = true;
		}, []),
		onCompositionEnd: useCallback(() => {
			composing.current = true;
			clearTimeout(timer.current);
			timer.current = setTimeout(() => {
				composing.current = false;
			}, 5);
		}, []),
		isComposing: useCallback((event) => composing.current || event.nativeEvent.isComposing, [])
	};
}
/** Provided by `DataTableFilter.Editor` for its kind editors. */
const EditorContext = createContext(null);
/**
* The editor a kind editor renders in, when the edited field has one of its kinds.
*
* @template K - The kinds the editor handles.
* @param part - The kind editor's name, for the error.
* @param kinds - The kinds the editor handles.
* @returns The editor narrowed to those kinds, or null when the edited field has another kind.
*/
function useKindEditor(part, kinds) {
	const editor = use(EditorContext);
	if (editor === null) throw new DataTableFilterCompositionError(part, "outside-editor");
	if (!isFieldOfKinds(editor.field, kinds)) return null;
	return {
		...editor,
		field: editor.field
	};
}
function isFieldOfKinds(field, kinds) {
	return kinds.includes(field.kind);
}
export { EditorContext, useCompositionGuard, useKindEditor };

//# sourceMappingURL=data-table-filter-editor-context.js.map