import { isBoolean, isFiniteNumber, isIsoDate, isNegated, isString } from "./filter-model.js";
// src/components/data-table-filter/filter-match.ts
/**
* Lower case with accents removed, so "Café" matches "cafe". A letter of its own, such as `ø`,
* stays.
*
* @param text - The text to normalize.
* @returns The normalized text.
*/
function normalizeText(text) {
	return text.normalize("NFD").replace(/\p{M}/gu, "").toLowerCase();
}
const dayFormatters = /* @__PURE__ */ new Map();
/**
* The calendar day an instant falls on in a time zone.
*
* @param date - The instant.
* @param timeZone - The zone, or undefined for the runtime zone.
* @returns The day as `YYYY-MM-DD`.
*/
function calendarDateIn(date, timeZone) {
	if (timeZone === void 0) {
		const month = String(date.getMonth() + 1).padStart(2, "0");
		const day = String(date.getDate()).padStart(2, "0");
		return `${date.getFullYear()}-${month}-${day}`;
	}
	let formatter = dayFormatters.get(timeZone);
	if (formatter === void 0) {
		formatter = new Intl.DateTimeFormat("en-CA", {
			timeZone,
			year: "numeric",
			month: "2-digit",
			day: "2-digit"
		});
		dayFormatters.set(timeZone, formatter);
	}
	let year = "";
	let month = "";
	let day = "";
	for (const part of formatter.formatToParts(date)) if (part.type === "year") year = part.value;
	else if (part.type === "month") month = part.value;
	else if (part.type === "day") day = part.value;
	return `${year}-${month}-${day}`;
}
const needles = /* @__PURE__ */ new WeakMap();
const pickedSets = /* @__PURE__ */ new WeakMap();
function prepared(cache, value, prepare) {
	let result = cache.get(value);
	if (result === void 0) {
		result = prepare();
		cache.set(value, result);
	}
	return result;
}
/** The picked option values as a set. */
function pickedOf(value) {
	return prepared(pickedSets, value, () => new Set(value.values));
}
/**
* Whether a multi-option cell holds any of the picked values, or with `all`, every one of them.
* One walk over the cell, and only the "every" check allocates.
*/
function holdsPicked(cell, picked, all) {
	const items = Array.isArray(cell) ? cell : [];
	if (!all) return items.some((item) => isString(item) && picked.has(item));
	const held = /* @__PURE__ */ new Set();
	for (const item of items) if (isString(item) && picked.has(item)) held.add(item);
	return held.size === picked.size;
}
/**
* Number and date operators, over numbers or ISO dates, which order the same way as text. A
* negated operator answers its positive twin, which the caller inverts.
*/
function compareOrdered(operator, cell, values) {
	const [first, second] = values;
	if (first === void 0) return false;
	switch (operator) {
		case "is":
		case "isNot": return cell === first;
		case "isGreaterThan":
		case "isAfter": return cell > first;
		case "isGreaterThanOrEqual":
		case "isOnOrAfter": return cell >= first;
		case "isLessThan":
		case "isBefore": return cell < first;
		case "isLessThanOrEqual":
		case "isOnOrBefore": return cell <= first;
		case "isBetween":
		case "isNotBetween": return second !== void 0 && cell >= first && cell <= second;
	}
}
/**
* Whether one cell passes a filter. Option values compare exactly. Text compares case- and
* accent-insensitively, anywhere in the cell or, for `startsWith`, at its start. A `Date` cell
* compares as its calendar day in `timeZone`, and an ISO date string compares as it is. A boolean
* compares `true` and `false` exactly, and any other cell counts as missing. A missing cell passes
* only the negated operators.
*
* @param value - The filter.
* @param cell - The row's value in the filtered column.
* @param options - The time zone for date cells.
* @returns Whether the row passes.
*/
function matchesFilter(value, cell, options = {}) {
	const hit = cell !== null && cell !== void 0 && cellHolds(value, cell, options);
	return isNegated(value.kind, value.operator) ? !hit : hit;
}
/** Whether a present cell holds the filter's values, read in the operator's positive sense. */
function cellHolds(value, cell, options) {
	switch (value.kind) {
		case "option": return isString(cell) && pickedOf(value).has(cell);
		case "multiOption": {
			const all = value.operator === "includesAllOf" || value.operator === "excludesAllOf";
			return holdsPicked(cell, pickedOf(value), all);
		}
		case "text": {
			const text = isString(cell) ? cell : isFiniteNumber(cell) ? String(cell) : null;
			if (text === null) return false;
			const haystack = normalizeText(text);
			const needle = prepared(needles, value, () => normalizeText(value.values[0]));
			return value.operator === "startsWith" || value.operator === "doesNotStartWith" ? haystack.startsWith(needle) : haystack.includes(needle);
		}
		case "number": return isFiniteNumber(cell) && compareOrdered(value.operator, cell, value.values);
		case "date": {
			const day = cell instanceof Date && !Number.isNaN(cell.getTime()) ? calendarDateIn(cell, options.timeZone) : isIsoDate(cell) ? cell : null;
			return day !== null && compareOrdered(value.operator, day, value.values);
		}
		case "boolean": return isBoolean(cell) && cell === value.values[0];
	}
}
export { calendarDateIn, matchesFilter, normalizeText };

//# sourceMappingURL=filter-match.js.map