"use client";
import { isThemeDevelopment } from "../../theme/validate-theme.js";
import { DataTableFilterCompositionError } from "./data-table-filter-error.js";
import { resolveFocusTarget } from "./filter-focus.js";
import { createContext, use, useCallback, useLayoutEffect, useRef, useState } from "react";
// src/components/data-table-filter/data-table-filter-context.ts
/** The public context the Root provides. */
const DataTableFilterContext = createContext(null);
/** The library parts' context the Root provides. */
const DataTableFilterInternalContext = createContext(null);
/** The chip a part renders in, provided by `Chips` per chip. */
const ChipContext = createContext(null);
/** Tells `Clear` it renders in the Bar, so it joins the toolbar's focus order. */
const BarContext = createContext(false);
/**
* Throws the composition error for a part that opens an overlay nothing rendered. A press would
* otherwise do nothing at all, the hardest composition mistake to find, so it throws in
* development.
*
* @param part - The part that was pressed.
* @param present - Whether the overlay registered.
* @param rule - `no-content` or `no-value-content`.
*/
function assertOverlay(part, present, rule) {
	if (isThemeDevelopment() && !present) throw new DataTableFilterCompositionError(part, rule);
}
/**
* The filter's state, actions and field metadata, for a custom part under `DataTableFilter.Root`.
*
* @returns The public context.
* @throws DataTableFilterCompositionError outside a Root.
*/
function useDataTableFilter() {
	const context = use(DataTableFilterContext);
	if (context === null) throw new DataTableFilterCompositionError("useDataTableFilter", "outside-root");
	return context;
}
/**
* The library parts' context: the public value plus the wiring.
*
* @param part - The part's name, for the error.
* @returns The internals.
*/
function useFilterInternals(part) {
	const context = use(DataTableFilterInternalContext);
	if (context === null) throw new DataTableFilterCompositionError(part, "outside-root");
	return context;
}
/**
* A ref that registers a popup with the Root as part of the add menu or the value popover, so
* focus inside it counts as staying when that overlay closes.
*
* @param registerOverlay - The Root's `actions.registerOverlay`.
* @param kind - The overlay the popup belongs to.
* @returns The popup's ref, which unregisters on detach.
*/
function useOverlayRef(registerOverlay, kind) {
	return useCallback((element) => element === null ? void 0 : registerOverlay(kind, element), [registerOverlay, kind]);
}
/**
* The chip a part renders in.
*
* @param part - The part's name, for the error.
* @returns The chip.
*/
function useChip(part) {
	const chip = use(ChipContext);
	if (chip === null) throw new DataTableFilterCompositionError(part, "outside-chip");
	return chip;
}
/**
* The chip a custom segment renders in: its field, value and ghost state.
*
* @returns The chip.
* @throws DataTableFilterCompositionError outside `DataTableFilter.Chip`.
*/
function useDataTableFilterChip() {
	return useChip("useDataTableFilterChip");
}
/**
* The focus request key of a field's editor.
*
* @param fieldId - The field.
* @returns The key.
*/
function editKey(fieldId) {
	return `edit:${fieldId}`;
}
/**
* The focus request key of a field's editor drilled into in the add menu.
*
* @param fieldId - The field.
* @returns The key.
*/
function drillKey(fieldId) {
	return `drill:${fieldId}`;
}
/** Provided by `Content` and `ValueContent` for the `Editor` inside them. */
const EditorTargetContext = createContext(null);
/**
* Focuses an editor's first control when that editor mounts in a popover that is already open,
* after a press on another chip's Value. The popover's own `initialFocus` handles an opening.
* The request stays until the next edit or close, because Base UI's Viewport mounts the new
* editor once more as it swaps the previous one out, and the editor it focused first unmounts.
*
* The focus waits for the render after mount, which React runs synchronously in the same task, so
* it still lands before Base UI's focus manager looks for focus lost with the previous editor. A
* Base UI composite, such as the date presets' toggle group, numbers its items in that render, and
* an item focused in the mount commit would report no index: the group would highlight none, and
* the first arrow key would only land on the first item.
*
* @template T - The element type the ref attaches to.
* @param key - The editor's focus request key.
* @returns A ref for the control or a wrapper around it.
*/
function useFocusRequest(key) {
	const { state } = useFilterInternals("useFocusRequest");
	const ref = useRef(null);
	const [mounted, setMounted] = useState(false);
	const { focusRequest } = state;
	useLayoutEffect(() => {
		setMounted(true);
	}, []);
	useLayoutEffect(() => {
		if (mounted && focusRequest === key && ref.current !== null) resolveFocusTarget(ref.current)?.focus({ preventScroll: true });
	}, [
		mounted,
		focusRequest,
		key
	]);
	return ref;
}
/** Provided by each value list for the footer the consumer renders after it. */
const ValueListContext = createContext(null);
/**
* The value list a footer part sits in.
*
* @param part - The part's name, for the error.
* @returns The list.
*/
function useValueList(part) {
	const list = use(ValueListContext);
	if (list === null) throw new DataTableFilterCompositionError(part, "outside-value-list");
	return list;
}
export { BarContext, ChipContext, DataTableFilterContext, DataTableFilterInternalContext, EditorTargetContext, ValueListContext, assertOverlay, drillKey, editKey, useChip, useDataTableFilter, useDataTableFilterChip, useFilterInternals, useFocusRequest, useOverlayRef, useValueList };

//# sourceMappingURL=data-table-filter-context.js.map