import { fieldAdmits, isFilterValue, isObject, isString } from "./filter-model.js";
// src/components/data-table-filter/filter-parse.ts
/**
* Parses `columnFilters` from untrusted input. An entry stays only when its id is a field, its
* value is well formed for that field's kind and its operator is one the field allows, and every
* option value is one of the field's options. The first entry per id wins, and input that is not
* an array gives no filters.
*
* @param input - The parsed JSON, of any shape.
* @param fields - The fields map.
* @returns The filters the fields admit.
*/
function parseColumnFilters(input, fields) {
	return parseEntries(input, fields, fieldAdmits);
}
/**
* Reads the table's own `columnFilters` for the Root's view. An entry stays when its id is a
* field and its value is well formed for that field's kind, whatever the field's current options
* and operators say, so a filter applied before the config changed stays visible and removable
* while TanStack keeps applying it.
*
* @param input - The table's `columnFilters`.
* @param fields - The fields map.
* @returns The filters of the fields' kinds.
*/
function viewColumnFilters(input, fields) {
	return parseEntries(input, fields, (field, value) => field.kind === value.kind);
}
function parseEntries(input, fields, keeps) {
	if (!Array.isArray(input)) return [];
	const seen = /* @__PURE__ */ new Set();
	const entries = [];
	const list = input;
	for (const entry of list) {
		if (!isObject(entry) || !("id" in entry && "value" in entry)) continue;
		const { id, value } = entry;
		if (!isString(id) || seen.has(id) || !Object.hasOwn(fields, id)) continue;
		const field = fields[id];
		if (field === void 0 || !isFilterValue(value) || !keeps(field, value)) continue;
		seen.add(id);
		entries.push({
			id,
			value
		});
	}
	return entries;
}
export { parseColumnFilters, viewColumnFilters };

//# sourceMappingURL=filter-parse.js.map