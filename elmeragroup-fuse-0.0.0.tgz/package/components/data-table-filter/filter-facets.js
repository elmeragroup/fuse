// src/components/data-table-filter/filter-facets.ts
const countsBySource = /* @__PURE__ */ new WeakMap();
/**
* Counts normalized to string keys, once per source: a server's counts object, or the map
* TanStack's faceting memoizes until its rows change. Every value row reads its field's counts,
* so a list of 50 rows over thousands of facet entries reads one map, not 50 copies.
*/
function normalizedCounts(source, normalize) {
	const cached = countsBySource.get(source);
	if (cached !== void 0) return cached;
	const counts = normalize();
	countsBySource.set(source, counts);
	return counts;
}
/**
* Reads each field's counts and range: the server's facets first, then TanStack faceting, which
* server mode skips. A number field's configured `min` and `max` stand in for an unknown range.
*
* @param table - The table, for faceting and `options.manualFiltering`.
* @param fields - The fields, for a number field's configured range.
* @param facets - The server's facets, if any.
* @returns The reader.
*/
function createFacetReader(table, fields, facets) {
	return {
		counts: (fieldId) => {
			const known = facets?.[fieldId]?.counts;
			if (known !== void 0) return normalizedCounts(known, () => new Map(Object.entries(known)));
			if (table.options.manualFiltering === true) return;
			const unique = table.getColumn(fieldId)?.getFacetedUniqueValues?.();
			return unique === void 0 ? void 0 : normalizedCounts(unique, () => new Map([...unique].map(([key, count]) => [String(key), count])));
		},
		range: (fieldId) => {
			const known = facets?.[fieldId]?.range;
			if (known !== void 0) return known;
			const field = fields[fieldId];
			const fromConfig = field?.kind === "number" && field.min !== void 0 && field.max !== void 0 ? [field.min, field.max] : void 0;
			if (table.options.manualFiltering === true) return fromConfig;
			return table.getColumn(fieldId)?.getFacetedMinMaxValues?.() ?? fromConfig;
		}
	};
}
export { createFacetReader };

//# sourceMappingURL=filter-facets.js.map