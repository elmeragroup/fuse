"use client";
import { cn } from "../../styles/cn.js";
import { useMergedRefs } from "../../hooks/use-merged-refs.js";
import { X } from "../../icons/generated/x.js";
import { isHTMLElement, isNode } from "../../internal/dom-node.js";
import { mergeClassName } from "../../styles/merge-class-name.js";
import { definedProps } from "../../internal/defined-props.js";
import { Button } from "../button/button.js";
import { BarContext, ChipContext, assertOverlay, useChip, useFilterInternals } from "./data-table-filter-context.js";
import { dataTableFilterSlots } from "./data-table-filter-variants.js";
import { isToggleOn } from "./filter-model.js";
import { optionsOf } from "./filter-fields.js";
import { SelectRoot as SelectRoot$1 } from "../select/select.js";
import { OperatorOptions, useOperatorItems } from "./operator-options.js";
import { Funnel } from "../../icons/generated/funnel.js";
import { XCircle } from "../../icons/generated/x-circle.js";
import { chain } from "./chain-handlers.js";
import { summarize } from "./filter-summary.js";
import { scrollStripOnWheel } from "./strip-wheel.js";
import { use, useCallback, useMemo } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { Toolbar } from "@base-ui/react/toolbar";
import { Menu } from "@base-ui/react/menu";
import { Popover } from "@base-ui/react/popover";
import { Select } from "@base-ui/react/select";
// src/components/data-table-filter/data-table-filter-bar.tsx
/**
* Runs the consumer's handler, then the part's bookkeeping whatever the consumer did with the
* event, since a prevented or stopped press still blurs the editor and may still click.
*/
function always(own, theirs) {
	return (event) => {
		theirs?.(event);
		own(event);
	};
}
/**
* Whether Base UI resolved the pressed control as disabled, its own `disabled` or one inherited from
* the Bar or the Chip. Toolbar.Button resolves that value from the Toolbar root and group contexts
* (`toolbar/button/ToolbarButton.tsx:35` in Base UI 1.9), which a part cannot read, and renders it
* as the `data-disabled` state attribute. Base UI Button, Clear's element outside the bar, renders
* its own resolved `disabled` the same way. Base UI drops a disabled control's click only in its
* bubbling handlers, so a capture handler asks this first.
*
* @param event - The press event, whose `currentTarget` is the control.
* @returns `true` when the control is disabled.
*/
function pressIsDisabled(event) {
	return event.currentTarget.hasAttribute("data-disabled");
}
/**
* A ref for one of a chip's segments that also registers it with the Root, so focus can move to
* it when a neighbour chip goes. The consumer's ref keeps working.
*/
function useSegmentRef(fieldId, ref) {
	const { actions } = useFilterInternals("DataTableFilter.Chip");
	const { registerSegment } = actions;
	const register = useCallback((element) => element === null ? void 0 : registerSegment(fieldId, element), [registerSegment, fieldId]);
	return useMergedRefs(ref, register);
}
/**
* The filter bar, a toolbar that is one Tab stop with arrow-key roving. Without children it
* renders the Trigger, the chips and Clear on one line, so its height never grows with the
* filters. It is named "Filters" unless `aria-label` says otherwise. Below a 36rem container
* width a container query hides Clear's label behind its icon.
*/
function DataTableFilterBar({ className, children, ...props }) {
	const { state, meta } = useFilterInternals("DataTableFilter.Bar");
	return /* @__PURE__ */ jsx(BarContext, {
		value: true,
		children: /* @__PURE__ */ jsx(Toolbar.Root, {
			"data-slot": "data-table-filter-bar",
			"data-empty": state.filters.length === 0 || void 0,
			"aria-label": meta.format("filters"),
			className: mergeClassName(className, dataTableFilterSlots.bar()),
			...props,
			children: /* @__PURE__ */ jsx("div", {
				"data-slot": "data-table-filter-bar-row",
				className: dataTableFilterSlots.barRow(),
				children: children ?? /* @__PURE__ */ jsxs(Fragment$1, { children: [
					/* @__PURE__ */ jsx(DataTableFilterTrigger, {}),
					/* @__PURE__ */ jsx(DataTableFilterChips, {}),
					/* @__PURE__ */ jsx(DataTableFilterClear, {})
				] })
			})
		})
	});
}
/**
* Opens the add menu, `DataTableFilter.Content`. It sits first in the bar, so a chip added under
* the open menu never moves it. Without children it draws the icon, named "Filter" unless
* `aria-label` says otherwise, as a square icon button at every width or in the `render`
* element. Children replace the icon and render it as a labelled button.
*/
function DataTableFilterTrigger({ className, children, render, onClick, ref, ...props }) {
	const { state, actions, meta } = useFilterInternals("DataTableFilter.Trigger");
	const triggerRef = useMergedRefs(ref, actions.registerTrigger);
	const label = props["aria-label"] ?? meta.format("filter");
	const iconOnly = children == null;
	return /* @__PURE__ */ jsx(Toolbar.Button, {
		ref: triggerRef,
		id: meta.triggerId,
		"data-slot": "data-table-filter-trigger",
		"data-empty": state.filters.length === 0 || void 0,
		...iconOnly ? { "aria-label": label } : null,
		render: /* @__PURE__ */ jsx(Menu.Trigger, {
			handle: meta.menuHandle,
			render: render ?? (iconOnly ? /* @__PURE__ */ jsx(Button, {
				variant: "outline",
				size: "icon-sm",
				"aria-label": label
			}) : /* @__PURE__ */ jsx(Button, {
				variant: "outline",
				size: "sm"
			}))
		}),
		className: mergeClassName(className, dataTableFilterSlots.trigger()),
		onClick: chain((_event) => {
			assertOverlay("DataTableFilter.Trigger", meta.hasContent(), "no-content");
		}, onClick),
		...definedProps(props),
		children: iconOnly ? /* @__PURE__ */ jsx(Funnel, { "aria-hidden": true }) : children
	});
}
/**
* One chip context per filter, keyed by field id, with no element per chip, in one strip that
* scrolls sideways at every width. Its ends fade while chips hide past them. A focused segment
* scrolls into view, since `focus()` leaves a partly visible element where it is, and a vertical
* mouse wheel scrolls the strip until it reaches an end.
*/
function DataTableFilterChips({ className, children, onFocus, ref, ...props }) {
	const { state } = useFilterInternals("DataTableFilter.Chips");
	const stripRef = useMergedRefs(ref, scrollStripOnWheel);
	return /* @__PURE__ */ jsx("div", {
		ref: stripRef,
		"data-slot": "data-table-filter-chips",
		className: cn(dataTableFilterSlots.chips(), className),
		onFocus: chain((event) => {
			if (isHTMLElement(event.target)) event.target.scrollIntoView({
				block: "nearest",
				inline: "nearest"
			});
		}, onFocus),
		...props,
		children: state.chips.map((chip) => /* @__PURE__ */ jsx(ChipContext, {
			value: chip,
			children: typeof children === "function" ? children(chip) : children ?? /* @__PURE__ */ jsx(DataTableFilterChip, {})
		}, chip.id))
	});
}
/**
* One filter as a sentence: Subject, Operator, Value and Remove by default. It is a group named
* "Status filter". Delete or Backspace on any of its segments removes it.
*/
function DataTableFilterChip({ className, children, onKeyDown, ref, ...props }) {
	const chip = useChip("DataTableFilter.Chip");
	const { actions, meta } = useFilterInternals("DataTableFilter.Chip");
	const { registerChip } = actions;
	const register = useCallback((element) => {
		registerChip(chip.id, element);
	}, [registerChip, chip.id]);
	const chipRef = useMergedRefs(ref, register);
	return /* @__PURE__ */ jsx(Toolbar.Group, {
		ref: chipRef,
		"data-slot": "data-table-filter-chip",
		"data-kind": chip.field.kind,
		"data-field": chip.id,
		"data-operator": chip.value.operator,
		"data-ghost": chip.ghost || void 0,
		"aria-label": meta.format("chip", { field: chip.field.label }),
		className: mergeClassName(className, dataTableFilterSlots.chip()),
		onKeyDown: chain((event) => {
			if ((event.key === "Delete" || event.key === "Backspace") && isNode(event.target) && event.currentTarget.contains(event.target) && !event.currentTarget.hasAttribute("data-disabled") && !(isHTMLElement(event.target) && event.target.hasAttribute("data-disabled"))) {
				event.preventDefault();
				actions.remove(chip.id);
			}
		}, onKeyDown),
		...props,
		children: children ?? /* @__PURE__ */ jsxs(Fragment$1, { children: [
			/* @__PURE__ */ jsx(DataTableFilterSubject, {}),
			/* @__PURE__ */ jsx(DataTableFilterOperator, {}),
			/* @__PURE__ */ jsx(DataTableFilterValue, {}),
			/* @__PURE__ */ jsx(DataTableFilterRemove, {})
		] })
	});
}
/** The field's icon and name. Static text, never a Tab or arrow-key stop. */
function DataTableFilterSubject({ className, children, ...props }) {
	const chip = useChip("DataTableFilter.Subject");
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "data-table-filter-subject",
		className: cn(dataTableFilterSlots.subject(), className),
		...props,
		children: children ?? /* @__PURE__ */ jsxs(Fragment$1, { children: [chip.field.icon === void 0 ? null : /* @__PURE__ */ jsx("span", {
			"aria-hidden": true,
			className: "contents",
			children: chip.field.icon
		}), chip.field.label] })
	});
}
/**
* The chip's operator, a Select whose trigger announces "Status operator, is any of". Option
* fields list only the operators for the current value count, so the operator never disagrees
* with it. A pick closes it and returns focus to the segment. A ghost chip's operator is disabled.
* A toggle that is on has no operator. Its name says it.
*/
function DataTableFilterOperator(props) {
	const chip = useChip("DataTableFilter.Operator");
	const { state } = useFilterInternals("DataTableFilter.Operator");
	if (showsNameOnly(chip, state.editing)) return null;
	return /* @__PURE__ */ jsx(OperatorSelect, {
		...props,
		chip
	});
}
/**
* Whether a chip shows its name and Remove only: a toggle that is on, unless its value popover is
* open, where it keeps its whole sentence until the popover closes.
*/
function showsNameOnly(chip, editing) {
	return isToggleOn(chip.field, chip.value) && editing !== chip.id;
}
function OperatorSelect({ chip, className, render, ref, ...props }) {
	const { actions, meta } = useFilterInternals("DataTableFilter.Operator");
	const segmentRef = useSegmentRef(chip.id, ref);
	const applied = chip.value;
	const items = useOperatorItems("DataTableFilter.Operator", chip.field, chip.id, applied, applied.operator);
	return /* @__PURE__ */ jsxs(SelectRoot$1, {
		items,
		value: applied.operator,
		modal: false,
		disabled: chip.ghost,
		onValueChange: (operator) => {
			if (operator !== null) actions.setOperator(chip.id, operator);
		},
		children: [/* @__PURE__ */ jsx(Toolbar.Button, {
			ref: segmentRef,
			"data-slot": "data-table-filter-operator",
			"data-operator": applied.operator,
			"aria-label": meta.format("operatorLabel", { field: chip.field.label }),
			render: /* @__PURE__ */ jsx(Select.Trigger, { render: render ?? /* @__PURE__ */ jsx(Button, {
				variant: "ghost",
				size: "sm"
			}) }),
			className: mergeClassName(className, dataTableFilterSlots.segment(), dataTableFilterSlots.operator()),
			...definedProps(props),
			children: /* @__PURE__ */ jsx(Select.Value, {})
		}), /* @__PURE__ */ jsx(OperatorOptions, {
			items,
			align: "start"
		})]
	});
}
/**
* The value summary, which opens the shared value popover at this chip's editor. Its name is the
* visible summary, and a shortened summary states the whole value as its description. Children
* replace the summary. A toggle that is on has no value.
*/
function DataTableFilterValue({ className, children, render, onClick, ref, ...props }) {
	const chip = useChip("DataTableFilter.Value");
	const { state, actions, meta } = useFilterInternals("DataTableFilter.Value");
	const segmentRef = useSegmentRef(chip.id, ref);
	const payload = useMemo(() => ({ fieldId: chip.id }), [chip.id]);
	if (showsNameOnly(chip, state.editing)) return null;
	const value = chip.value;
	const summary = summarize(value, chip.field, meta.locale, {
		moreValues: (count) => meta.format("moreValues", { count }),
		quoted: (text) => meta.format("quoted", { text }),
		yes: meta.format("yes"),
		no: meta.format("no")
	});
	const options = optionsOf(chip.field);
	const icons = value.kind !== "option" && value.kind !== "multiOption" ? [] : value.values.slice(0, 3).flatMap((item) => {
		const option = options.find((candidate) => candidate.value === item);
		return option?.icon === void 0 ? [] : [option];
	});
	return /* @__PURE__ */ jsx(Toolbar.Button, {
		ref: segmentRef,
		id: meta.valueId(chip.id),
		"data-slot": "data-table-filter-value",
		"data-count": value.values.length,
		render: /* @__PURE__ */ jsx(Popover.Trigger, {
			handle: meta.valueHandle,
			payload,
			render: render ?? /* @__PURE__ */ jsx(Button, {
				variant: "ghost",
				size: "sm"
			})
		}),
		...definedProps({ "aria-description": summary.full === summary.text ? void 0 : summary.full }),
		className: mergeClassName(className, dataTableFilterSlots.segment(), dataTableFilterSlots.value()),
		onClick: chain((_event) => {
			assertOverlay("DataTableFilter.Value", meta.hasValueContent(), "no-value-content");
			actions.beginEdit(chip.id);
		}, onClick),
		...definedProps(props),
		children: children ?? /* @__PURE__ */ jsxs(Fragment$1, { children: [icons.length > 0 ? /* @__PURE__ */ jsx("span", {
			"aria-hidden": true,
			className: dataTableFilterSlots.valueIcons(),
			children: icons.map((option) => /* @__PURE__ */ jsx("span", {
				className: "contents",
				children: option.icon
			}, option.value))
		}) : null, /* @__PURE__ */ jsx("span", {
			className: dataTableFilterSlots.valueText(),
			children: summary.text
		})] })
	});
}
/**
* Removes the chip, named "Remove Status filter". Focus moves to the next chip, else the previous
* one, else the Trigger. A press on it closes the chip's open editor and drops any change the
* editor has not applied, so the removal is the one write. A press that slides off before its click,
* or whose click a consumer cancels, still closes the editor and drops the change, and the applied
* filter stays as it was.
*/
function DataTableFilterRemove({ className, render, onClick, onPointerDownCapture, onClickCapture, ref, "aria-label": ariaLabel, ...props }) {
	const chip = useChip("DataTableFilter.Remove");
	const { actions, meta } = useFilterInternals("DataTableFilter.Remove");
	const segmentRef = useSegmentRef(chip.id, ref);
	const label = ariaLabel ?? meta.format("removeFilter", { field: chip.field.label });
	const discard = (event) => {
		if (!pressIsDisabled(event)) actions.discardEditors(chip.id);
	};
	return /* @__PURE__ */ jsx(Toolbar.Button, {
		ref: segmentRef,
		"data-slot": "data-table-filter-remove",
		"aria-label": label,
		render: render ?? /* @__PURE__ */ jsx(Button, {
			variant: "ghost",
			size: "icon-sm",
			"aria-label": label
		}),
		className: mergeClassName(className, dataTableFilterSlots.segment()),
		onPointerDownCapture: always(discard, onPointerDownCapture),
		onClickCapture: always(discard, onClickCapture),
		onClick: chain((_event) => {
			actions.remove(chip.id);
		}, onClick),
		...definedProps(props),
		children: /* @__PURE__ */ jsx(X, { "aria-hidden": true })
	});
}
/**
* Removes every filter and moves focus to the Trigger, and renders nothing when there are none. A
* press on it closes any open editor and drops a change the editor has not applied, so the clear is
* the one write. A press that slides off before its click, or whose click a consumer cancels, still
* closes the editor and drops the change, and the applied filters stay as they were.
* In the Bar it joins the toolbar's focus order. Anywhere else under the Root, such as a table's
* empty state, it is a plain outline button.
*/
function DataTableFilterClear({ className, children, onClick, onPointerDownCapture, onClickCapture, ...props }) {
	const { state, actions, meta } = useFilterInternals("DataTableFilter.Clear");
	const inBar = use(BarContext);
	if (state.filters.length === 0) return null;
	const handleClick = chain((_event) => {
		actions.clear();
	}, onClick);
	const discard = (event) => {
		if (!pressIsDisabled(event)) actions.discardEditors(null);
	};
	const handlePointerDownCapture = always(discard, onPointerDownCapture);
	const handleClickCapture = always(discard, onClickCapture);
	const label = children ?? meta.format("clearFilters");
	return inBar ? /* @__PURE__ */ jsxs(Toolbar.Button, {
		"data-slot": "data-table-filter-clear",
		...definedProps({ "aria-label": children === void 0 ? meta.format("clearFilters") : void 0 }),
		render: /* @__PURE__ */ jsx(Button, {
			variant: "ghost",
			size: "sm"
		}),
		className: mergeClassName(className, dataTableFilterSlots.clear()),
		onPointerDownCapture: handlePointerDownCapture,
		onClickCapture: handleClickCapture,
		onClick: handleClick,
		...definedProps(props),
		children: [/* @__PURE__ */ jsx(XCircle, {
			"aria-hidden": true,
			className: dataTableFilterSlots.clearIcon()
		}), /* @__PURE__ */ jsx("span", {
			className: dataTableFilterSlots.clearLabel(),
			children: label
		})]
	}) : /* @__PURE__ */ jsx(Button, {
		"data-slot": "data-table-filter-clear",
		variant: "outline",
		size: "sm",
		className,
		onPointerDownCapture: handlePointerDownCapture,
		onClickCapture: handleClickCapture,
		onClick: handleClick,
		...definedProps(props),
		children: label
	});
}
DataTableFilterBar.displayName = "DataTableFilter.Bar";
DataTableFilterTrigger.displayName = "DataTableFilter.Trigger";
DataTableFilterChips.displayName = "DataTableFilter.Chips";
DataTableFilterChip.displayName = "DataTableFilter.Chip";
DataTableFilterSubject.displayName = "DataTableFilter.Subject";
DataTableFilterOperator.displayName = "DataTableFilter.Operator";
DataTableFilterValue.displayName = "DataTableFilter.Value";
DataTableFilterRemove.displayName = "DataTableFilter.Remove";
DataTableFilterClear.displayName = "DataTableFilter.Clear";
export { DataTableFilterBar, DataTableFilterChip, DataTableFilterChips, DataTableFilterClear, DataTableFilterOperator, DataTableFilterRemove, DataTableFilterSubject, DataTableFilterTrigger, DataTableFilterValue };

//# sourceMappingURL=data-table-filter-bar.js.map