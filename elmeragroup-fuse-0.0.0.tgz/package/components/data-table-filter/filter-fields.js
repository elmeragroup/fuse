import { allowedOperators } from "./filter-model.js";
// src/components/data-table-filter/filter-fields.ts
/**
* Pins a fields map to a row type: an option's values must be the column's values, and a kind
* must fit the column's type. Pass the row type once, as with `createColumnHelper<TRow>()`, and
* the map's literal type is inferred.
*
* @template TRow - The table's row type.
* @returns A function that returns the map it receives, typed as written.
*/
function defineFilterFields() {
	return (fields) => fields;
}
/**
* The operator a new filter starts with: the field's first allowed operator, else the kind's
* default for one value, or `isBetween` for a number or date.
*
* @param field - The field.
* @returns The operator.
*/
function firstOperator(field) {
	const [first] = field.operators === void 0 ? [] : allowedOperators(field);
	if (first !== void 0) return first;
	switch (field.kind) {
		case "option":
		case "boolean": return "is";
		case "multiOption": return "includes";
		case "text": return "contains";
		case "number":
		case "date": return "isBetween";
	}
}
/**
* The options of an option field, or none for other kinds.
*
* @param field - The field.
* @returns Its options.
*/
function optionsOf(field) {
	return field.kind === "option" || field.kind === "multiOption" ? field.options : [];
}
export { defineFilterFields, firstOperator, optionsOf };

//# sourceMappingURL=filter-fields.js.map