import { firstDayOfWeek } from "../../temporal/week-info.js";
// src/components/data-table-filter/date-presets.ts
/** The presets a date field offers when it lists none. */
const DEFAULT_DATE_PRESETS = [
	"today",
	"last7Days",
	"last30Days",
	"thisMonth",
	"thisYear"
];
/** A calendar date from a year, a zero-based month and a day, which `Date.UTC` normalizes. */
function utcDate(year, month, day) {
	return new Date(Date.UTC(year, month, day)).toISOString().slice(0, 10);
}
/** A date's year, zero-based month and day. */
function partsOf(date) {
	const [year = 0, month = 1, day = 1] = date.split("-").map(Number);
	return [
		year,
		month - 1,
		day
	];
}
/** An ISO date moved by whole days, negative to go back. */
function addDays(date, days) {
	const [year, month, day] = partsOf(date);
	return utcDate(year, month, day + days);
}
/** The seven days of the week that holds a date, from the locale's first day. */
function weekOf(date, locale) {
	const [year, month, day] = partsOf(date);
	const first = addDays(date, -((new Date(Date.UTC(year, month, day)).getUTCDay() - firstDayOfWeek(locale) + 7) % 7));
	return [first, addDays(first, 6)];
}
/** The first and last day of the month `offset` months from a date's month. */
function monthOf(date, offset) {
	const [year, month] = partsOf(date);
	return [utcDate(year, month + offset, 1), utcDate(year, month + offset + 1, 0)];
}
/** January 1 and December 31 of the year `offset` years from a date's year. */
function yearOf(date, offset) {
	const [year] = partsOf(date);
	return [utcDate(year + offset, 0, 1), utcDate(year + offset, 11, 31)];
}
/**
* A preset's first and last day. A period, such as This month, covers the whole period, days after
* today included. Last 7 days and Last 30 days end today.
*
* @param key - The preset.
* @param today - Today's calendar date in the Root's time zone.
* @param locale - The Root's locale. Weeks start on Sunday in en-US and on Monday in nb-NO, sv-SE
*   and fi-FI.
* @returns The range, first day first.
*/
function datePresetRange(key, today, locale) {
	switch (key) {
		case "today": return [today, today];
		case "yesterday": {
			const yesterday = addDays(today, -1);
			return [yesterday, yesterday];
		}
		case "thisWeek": return weekOf(today, locale);
		case "lastWeek": return weekOf(addDays(today, -7), locale);
		case "last7Days": return [addDays(today, -6), today];
		case "last30Days": return [addDays(today, -29), today];
		case "thisMonth": return monthOf(today, 0);
		case "lastMonth": return monthOf(today, -1);
		case "thisYear": return yearOf(today, 0);
		case "lastYear": return yearOf(today, -1);
	}
}
/**
* Whether a preset names one day, so a field without `isBetween` can still write it as `is`. It
* reads the key, never a range, so a period that happens to be one day long stays a period.
*
* @param key - The preset.
* @returns Whether it is Today or Yesterday.
*/
function isOneDayPreset(key) {
	return key === "today" || key === "yesterday";
}
export { DEFAULT_DATE_PRESETS, datePresetRange, isOneDayPreset };

//# sourceMappingURL=date-presets.js.map