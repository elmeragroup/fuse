import * as ClockChart from "./clock-chart-parts.js";
export { ClockChart };
