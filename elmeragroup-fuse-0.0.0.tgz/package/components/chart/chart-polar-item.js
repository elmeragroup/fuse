"use client";
import { countOf } from "../../intl/count-of.js";
import { isThemeDevelopment } from "../../theme/validate-theme.js";
import { CHART_STRINGS } from "./format/chart-strings.js";
import { formatValue, sameFormat } from "./format/value-format.js";
import { ChartDataError, DATA_MESSAGES, assertKnownKey, dataMessage, issueGroups } from "./layout/errors.js";
import { stringOf } from "./layout/scalar.js";
import { readSeries } from "./layout/readings.js";
import { isRoleList, seriesPaint, singleRole } from "./layout/color-key.js";
import { seriesLabel } from "./format/series-label.js";
import { roundShares } from "./layout/shares.js";
import { angleInSweep, pointerAngle } from "./layout/polar-angle.js";
import { OTHER_KEY, foldPie, gaugeFill, pieAngles, sliceAt } from "./layout/pie.js";
import { POLAR_STRINGS } from "./format/polar-strings.js";
import { ringAngle, ringAt, ringBands, ringFills } from "./layout/rings.js";
// src/components/chart/chart-polar-item.ts
/** A reading's quality state, or undefined for a measured or pending one. */
function qualityOf(reading) {
	if (reading.kind === "missing") return "missing";
	if (reading.kind === "reading" && reading.quality !== "measured") return reading.quality;
}
/**
* The quality of the readings Other holds (section 8.7). Folding is a drawing rule, so Other
* keeps their uncertainty: estimated when any is estimated, corrected when any is corrected and none
* estimated, missing only when every one is missing, and measured otherwise.
*
* @param readings - The folded readings.
* @returns The quality state, or undefined for measured.
*/
function foldedQuality(readings) {
	const states = readings.map(qualityOf);
	if (states.includes("estimated")) return "estimated";
	if (states.includes("corrected")) return "corrected";
	if (states.length > 0 && states.every((state) => state === "missing")) return "missing";
}
/** A reading's value, or null for a missing or pending one. */
function valueOf(reading) {
	return reading.kind === "reading" ? reading.value : null;
}
/**
* Read the rows: each row's category and reading, the first row of a category only. A cell that breaks a reading rule, such as a value
* that is not a finite number, throws that rule in development, and production counts the reading
* as missing and warns once. A negative reading throws `negative-polar-value` in development, and
* production draws it as 0 and keeps its sign in the texts. A category config lacks throws
* `unknown-category` in development.
*/
function readRows(input, issues) {
	const { rows, config, nameKey, valueKey, qualityKey, part } = input;
	const { readings, issues: cells } = readSeries({
		values: rows.map((row) => row[valueKey]),
		qualities: qualityKey === void 0 ? [] : rows.map((row) => row[qualityKey])
	}, void 0, void 0);
	const categoryAt = (index) => {
		const row = rows[index];
		return row === void 0 ? "" : stringOf(row[nameKey]) ?? String(row[nameKey] ?? "");
	};
	const named = cells.map((issue) => ({
		...issue,
		key: categoryAt(issue.slot)
	}));
	const rowAt = rows.map((_, index) => index);
	const [first] = named;
	if (first !== void 0 && isThemeDevelopment()) throw new ChartDataError(part, first.rule, dataMessage(first, rowAt));
	for (const { rule, subject, first: issue, count } of issueGroups(named)) issues.push({
		rule,
		subject,
		message: `${part} ${dataMessage(issue, rowAt, count)}`
	});
	const seen = /* @__PURE__ */ new Set();
	const duplicates = [];
	const kept = rows.flatMap((_, index) => {
		const category = categoryAt(index);
		if (seen.has(category)) {
			duplicates.push({
				rule: "duplicate-x",
				row: index,
				subject: category
			});
			return [];
		}
		seen.add(category);
		return [index];
	});
	const [duplicate] = duplicates;
	if (duplicate !== void 0 && isThemeDevelopment()) throw new ChartDataError(part, "duplicate-x", dataMessage(duplicate, rowAt));
	for (const { rule, subject, first: issue, count } of issueGroups(duplicates)) issues.push({
		rule,
		subject,
		message: `${part} ${dataMessage(issue, rowAt, count)}`
	});
	return kept.map((index) => {
		const category = categoryAt(index);
		const reading = readings[index] ?? { kind: "missing" };
		if (reading.kind === "reading" && reading.value < 0) {
			const message = DATA_MESSAGES["negative-polar-value"];
			if (isThemeDevelopment()) throw new ChartDataError(part, "negative-polar-value", message);
			issues.push({
				rule: "negative-polar-value",
				subject: category,
				message: `${part} ${message}`
			});
		}
		const known = Object.hasOwn(config, category);
		if (!known) {
			const message = DATA_MESSAGES["unknown-category"];
			if (isThemeDevelopment()) throw new ChartDataError(part, "unknown-category", message);
			issues.push({
				rule: "unknown-category",
				subject: category,
				message: `${part} ${message}`
			});
		}
		return {
			category,
			reading,
			known,
			row: index
		};
	});
}
/** A category's paint, the consumer's `--chart-color-<key>` first. */
function paintOf(config, key) {
	return seriesPaint(key, singleRole(config[key]?.color));
}
/** A value's text with its quality word, in both forms, or the missing word. */
function valueText(locale, item, format) {
	const strings = CHART_STRINGS[locale];
	if (item.value === null) return {
		text: strings.missing,
		spoken: strings.missing
	};
	const value = formatValue(locale, item.value, format ?? item.format, "full");
	if (item.quality === void 0 || item.quality === "missing") return value;
	const word = strings[item.quality];
	return {
		text: `${value.text} (${word})`,
		spoken: `${value.spoken}, ${word}`
	};
}
/** A share in percent as text in both forms, or the dictionary dash. */
function shareWords(locale, share, digits) {
	if (share === null) return {
		text: "–",
		spoken: "–"
	};
	return formatValue(locale, share / 100, {
		style: "percent",
		minimumFractionDigits: 0,
		maximumFractionDigits: digits
	}, "full");
}
/** The readout over items. */
function itemReadout(source, kernel, empty) {
	const { items, input } = source;
	const { locale } = input;
	const indexOf = new Map(items.map(({ key }, index) => [key, index]));
	const readoutItems = new Map(items.map((item, index) => [item.key, {
		index,
		label: item.label,
		icon: item.icon,
		selectable: item.key !== "\0other" && Object.hasOwn(input.config, item.key),
		sides: null
	}]));
	for (const key of Object.keys(input.config)) {
		if (readoutItems.has(key)) continue;
		readoutItems.set(key, {
			index: void 0,
			label: seriesLabel({ config: input.config }, key),
			icon: input.config[key]?.icon,
			selectable: false,
			sides: null
		});
	}
	const ownRows = new Map(source.rows.map((row) => [row.category, row]));
	const values = {};
	const quality = {};
	for (const key of Object.keys(input.config)) {
		const row = ownRows.get(key);
		const value = row === void 0 ? null : valueOf(row.reading);
		values[key] = value;
		const state = row === void 0 ? void 0 : qualityOf(row.reading);
		if (state !== void 0) quality[key] = state;
		else if (value !== null) quality[key] = "measured";
	}
	const itemAt = (key) => items[indexOf.get(key) ?? -1];
	return {
		id: kernel.id,
		locale,
		root: kernel.root,
		store: kernel.store,
		followers: kernel.followers,
		window: items.length === 0 ? null : {
			first: 0,
			last: items.length - 1
		},
		empty,
		legendKeys: items.map(({ key }) => key),
		toggleGroupName: POLAR_STRINGS[input.locale].categoryGroup,
		item: (key) => readoutItems.get(key),
		assertKey: (part, key) => {
			assertKnownKey(part, input.config, key);
		},
		pointKey: (active) => active === null ? null : items[active]?.key ?? null,
		itemsFollowActive: true,
		tooltipKeys: (active) => {
			const item = active === null ? void 0 : items[active];
			return item === void 0 ? [] : [item.key];
		},
		activeLabel: (active) => items[active]?.label.text ?? "",
		valueText: (key, _at, format) => {
			const item = itemAt(key);
			return item === void 0 ? "" : valueText(locale, item, format).text;
		},
		share: (key, _at, digits) => source.share(indexOf.get(key) ?? -1, digits),
		legendAt: (key) => indexOf.get(key) ?? null,
		legendShare: (key, digits) => source.share(indexOf.get(key) ?? -1, digits),
		swatch: (key) => ({
			paint: itemAt(key)?.paint ?? (Object.hasOwn(input.config, key) ? paintOf(input.config, key) : ""),
			look: void 0
		}),
		point: (active) => {
			const item = items[active];
			return {
				index: active,
				x: item?.key === "\0other" ? item.label.text : item?.key ?? "",
				label: item?.label ?? {
					text: "",
					spoken: ""
				},
				key: item === void 0 || item.key === "\0other" ? null : item.key,
				values,
				quality
			};
		},
		select: kernel.select,
		registerToggleGroup: kernel.registerToggleGroup,
		highlight: kernel.highlight,
		warnOnce: kernel.warnOnce,
		usePick: kernel.usePick
	};
}
/** Whether every item reads one format, so the table's headers carry the unit and the cells none. */
function sharedFormat(items) {
	const [first] = items;
	if (first === void 0) return null;
	return items.every(({ format }) => sameFormat(format, first.format)) ? first.format : null;
}
/**
* A pie's model: the folded items, their slices in the sweep, the shares, the option names, the
* description, the pick by angle and the table.
*
* @param input - The Root's rows, config and props.
* @returns The model.
*/
function pieModel(input) {
	const { config, locale, valueFormat } = input;
	const strings = CHART_STRINGS[locale];
	const polarStrings = POLAR_STRINGS[locale];
	const issues = [];
	const rows = readRows(input, issues);
	const roles = rows.map(({ category, known }) => {
		if (!known) return "unknown";
		return config[category]?.color === "chart-other" ? "other" : "own";
	});
	const folded = foldPie(rows.map(({ category, reading }, index) => ({
		key: category,
		value: valueOf(reading),
		role: roles[index] ?? "own"
	})), input.maxSlices);
	const items = folded.map(({ key, value, rows: members }) => {
		if (key === "\0other") {
			const label = `${input.otherLabel ?? strings.other}, ${countOf(locale, members.length, strings.slots.category)}`;
			return {
				key,
				label: {
					text: label,
					spoken: label
				},
				value,
				quality: foldedQuality(members.flatMap((member) => rows[member]?.reading ?? [])),
				format: valueFormat ?? {},
				icon: void 0,
				paint: "var(--chart-other)"
			};
		}
		const row = rows[members[0] ?? -1];
		return {
			key,
			label: seriesLabel({ config }, key),
			value,
			quality: row === void 0 ? void 0 : qualityOf(row.reading),
			format: config[key]?.format ?? valueFormat ?? {},
			icon: config[key]?.icon,
			paint: paintOf(config, key)
		};
	});
	const drawn = folded.map(({ weight }) => weight);
	const total = drawn.reduce((sum, value) => sum + value, 0);
	const gauge = input.max === void 0 ? null : gaugeFill(input.sweep, total, input.max);
	const sweep = gauge?.sweep ?? input.sweep;
	const slices = pieAngles(drawn, sweep, input.padAngle);
	const shareSets = /* @__PURE__ */ new Map();
	const shares = (digits) => {
		const known = shareSets.get(digits);
		if (known !== void 0) return known;
		const set = roundShares(items.map(({ value }) => value), digits);
		shareSets.set(digits, set);
		return set;
	};
	const rowShareSets = /* @__PURE__ */ new Map();
	const rowShares = (digits) => {
		const known = rowShareSets.get(digits);
		if (known !== void 0) return known;
		const set = roundShares(rows.map(({ reading }) => valueOf(reading)), digits);
		rowShareSets.set(digits, set);
		return set;
	};
	const source = {
		items,
		rows,
		input,
		share: (index, digits) => index < 0 ? null : shares(digits)[index] ?? null,
		max: () => input.max ?? null,
		third: "share"
	};
	const empty = total === 0 && items.every(({ value }) => value === null || value === 0);
	const totalText = formatValue(locale, total, sharedFormat(items) ?? valueFormat ?? {}, "full").spoken;
	const optionName = (index) => {
		const item = items[index];
		if (item === void 0) return "";
		const value = valueText(locale, item, void 0).spoken;
		if (item.value === null) return `${item.label.spoken}: ${strings.missing}`;
		if (input.max !== void 0) {
			const max = formatValue(locale, input.max, item.format, "full").spoken;
			return `${item.label.spoken}: ${strings.ofMax(value, max)}`;
		}
		return `${item.label.spoken}: ${value}, ${shareWords(locale, source.share(index, 0), 0).spoken}`;
	};
	return {
		family: "pie",
		sweep: input.sweep,
		count: items.length,
		keys: items.map(({ key }) => key),
		empty,
		description: empty ? `${strings.noData}.` : [polarStrings.descriptionPie(countOf(locale, items.length, polarStrings.slices), totalText), ...items.map((_, index) => `${optionName(index)}.`)].join(" "),
		instructions: "polar",
		orientation: "vertical",
		wrap: true,
		series: 0,
		page: null,
		optionName,
		pick: (point, pixels) => {
			const drawn = slices.map((slice, index) => {
				const key = items[index]?.key;
				const angles = key === void 0 ? void 0 : pixels.painted?.(key);
				return angles === void 0 ? slice : angles;
			});
			const index = sliceAt(pointerAngle(point.x, point.y), drawn, sweep);
			return index === null ? null : {
				slot: index,
				near: null
			};
		},
		ray: (index) => {
			const slice = slices[index];
			if (slice === null || slice === void 0) return null;
			return {
				angle: (slice.start + slice.end) / 2,
				radius: 1
			};
		},
		selectKey: (index) => {
			const key = items[index]?.key;
			return key === void 0 || key === "\0other" || !Object.hasOwn(config, key) ? null : key;
		},
		selectable: Object.keys(config),
		table: {
			kind: "items",
			source,
			shares: rowShares
		},
		readout: (kernel) => itemReadout(source, kernel, empty),
		issues,
		drawing: {
			kind: "pie",
			pie: {
				track: input.sweep,
				fill: sweep,
				innerRadius: input.innerRadius,
				slices: items.map((item, index) => {
					const color = config[item.key]?.color;
					const role = item.key === "\0other" ? "chart-other" : singleRole(color);
					return {
						key: item.key,
						label: item.label,
						role,
						paint: item.paint,
						stops: color !== void 0 && isRoleList(color) ? color.map((stop) => seriesPaint(item.key, stop)) : void 0,
						series: Object.keys(config).indexOf(item.key),
						angles: slices[index] ?? null,
						quality: item.quality
					};
				}),
				over: gauge?.over ?? false,
				share: source.share,
				sliceOf: (category) => folded.some(({ key }) => key === category) ? category : OTHER_KEY,
				folds: (category) => folded.some(({ key, rows: members }) => key === "\0other" && members.some((member) => rows[member]?.category === category))
			},
			centre: {
				label: (index) => items[index]?.label.text ?? null,
				value: (index) => items[index]?.value ?? null,
				format: (index) => items[index]?.format ?? valueFormat ?? {},
				total: sharedFormat(items) === null ? null : {
					value: total,
					format: sharedFormat(items) ?? {}
				},
				share: source.share,
				totalShare: (digits) => input.max !== void 0 && input.max > 0 ? rounded(total / input.max * 100, digits) : null,
				max: () => input.max ?? null,
				totalMax: input.max ?? null
			}
		}
	};
}
/** The share of each ring's band its stroke fills, `--chart-ring-fill`'s default. */
const RING_FILL = .7;
/**
* A radial chart's model: one ring per row, the first outermost, each filling its maximum, with the
* option names, the description, the pick by radius band and the table.
*
* @param input - The Root's rows, config and props.
* @returns The model.
*/
function radialModel(input) {
	const { config, locale, valueFormat, sweep } = input;
	const strings = CHART_STRINGS[locale];
	const polarStrings = POLAR_STRINGS[locale];
	const issues = [];
	const rows = readRows(input, issues);
	const given = input.maxima;
	const maxima = given.kind === "rows" ? {
		kind: "rows",
		maxima: rows.map(({ row }) => given.maxima[row] ?? null)
	} : given;
	const fills = ringFills(rows.map(({ reading }) => valueOf(reading)), maxima);
	const items = rows.map(({ category, reading, known }, index) => ({
		key: known ? category : `${OTHER_KEY}${String(index)}`,
		label: known ? seriesLabel({ config }, category) : {
			text: category,
			spoken: category
		},
		value: valueOf(reading),
		quality: qualityOf(reading),
		format: config[category]?.format ?? valueFormat ?? {},
		icon: config[category]?.icon,
		paint: known ? paintOf(config, category) : "var(--chart-other)"
	}));
	const bands = ringBands(items.length, {
		outer: 1,
		innerRadius: input.innerRadius,
		fill: RING_FILL
	});
	const share = (index, digits) => {
		const value = fills[index]?.share ?? null;
		return value === null ? null : rounded(value * 100, digits);
	};
	const source = {
		items,
		rows,
		input,
		share,
		max: (index) => fills[index]?.max ?? null,
		third: "max"
	};
	const empty = items.every(({ value }) => value === null);
	const optionName = (index) => {
		const item = items[index];
		if (item === void 0) return "";
		if (item.value === null) return `${item.label.spoken}: ${strings.missing}`;
		const value = valueText(locale, item, void 0).spoken;
		const max = fills[index]?.max;
		if (max === null || max === void 0) return `${item.label.spoken}: ${value}`;
		return `${item.label.spoken}: ${strings.ofMax(value, formatValue(locale, max, item.format, "full").spoken)}`;
	};
	return {
		family: "radial",
		sweep,
		count: items.length,
		keys: items.map(({ key }) => key),
		empty,
		description: empty ? `${strings.noData}.` : [polarStrings.descriptionRadial(countOf(locale, items.length, polarStrings.rings)), ...items.map((_, index) => `${optionName(index)}.`)].join(" "),
		instructions: "polar",
		orientation: "vertical",
		wrap: false,
		series: 0,
		page: null,
		optionName,
		pick: (point) => {
			if (angleInSweep(pointerAngle(point.x, point.y), sweep) === null) return null;
			const index = ringAt(Math.hypot(point.x, point.y), bands);
			return index === null ? null : {
				slot: index,
				near: null
			};
		},
		ray: (index) => {
			const fill = fills[index];
			const band = bands[index];
			if (fill === void 0 || band === void 0) return null;
			return {
				angle: sweep.start + ringAngle(fill, sweep.width) * sweep.direction,
				radius: 1
			};
		},
		selectKey: (index) => {
			const key = items[index]?.key;
			return key !== void 0 && Object.hasOwn(config, key) ? key : null;
		},
		selectable: Object.keys(config),
		table: {
			kind: "items",
			source,
			shares: (digits) => items.map((_, index) => share(index, digits))
		},
		readout: (kernel) => itemReadout(source, kernel, empty),
		issues,
		drawing: {
			kind: "radial",
			radial: {
				sweep,
				innerRadius: input.innerRadius,
				rings: items.map((item, index) => {
					const color = config[item.key]?.color;
					const fill = fills[index] ?? {
						max: null,
						share: null,
						over: false
					};
					return {
						key: item.key,
						paint: item.paint,
						stops: color !== void 0 && isRoleList(color) ? color.map((stop) => seriesPaint(item.key, stop)) : void 0,
						series: Object.keys(config).indexOf(item.key),
						quality: item.quality,
						band: bands[index] ?? {
							radius: 0,
							width: 0,
							inner: 0,
							outer: 0
						},
						angle: ringAngle(fill, sweep.width),
						over: fill.over
					};
				})
			},
			centre: radialCentre(items, fills, share, valueFormat)
		}
	};
}
/**
* A radial chart's centre: the active ring, or with nothing active the sum of the values over the
* sum of the maxima when every ring shares one format (CONTRACT section 8.13).
*/
function radialCentre(items, fills, share, valueFormat) {
	const format = sharedFormat(items);
	const sum = items.reduce((total, { value }) => total + (value !== null && value > 0 ? value : 0), 0);
	const maxima = fills.flatMap(({ max }) => max === null ? [] : [max]);
	const maxSum = maxima.length === fills.length ? maxima.reduce((total, max) => total + max, 0) : null;
	return {
		label: (index) => items[index]?.label.text ?? null,
		value: (index) => items[index]?.value ?? null,
		format: (index) => items[index]?.format ?? valueFormat ?? {},
		total: format === null ? null : {
			value: sum,
			format
		},
		share,
		totalShare: (digits) => format === null || maxSum === null || !(maxSum > 0) ? null : rounded(sum / maxSum * 100, digits),
		max: (index) => fills[index]?.max ?? null,
		totalMax: format === null ? null : maxSum
	};
}
/** A number rounded to `digits` fraction digits. */
function rounded(value, digits) {
	const unit = 10 ** digits;
	return Math.round(value * unit) / unit;
}
export { pieModel, qualityOf, radialModel, shareWords, sharedFormat, valueOf };

//# sourceMappingURL=chart-polar-item.js.map