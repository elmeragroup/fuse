"use client";
import { FOLLOW_SPEEDS } from "./layout/motion.js";
import { rideAt } from "./layout/ride.js";
import { easingCurve, followSpring, linearEasing, springEasing } from "./layout/spring.js";
// src/components/chart/chart-spring.ts
const timings = /* @__PURE__ */ new Map();
const glides = /* @__PURE__ */ new WeakMap();
/**
* A spring's duration in milliseconds and its easing: its `linear()` curve, or `ease-out` in an
* engine without `linear()`, where an unknown easing would throw.
*
* @param spring - The spring, one of the chart's fixed spring objects.
* @returns The timing, sampled once per page for each spring.
*/
function springTiming(spring) {
	const known = timings.get(spring);
	if (known !== void 0) return known;
	const { duration, easing, stops } = springEasing(spring);
	const supported = CSS.supports("transition-timing-function", easing);
	const peak = Math.max(1, ...stops.map(({ output }) => output));
	const held = stops.map(({ output, input }) => ({
		output: Number((output / peak).toFixed(5)),
		input
	}));
	const made = {
		duration,
		easing: supported ? easing : "ease-out",
		spring: supported,
		peak,
		held: linearEasing(held),
		played: easingCurve(stops),
		heldPlayed: easingCurve(held)
	};
	timings.set(spring, made);
	return made;
}
/**
* The spring a step moves the crosshair and the active dots on: `FOLLOW_FASTEST` for a keyboard
* step, which wants the least motion, so an arrow key held down never trails, and one that quickens
* with the pointer's speed for a pointer step. Every follower reads the same store in the same step,
* so all of them take the same spring.
*
* @param store - Root's store.
* @returns The spring.
*/
function stepSpring(store) {
	return followSpring(store.get().source === "keyboard" ? FOLLOW_SPEEDS.fast : store.pointer()?.speed ?? null);
}
/**
* The spring of a polar step that leaps across the dial, faster than the pointer's pace would carry
* it: `FOLLOW_FASTEST`, the keyboard step's, since the pointer is already where the step lands.
*
* @returns The spring.
*/
function leapSpring() {
	return followSpring(FOLLOW_SPEEDS.fast);
}
/**
* Glide an element onto the place it rests, from `by` CSS pixels away along x and y, plus whatever
* offset a running glide shows.
*
* @param element - The element whose resting place was just written.
* @param by - The old resting place less the new one.
* @param spring - The spring.
*/
function glideFrom(element, by, spring) {
	const shown = glideShown(element);
	start(element, [by[0] + (shown?.[0] ?? 0), by[1] + (shown?.[1] ?? 0)], spring, null);
}
/**
* Glide an element along the slot axis onto the place it rests, from `ride.along` CSS pixels away,
* with its offset across following the ride's keyframes. Along the slot axis it moves as
* `glideFrom` would move it on the same spring, so it keeps pace with the crosshair.
*
* @param element - The element whose resting place was just written.
* @param spring - The spring.
* @param ride - Where the element shows now, a running glide included, along the slot axis from
*   its rest, the slot axis, and the keyframes it plays.
*/
function rideFrom(element, spring, ride) {
	start(element, ride.axis === "x" ? [ride.along, 0] : [0, ride.along], spring, ride);
}
/**
* Glide a length property onto the value it rests at, from `by` CSS pixels away plus whatever
* offset a running glide of it shows, on the spring and the clock `glideFrom` moves a mark on. The
* element's own value is its rest, written first, and the glide plays over it.
*
* @param element - The element whose resting value was just written.
* @param property - The registered length property, such as `--chart-active-x`.
* @param rest - The resting value, in CSS pixels.
* @param by - The old resting value less the new one.
* @param spring - The spring.
*/
function glideLength(element, property, rest, by, spring) {
	const from = by + (glideShown(element)?.[0] ?? 0);
	snapGlide(element);
	const timing = springTiming(spring);
	if (!timing.spring || from === 0) return;
	keep(element, {
		animation: element.animate([{ [property]: `${String(rest + from)}px` }, { [property]: `${String(rest)}px` }], timing),
		from: [from, 0],
		spring,
		ride: null
	});
}
/**
* The offset an element's glide shows now, along x and y in CSS pixels, from the easing and the
* keyframes its animation plays, on the glide's own clock, or null when none runs.
*
* @param element - The element that may be gliding.
* @returns The offset, or null.
*/
function glideShown(element) {
	const running = glides.get(element);
	if (running === void 0) return null;
	const timing = springTiming(running.spring);
	const progress = Math.min(1, elapsed(running.animation) / timing.duration);
	const [x, y] = running.from;
	const { ride } = running;
	if (ride === null) {
		const moved = timing.played(progress);
		return [x * (1 - moved), y * (1 - moved)];
	}
	const { along, across } = rideAt(ride.frames, timing.heldPlayed(progress));
	return ride.axis === "x" ? [along, across] : [across, along];
}
/** Replace an element's glide with one from an offset, on a spring, riding a course if given. */
function start(element, from, spring, ride) {
	snapGlide(element);
	const timing = springTiming(spring);
	if (!timing.spring) return;
	const [x, y] = from;
	if (x === 0 && y === 0) return;
	if (ride === null) {
		keep(element, {
			animation: element.animate([{ translate: shift(x, y) }, { translate: "0px 0px" }], timing),
			from,
			spring,
			ride: null
		});
		return;
	}
	const frames = ride.keyframes(timing.peak);
	keep(element, {
		animation: element.animate(frames.map(({ offset, along, across }) => ({
			offset,
			translate: ride.axis === "x" ? rounded(along, across) : rounded(across, along)
		})), {
			duration: timing.duration,
			easing: timing.held
		}),
		from,
		spring,
		ride: {
			axis: ride.axis,
			frames
		}
	});
}
/** Hold an element's running glide until it finishes or another replaces it. */
function keep(element, glide) {
	glides.set(element, glide);
	glide.animation.onfinish = () => {
		if (glides.get(element)?.animation === glide.animation) glides.delete(element);
	};
}
function shift(x, y) {
	return `${String(x)}px ${String(y)}px`;
}
/** A shift to a hundredth of a pixel, which keeps a long keyframe list short to parse. */
function rounded(x, y) {
	return `${x.toFixed(2)}px ${y.toFixed(2)}px`;
}
/**
* End an element's glide at once, so it shows the place it rests. Every path that places a mark
* without a step's glide calls it: a mark that shows or hides, a commit or a resize, a change of
* look, reduced motion and unmounting.
*
* @param element - The element that may be gliding.
*/
function snapGlide(element) {
	glides.get(element)?.animation.cancel();
	glides.delete(element);
}
/** How far a glide has run, in milliseconds. */
function elapsed(animation) {
	const time = Number(animation.currentTime ?? 0);
	return Number.isFinite(time) ? time : 0;
}
export { glideFrom, glideLength, glideShown, leapSpring, rideFrom, snapGlide, springTiming, stepSpring };

//# sourceMappingURL=chart-spring.js.map