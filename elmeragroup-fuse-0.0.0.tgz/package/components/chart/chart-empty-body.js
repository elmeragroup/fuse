"use client";
import { CHART_STRINGS } from "./format/chart-strings.js";
import { Empty } from "../empty/empty.js";
import { Fragment, jsx } from "react/jsx-runtime";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
// src/components/chart/chart-empty-body.tsx
/**
* Fuse Empty in the plot cell while the Root draws nothing. The part is the plot cell's `div`, and
* Fuse Empty inside it keeps its own slots and spacing. Its default children are the dictionary's
* "Ingen data for perioden". While anything draws it renders nothing.
*
* @param props - The part's props, the Root's locale, and whether the Root is empty.
* @returns The empty state, or an empty fragment.
*/
function ChartEmptyBody({ locale, empty, render, className, children, ...props }) {
	const element = useRender({
		defaultTagName: "div",
		render,
		props: {
			"data-slot": "chart-empty",
			...mergeProps({
				className,
				children: /* @__PURE__ */ jsx(Empty.Root, { children: children ?? /* @__PURE__ */ jsx(Empty.Description, { children: CHART_STRINGS[locale].noData }) })
			}, props)
		}
	});
	return empty ? element : /* @__PURE__ */ jsx(Fragment, {});
}
Object.assign(ChartEmptyBody, { displayName: "Chart.EmptyBody" });
export { ChartEmptyBody };

//# sourceMappingURL=chart-empty-body.js.map