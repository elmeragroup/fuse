"use client";
import { Skeleton } from "../skeleton/skeleton.js";
import { ChartSkeletonBody } from "./chart-skeleton-body.js";
import { jsx } from "react/jsx-runtime";
// src/components/chart/clock-chart-skeleton.tsx
/**
* A loading placeholder that renders in place of `ClockChart.Root`, for example as a Suspense
* fallback. One Fuse Skeleton annulus sketches the dial, and one Fuse Loader names the wait.
*
* @beta
*/
function ClockChartSkeleton({ label, ...props }) {
	return /* @__PURE__ */ jsx(ChartSkeletonBody, {
		variant: "clock",
		label,
		marks: /* @__PURE__ */ jsx(Skeleton, { "data-slot": "chart-skeleton-mark" }),
		...props
	});
}
Object.assign(ClockChartSkeleton, { displayName: "ClockChart.Skeleton" });
export { ClockChartSkeleton };

//# sourceMappingURL=clock-chart-skeleton.js.map