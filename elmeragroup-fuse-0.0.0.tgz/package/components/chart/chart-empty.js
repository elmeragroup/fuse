"use client";
import { useChartReadout } from "./chart-readout.js";
import { ChartEmptyBody } from "./chart-empty-body.js";
import { jsx } from "react/jsx-runtime";
// src/components/chart/chart-empty.tsx
/**
* Fuse Empty in the plot cell, shown when no slot holds a reading, which covers no rows and rows
* whose every value is missing. The part is the plot cell's `div`, and Fuse Empty inside it keeps
* its own slots and spacing. Its default children are the dictionary's "Ingen data for perioden".
* While any slot holds a reading it renders nothing.
*
* @beta
*/
function ChartEmpty(props) {
	const { locale, empty } = useChartReadout("Chart.Empty");
	return /* @__PURE__ */ jsx(ChartEmptyBody, {
		locale,
		empty,
		...props
	});
}
Object.assign(ChartEmpty, { displayName: "Chart.Empty" });
export { ChartEmpty };

//# sourceMappingURL=chart-empty.js.map