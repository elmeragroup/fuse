"use client";
import { pathValues, topologyOf } from "./layout/line-path.js";
import { useIntro } from "./chart-store.js";
import { ChartCompositionError } from "./layout/errors.js";
import { alongLength, valueAt } from "./layout/plot-frame.js";
import { seriesPathOf } from "./layout/series-path.js";
import { useSvgIdPrefix } from "./chart-dom.js";
import { seriesPaintOf, stackedScaleError } from "./chart-paint.js";
import { usePlotRead } from "./chart-plot-measure.js";
import { useChartFrame } from "./chart-plot.js";
import { seriesOf } from "./layout/series-of.js";
import { useCommitMotion, useMotionMark } from "./chart-motion-mark.js";
import { centreAlong, pathAxes, placePath, seriesPathKind, slotStep } from "./chart-path-draw.js";
import { useLayoutEffect, useMemo, useRef, useState } from "react";
// src/components/chart/chart-series-path.ts
/**
* The life of a series path, which a Line, an Area and a Bar's path form share. `usePathMark` owns
* a path's registration with Root's loop, the commit classifier, the placement of every commit and
* the route record's cleanup. `useSeriesPath` adds what a Line and an Area lay out for their series:
* the curve rule, the vertices over the measured plot, their topology, the look and the resting
* numbers. Each part keeps its writer at module scope in its own module and hands it in.
*/
/**
* Register a series path with Root's loop and place it on every commit: a data update tweens its
* route or crossfades it, and every other commit places its rest as the commit classifier asks.
* The path's route record leaves with the mark.
*
* @param draw - The part's writer, bound at module scope in the part's module.
* @param input - Root's context, the plot the path draws in, the series and what draws it, the
*   writer's look, and what the commit places, or null before the plot is measured.
* @returns The path's handles.
*/
function usePathMark(draw, input) {
	const { context, plot, frame, axes, seriesIndex, route, placed } = input;
	const { motion, update, paths } = context;
	const mark = useMotionMark(motion, draw, placed?.look ?? null, axes);
	const commit = useCommitMotion(update, plot, context.orientation, frame);
	const memoryRef = useRef(null);
	const lastLookRef = useRef(null);
	const outgoingRef = useRef(null);
	useLayoutEffect(() => {
		const asked = commit();
		if (placed === null) return;
		placePath(asked, {
			mark,
			motion,
			paths,
			seriesIndex,
			drawn: route,
			kind: placed.kind,
			look: placed.look,
			path: placed.path,
			topology: placed.topology,
			rest: placed.rest,
			memory: memoryRef,
			lastLook: lastLookRef,
			outgoing: outgoingRef.current,
			draw
		});
	});
	useLayoutEffect(() => () => {
		paths.delete(seriesIndex, route, memoryRef);
	}, [
		paths,
		seriesIndex,
		route
	]);
	return {
		markRef: mark.ref,
		outgoingRef,
		node: mark.node
	};
}
/**
* Register the line a series path rests on with Root's paths, so an active dot rides it without
* reading the page: the part's own resting numbers drawn by `draw`, a Line's path or an Area's top
* edge. The reader draws it when a dot first asks, once for each resting state.
*
* @param paths - Root's path routes.
* @param seriesIndex - The series ordinal.
* @param kind - What the part draws.
* @param resting - The part's resting look, numbers and topology, or null before it measures.
* @param draw - Draws the line from the resting state, as path data.
*/
function useRestingLine(paths, seriesIndex, kind, resting, draw) {
	const latest = useRef({
		resting,
		draw
	});
	useLayoutEffect(() => {
		latest.current = {
			resting,
			draw
		};
	});
	useLayoutEffect(() => {
		let kept = null;
		return paths.setLine(seriesIndex, kind, () => {
			const now = latest.current;
			if (now.resting === null) return "";
			if (kept?.resting !== now.resting) kept = {
				resting: now.resting,
				line: now.draw(now.resting)
			};
			return kept.line;
		});
	}, [
		paths,
		seriesIndex,
		kind
	]);
}
/**
* Hold the series a part draws as the one path of its kind in the chart, for as long as the part
* is mounted. Each layout effect claims after the commit's unmounted parts let go, so a part that
* replaces another of its kind takes the series over.
*
* @param paths - Root's path routes.
* @param part - The part's display name, which the error names.
* @param kind - What the part draws: a Line's line, an Area's area or a Bar's columns.
* @param dataKey - The config key the part draws.
* @throws {ChartCompositionError} `series-drawn-twice` from the layout effect of a second part of
*   one kind on one key.
*/
function useSeriesOwner(paths, part, kind, dataKey) {
	useLayoutEffect(() => paths.claim(part, kind, dataKey), [
		paths,
		part,
		kind,
		dataKey
	]);
}
/** A part with no props of its own that set its stroke. */
const NO_INPUTS = [];
/**
* Lay out one series path over the measured plot, and place it on Root's loop through
* `usePathMark`.
*
* @param part - The calling part's display name.
* @param draw - The part's writer, bound at module scope in the part's module.
* @param options - Root's context and the part's layout, the series key, the curve, the route kind,
*   the numbers per vertex, `LINE_STRIDE` or `AREA_STRIDE`, and how a stroked path reads its width.
* @returns The state the part draws from.
* @throws {ChartCompositionError} `step-curve-needs-cells` for a step curve under a point scale, and
*   `scale-colour-on-stack` for a scale colour on a stacked series.
*/
function useSeriesPath(part, draw, options) {
	const { context, layout, dataKey, curve, route, stride, stroke } = options;
	const { model, update, xScale } = context;
	if ((curve === "step-after" || curve === "step-before") && xScale === "point") throw new ChartCompositionError(part, "step-curve-needs-cells", `draws curve="${curve}" under xScale="point", where slots have no cells to run across. Use xScale="band", or curve="step".`);
	const series = seriesOf(model, dataKey);
	const config = context.config[dataKey];
	const color = config?.color ?? "chart-1";
	const stacked = model.stacks.some(({ keys }) => keys.includes(dataKey));
	const scaleRule = stackedScaleError(part, color, stacked, context.stackOffset);
	if (scaleRule !== null) throw scaleRule;
	const drawn = useChartFrame(part, layout);
	const frame = drawn?.frame ?? null;
	const prefix = useSvgIdPrefix(`chart-${route}`);
	const intro = useIntro(context.store, update.kind, context.entrance, frame !== null);
	const columns = frame === null ? void 0 : alongLength(frame);
	const path = useMemo(() => series === void 0 ? null : seriesPathOf(model, series, update.keys, columns), [
		model,
		series,
		update.keys,
		columns
	]);
	const paint = useMemo(() => seriesPaintOf(dataKey, color, series), [
		dataKey,
		color,
		series
	]);
	const missing = config?.missing ?? "gap";
	const topology = useMemo(() => topologyOf(path?.vertices ?? [], missing), [path, missing]);
	const moving = useRef(null);
	const [width, setWidth] = useState(stroke?.guess ?? 0);
	const readWidth = useRef(width);
	const look = useMemo(() => frame === null ? null : {
		frame,
		xScale,
		curve,
		topology,
		moving,
		clips: {
			solid: `${prefix}-solid`,
			marked: `${prefix}-marked`
		},
		stroke: { width }
	}, [
		frame,
		xScale,
		curve,
		topology,
		prefix,
		width
	]);
	const rest = useMemo(() => frame === null || path === null ? [] : pathValues(path.vertices, stride, centreAlong(frame, xScale), (value) => valueAt(frame, value)), [
		frame,
		path,
		xScale,
		stride
	]);
	const axes = useMemo(() => pathAxes(context.orientation, stride), [context.orientation, stride]);
	const kind = useMemo(() => frame === null ? null : seriesPathKind(stride, slotStep(frame, xScale)), [
		frame,
		stride,
		xScale
	]);
	const placed = useMemo(() => look === null || path === null || kind === null ? null : {
		look,
		kind,
		path,
		topology,
		rest
	}, [
		look,
		path,
		kind,
		topology,
		rest
	]);
	useSeriesOwner(context.paths, part, route, dataKey);
	const mark = usePathMark(draw, {
		context,
		plot: drawn?.plot ?? null,
		frame: drawn?.frame ?? null,
		axes,
		seriesIndex: series?.seriesIndex ?? 0,
		route,
		placed
	});
	usePlotRead(() => {
		if (stroke === void 0) return true;
		const group = mark.node();
		if (group === null) return false;
		const next = stroke.read(group);
		if (next !== readWidth.current) {
			readWidth.current = next;
			setWidth(next);
		}
		return true;
	}, stroke?.inputs ?? NO_INPUTS);
	const absent = series === void 0;
	const resting = useMemo(() => look === null || absent ? null : {
		look,
		rest,
		topology
	}, [
		look,
		absent,
		rest,
		topology
	]);
	return {
		...mark,
		series,
		seriesIndex: series?.seriesIndex ?? 0,
		paint,
		frame,
		prefix,
		intro,
		resting
	};
}
export { usePathMark, useRestingLine, useSeriesOwner, useSeriesPath };

//# sourceMappingURL=chart-series-path.js.map