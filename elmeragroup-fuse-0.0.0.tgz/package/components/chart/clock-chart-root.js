"use client";
import { useLocale } from "../../intl/locale-context.js";
import { isThemeDevelopment } from "../../theme/validate-theme.js";
import { nextSlotStart, slotStart } from "./format/time-format.js";
import { ChartCompositionError, ChartDataError, DATA_MESSAGES, dataMessage, issueGroups } from "./layout/errors.js";
import { intervalNests } from "./layout/coarse-slots.js";
import { sameItems } from "./layout/same-items.js";
import { instantOf } from "./layout/x-domain.js";
import { buildCartesianModel } from "./layout/cartesian-model.js";
import { colourFamilyError, nonFiniteThresholds } from "./chart-paint.js";
import { seriesLabel } from "./format/series-label.js";
import { sameConfig, sameShallow, useSteady } from "./chart-steady.js";
import { clockModel } from "./chart-polar-clock.js";
import { PolarRoot } from "./chart-polar-root.js";
import { useMemo } from "react";
import { jsx } from "react/jsx-runtime";
// src/components/chart/clock-chart-root.tsx
/** The cycles each interval nests in, and the zone a dial needs. */
function assertDial(cycle, interval, config, timeZone) {
	if (timeZone === void 0) throw new ChartCompositionError("ClockChart.Root", "time-axis-without-zone", "draws a dial with no time zone. Pass timeZone on the Root or on LocaleProvider, the IANA zone of the data's market, such as \"Europe/Oslo\".");
	const nests = (unit) => cycle === "day" && (unit === "quarter-hour" || unit === "hour") || cycle === "week" && (unit === "hour" || unit === "day") || cycle === "year" && (unit === "hour" || unit === "day" || unit === "month");
	if (!nests(interval)) throw new ChartCompositionError("ClockChart.Root", "interval-not-nested", `has interval ${JSON.stringify(interval)}, which does not nest the ${JSON.stringify(cycle)} cycle. A day takes quarter-hours or hours, a week hours or days, and a year hours, days or months.`);
	for (const [key, entry] of Object.entries(config)) {
		const own = entry.interval;
		if (own === void 0) continue;
		if (!nests(own) || !intervalNests(interval, own)) throw new ChartCompositionError("ClockChart.Root", "interval-not-nested", `has config ${JSON.stringify(key)} interval ${JSON.stringify(own)}, which does not nest Root's ${JSON.stringify(interval)} inside the ${JSON.stringify(cycle)} cycle.`);
	}
}
/**
* The root of clock charts, which draw one cycle of a time series round a calendar dial: a day, a
* week or a year from 12 o'clock, every slot an equal angle.
*
* @template TRow - The row type, inferred from `data`.
* @template TConfig - The config, inferred with its literal keys.
* @template TXKey - The instant column, inferred from `xKey`.
* @template TCycle - The dial's cycle, inferred from `cycle`.
* @beta
*/
function ClockChartRoot(props) {
	const { data, config, xKey, cycle, interval, period, now, timeZone: ownZone, xFormat, stackOffset = "diverging", yBaseline = "zero", yInclude, innerRadius = .3, radiusScale = "radial", defaultActiveX, selectedKey, defaultSelectedKey, onSelectedKeyChange, description, children, ...figure } = props;
	const { locale, timeZone: providerZone } = useLocale();
	const timeZone = ownZone ?? providerZone;
	assertDial(cycle, interval, config, timeZone);
	const steadyConfig = useSteady(config, sameConfig);
	const include = useSteady(yInclude, sameItems);
	const steadyPeriod = useSteady(period, sameItems);
	const steadyFormat = useSteady(xFormat, sameShallow);
	const colourError = useMemo(() => colourFamilyError("ClockChart.Root", steadyConfig, Object.keys(steadyConfig)), [steadyConfig]);
	if (colourError !== null) throw colourError;
	const name = "aria-label" in figure ? figure["aria-label"] : void 0;
	const nowInstant = now === void 0 ? void 0 : instantOf(now);
	const firstX = data[0]?.[xKey];
	const anchor = nowInstant ?? (firstX === void 0 ? void 0 : instantOf(firstX));
	const cycleStart = anchor === void 0 || Number.isNaN(anchor) ? void 0 : slotStart(anchor, cycle, timeZone);
	const window = steadyPeriod !== void 0 ? [instantOf(steadyPeriod[0]), instantOf(steadyPeriod[1])] : cycleStart === void 0 ? void 0 : [cycleStart, nextSlotStart(cycleStart, cycle, timeZone)];
	const windowStart = window?.[0];
	const windowEnd = window?.[1];
	const model = useMemo(() => {
		const issues = [];
		const series = buildCartesianModel({
			rows: data,
			series: Object.entries(steadyConfig).map(([key, entry]) => [key, {
				stack: entry.stack,
				qualityKey: entry.qualityKey,
				projectedFrom: entry.projectedFrom,
				interval: entry.interval
			}]),
			xKey,
			time: {
				interval,
				timeZone,
				period: windowStart === void 0 || windowEnd === void 0 ? void 0 : [windowStart, windowEnd],
				now: nowInstant
			},
			stackOffset,
			baseline: yBaseline,
			include: include ?? []
		});
		const [first] = series.issues;
		if (first !== void 0 && isThemeDevelopment()) throw new ChartDataError("ClockChart.Root", first.rule, dataMessage(first, series.rowAt));
		for (const { rule, subject, first: issue, count } of issueGroups(series.issues)) issues.push({
			rule,
			subject,
			message: `ClockChart.Root ${dataMessage(issue, series.rowAt, count)}`
		});
		for (const key of nonFiniteThresholds(steadyConfig)) {
			const message = `${DATA_MESSAGES["non-finite-threshold"]} Series ${JSON.stringify(key)}.`;
			if (isThemeDevelopment()) throw new ChartDataError("ClockChart.Root", "non-finite-threshold", message);
			issues.push({
				rule: "non-finite-threshold",
				subject: key,
				message: `ClockChart.Root ${message}`
			});
		}
		return clockModel({
			model: series,
			config: steadyConfig,
			rows: data,
			locale,
			timeZone,
			cycle,
			inner: Math.min(.9, Math.max(0, innerRadius)),
			scale: radiusScale,
			now: nowInstant,
			xFormat: steadyFormat,
			name,
			issues,
			stackOffset,
			baseline: yBaseline
		});
	}, [
		data,
		steadyConfig,
		xKey,
		interval,
		timeZone,
		windowStart,
		windowEnd,
		nowInstant,
		stackOffset,
		yBaseline,
		include,
		locale,
		cycle,
		innerRadius,
		radiusScale,
		steadyFormat,
		name
	]);
	const defaultSlot = defaultActiveX === void 0 || model.drawing.kind !== "clock" ? -1 : model.drawing.clock.slotOf(defaultActiveX);
	return /* @__PURE__ */ jsx(PolarRoot, {
		model,
		figure,
		defaultActive: defaultSlot === -1 ? null : defaultSlot,
		selectedKey,
		defaultSelectedKey,
		onSelectedKeyChange,
		labelOf: (key) => seriesLabel({ config: steadyConfig }, key).text,
		description,
		locale,
		children
	});
}
Object.assign(ClockChartRoot, { displayName: "ClockChart.Root" });
export { ClockChartRoot };

//# sourceMappingURL=clock-chart-root.js.map