"use client";
import { areaPaths, areaTopPath } from "./layout/line-path.js";
import { ChartCompositionError } from "./layout/errors.js";
import { runMargins } from "./layout/plot-frame.js";
import { useSeriesPart } from "./chart-context.js";
import { useFirstDraw } from "./chart-motion-mark.js";
import { placeOf, topologyAt, writePath } from "./chart-path-draw.js";
import { useRestingLine, useSeriesPath } from "./chart-series-path.js";
import { PATH_GLOW, plotGlowRegion, valueGlow } from "./chart-glow-filter.js";
import { PathPaint, hasPathPaint } from "./chart-path-paint.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-area.tsx
/** Draw an area's frame from the loop's numbers: its fill, and the hatched twin over its spans. */
function drawArea(group, look, values) {
	if (look === null) return;
	const topology = topologyAt(look.moving.current, look.topology, values.length / 3);
	const { area, dots, hatched } = areaPaths(values, topology, placeOf(look));
	writePath(group, look, area, hatched, "overlay", dots);
}
/**
* The paint servers of an area's looks. Each look is a mask over the series paint: a ramp along the
* value axis for the gradients, and a texture for the patterned fills and for the hatched twin that
* marks estimated, bridged and projected spans.
*/
function AreaMasks({ prefix, frame, variant }) {
	const { width, height } = frame.box;
	const vertical = frame.orientation === "vertical";
	const look = variant === "gradient" || variant === "gradient-reverse" ? "ramp" : variant;
	const mask = (id, fill) => /* @__PURE__ */ jsx("mask", {
		id,
		maskUnits: "userSpaceOnUse",
		x: "0",
		y: "0",
		width,
		height,
		children: /* @__PURE__ */ jsx("rect", {
			width,
			height,
			fill
		})
	});
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		look === "ramp" ? /* @__PURE__ */ jsxs("linearGradient", {
			id: `${prefix}-ramp`,
			gradientUnits: "userSpaceOnUse",
			x1: vertical ? 0 : width,
			y1: "0",
			x2: "0",
			y2: vertical ? height : 0,
			children: [/* @__PURE__ */ jsx("stop", {
				offset: "0",
				"data-part": "near"
			}), /* @__PURE__ */ jsx("stop", {
				offset: "1",
				"data-part": "far"
			})]
		}) : null,
		look === "dotted" ? /* @__PURE__ */ jsx("pattern", {
			id: `${prefix}-texture`,
			width: "6",
			height: "6",
			patternUnits: "userSpaceOnUse",
			children: /* @__PURE__ */ jsx("circle", {
				cx: "3",
				cy: "3",
				r: "1"
			})
		}) : null,
		look === "lines" ? /* @__PURE__ */ jsx("pattern", {
			id: `${prefix}-texture`,
			width: "5",
			height: "5",
			patternUnits: "userSpaceOnUse",
			patternTransform: "rotate(45)",
			children: /* @__PURE__ */ jsx("rect", {
				width: "1",
				height: "5"
			})
		}) : null,
		/* @__PURE__ */ jsx("pattern", {
			id: `${prefix}-hatch`,
			width: "6",
			height: "6",
			patternUnits: "userSpaceOnUse",
			patternTransform: "rotate(45)",
			children: /* @__PURE__ */ jsx("rect", {
				width: "3",
				height: "6"
			})
		}),
		look === "hatched" ? /* @__PURE__ */ jsx("pattern", {
			id: `${prefix}-hatch-dense`,
			width: "3",
			height: "3",
			patternUnits: "userSpaceOnUse",
			patternTransform: "rotate(45)",
			children: /* @__PURE__ */ jsx("rect", {
				width: "1.5",
				height: "3"
			})
		}) : null,
		look === "solid" ? null : mask(`${prefix}-look`, look === "ramp" ? `url(#${prefix}-ramp)` : `url(#${prefix}-${look === "hatched" ? "hatch" : "texture"})`),
		mask(`${prefix}-marks`, `url(#${prefix}-${look === "hatched" ? "hatch-dense" : "hatch"})`)
	] });
}
/**
* One series as a filled area down to the baseline, which is 0 in every layout an Area sits in.
* Series that share a `stack` id stack, each filling from the series below it. The area draws its
* fill only, so a Line on the same key draws its edge. The spans of estimated readings, of a
* bridge under `missing: "connect"` and of the projected tail draw hatched over the fill. It moves
* on a data update as `Chart.Line` does. A chart draws each series with one Area, and a second Area
* on the same `dataKey` throws `series-drawn-twice` once it mounts.
*
* @beta
*/
function ChartArea({ dataKey, variant = "gradient", curve = "monotone", className, style }) {
	const { context, layout } = useSeriesPart("Chart.Area", dataKey);
	if (layout.baseline === "none") throw new ChartCompositionError("Chart.Area", "baseline-required", "draws in a layout with yBaseline=\"none\", but an area encodes its value as the filled height from 0. Keep the zero baseline, or draw a Chart.Line alone.");
	const { series, seriesIndex, resting, prefix, frame, outgoingRef, markRef, intro, paint } = useSeriesPath("Chart.Area", drawArea, {
		context,
		layout,
		dataKey,
		curve,
		route: "area",
		stride: 3
	});
	const drawn = useFirstDraw(() => resting === null ? null : areaPaths(resting.rest, resting.topology, placeOf(resting.look)));
	useRestingLine(context.paths, seriesIndex, "area", resting, (rest) => areaTopPath(rest.rest, rest.topology, placeOf(rest.look)));
	const margins = runMargins(frame);
	const glow = valueGlow(paint, prefix, PATH_GLOW);
	return /* @__PURE__ */ jsx("svg", {
		"data-slot": "chart-area-series",
		"data-orientation": context.orientation,
		"data-variant": variant,
		"data-series": seriesIndex,
		"data-paint": glow?.paint,
		"data-intro": intro,
		"aria-hidden": "true",
		className,
		style: {
			"--chart-series-paint": paint.base,
			"--chart-series": seriesIndex,
			"--_paint-server": hasPathPaint(paint) ? `url(#${prefix}-paint)` : void 0,
			"--_glow": glow?.url,
			"--_run-before": margins.before,
			"--_run-after": margins.after,
			...style
		},
		children: frame === null || series === void 0 || drawn === null ? null : /* @__PURE__ */ jsxs(Fragment, { children: [
			/* @__PURE__ */ jsxs("defs", { children: [
				/* @__PURE__ */ jsx(PathPaint, {
					id: `${prefix}-paint`,
					paint,
					frame
				}),
				glow?.filter(plotGlowRegion(frame.box)),
				/* @__PURE__ */ jsx(AreaMasks, {
					prefix,
					frame,
					variant
				})
			] }),
			/* @__PURE__ */ jsxs("g", {
				ref: markRef,
				children: [
					/* @__PURE__ */ jsx("clipPath", {
						id: `${prefix}-solid`,
						"data-part": "solid-clip"
					}),
					/* @__PURE__ */ jsx("clipPath", {
						id: `${prefix}-marked`,
						"data-part": "marked-clip"
					}),
					/* @__PURE__ */ jsx("path", {
						"data-slot": "chart-area",
						"data-part": "solid",
						"data-series": seriesIndex,
						mask: variant === "solid" ? void 0 : `url(#${prefix}-look)`,
						d: drawn.area
					}),
					/* @__PURE__ */ jsx("path", {
						"data-slot": "chart-area",
						"data-part": "marked",
						"data-series": seriesIndex,
						mask: `url(#${prefix}-marks)`,
						d: ""
					}),
					/* @__PURE__ */ jsx("path", {
						"data-slot": "chart-area",
						"data-part": "dot",
						"data-series": seriesIndex,
						d: drawn.dots
					}),
					/* @__PURE__ */ jsx("path", {
						"data-slot": "chart-area",
						"data-part": "dot-marked",
						"data-series": seriesIndex,
						d: ""
					})
				]
			}),
			/* @__PURE__ */ jsx("g", {
				ref: outgoingRef,
				"data-part": "outgoing"
			})
		] })
	});
}
Object.assign(ChartArea, { displayName: "Chart.Area" });
export { ChartArea };

//# sourceMappingURL=chart-area.js.map