"use client";
import { OverlayPortal } from "../overlay/overlay-portal.js";
import { ChartHeldPointContext, ChartLiveContext } from "./chart-scope-contexts.js";
import { useActivePoint } from "./chart-active-point.js";
import { useChartReadout } from "./chart-readout.js";
import { useChartFollower } from "./chart-followers.js";
import { TOOLTIP_POSITIONER, chartTakesPress, tooltipPopupClass, watchOverflow } from "./chart-tooltip-popup.js";
import { shareCorridor } from "./chart-tooltip-corridor.js";
import { createTooltipGlider } from "./chart-tooltip-glide.js";
import { useCallback, useEffect, useLayoutEffect, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { flushSync } from "react-dom";
import { Tooltip } from "@base-ui/react/tooltip";
// src/components/chart/chart-tooltip-body.tsx
/**
* The tooltip every chart family shares: the popup over the active datum, which a pointer can move
* into and pin, its glide between steps and its dismissals. It reads the Root through its readout,
* and the family's Tooltip part hands it the anchor the popup rests on and the content it shows.
*/
const STRAIGHT = { kind: "straight" };
/**
* The positioner props of a popup that keeps its lane: Base UI puts its corner at the lane's anchor
* and never moves it to avoid a collision, since the anchor places it inside the Root's figure.
*/
function laneProps(figure) {
	return {
		...TOOLTIP_POSITIONER,
		align: "start",
		collisionAvoidance: {
			side: "none",
			align: "none"
		},
		collisionPadding: 0,
		collisionBoundary: figure ?? "clipping-ancestors"
	};
}
/**
* The popup over the active datum. A pointer, key or touch step to another datum glides it there
* over `--chart-glide` on a spring that never overshoots, unless the reader prefers reduced motion,
* and opening, scrolling, resizing, a data update, a change of side and a route with no way move it
* at once. Touch passes through the popup to the plot, except on a popup that scrolls, where a drag
* scrolls it and a tap dismisses it. The popup stays while the pointer is on the plot or inside the
* popup and while the option has focus. It is hidden from screen readers, which read the same values
* from the plot's option.
*
* @param props - The family's anchor, the Tooltip's props and the popup's content.
* @returns The tooltip.
*/
function ChartTooltipBody({ variant, placement, placer, className, style, children }) {
	const readout = useChartReadout("Chart.Tooltip");
	const lane = placer.keeps === "lane";
	const { store, id, root: rootOf } = readout;
	const point = useActivePoint(readout, true);
	const active = point.index;
	const open = active !== null;
	const [kept, setKept] = useState(false);
	if (open && !kept) setKept(true);
	const [shown, setShown] = useState(null);
	if (active !== null && (active !== shown?.index || point.near !== shown.near)) setShown({
		index: active,
		near: point.near
	});
	const positioner = useRef(null);
	const [measures, setMeasures] = useState(0);
	const stepped = useRef(null);
	useChartFollower("Chart.Tooltip", (current, cause) => {
		if (cause === "step") stepped.current = current?.slot ?? null;
	});
	const { virtual, side, bridge, revision, forget, watch, freezes, sideOffset, alignOffset } = placer.useAnchor({
		active,
		positioner,
		placement,
		measures
	});
	const pick = readout.usePick();
	const latestFreezes = useRef(freezes);
	useLayoutEffect(() => {
		latestFreezes.current = freezes;
	});
	useEffect(() => {
		if (!open) return void 0;
		shareCorridor(store, (from, to) => latestFreezes.current(from, to, positioner.current?.getAttribute("data-side") ?? null));
		return () => {
			shareCorridor(store, null);
		};
	}, [open, store]);
	const glider = useRef(null);
	const watchPositioner = useCallback((node) => {
		positioner.current = node;
		glider.current = node === null || lane ? null : createTooltipGlider(node, rootOf());
		return () => {
			glider.current?.dispose();
			glider.current = null;
			positioner.current = null;
		};
	}, [rootOf, lane]);
	const latestAnchor = useRef(virtual);
	const before = useRef({
		active: null,
		revision
	});
	useLayoutEffect(() => {
		latestAnchor.current = virtual;
	}, [virtual]);
	useLayoutEffect(() => {
		const last = before.current;
		before.current = {
			active,
			revision
		};
		if (active === null) forget("closed");
		else if (last.active === null || last.revision !== revision) forget("moved");
		const steps = last.active !== null && active !== null && last.active !== active && stepped.current === active && last.revision === revision;
		stepped.current = null;
		if (steps) glider.current?.arm(() => latestAnchor.current?.placed().route ?? STRAIGHT);
		else glider.current?.stop();
	}, [
		active,
		revision,
		forget
	]);
	useEffect(() => {
		if (!open) return void 0;
		return watch(() => {
			glider.current?.stop();
			flushSync(() => setMeasures((count) => count + 1));
		});
	}, [open, watch]);
	const frozen = useRef(false);
	const touchInput = ["touch", "pen"].includes(store.pointer()?.type ?? "");
	return /* @__PURE__ */ jsx(Tooltip.Root, {
		open,
		onOpenChange: (next, details) => {
			if (next || chartTakesPress(details, rootOf())) return;
			store.dismiss();
		},
		onOpenChangeComplete: (isOpen) => {
			if (!isOpen) setShown(null);
		},
		children: /* @__PURE__ */ jsx(OverlayPortal, {
			portal: Tooltip.Portal,
			keepMounted: kept,
			children: /* @__PURE__ */ jsx(Tooltip.Positioner, {
				...lane ? laneProps(rootOf()) : TOOLTIP_POSITIONER,
				anchor: virtual,
				side,
				sideOffset: ({ side: placed, positioner: size }) => sideOffset(placed, size),
				alignOffset: ({ side: placed }) => {
					const node = positioner.current;
					return node === null ? 0 : alignOffset(placed, node);
				},
				ref: watchPositioner,
				children: /* @__PURE__ */ jsxs(Tooltip.Popup, {
					"data-slot": "chart-tooltip",
					"data-variant": variant,
					"data-input": touchInput ? "touch" : void 0,
					"aria-hidden": "true",
					ref: watchOverflow,
					className: tooltipPopupClass(variant, className),
					style,
					onClick: (event) => {
						if (event.currentTarget.dataset.input === "touch") store.dismiss();
					},
					onPointerEnter: (event) => {
						const from = store.pointer();
						frozen.current = from !== null && freezes(from, {
							x: event.clientX,
							y: event.clientY
						}, event.currentTarget.getAttribute("data-side"));
					},
					onPointerMove: (event) => {
						const snapshot = store.get();
						if (frozen.current || snapshot.pinned || snapshot.source === "keyboard") return;
						const next = pick(event.clientX, event.clientY);
						if (next !== null && next.slot !== snapshot.active) store.set({
							active: next.slot,
							source: "pointer",
							near: next.near
						});
					},
					onPointerLeave: (event) => {
						const surface = document.getElementById(`${id}-surface`);
						if (surface !== null && event.relatedTarget instanceof Node && surface.contains(event.relatedTarget)) return;
						if (store.get().source === "pointer" && !store.get().pinned) store.set({
							active: null,
							source: null,
							near: null
						});
					},
					children: [/* @__PURE__ */ jsx(ChartLiveContext, {
						value: true,
						children: /* @__PURE__ */ jsx(ChartHeldPointContext, {
							value: open ? null : shown,
							children
						})
					}), bridge ? /* @__PURE__ */ jsx("span", { "data-slot": "chart-tooltip-bridge" }) : null]
				})
			})
		})
	});
}
Object.assign(ChartTooltipBody, { displayName: "Chart.TooltipBody" });
export { ChartTooltipBody };

//# sourceMappingURL=chart-tooltip-body.js.map