"use client";
import { useChartStore } from "./chart-store.js";
import { ChartSelectionContext } from "./chart-readout-port.js";
import { slotX } from "./layout/x-domain.js";
import { keepSlot, stepSlot } from "./layout/slot-window.js";
import { optionBand } from "./layout/plot-frame.js";
import { useChartRoot } from "./chart-context.js";
import { useRootFrame } from "./chart-plot.js";
import { pointerSlot } from "./chart-pick.js";
import { optionName } from "./chart-text.js";
import { StatusRegion, SurfaceName, listboxProps, useGestureEnd, useOptionHandoff } from "./chart-listbox.js";
import { useTapLift } from "./chart-tap-lift.js";
import { use, useLayoutEffect, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-surface.tsx
/**
* The slot move a key makes. Arrow directions are physical, so time runs left to right under
* `dir="rtl"` too, and horizontal bars list their categories top to bottom.
*/
function slotStepOf(orientation, key) {
	switch (key) {
		case "ArrowRight": return orientation === "vertical" ? "next" : void 0;
		case "ArrowLeft": return orientation === "vertical" ? "previous" : void 0;
		case "ArrowDown": return orientation === "horizontal" ? "next" : void 0;
		case "ArrowUp": return orientation === "horizontal" ? "previous" : void 0;
		case "PageDown": return "page-next";
		case "PageUp": return "page-previous";
		case "Home": return "first";
		case "End": return "last";
		default: return;
	}
}
/** The series-focus move a key makes, across the axis the slots run along. */
function seriesStepOf(orientation, key) {
	if (orientation === "vertical") return key === "ArrowDown" ? 1 : key === "ArrowUp" ? -1 : void 0;
	return key === "ArrowRight" ? 1 : key === "ArrowLeft" ? -1 : void 0;
}
/** Whether two slot x values name the same slot. */
function sameX(a, b) {
	return a instanceof Date && b instanceof Date ? a.getTime() === b.getTime() : a === b;
}
/** The slot an option names in the current model, which keeps its x across data updates. */
function slotOfOption(context, window, option) {
	return keepSlot(context.model.domain, window, option.x);
}
/**
* The plot's single tab stop, whose one option names the active slot. The surface is also the
* plot's one pointer target. A pointer picks the slot by arithmetic and never moves focus or
* changes the option.
*/
function ChartSurface({ name, labelledBy }) {
	const context = useChartRoot("Chart.Root");
	const selectedKey = use(ChartSelectionContext);
	const { model, store, id, orientation, locale } = context;
	const window = model.window;
	const listbox = useRef(null);
	const handoff = useOptionHandoff(id, listbox, () => ({
		x: slotX(model.domain, store.initial.active ?? window?.first ?? 0),
		focus: -1,
		order: "slot-first"
	}));
	const { options } = handoff;
	/** Whether the current press started while a tooltip was pinned, which a touch lift reads. */
	const gesture = useRef(null);
	/** The touch or pen lift that just acted, so the focus that follows a tap keeps its slot. */
	const lift = useTapLift();
	const drawn = useRootFrame("Chart.Root");
	const pinned = useChartStore(store, (snapshot) => snapshot.pinned);
	const emphasis = useChartStore(store, (snapshot) => snapshot.emphasis);
	const [seen, setSeen] = useState(() => ({
		model,
		keys: model.series.map(({ key }) => key)
	}));
	if (seen.model !== model) {
		const keys = model.series.map(({ key }) => key);
		setSeen({
			model,
			keys
		});
		const latest = handoff.current;
		if (latest !== void 0 && model.window !== null) {
			const x = slotX(model.domain, keepSlot(model.domain, model.window, latest.x));
			const focusKey = latest.focus === -1 ? void 0 : seen.keys[latest.focus];
			const focus = focusKey === void 0 ? -1 : keys.indexOf(focusKey);
			if (!sameX(x, latest.x) || focus !== latest.focus) handoff.revise({
				x,
				focus,
				order: latest.order
			});
		}
	}
	useLayoutEffect(() => {
		const latest = options.at(-1);
		const snapshot = store.get();
		if (latest === void 0 || snapshot.source !== "keyboard") return;
		const near = latest.focus === -1 ? null : latest.focus;
		if (snapshot.near !== near) store.set({ near });
	}, [options, store]);
	useGestureEnd(window !== null && !model.empty, lift, gesture, null);
	const current = handoff.current;
	if (window === null || model.empty || current === void 0) return null;
	const count = window.last - window.first + 1;
	const keys = model.series.length;
	const move = (patch) => {
		const next = {
			x: current.x,
			focus: current.focus,
			order: current.order,
			...patch
		};
		handoff.step(next);
		store.set({
			active: slotOfOption(context, window, next),
			source: "keyboard",
			near: next.focus === -1 ? null : next.focus
		});
	};
	const onKeyDown = (event) => {
		if (event.ctrlKey || event.altKey || event.metaKey) return;
		if (!(event.target instanceof HTMLElement) || event.target.getAttribute("role") !== "option") return;
		const slot = slotOfOption(context, window, current);
		const step = slotStepOf(orientation, event.key);
		const seriesStep = seriesStepOf(orientation, event.key);
		if (step !== void 0) move({
			x: slotX(model.domain, stepSlot(window, slot, step)),
			order: "slot-first"
		});
		else if (seriesStep !== void 0) {
			const focus = Math.max(-1, Math.min(keys - 1, current.focus + seriesStep));
			if (keys > 1 && focus !== current.focus) move({
				focus,
				order: "series-first"
			});
		} else if (event.key === "Enter" || event.key === " ") {
			if (context.hasToggles()) {
				const key = current.focus === -1 ? null : model.series[current.focus]?.key ?? null;
				context.select(key === selectedKey ? null : key, "keyboard", event.nativeEvent);
			} else store.set({
				pinned: !store.get().pinned,
				active: slot,
				source: "keyboard"
			});
		} else if (event.key === "Escape") {
			const snapshot = store.get();
			if (snapshot.active === null && !snapshot.pinned) return;
			store.dismiss();
			event.stopPropagation();
		} else return;
		event.preventDefault();
	};
	const onFocus = (event) => {
		if (handoff.within(event)) {
			handoff.prune();
			return;
		}
		if (lift.tapFocus() || gesture.current !== null) return;
		store.set({
			active: slotOfOption(context, window, current),
			source: "keyboard",
			near: current.focus === -1 ? null : current.focus
		});
	};
	const onBlur = (event) => {
		if (handoff.within(event) || handoff.kept(event)) return;
		if (!(lift.tapFocus() || gesture.current !== null) && (store.get().source === "keyboard" || store.get().pinned)) store.set({
			active: null,
			source: null,
			near: null,
			pinned: false
		});
		else if (store.get().dismissed !== null) store.set({ dismissed: null });
		handoff.reset({
			x: current.x,
			focus: current.focus,
			order: "slot-first"
		});
	};
	/** The slot and the nearest series under a pointer, picked by arithmetic. */
	const slotAt = (event) => pointerSlot(context, drawn?.frame ?? null, event.currentTarget.getBoundingClientRect(), event.clientX, event.clientY);
	const pick = (event) => {
		store.track(event.clientX, event.clientY, event.pointerType, event.timeStamp);
		const { pinned: isPinned, dismissed } = store.get();
		if (isPinned) return;
		const { slot, near } = slotAt(event);
		if (dismissed === slot) return;
		store.set({
			active: slot,
			source: "pointer",
			near
		});
	};
	/**
	* A tap or a click on the plot. It pins the slot under the pointer, and on the pinned slot it
	* takes the one dismissal. Under a LegendToggleGroup it selects the nearest series instead.
	*/
	const press = (event, slot, shown = false) => {
		const snapshot = store.get();
		if (shown) {
			store.dismiss();
			return;
		}
		if (context.hasToggles()) {
			const key = snapshot.near === null ? null : model.series[snapshot.near]?.key ?? null;
			context.select(key === selectedKey ? null : key, "plot", event.nativeEvent);
			return;
		}
		if (snapshot.pinned && snapshot.active === slot) store.dismiss();
		else store.set({
			active: slot,
			source: "pointer",
			pinned: true
		});
	};
	const naming = {
		id,
		name,
		labelledBy,
		locale
	};
	return /* @__PURE__ */ jsxs("div", {
		ref: listbox,
		role: "listbox",
		...listboxProps(naming, pinned, orientation === "vertical" ? "horizontal" : "vertical"),
		"data-orientation": orientation,
		onKeyDown,
		onFocus,
		onBlur,
		onPointerMove: pick,
		onPointerEnter: () => context.placeSpan(),
		onMouseDown: () => {
			lift.mouseDown();
		},
		onPointerDown: (event) => {
			lift.press();
			if (event.pointerType === "mouse") return;
			const snapshot = store.get();
			const { slot } = slotAt(event);
			gesture.current = {
				pinned: snapshot.pinned,
				slot,
				shown: context.hasToggles() && snapshot.source === "pointer" && snapshot.active === slot
			};
			if (snapshot.dismissed !== null) store.set({ dismissed: null });
			pick(event);
		},
		onPointerUp: (event) => {
			const started = gesture.current;
			gesture.current = null;
			if (event.pointerType === "mouse" || started === null) return;
			const snapshot = store.get();
			const slot = started.pinned ? started.slot : snapshot.active;
			if (slot === null) return;
			lift.lift();
			press(event, slot, started.shown && slot === started.slot);
		},
		onPointerCancel: () => {
			gesture.current = null;
		},
		onPointerLeave: (event) => {
			const intoPopup = event.relatedTarget instanceof Element && event.relatedTarget.closest("[data-slot=\"chart-tooltip\"]") !== null;
			if (!intoPopup && event.pointerType === "mouse" && store.get().source === "pointer" && !store.get().pinned) store.set({
				active: null,
				source: null,
				near: null
			});
			if (!intoPopup && event.pointerType === "mouse" && store.get().dismissed !== null) store.set({ dismissed: null });
		},
		onClick: (event) => {
			if (!lift.clickActs(event)) return;
			if (event.detail === 0) {
				const { active } = store.get();
				if (active !== null) press(event, active);
				return;
			}
			press(event, slotAt(event).slot);
		},
		children: [/* @__PURE__ */ jsx(SurfaceName, { ...naming }), options.map((option) => {
			const slot = slotOfOption(context, window, option);
			const isCurrent = option === current;
			const band = drawn === null ? void 0 : optionBand(drawn.frame, slot - window.first, context.xScale);
			return /* @__PURE__ */ jsx("div", {
				id: option.id,
				role: "option",
				"data-slot": "chart-point",
				"data-focus-ring-control": "",
				tabIndex: isCurrent ? 0 : -1,
				"aria-label": optionName(context, slot, option.focus, option.order, emphasis),
				"aria-posinset": slot - window.first + 1,
				"aria-setsize": count,
				"aria-describedby": option.entry ? `${id}-description ${id}-instructions` : void 0,
				style: {
					"--chart-col": slot - window.first + 1,
					"--chart-option-start": band === void 0 ? void 0 : `${String(band[0])}px`,
					"--chart-option-size": band === void 0 ? void 0 : `${String(band[1] - band[0])}px`
				}
			}, option.id);
		})]
	});
}
/** Root's status region, which announces what Root's store says. */
function ChartStatus() {
	const { store } = useChartRoot("Chart.Root");
	const text = useChartStore(store, (snapshot) => snapshot.announcement.text);
	const count = useChartStore(store, (snapshot) => snapshot.announcement.count);
	return /* @__PURE__ */ jsx(StatusRegion, {
		text,
		count
	});
}
Object.assign(ChartSurface, { displayName: "Chart.Root.Surface" });
Object.assign(ChartStatus, { displayName: "Chart.Root.Status" });
export { ChartStatus, ChartSurface };

//# sourceMappingURL=chart-surface.js.map