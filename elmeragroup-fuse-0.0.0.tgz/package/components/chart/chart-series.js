"use client";
import { useActiveItem, useChartReadout, useLegendSide, useReadoutKey } from "./chart-readout.js";
import { seriesPaint } from "./layout/color-key.js";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
// src/components/chart/chart-series.tsx
/**
* The series' paint. A role list shows the list as a gradient, a scale shows its ramp, and a
* threshold shows its two sides split in half. Inside a tooltip row a scale or a threshold series
* shows the step of the active value, and inside a threshold series' legend entry it shows the
* entry's side. The swatch is decoration, so it is hidden from screen readers.
*
* @beta
*/
function ChartSwatch({ dataKey, variant = "square", render, className, style, ...props }) {
	const readout = useChartReadout("Chart.Swatch");
	const point = useActiveItem(readout);
	const key = useReadoutKey("Chart.Swatch", readout, dataKey, point.key) ?? readout.legendKeys[0] ?? "";
	const side = useLegendSide(key);
	const { paint, look } = readout.swatch(key, point.index);
	return useRender({
		defaultTagName: "span",
		render,
		props: {
			"data-slot": "chart-swatch",
			"data-variant": variant,
			"data-series": readout.item(key)?.index,
			"data-series-variant": look,
			...mergeProps({
				"aria-hidden": true,
				className,
				style: {
					"--chart-swatch-paint": side === null ? paint : seriesPaint(key, side.color),
					...style
				}
			}, props)
		}
	});
}
/**
* The series' visible label from config. Inside a threshold series' legend entry it is the entry's
* side label, and everywhere else, the tooltip row included, the series' own `label`.
*
* @beta
*/
function ChartSeriesLabel({ dataKey, render, className, ...props }) {
	const readout = useChartReadout("Chart.SeriesLabel");
	const point = useActiveItem(readout);
	const key = useReadoutKey("Chart.SeriesLabel", readout, dataKey, point.key);
	const side = useLegendSide(key);
	const text = key === null ? null : side?.label ?? readout.item(key)?.label.text ?? key;
	return useRender({
		defaultTagName: "span",
		render,
		props: {
			"data-slot": "chart-series-label",
			...mergeProps({
				className,
				children: text
			}, props)
		}
	});
}
/**
* The series' config `icon`, or nothing when it has none. The icon is decoration, because the
* label beside it names the series.
*
* @beta
*/
function ChartSeriesIcon({ dataKey, render, className, ...props }) {
	const readout = useChartReadout("Chart.SeriesIcon");
	const point = useActiveItem(readout);
	const key = useReadoutKey("Chart.SeriesIcon", readout, dataKey, point.key);
	return useRender({
		defaultTagName: "span",
		render,
		props: {
			"data-slot": "chart-series-icon",
			...mergeProps({
				"aria-hidden": true,
				className,
				children: key === null ? null : readout.item(key)?.icon
			}, props)
		}
	});
}
Object.assign(ChartSwatch, { displayName: "Chart.Swatch" });
Object.assign(ChartSeriesLabel, { displayName: "Chart.SeriesLabel" });
Object.assign(ChartSeriesIcon, { displayName: "Chart.SeriesIcon" });
export { ChartSeriesIcon, ChartSeriesLabel, ChartSwatch };

//# sourceMappingURL=chart-series.js.map