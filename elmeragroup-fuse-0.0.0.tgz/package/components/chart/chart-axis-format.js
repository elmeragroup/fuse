"use client";
import { useSyncExternalStore } from "react";
// src/components/chart/chart-axis-format.ts
/**
* Root's record of its x axis: the axis's `format`, which a part beside the axis such as
* Chart.SlotLabel prints slots in, and the generation of the axis's tick nodes, which that part
* reads boxes from. Chart.XAxis writes both in its commits, never on a pointer step, and a reader
* renders again only when one of them changes.
*/
/**
* Create Root's record of its x axis.
*
* @returns The record, holding no format at tick generation 0.
*/
function createAxisRecord() {
	let format;
	let ticks = 0;
	const listeners = /* @__PURE__ */ new Set();
	const notify = () => {
		for (const listener of listeners) listener();
	};
	return {
		format: () => format,
		setFormat: (next) => {
			if (next === format) return;
			format = next;
			notify();
		},
		ticks: () => ticks,
		touchTicks: () => {
			ticks += 1;
			notify();
		},
		subscribe: (listener) => {
			listeners.add(listener);
			return () => {
				listeners.delete(listener);
			};
		}
	};
}
const NO_FORMAT = () => void 0;
const NO_TICKS = () => 0;
/**
* Read the x axis's format, rendering again when it changes. The server reads none.
*
* @param record - Root's record.
* @returns The axis's format, or undefined.
*/
function useAxisFormat(record) {
	return useSyncExternalStore(record.subscribe, record.format, NO_FORMAT);
}
/**
* Read the generation of the x axis's tick nodes, rendering again when it changes.
*
* @param record - Root's record.
* @returns The generation.
*/
function useAxisTicks(record) {
	return useSyncExternalStore(record.subscribe, record.ticks, NO_TICKS);
}
export { createAxisRecord, useAxisFormat, useAxisTicks };

//# sourceMappingURL=chart-axis-format.js.map