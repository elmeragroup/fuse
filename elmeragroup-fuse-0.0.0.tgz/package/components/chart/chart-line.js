"use client";
import { linePaths } from "./layout/line-path.js";
import { runMargins } from "./layout/plot-frame.js";
import { useSeriesPart } from "./chart-context.js";
import { sameShallow, useSteady } from "./chart-steady.js";
import { useFirstDraw } from "./chart-motion-mark.js";
import { placeOf, topologyAt, writePath } from "./chart-path-draw.js";
import { useRestingLine, useSeriesPath } from "./chart-series-path.js";
import { PATH_GLOW, plotGlowRegion, valueGlow } from "./chart-glow-filter.js";
import { PathPaint, hasPathPaint } from "./chart-path-paint.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-line.tsx
/** Draw a line's frame from the loop's numbers: its path, and the dashed twin over its spans. */
function drawLine(group, look, values) {
	if (look === null) return;
	const topology = topologyAt(look.moving.current, look.topology, values.length / 2);
	const { line, dashed } = linePaths(values, topology, placeOf(look));
	writePath(group, look, line, dashed, "replace");
}
/** The width a line strokes its solid path in, which a consumer's --chart-stroke or the look sets. */
function readStroke(group) {
	const solid = group.querySelector("[data-part=\"solid\"]");
	return solid === null ? 0 : Number.parseFloat(getComputedStyle(solid).strokeWidth) || 0;
}
/**
* One series as a line. A missing reading leaves a gap unless the series' config sets
* `missing: "connect"`, which bridges it with a dashed segment, and a reading between two gaps
* draws a dot. The segments that touch an estimated reading, and the tail from config
* `projectedFrom`, draw dashed. On a data update the line tweens to the new readings with the marks
* on it, slides when the window moves by whole slots, and crossfades when its slots change in
* another way. A chart draws each series with one Line, and a second Line on the same `dataKey`
* throws `series-drawn-twice` once it mounts.
*
* @beta
*/
function ChartLine({ dataKey, variant = "default", curve = "monotone", className, style }) {
	const { context, layout } = useSeriesPart("Chart.Line", dataKey);
	const steadyStyle = useSteady(style, sameShallow);
	const { series, seriesIndex, resting, prefix, frame, outgoingRef, markRef, intro, paint } = useSeriesPath("Chart.Line", drawLine, {
		context,
		layout,
		dataKey,
		curve,
		route: "line",
		stride: 2,
		stroke: {
			guess: variant === "quiet" ? 1 : 2,
			inputs: [
				variant,
				className,
				steadyStyle
			],
			read: readStroke
		}
	});
	const drawn = useFirstDraw(() => resting === null ? null : linePaths(resting.rest, resting.topology, placeOf(resting.look)).line);
	useRestingLine(context.paths, seriesIndex, "line", resting, (rest) => linePaths(rest.rest, rest.topology, placeOf(rest.look)).line);
	const margins = runMargins(frame);
	const glow = valueGlow(paint, prefix, PATH_GLOW);
	return /* @__PURE__ */ jsx("svg", {
		"data-slot": "chart-line-series",
		"data-orientation": context.orientation,
		"data-variant": variant,
		"data-series": seriesIndex,
		"data-paint": glow?.paint,
		"data-intro": intro,
		"aria-hidden": "true",
		className,
		style: {
			"--chart-series-paint": paint.base,
			"--chart-series": seriesIndex,
			"--_paint-server": hasPathPaint(paint) ? `url(#${prefix}-paint)` : void 0,
			"--_glow": glow?.url,
			"--_run-before": margins.before,
			"--_run-after": margins.after,
			...style
		},
		children: frame === null || series === void 0 || drawn === null ? null : /* @__PURE__ */ jsxs(Fragment, { children: [
			/* @__PURE__ */ jsxs("defs", { children: [/* @__PURE__ */ jsx(PathPaint, {
				id: `${prefix}-paint`,
				paint,
				frame
			}), glow?.filter(plotGlowRegion(frame.box))] }),
			/* @__PURE__ */ jsxs("g", {
				ref: markRef,
				children: [
					/* @__PURE__ */ jsx("clipPath", {
						id: `${prefix}-solid`,
						"data-part": "solid-clip"
					}),
					/* @__PURE__ */ jsx("clipPath", {
						id: `${prefix}-marked`,
						"data-part": "marked-clip"
					}),
					/* @__PURE__ */ jsx("path", {
						"data-slot": "chart-line",
						"data-part": "solid",
						"data-series": seriesIndex,
						d: drawn
					}),
					/* @__PURE__ */ jsx("path", {
						"data-slot": "chart-line",
						"data-part": "marked",
						"data-series": seriesIndex,
						d: ""
					})
				]
			}),
			/* @__PURE__ */ jsx("g", {
				ref: outgoingRef,
				"data-part": "outgoing"
			})
		] })
	});
}
Object.assign(ChartLine, { displayName: "Chart.Line" });
export { ChartLine };

//# sourceMappingURL=chart-line.js.map