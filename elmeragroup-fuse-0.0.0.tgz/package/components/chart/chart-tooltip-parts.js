"use client";
import { ChartRowContext } from "./chart-scope-contexts.js";
import { useActiveIndex } from "./chart-active-point.js";
import { ChartSelectionContext } from "./chart-readout-port.js";
import { shareDigits, shareText, useActiveItem, useChartReadout, useReadoutKey } from "./chart-readout.js";
import { use } from "react";
import { jsx } from "react/jsx-runtime";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
// src/components/chart/chart-tooltip-parts.tsx
/**
* The tooltip's content parts every chart family shares: the active datum's label, the row
* template, the value and the share. Each reads its Root through the readout port, so a family's
* Tooltip and its content ship no other family's code.
*/
/**
* The active slot's label, or the category's label in pie, radial and radar charts.
*
* @beta
*/
function ChartTooltipLabel({ format, render, className, ...props }) {
	const readout = useChartReadout("Chart.TooltipLabel");
	const active = useActiveIndex(readout);
	return useRender({
		defaultTagName: "span",
		render,
		props: {
			"data-slot": "chart-tooltip-label",
			...mergeProps({
				className,
				children: active === null ? null : readout.activeLabel(active, format)
			}, props)
		}
	});
}
/**
* A row template, rendered once per config key at the active point, or once for the active slice
* or ring. Each row carries `data-series`, and `data-dimmed` while another series is selected.
*
* @beta
*/
function ChartTooltipItems({ render, className, children, ...props }) {
	const readout = useChartReadout("Chart.TooltipItems");
	const selectedKey = use(ChartSelectionContext);
	const active = useActiveIndex(readout, readout.itemsFollowActive ? void 0 : false);
	const rows = readout.tooltipKeys(active).map((key) => /* @__PURE__ */ jsx(ChartRowContext, {
		value: key,
		children: /* @__PURE__ */ jsx("div", {
			"data-slot": "chart-tooltip-item",
			"data-series": readout.item(key)?.index,
			"data-dimmed": selectedKey !== null && selectedKey !== key ? "" : void 0,
			children
		})
	}, key));
	return useRender({
		defaultTagName: "div",
		render,
		props: {
			"data-slot": "chart-tooltip-items",
			...mergeProps({
				className,
				children: rows
			}, props)
		}
	});
}
/**
* The reading at the active point, followed by its quality and projection words. A series coarser
* than Root's interval adds its own slot label. Under `stackOffset="expand"` it prints the raw value.
*
* @beta
*/
function ChartTooltipValue({ dataKey, format, render, className, ...props }) {
	const readout = useChartReadout("Chart.TooltipValue");
	const point = useActiveItem(readout);
	const key = useReadoutKey("Chart.TooltipValue", readout, dataKey, point.key);
	const text = key === null || point.index === null ? null : readout.valueText(key, point.index, format);
	return useRender({
		defaultTagName: "span",
		render,
		props: {
			"data-slot": "chart-tooltip-value",
			...mergeProps({
				className,
				children: text
			}, props)
		}
	});
}
/**
* The reading's share as a percentage, signed as the reading is. In cartesian and radar charts the
* denominator is the sum of the absolute readings of every series at the active slot or spoke, so a
* share never passes 100 % in magnitude. A slice divides by the absolute total of the slices, and a
* ring divides by its own maximum. A zero denominator prints the dictionary dash `–`. The shares at
* one slot share a denominator, so they round together on their magnitudes and keep their signs.
* Their magnitudes sum to 100 %, so readings of 3 and −1 print 75 % and −25 %. A ring's share
* against its own maximum has no set and rounds alone.
*
* @beta
*/
function ChartTooltipShare({ dataKey, format, render, className, ...props }) {
	const readout = useChartReadout("Chart.TooltipShare");
	const point = useActiveItem(readout);
	const key = useReadoutKey("Chart.TooltipShare", readout, dataKey, point.key);
	const text = key === null || point.index === null ? null : shareText(readout.locale, readout.share(key, point.index, shareDigits(format)), format);
	return useRender({
		defaultTagName: "span",
		render,
		props: {
			"data-slot": "chart-tooltip-share",
			...mergeProps({
				className,
				children: text
			}, props)
		}
	});
}
Object.assign(ChartTooltipLabel, { displayName: "Chart.TooltipLabel" });
Object.assign(ChartTooltipItems, { displayName: "Chart.TooltipItems" });
Object.assign(ChartTooltipValue, { displayName: "Chart.TooltipValue" });
Object.assign(ChartTooltipShare, { displayName: "Chart.TooltipShare" });
export { ChartTooltipItems, ChartTooltipLabel, ChartTooltipShare, ChartTooltipValue };

//# sourceMappingURL=chart-tooltip-parts.js.map