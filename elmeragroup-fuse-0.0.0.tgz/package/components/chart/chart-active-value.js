"use client";
import { formatValue } from "./format/value-format.js";
import { ChartDatumContext, ChartHeadlineContext } from "./chart-scope-contexts.js";
import { useActiveIndex } from "./chart-active-point.js";
import { assertKnownKey } from "./layout/errors.js";
import { centreOf, hairline, ruleAcross, slotShare, snapAcross, valueShare } from "./layout/plot-frame.js";
import { barCellAt, barEndValue, barTip } from "./layout/bar-geometry.js";
import { assertLayoutKey, useChartLayout, useChartRoot, usePlotLayout, useSeriesPart } from "./chart-context.js";
import { partsCache, writeAttribute, writeAttributes, writeStyle } from "./chart-dom.js";
import { useChartFollower } from "./chart-followers.js";
import { useChartFrame } from "./chart-plot.js";
import { seriesOf } from "./layout/series-of.js";
import { fallbackSlot, readingAt } from "./chart-series-readout.js";
import { slotCentre, valueTop } from "./layout/plot-geometry.js";
import { useFirstDraw } from "./chart-motion-mark.js";
import { attachJoin, copyBefore, pointAxes, useAttachedMark } from "./chart-attached.js";
import { use, useMemo } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-active-value.tsx
/** The bar a series draws at a slot, whose end the value followers sit at. Null where it draws none. */
function cellAt(context, dataKey, slot) {
	const series = seriesOf(context.model, dataKey);
	return series === void 0 || slot === null ? null : barCellAt(context.model, series, slot);
}
/**
* The value at the active slot, or the `fallback` value when nothing is active, "last" by default.
* Inside a Headline it is exposed text, with a visually hidden spoken twin wherever the spoken form
* differs, such as a negative price. Anywhere else it is plot output that readers skip.
*
* @beta
*/
function ChartActiveValue({ dataKey, fallback = "last", format, className, style }) {
	const context = useChartRoot("Chart.ActiveValue");
	const layout = useChartLayout("Chart.ActiveValue");
	assertKnownKey("Chart.ActiveValue", context.config, dataKey);
	const exposed = use(ChartHeadlineContext);
	const slot = useActiveIndex({
		store: context.store,
		window: context.model.window
	}, true) ?? fallbackSlot(context, dataKey, fallback);
	const reading = slot === null ? void 0 : readingAt(context, dataKey, slot);
	const label = reading?.kind === "reading" ? formatValue(context.locale, reading.value, format ?? context.config[dataKey]?.format ?? {}, "full") : null;
	if (!exposed) return /* @__PURE__ */ jsx(PlotValue, {
		context,
		dataKey,
		slot,
		label: label?.text,
		className,
		style,
		y: layout.y.domain
	});
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "chart-active-value",
		className,
		style,
		children: label === null || label.text === label.spoken ? label?.text : /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("span", {
			"aria-hidden": "true",
			children: label.text
		}), /* @__PURE__ */ jsx("span", {
			"data-spoken": "",
			children: label.spoken
		})] })
	});
}
/**
* How a value follower joins what it marks: the bar at its series and slot, or a Bar's columns in
* the path form, and the series' line where no Bar draws it, so every coordinate it draws is the
* bar's or the vertex's, at rest and in a tween. Inside a BarGroup it centres over its own bar, as
* a Marker does.
*/
function joinValue(context, dataKey, slot, fromPoint, rest) {
	const series = seriesOf(context.model, dataKey);
	if (series === void 0 || slot === null) return void 0;
	const join = attachJoin(context, series, [slot], rest, "bar");
	return join === void 0 ? void 0 : {
		leads: join.leads.map((lead) => {
			const size = fromPoint([0, 0]).length;
			if ("clock" in lead) return {
				anchor: lead.anchor,
				clock: size
			};
			const { anchor, pick, rest: resting } = lead;
			return {
				anchor,
				size,
				pick: (values) => fromPoint(pick(values)),
				rest: resting === void 0 ? void 0 : (values) => fromPoint(resting(values))
			};
		}),
		crossfade: join.crossfade
	};
}
/** Draw ActiveValue at the loop's numbers: its centre along the slot axis and its tip. */
function drawValue(span, look, values) {
	const { frame } = look;
	if (frame === null) return;
	const [centre = 0, end = 0] = values;
	writeStyle(span, "--chart-value-at", String(slotShare(frame, centre) / 100));
	writeStyle(span, "--chart-value-top", `${String(valueShare(frame, snapAcross(frame, end)))}%`);
}
/** The active value line's rule, found once per commit of its mark. */
const valueRule = partsCache((box) => box.querySelector(":scope > svg > [data-slot=\"chart-active-value-rule\"]"));
/** Draw the active value line at the loop's number, the tip, across the whole plot. */
function drawValueLine(box, look, values) {
	const { frame } = look;
	if (frame === null) return;
	const [end = 0] = values;
	writeStyle(box, "--chart-line-top", `${String(valueShare(frame, snapAcross(frame, end)))}%`);
	writeStyle(box, "--_rule-width", `${String(hairline(frame.box))}px`);
	const direction = frame.orientation === "vertical" ? "horizontal" : "vertical";
	writeAttributes(valueRule(box), ruleAcross(frame.box, direction, end));
}
/**
* An ActiveValue placed directly in Root: plot output above the active bar's far end, or above the
* fallback datum while nothing is active. Root moves it with the pointer, and it moves with the
* bars on a data update.
*/
function PlotValue({ context, dataKey, slot, label, y, className, style }) {
	const window = context.model.window;
	const layout = usePlotLayout("Chart.ActiveValue");
	assertLayoutKey("Chart.ActiveValue", layout, dataKey);
	const drawn = useChartFrame("Chart.ActiveValue", layout);
	const frame = drawn?.frame ?? null;
	const look = useMemo(() => ({ frame }), [frame]);
	const { ref: markRef, outgoingRef, attach } = useAttachedMark(context, drawn, drawValue, look, pointAxes(context.orientation));
	useChartFollower("Chart.ActiveValue", (active, cause) => {
		const shown = active?.slot ?? slot;
		const centre = drawn === null || window === null || shown === null ? 0 : centreOf(drawn.frame, shown - window.first, context.xScale);
		const cell = cellAt(context, dataKey, shown);
		const tip = drawn === null || cell === null ? 0 : barTip(drawn.frame, cell);
		attach(cause, joinValue(context, dataKey, shown, (point) => point, [centre, tip]), drawn === null || window === null || shown === null || cell === null ? null : [centre, tip]);
	});
	const shares = () => {
		const resting = cellAt(context, dataKey, slot);
		const at = window === null || slot === null ? 0 : slotCentre(window, slot, context.xScale);
		const top = resting === null ? 0 : valueTop(y, barEndValue(resting));
		return {
			"--chart-value-at": at,
			"--chart-value-top": `${String(top)}%`
		};
	};
	const position = useFirstDraw(() => frame === null ? null : shares()) ?? shares();
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("span", {
		ref: markRef,
		"data-slot": "chart-active-value",
		"data-orientation": context.orientation,
		"aria-hidden": "true",
		className,
		style: {
			"--chart-value-at": position["--chart-value-at"],
			"--chart-value-top": position["--chart-value-top"],
			...style
		},
		children: label
	}), /* @__PURE__ */ jsx("div", {
		ref: outgoingRef,
		"data-part": "outgoing"
	})] });
}
/**
* The value line's pill text follows the active slot, which a pointer step changes, so the line
* keeps no copy of its own. A crossfade copies the live line and gives its pill the text it showed
* before the update.
*/
const PILL_COPY = {
	keep: (live) => live,
	outgoing: (live, _before, update) => copyBefore(live, update)
};
/**
* A line across the plot at the active value. A `ValueLabel` child adds the value as a pill at the
* value axis. Root moves it with the pointer, and it moves with the bars on a data update.
*
* @beta
*/
function ChartActiveValueLine({ dataKey, className, style, children }) {
	const { context, layout } = useSeriesPart("Chart.ActiveValueLine", dataKey);
	const drawn = useChartFrame("Chart.ActiveValueLine", layout);
	const frame = drawn?.frame ?? null;
	const look = useMemo(() => ({ frame }), [frame]);
	const { ref: markRef, node: markNode, outgoingRef, attach } = useAttachedMark(context, drawn, drawValueLine, look, [context.orientation === "vertical" ? "y" : "x"], { copy: PILL_COPY });
	useChartFollower("Chart.ActiveValueLine", (active, cause) => {
		const cell = active === null ? null : cellAt(context, dataKey, active.slot);
		const tip = drawn === null || cell === null ? 0 : barTip(drawn.frame, cell);
		const box = markNode();
		const shows = box !== null && cell !== null && drawn !== null;
		if (box !== null) writeAttribute(box, "data-value", shows ? "" : null);
		attach(cause, joinValue(context, dataKey, active?.slot ?? null, (point) => [point[1] ?? 0], [0, tip]), shows ? [tip] : null);
	});
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs("div", {
		ref: markRef,
		"data-slot": "chart-active-value-line",
		"data-orientation": context.orientation,
		"aria-hidden": "true",
		className,
		style,
		children: [/* @__PURE__ */ jsx("svg", {
			"aria-hidden": "true",
			children: drawn === null ? null : /* @__PURE__ */ jsx("line", {
				"data-slot": "chart-active-value-rule",
				x1: "0",
				y1: "0",
				x2: "0",
				y2: "0"
			})
		}), /* @__PURE__ */ jsx(ChartDatumContext, {
			value: {
				key: dataKey,
				slot: null
			},
			children
		})]
	}), /* @__PURE__ */ jsx("div", {
		ref: outgoingRef,
		"data-part": "outgoing"
	})] });
}
Object.assign(ChartActiveValue, { displayName: "Chart.ActiveValue" });
Object.assign(ChartActiveValueLine, { displayName: "Chart.ActiveValueLine" });
export { ChartActiveValue, ChartActiveValueLine };

//# sourceMappingURL=chart-active-value.js.map