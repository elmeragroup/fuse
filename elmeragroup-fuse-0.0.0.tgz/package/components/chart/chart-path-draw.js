"use client";
import "./layout/line-path.js";
import { sameItems } from "./layout/same-items.js";
import { pathMotion } from "./layout/path-motion.js";
import { alongLength, cellRun, pointAlong, slotCentreAt, snapAcross, snapAlong, strokeCentre } from "./layout/plot-frame.js";
import { writeAttribute } from "./chart-dom.js";
import { pathAnchor } from "./chart-paths.js";
import { placementOf } from "./chart-motion-mark.js";
import { crossfade } from "./chart-crossfade.js";
// src/components/chart/chart-path-draw.ts
/**
* What a Line and an Area share between the vertices of `layout/series-path.ts` and Root's loop:
* where the numbers land, the topology a writer draws them in, the clip spans that dash or hatch a
* part of the path, the route a data update tweens, and the crossfade that replaces a path whose
* slots changed in another way. Each part's writer stays in its own module and calls these.
*/
/**
* Where a path's numbers land: vertices on the crosshair's column, and cell edges, plain step
* risers and values on device pixels, each moved by the stroke's parity, so a stroked step's runs
* and risers cover whole device pixels at any width. A riser of an odd width takes the pixels just past its cell
* edge, inside the band of the run it starts. An Area strokes nothing, so its fill edges stay on
* the cell edges.
*
* @param look - The path's look.
* @returns The placement for `linePaths` and `areaPaths`.
*/
function placeOf(look) {
	const { frame } = look;
	const width = look.stroke.width;
	return {
		orientation: frame.orientation,
		curve: look.curve,
		along: (at) => pointAlong(frame, at, look.xScale),
		run: (centre, cells) => {
			const [start, end] = cellRun(frame, centre, cells);
			return [strokeCentre(frame, start, width), strokeCentre(frame, end, width)];
		},
		across: (at) => strokeCentre(frame, snapAcross(frame, at), width),
		edge: (at) => strokeCentre(frame, snapAlong(frame, at), width),
		digits: null
	};
}
/**
* The topology of the numbers a frame draws: the last route's while its vertex count matches,
* which a frame of the route and its resting frame both draw in, and the resting one otherwise.
* Where the two hold the same vertices they differ only in what a vertex that leaves the path
* draws on its way, which has no length at rest.
*
* @param moving - The last route's topology, or null.
* @param topology - The resting topology.
* @param count - The vertices the frame draws.
* @returns The topology.
*/
function topologyAt(moving, topology, count) {
	return moving?.count === count ? moving : topology;
}
/** How far the clip rectangles reach past the plot, so a stroke or a cap at the edge keeps its paint. */
const CLIP_MARGIN = 16;
/** Fill a clip path with one rectangle per span along the slot axis, reusing its rectangles. */
function fillClip(clip, frame, spans) {
	const vertical = frame.orientation === "vertical";
	const across = (vertical ? frame.box.height : frame.box.width) + 32;
	while (clip.children.length > spans.length) clip.lastElementChild?.remove();
	while (clip.children.length < spans.length) clip.append(clip.ownerDocument.createElementNS("http://www.w3.org/2000/svg", "rect"));
	spans.forEach(([start, end], index) => {
		const rect = clip.children[index];
		if (rect === void 0) return;
		writeAttribute(rect, vertical ? "x" : "y", start);
		writeAttribute(rect, vertical ? "width" : "height", Math.max(0, end - start));
		writeAttribute(rect, vertical ? "y" : "x", -16);
		writeAttribute(rect, vertical ? "height" : "width", across);
	});
}
/**
* Write the path data of a frame onto a series group: the solid path and its marked twin, which
* dashes or hatches the spans, each clipped to its side of them. A path without spans draws whole.
*
* @param group - The series group, which holds both clip paths and both paths.
* @param look - The path's look.
* @param d - The path data.
* @param spans - The spans the twin draws, sorted and disjoint.
* @param mode - "replace" draws the twin in place of the solid path over the spans, as a Line
*   dashes them, and "overlay" draws it over the whole path, as an Area hatches them.
* @param dots - An Area's lone readings, which its dot and dashed dot twin draw, each clipped to
*   its side of the spans as a Line's dots are.
*/
function writePath(group, look, d, spans, mode, dots = "") {
	const { frame, clips } = look;
	const length = alongLength(frame);
	const low = -16;
	const high = length + CLIP_MARGIN;
	const marked = spans.map(([start, end]) => [Math.max(low, start), Math.min(high, end)]);
	const solid = [];
	let from = low;
	for (const [start, end] of marked) {
		solid.push([from, start]);
		from = end;
	}
	solid.push([from, high]);
	for (const child of group.children) {
		const part = child.getAttribute("data-part");
		if (part === "solid-clip") fillClip(child, frame, solid);
		else if (part === "marked-clip") fillClip(child, frame, marked);
		else if (part === "solid") {
			writeAttribute(child, "d", d);
			writeAttribute(child, "clip-path", spans.length === 0 || mode === "overlay" ? null : `url(#${clips.solid})`);
		} else if (part === "marked") {
			writeAttribute(child, "d", spans.length === 0 ? "" : d);
			writeAttribute(child, "clip-path", `url(#${clips.marked})`);
		} else if (part === "dot") {
			writeAttribute(child, "d", dots);
			writeAttribute(child, "clip-path", spans.length === 0 ? null : `url(#${clips.solid})`);
		} else if (part === "dot-marked") {
			writeAttribute(child, "d", spans.length === 0 ? "" : dots);
			writeAttribute(child, "clip-path", `url(#${clips.marked})`);
		}
	}
}
/**
* What each of a path's numbers measures: a vertex's place along the slot axis, then its value, and
* an Area's base, both across the value axis. The loop repeats the declaration for every vertex.
*
* @param orientation - Root's orientation.
* @param stride - The numbers per vertex.
* @returns One vertex's axes.
*/
function pathAxes(orientation, stride) {
	const along = orientation === "vertical" ? "x" : "y";
	const across = orientation === "vertical" ? "y" : "x";
	return stride === 3 ? [
		along,
		across,
		across
	] : [along, across];
}
/** One vertex's numbers out of a list, by its index. */
function vertexAt(values, stride, index) {
	return Array.from({ length: stride }, (_, offset) => values[index * stride + offset] ?? 0);
}
/**
* The path kind of a Line or an Area: a vertex is its place along the slot axis, then its value and
* its base, so a slide moves its first number.
*
* @param stride - `LINE_STRIDE` or `AREA_STRIDE`.
* @param slot - The distance from one slot's centre to the next along the slot axis.
* @returns The kind.
*/
function seriesPathKind(stride, slot) {
	return {
		stride,
		at: (topology, index) => ({
			state: topology.states[index] ?? "pending",
			estimated: topology.estimated[index] ?? false,
			projected: index >= topology.projectedFrom,
			side: topology.sides[index] ?? null,
			cells: topology.cells[index] ?? 1
		}),
		of: (vertices, like) => {
			const projected = vertices.findIndex((vertex) => vertex.projected);
			return {
				count: vertices.length,
				states: vertices.map((vertex) => vertex.state),
				estimated: vertices.map((vertex) => vertex.estimated),
				projectedFrom: projected === -1 ? vertices.length : projected,
				missing: like.missing,
				sides: vertices.map((vertex) => vertex.side),
				cells: vertices.map((vertex) => vertex.cells)
			};
		},
		shift: ([along = 0, ...rest], by) => [along + by * slot, ...rest]
	};
}
/**
* The numbers a path draws at a place in its window, between the vertices around it, or its end
* vertex past either end. Vertices sit about a pixel column apart where a path decimates, so a
* straight blend lands on the path.
*/
function sampler(positions, values, stride) {
	const order = positions.map((_, index) => index).toSorted((a, b) => (positions[a] ?? 0) - (positions[b] ?? 0));
	const at = (rank) => positions[order[rank] ?? 0] ?? 0;
	return (position) => {
		let low = 0;
		let high = order.length;
		while (low < high) {
			const middle = low + high >> 1;
			if (at(middle) < position) low = middle + 1;
			else high = middle;
		}
		const after = order[Math.min(low, order.length - 1)] ?? 0;
		const before = order[Math.max(low - 1, 0)] ?? 0;
		const end = vertexAt(values, stride, after);
		if (low === 0 || low === order.length || at(low) === position) return low === order.length ? vertexAt(values, stride, before) : end;
		const start = vertexAt(values, stride, before);
		const share = (position - at(low - 1)) / (at(low) - at(low - 1));
		return start.map((value, offset) => value + ((end[offset] ?? value) - value) * share);
	};
}
/**
* Decide how a data update moves a path, and lay its route out from what the path drew. The mode
* reads off the window's slots, and the route joins the vertices the loop holds with the new ones
* by key. A vertex in both tweens from where it drew. A new vertex starts on the old path at its
* slot, where a decimated path drew no vertex, or slides in from beyond the edge, or grows out of
* the old end. An old vertex the new path lacks ends on the new path at its slot, slides out past
* the edge, or shrinks into the new end, and a vertex an interrupted slide still takes out keeps
* sliding, so the path keeps its geometry until the clip hides it.
*
* @param memory - What the path placed last, or null before its first placement.
* @param path - The new vertices' keys and places, and the new window's slots.
* @param topology - The new topology.
* @param rest - The new resting numbers.
* @param drawn - What the loop drew last for the path.
* @param kind - How the path's vertices hold their numbers and topology.
* @returns The route, a crossfade, or a snap when no old vertex is known.
*/
function pathStep(memory, path, topology, rest, drawn, kind) {
	if (memory === null || drawn === null) return { kind: "snap" };
	const { stride } = kind;
	const motion = pathMotion(memory.window, path.window);
	if (motion.mode === "crossfade") return { kind: "crossfade" };
	const { by } = motion;
	const slides = motion.mode === "slide";
	const { route } = memory;
	const held = route !== null && route.keys.length * stride === drawn.length ? route : memory;
	if (held.keys.length * stride !== drawn.length) return { kind: "snap" };
	const oldLast = memory.window.keys.length - 1;
	const newLast = path.window.keys.length - 1;
	const oldAt = sampler(held.positions, drawn, stride);
	const newAt = sampler(path.positions, rest, stride);
	const heldIndex = new Map(held.keys.map((key, index) => [key, index]));
	const resting = new Set(memory.keys);
	const vertices = [];
	const grown = /* @__PURE__ */ new Set();
	path.keys.forEach((key, index) => {
		const at = path.positions[index] ?? index;
		const to = vertexAt(rest, stride, index);
		const next = kind.at(topology, index);
		const old = heldIndex.get(key);
		if (old !== void 0) {
			const vertex = kind.keep === void 0 ? next : kind.keep(kind.at(held.topology, old), next);
			vertices.push({
				key,
				at,
				from: vertexAt(drawn, stride, old),
				to,
				vertex
			});
			return;
		}
		const source = at + by;
		let from;
		if (source >= 0 && source <= oldLast) from = kind.flat?.(to, next) ?? oldAt(source);
		else if (slides) from = kind.shift(to, by);
		else {
			from = oldAt(oldLast);
			grown.add(key);
		}
		vertices.push({
			key,
			at,
			from,
			to,
			vertex: next
		});
	});
	const kept = new Set(path.keys);
	held.keys.forEach((key, index) => {
		if (kept.has(key)) return;
		const at = (held.positions[index] ?? index) - by;
		const from = vertexAt(drawn, stride, index);
		let to;
		const vertex = kind.at(held.topology, index);
		if (at >= 0 && at <= newLast) to = kind.flat?.(from, vertex) ?? newAt(at);
		else if (slides) to = kind.shift(from, -by);
		else if (at > newLast && resting.has(key)) to = newAt(newLast);
		else to = from;
		vertices.push({
			key,
			at,
			from,
			to,
			vertex
		});
	});
	const ordered = vertices.toSorted((a, b) => a.at - b.at);
	return {
		kind: "route",
		via: {
			from: ordered.flatMap(({ from }) => from),
			to: ordered.flatMap(({ to }) => to)
		},
		route: {
			keys: ordered.map(({ key }) => key),
			positions: ordered.map(({ at }) => at),
			topology: kind.of(ordered.map(({ vertex }) => vertex), topology)
		},
		grown
	};
}
/**
* The distance from one slot's centre to the next along the slot axis.
*
* @param frame - The layout's frame.
* @param xScale - Root's x scale.
* @returns The distance in CSS pixels.
*/
function slotStep(frame, xScale) {
	return slotCentreAt(frame, 1, xScale) - slotCentreAt(frame, 0, xScale);
}
/**
* A window position's unsnapped centre along the slot axis, where a vertex rests.
*
* @param frame - The layout's frame.
* @param xScale - Root's x scale.
* @returns The function.
*/
function centreAlong(frame, xScale) {
	return (position) => slotCentreAt(frame, position, xScale);
}
/**
* Place a series path for a commit, the one placement Lines, Areas and path-form Bars share. A
* data update tweens the path's route from what it drew, or crossfades it, and records the route
* for the marks attached to the series. Under reduced motion an update snaps to its rest and
* records no route. Every other commit places the rest as the classifier asks, and a resize keeps a
* running route.
*
* @param asked - What the commit asks of the path, from `useCommitMotion`.
* @param input - The path, its look and what it keeps between commits.
*/
function placePath(asked, input) {
	const { mark, motion, paths, seriesIndex, drawn, kind, look, path, topology, rest, memory } = input;
	const anchor = pathAnchor(seriesIndex, drawn);
	const previous = memory.current;
	const before = mark.drawn();
	const step = asked.kind === "move" && !motion.snaps() ? pathStep(previous, path, topology, rest, before, kind) : null;
	const keptRoute = asked.kind === "settle" && previous !== null && sameItems(previous.keys, path.keys);
	if (step?.kind === "route") {
		look.moving.current = step.route.topology;
		mark.place(rest, placementOf(asked, { via: step.via }), anchor);
	} else if (step?.kind === "crossfade") {
		const node = mark.node();
		const old = input.lastLook.current;
		if (node !== null && input.outgoing !== null && old !== null && before !== null && !motion.snaps()) crossfade(node, input.outgoing, (copy) => {
			if (copy instanceof SVGGElement) input.draw(copy, old, before);
		});
		look.moving.current = null;
		mark.place(rest, { kind: "snap" }, anchor);
	} else {
		if (!keptRoute) look.moving.current = null;
		mark.place(rest, step?.kind === "snap" ? { kind: "snap" } : placementOf(asked), anchor);
	}
	const route = step?.kind === "route" ? step.route : keptRoute ? previous.route : null;
	const grown = step?.kind === "route" ? step.grown : keptRoute ? paths.get(seriesIndex, drawn)?.grown : void 0;
	memory.current = {
		keys: path.keys,
		positions: path.positions,
		window: path.window,
		topology,
		route
	};
	input.lastLook.current = look;
	paths.set(seriesIndex, drawn, memory, {
		keys: route?.keys ?? path.keys,
		positions: route?.positions ?? path.positions,
		rest: path.keys,
		restPositions: path.positions,
		stride: kind.stride,
		grown: grown ?? /* @__PURE__ */ new Set(),
		crossfade: step?.kind === "crossfade" ? {} : null
	});
}
export { centreAlong, pathAxes, pathStep, placeOf, placePath, seriesPathKind, slotStep, topologyAt, writePath };

//# sourceMappingURL=chart-path-draw.js.map