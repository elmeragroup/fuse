"use client";
import { ChartCompositionError } from "./layout/errors.js";
// src/components/chart/chart-paths.ts
/**
* Create a Root's path routes.
*
* @returns The record.
*/
function createChartPaths() {
	const routes = /* @__PURE__ */ new Map();
	const lines = /* @__PURE__ */ new Map();
	const claims = /* @__PURE__ */ new Map();
	return {
		claim: (part, kind, dataKey) => {
			const name = `${kind} ${dataKey}`;
			if (claims.has(name)) throw new ChartCompositionError(part, "series-drawn-twice", `draws ${JSON.stringify(dataKey)}, which another ${part} in this Chart.Root draws too, so two marks would move one series and its followers could join either. Draw each series with one ${part}.`);
			const token = {};
			claims.set(name, token);
			return () => {
				if (claims.get(name) === token) claims.delete(name);
			};
		},
		set: (series, kind, owner, route) => {
			routes.set(pathAnchor(series, kind), {
				owner,
				route
			});
		},
		delete: (series, kind, owner) => {
			const anchor = pathAnchor(series, kind);
			if (routes.get(anchor)?.owner === owner) routes.delete(anchor);
		},
		get: (series, kind) => routes.get(pathAnchor(series, kind))?.route,
		setLine: (series, kind, read) => {
			const anchor = pathAnchor(series, kind);
			lines.set(anchor, read);
			return () => {
				if (lines.get(anchor) === read) lines.delete(anchor);
			};
		},
		line: (series, kind) => lines.get(pathAnchor(series, kind))?.() ?? null
	};
}
/**
* The anchor a series path places its vertices under, which its attached marks join.
*
* @param seriesIndex - The series ordinal.
* @param kind - What draws the path.
* @returns The anchor.
*/
function pathAnchor(seriesIndex, kind) {
	return `${kind} ${String(seriesIndex)}`;
}
/**
* A path's place and value at a place in the window: its vertex's there, or a straight blend of
* the two vertices around it, or its end vertex's past either end.
*/
function projectAt(values, stride, positions, position) {
	const vertex = (index) => [values[index * stride] ?? 0, values[index * stride + 1] ?? 0];
	let low = 0;
	let high = positions.length;
	while (low < high) {
		const middle = low + high >> 1;
		if ((positions[middle] ?? 0) < position) low = middle + 1;
		else high = middle;
	}
	if (low >= positions.length) return vertex(positions.length - 1);
	if (low === 0 || positions[low] === position) return vertex(low);
	const [a, b] = [positions[low - 1] ?? 0, positions[low] ?? 0];
	const share = (position - a) / (b - a);
	const [from, to] = [vertex(low - 1), vertex(low)];
	return [from[0] + (to[0] - from[0]) * share, from[1] + (to[1] - from[1]) * share];
}
/**
* Each key list's vertex index by key. A route's lists are the series path's own key arrays, which
* the series-path cache keeps across commits that settle, so a resize or a legend toggle reuses the
* index a pointer sweep built.
*/
const indexes = /* @__PURE__ */ new WeakMap();
/** A key list's vertex index by key, so a pointer step looks a mark up in O(1). */
function indexOf(keys) {
	const cached = indexes.get(keys);
	if (cached !== void 0) return cached;
	const built = new Map(keys.map((key, index) => [key, index]));
	indexes.set(keys, built);
	return built;
}
/**
* The index of a key's vertex among a route's held vertices.
*
* @param route - The series path's route.
* @param key - The slot key.
* @returns The index, or undefined when the route holds no vertex for the key.
*/
function routeIndex(route, key) {
	return indexOf(route.keys).get(key);
}
/**
* The index of a key's vertex among the vertices a route rests on.
*
* @param route - The series path's route.
* @param key - The slot key.
* @returns The index, or undefined when the route rests on no vertex for the key.
*/
function routeRestIndex(route, key) {
	return indexOf(route.rest).get(key);
}
/**
* How attached marks join their series path: one lead per run of marks, which reads each mark's
* place and value from the path's numbers in one pass. On a line, a mark whose slot the path draws
* no vertex for, as decimation leaves out, sits on the path between the vertices around its slot,
* in motion and at rest. A decimated column stands for a bucket's extremes, not for one reading,
* so a run of marks on slots the columns draw no entry for keeps its own numbers and moves them on
* the columns' clock. A mark a paired update grows past the old end keeps its own numbers in
* motion, so it fades in where it rests.
*
* @param route - The series path's route.
* @param seriesIndex - The series ordinal.
* @param kind - What draws the path.
* @param marks - Each attached mark's slot key and its place in the window, in the order of its numbers.
* @param rest - The attached marks' resting numbers, a place and a value each.
* @returns The leads for `useFollowerPlacement`, which cover the marks' numbers in order.
*/
function joinPath(route, seriesIndex, kind, marks, rest) {
	const anchor = pathAnchor(seriesIndex, kind);
	const held = indexOf(route.keys);
	const resting = indexOf(route.rest);
	const joined = marks.map(({ key, position }, mark) => ({
		key,
		position,
		index: held.get(key),
		restIndex: resting.get(key),
		own: [rest[mark * 2] ?? 0, rest[mark * 2 + 1] ?? 0]
	}));
	const free = ({ index, restIndex }) => kind === "columns" && (index === void 0 || restIndex === void 0);
	const vertexInto = (out, values, index) => {
		out.push(values[index * route.stride] ?? 0, values[index * route.stride + 1] ?? 0);
	};
	const leadOf = (clocked, run) => clocked ? {
		anchor,
		clock: run.length * 2
	} : {
		anchor,
		size: run.length * 2,
		pick: (values) => {
			const out = [];
			for (const { key, position, index, own } of run) if (route.grown.has(key)) out.push(...own);
			else if (index === void 0) out.push(...projectAt(values, route.stride, route.positions, position));
			else vertexInto(out, values, index);
			return out;
		},
		rest: (values) => {
			const out = [];
			for (const { position, restIndex } of run) if (restIndex === void 0) out.push(...projectAt(values, route.stride, route.restPositions, position));
			else vertexInto(out, values, restIndex);
			return out;
		}
	};
	const leads = [];
	let start = 0;
	joined.forEach((mark, index) => {
		const next = joined[index + 1];
		if (next !== void 0 && free(next) === free(mark)) return;
		leads.push(leadOf(free(mark), joined.slice(start, index + 1)));
		start = index + 1;
	});
	return leads;
}
export { createChartPaths, joinPath, pathAnchor, routeIndex, routeRestIndex };

//# sourceMappingURL=chart-paths.js.map