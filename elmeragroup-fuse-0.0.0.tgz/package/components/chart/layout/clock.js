import { valueFloor } from "./value-floor.js";
import { toDegrees } from "./polar-angle.js";
// src/components/chart/layout/clock.ts
/**
* The angles of slot i of n. Slot i spans `[360·i/n, 360·(i+1)/n)` clockwise from 12 o'clock, and its
* vertex sits in the middle.
*
* @param index - The slot's index.
* @param count - The cycle's slot count.
* @returns The slot's angles.
*/
function slotAngles(index, count) {
	const step = 360 / count;
	return {
		start: step * index,
		end: step * (index + 1),
		centre: step * (index + .5)
	};
}
/**
* The angle of an instant inside a slot, where Now's hand points: the slot's start plus the share of
* the slot that has passed.
*
* @param index - The slot's index.
* @param passed - The share of the slot that has passed, 0 to 1.
* @param count - The cycle's slot count.
* @returns Degrees from 12 o'clock.
*/
function instantAngle(index, passed, count) {
	return 360 * (index + Math.min(1, Math.max(0, passed))) / count;
}
/**
* The radius of a value. Under "radial", r = √(lerp(inner², outer², t)), so the ring a value fills
* from the hole grows in area as the value does. Under "linear", r = lerp(inner, outer, t). A value
* outside the domain extrapolates, as a cartesian scale does.
*
* @param radii - The dial's radii, domain and scale.
* @returns The map from a value to its radius.
*/
function clockRadius(radii) {
	const { inner, outer, domain, scale } = radii;
	const [lo, hi] = domain;
	const span = hi - lo;
	return (value) => {
		const t = span === 0 ? 0 : (value - lo) / span;
		if (scale === "linear") return inner + (outer - inner) * t;
		const square = inner * inner + (outer * outer - inner * inner) * t;
		return Math.sqrt(Math.max(0, square));
	};
}
/**
* The pad that cuts a constant-width gap between two wedges. d3's arc keeps its pad's width
* `2·padRadius·sin(padAngle / 2)` at every radius, so the gap reads one width from hole to rim and
* every wedge keeps an identical angle. The cut-off is measured at the rim, where a wedge is widest:
* the gap stays while the rim arc leaves at least one device pixel of wedge after it, and vanishes
* below that, where a gap would leave nothing to see. A wedge whose inner arc is narrower than the
* gap tapers to a point at the hole, as a week of hours does. This is the dial's pad: `clockWedges`
* narrows it for a short wedge whose outer arc the gap would erase, so the wedge keeps one device
* pixel of arc at its tip.
*
* @param count - The cycle's slot count.
* @param outer - The rim's radius in CSS pixels.
* @param gap - The gap's width in CSS pixels.
* @param dpr - Device pixels per CSS pixel.
* @returns The pad, with a pad angle of 0 where the gap vanishes.
*/
function wedgePad(count, outer, gap, dpr) {
	if ((2 * Math.PI * outer / count - gap) * dpr < 1 || !(gap > 0) || !(outer > 0)) return {
		padAngle: 0,
		padRadius: outer
	};
	return {
		padAngle: toDegrees(2 * Math.asin(Math.min(1, gap / (2 * outer)))),
		padRadius: outer
	};
}
/** A radius snapped to the device pixel grid. */
function snapRadius(radius, dpr) {
	return Math.round(radius * dpr) / dpr;
}
/**
* The axis a dial's columns floor along, their radius. It grows outward as a horizontal frame's
* value axis grows to the right, so `floor-settle.ts` reads a wedge's radial span as it reads a
* bar's, and the floor stays inside the rim. It reads no plot geometry.
*
* @param outer - The rim's radius in CSS pixels.
* @param dpr - Device pixels per CSS pixel.
* @returns The axis.
*/
function columnAxis(outer, dpr) {
	const limit = snapRadius(outer, dpr);
	return {
		orientation: "horizontal",
		dpr,
		outer,
		floorAcross: (from, to, [base, tip]) => valueFloor(from, to, Math.abs(tip - base), tip < base ? "start" : "end", dpr, limit)
	};
}
/**
* A column's radial span with the floor: its base and tip snapped to device pixels, widened to one
* device pixel away from its base when a non-zero value would snap to nothing, and kept inside the
* dial.
*
* @param axis - The dial's column axis.
* @param base - The column's base radius in CSS pixels, the zero ring or the stack below it.
* @param tip - Its tip radius.
* @returns The span's inner and outer radius.
*/
function columnSpan(axis, base, tip) {
	const { dpr } = axis;
	const [from, to] = [snapRadius(Math.min(base, tip), dpr), snapRadius(Math.max(base, tip), dpr)];
	return axis.floorAcross(from, to, [base, tip]);
}
/**
* The span a stacked column hands the stack floors, which settle which segment keeps the floor on
* each side of the zero ring through `settleFloors`. Its slot stands for its device pixel columns,
* since every wedge of a dial takes an equal angle and no two slots share one.
*
* @param axis - The dial's column axis.
* @param slot - The column's slot.
* @param series - The series it draws, by config key.
* @param base - The segment's base radius in CSS pixels.
* @param tip - Its tip radius.
* @returns The span.
*/
function columnFloorSpan(axis, slot, series, base, tip) {
	const { dpr } = axis;
	return {
		from: slot,
		to: slot + 1,
		series,
		segment: {
			base,
			tip,
			plainFrom: snapRadius(Math.min(base, tip), dpr),
			plainTo: snapRadius(Math.max(base, tip), dpr)
		}
	};
}
export { clockRadius, columnAxis, columnFloorSpan, columnSpan, instantAngle, slotAngles, wedgePad };

//# sourceMappingURL=clock.js.map