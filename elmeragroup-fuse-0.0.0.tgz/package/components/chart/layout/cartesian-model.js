import { coarseSlots } from "./coarse-slots.js";
import { EMPTY_DOMAIN, valueDomain } from "./value-domain.js";
import { readSeries } from "./readings.js";
import { placeRows, projectedSlot } from "./x-domain.js";
import { effectiveWindow } from "./slot-window.js";
import { stackSeries } from "./stack.js";
// src/components/chart/layout/cartesian-model.ts
/**
* Build the model of a cartesian chart.
*
* @param input - Root's data, config, axis and layout props.
* @param place - What places the rows on the x domain. Root passes a placer from
*   `createRowPlacer`, so an update that keeps every x keeps the domain object.
* @returns The model with every issue it met.
*/
function buildCartesianModel(input, place = placeRows) {
	const { rows, series: entries, xKey, time } = input;
	const placed = place(rows.map((row) => row[xKey]), time);
	const { domain, rowAt } = placed;
	const issues = [...placed.issues];
	const slots = domain.kind === "time" ? domain : void 0;
	const column = (name) => name === void 0 ? [] : rowAt.map((row) => row === void 0 ? void 0 : rows[row]?.[name]);
	const read = entries.map(([key, config]) => {
		const coarse = slots === void 0 || config.interval === void 0 || config.interval === slots.interval ? void 0 : coarseSlots(slots.starts, config.interval, slots.timeZone);
		if (coarse === void 0 || slots === void 0) {
			const result = readSeries({
				values: column(key),
				qualities: column(config.qualityKey)
			}, slots, time?.now);
			for (const issue of result.issues) issues.push({
				...issue,
				key
			});
			return {
				key,
				readings: result.readings,
				coarse
			};
		}
		const own = readCoarse(column(key), column(config.qualityKey), coarse, slots, rowAt, time?.now);
		issues.push(...own.offGrid);
		for (const issue of own.issues) issues.push({
			...issue,
			key
		});
		return {
			key,
			readings: own.readings,
			coarse
		};
	});
	const stackOf = /* @__PURE__ */ new Map();
	for (const [key, config] of entries) {
		if (config.stack === void 0) continue;
		stackOf.set(config.stack, [...stackOf.get(config.stack) ?? [], key]);
	}
	const stacks = [...stackOf].filter(([, keys]) => keys.length > 1).map(([id, keys]) => ({
		id,
		keys
	}));
	const stackedKey = new Map(stacks.flatMap(({ id, keys }) => keys.map((key) => [key, id])));
	const groups = [...stacks.map(({ id, keys }) => ({
		stack: id,
		keys
	})), ...entries.flatMap(([key]) => stackedKey.has(key) ? [] : [{
		stack: key,
		keys: [key]
	}])];
	const extents = /* @__PURE__ */ new Map();
	for (const { stack, keys } of groups) {
		const members = read.filter(({ key }) => keys.includes(key));
		const result = stackSeries(members.map(({ readings }) => readings.map((reading) => reading.kind === "reading" ? reading.value : null)), input.stackOffset);
		for (const slot of result.mixedSignSlots) issues.push({
			rule: "mixed-sign-expand",
			slot,
			stack
		});
		members.forEach(({ key }, position) => {
			const list = result.extents[position];
			if (list) extents.set(key, list);
		});
	}
	const window = effectiveWindow(domain, input.xRange);
	const configOf = new Map(entries);
	const series = read.map(({ key, readings, coarse }, seriesIndex) => ({
		key,
		seriesIndex,
		stack: stackedKey.get(key),
		readings,
		extents: extents.get(key) ?? [],
		projectedFrom: projectedSlot(domain, configOf.get(key)?.projectedFrom),
		coarse
	}));
	const empty = !read.some(({ readings }) => readings.some((reading) => reading.kind === "reading"));
	return {
		domain,
		rowAt,
		window,
		series,
		stacks,
		y: layoutDomain({
			window,
			series,
			empty,
			stackOffset: input.stackOffset
		}, {
			keys: entries.map(([key]) => key),
			baseline: input.baseline,
			include: input.include
		}),
		empty,
		issues
	};
}
/**
* Read a coarse series: one cell per coarse slot, the one on the row at the slot's own start. A
* value on any other row of the slot is off the series' grid, `off-grid-x`, as is the slot's first
* row when the domain starts inside the slot, and in production it moves to the slot that contains
* it when the start row holds none. Each coarse slot's state comes from its own start and end
* against `now`, which can lie past the domain's ends, and every Root slot it covers holds it.
*/
function readCoarse(values, qualities, coarse, slots, rowAt, now) {
	const firsts = coarse.first.flatMap((first, slot) => first === slot ? [slot] : []);
	const offGrid = [];
	const cells = firsts.map((first) => {
		const own = slots.starts[first] === coarse.start[first] ? first : -1;
		let value = own === -1 ? void 0 : values[own];
		let quality = own === -1 ? void 0 : qualities[own];
		for (let slot = first; slot <= (coarse.last[first] ?? first); slot += 1) {
			const cell = values[slot];
			if (slot === own || cell === void 0 || cell === null) continue;
			offGrid.push({
				rule: "off-grid-x",
				row: rowAt[slot] ?? slot
			});
			if (value === void 0 || value === null) {
				value = cell;
				quality = qualities[slot];
			}
		}
		return {
			value,
			quality
		};
	});
	const result = readSeries({
		values: cells.map(({ value }) => value),
		qualities: cells.map(({ quality }) => quality)
	}, {
		starts: firsts.map((first) => coarse.start[first] ?? 0),
		ends: firsts.map((first) => coarse.end[first] ?? 0)
	}, now);
	const indexOf = new Map(firsts.map((first, index) => [first, index]));
	return {
		readings: coarse.first.map((first) => result.readings[indexOf.get(first) ?? 0] ?? { kind: "pending" }),
		issues: result.issues.map((issue) => ({
			...issue,
			slot: firsts[issue.slot] ?? issue.slot
		})),
		offGrid
	};
}
/**
* One layout's value domain over the rows inside the effective window, as CONTRACT section 8.3
* gives it: Root's default layout over every config key, a Panel over its `series`. A stacked key
* reaches its stack's ends and an unstacked key its value, so a "none" baseline can leave 0 out.
* It reads the model alone, so a Panel computes it during render and the server agrees.
*
* @param model - The model's window, series, emptiness and stack offset.
* @param layout - The layout's keys, baseline and `yInclude`.
* @returns The niced domain and its ticks, `[0, 1]` when the chart is empty.
*/
function layoutDomain(model, layout) {
	const { window } = model;
	if (model.empty || window === null) return EMPTY_DOMAIN;
	const keys = new Set(layout.keys);
	const members = model.series.filter(({ key }) => keys.has(key));
	let low = Number.POSITIVE_INFINITY;
	let high = Number.NEGATIVE_INFINITY;
	const take = (value) => {
		if (!Number.isFinite(value)) return;
		if (value < low) low = value;
		if (value > high) high = value;
	};
	for (const { extents: list, readings, stack } of members) {
		const own = stack === void 0 && model.stackOffset === "diverging";
		for (let slot = window.first; slot <= window.last; slot += 1) if (own) {
			const reading = readings[slot];
			if (reading?.kind === "reading") take(reading.value);
		} else {
			const extent = list[slot];
			if (extent) {
				take(extent[0]);
				take(extent[1]);
			}
		}
	}
	return valueDomain({
		values: low > high ? [] : [low, high],
		baseline: layout.baseline,
		include: layout.include
	});
}
export { buildCartesianModel, layoutDomain };

//# sourceMappingURL=cartesian-model.js.map