// src/components/chart/layout/band-scale.ts
/**
* Lay out `count` bands across a range, as d3-scale's band scale does.
*
* @param options - The slot count, the range and the padding.
* @returns The step, the bandwidth and every band's start.
*/
function bandScale(options) {
	const { count, range, round = false } = options;
	const paddingInner = Math.min(1, options.paddingInner ?? 0);
	const paddingOuter = options.paddingOuter ?? 0;
	const align = Math.max(0, Math.min(1, options.align ?? .5));
	const [r0, r1] = range;
	const reverse = r1 < r0;
	let start = reverse ? r1 : r0;
	const stop = reverse ? r0 : r1;
	let step = (stop - start) / Math.max(1, count - paddingInner + paddingOuter * 2);
	if (round) step = Math.floor(step);
	start += (stop - start - step * (count - paddingInner)) * align;
	let bandwidth = step * (1 - paddingInner);
	if (round) {
		start = Math.round(start);
		bandwidth = Math.round(bandwidth);
	}
	const starts = Array.from({ length: count }, (_, index) => start + step * index);
	return {
		step,
		bandwidth,
		starts: reverse ? starts.reverse() : starts
	};
}
/**
* Space `count` points across a range, as d3-scale's point scale does. A point scale is a band
* scale whose bands have no width, so a line's first and last vertices reach the range ends.
*
* @param options - The slot count, the range and the outer padding.
* @returns The step, a bandwidth of 0 and every point's position.
*/
function pointScale(options) {
	return bandScale({
		count: options.count,
		range: options.range,
		paddingInner: 1,
		paddingOuter: options.padding ?? 0,
		align: options.align ?? .5,
		round: options.round ?? false
	});
}
/**
* The slot whose centre lies nearest a position along the scale's range. Centres are evenly
* spaced, so the pick is arithmetic. Each cell is half-open, so a position exactly between two
* centres picks the later slot.
*
* @param scale - A band or point scale over at least one slot.
* @param position - The position in the scale's range units.
* @returns The nearest slot index, clamped to the scale's slots.
*/
function nearestIndex(scale, position) {
	const count = scale.starts.length;
	const [first, second] = scale.starts;
	if (first === void 0 || second === void 0) return 0;
	const signedStep = second - first;
	const raw = Math.floor((position - first - scale.bandwidth / 2) / signedStep + .5);
	return Math.max(0, Math.min(count - 1, raw));
}
export { bandScale, nearestIndex, pointScale };

//# sourceMappingURL=band-scale.js.map