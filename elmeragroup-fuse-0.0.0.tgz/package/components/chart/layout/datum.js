import { slotOf } from "./x-domain.js";
// src/components/chart/layout/datum.ts
/**
* The slot that holds Root's `now`, which the "now" keyword picks.
*
* @param domain - The model's domain.
* @param now - Root's `now`, or undefined.
* @returns The slot, or -1 off a time axis, without a `now` or past the domain.
*/
function nowSlotOf(domain, now) {
	return now === void 0 || domain.kind !== "time" ? -1 : slotOf(domain, now);
}
/**
* The slots a keyword picks.
*
* @param keyword - The keyword.
* @param input - The drawn values, the window and the now slot.
* @returns The picked slots in x order.
*/
function keywordSlots(keyword, input) {
	const { values, window, nowSlot } = input;
	const drawn = [];
	for (let slot = window.first; slot <= window.last; slot += 1) if (values[slot] !== null && values[slot] !== void 0) drawn.push(slot);
	switch (keyword) {
		case "now": return nowSlot >= window.first && nowSlot <= window.last ? [nowSlot] : [];
		case "first": return drawn.slice(0, 1);
		case "last": return drawn.slice(-1);
		case "min":
		case "max": {
			const sign = keyword === "max" ? 1 : -1;
			let best = Number.NEGATIVE_INFINITY;
			for (const slot of drawn) best = Math.max(best, sign * (values[slot] ?? 0));
			return drawn.filter((slot) => sign * (values[slot] ?? 0) === best);
		}
	}
}
/**
* The slots a list of x values picks, inside the window.
*
* @param slots - The slot each x value names, -1 for one outside the domain.
* @param window - The effective window.
* @returns The distinct picked slots in x order.
*/
function listedSlots(slots, window) {
	const inside = slots.filter((slot) => slot >= window.first && slot <= window.last);
	return [...new Set(inside)].sort((a, b) => a - b);
}
export { keywordSlots, listedSlots, nowSlotOf };

//# sourceMappingURL=datum.js.map