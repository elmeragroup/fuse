import { snapBarSpan, snapBody } from "./plot-frame.js";
// src/components/chart/layout/bar-shapes.ts
/** The size of one square of the blocks look and the gap above it, in CSS pixels. */
const BLOCK = 10;
const BLOCK_GAP = 2;
/** The depth of the isometric faces, in CSS pixels. */
const DEPTH = 10;
/** The striped cap's thickness and its gap from the bar's far end, in CSS pixels. */
const CAP = 2;
const CAP_GAP = 2;
/** The expandable look's resting strip, a share of the bar centred in it. */
const STRIP = .12;
/** Split a rectangle into its span along the slot axis and its span along the value axis. */
function axes(rect, orientation) {
	return orientation === "vertical" ? {
		along: [rect.x, rect.width],
		across: [rect.y, rect.height]
	} : {
		along: [rect.y, rect.height],
		across: [rect.x, rect.width]
	};
}
/** Join a span along the slot axis and one along the value axis into a rectangle. */
function join(along, across, orientation) {
	return orientation === "vertical" ? {
		x: along[0],
		width: along[1],
		y: across[0],
		height: across[1]
	} : {
		y: along[0],
		height: along[1],
		x: across[0],
		width: across[1]
	};
}
/**
* Whether the far end of a bar lies at the start of the value axis's coordinates: the top of a
* positive vertical bar and the left of a negative horizontal one.
*/
function farAtStart({ orientation, negative }) {
	return orientation === "vertical" ? !negative : negative;
}
/**
* The rectangles of one bar's look, unsnapped.
*
* @param variant - The bar's look.
* @param rect - The bar's rectangle.
* @param placement - The orientation and the sign of the bar.
* @param plotLength - The plot's length along the value axis, where the blocks track ends.
* @returns The rectangles, in CSS pixels from the plot's top left.
*/
function barParts(variant, rect, placement, plotLength) {
	const { orientation } = placement;
	const { along, across } = axes(rect, orientation);
	const [start, size] = along;
	const [from, length] = across;
	const atStart = farAtStart(placement);
	switch (variant) {
		case "expandable": return { body: join([start + size * (.88 / 2), size * STRIP], across, orientation) };
		case "striped": return {
			body: rect,
			cap: join(along, [atStart ? from - CAP_GAP - CAP : from + length + CAP_GAP, CAP], orientation)
		};
		case "blocks": {
			const width = Math.min(size, BLOCK, Math.max(BLOCK_GAP, size - BLOCK_GAP));
			const blocks = Math.max(BLOCK, Math.floor(length / 12) * 12 - BLOCK_GAP);
			const centre = start + (size - width) / 2;
			const base = atStart ? from + length : from;
			return {
				body: join([centre, width], atStart ? [base - blocks, blocks] : [base, blocks], orientation),
				track: join([centre, width], atStart ? [0, base] : [base, Math.max(0, plotLength - base)], orientation)
			};
		}
		default: return { body: rect };
	}
}
/** One SVG polygon point. */
function point(px, py) {
	return `${String(px)},${String(py)}`;
}
/**
* A rectangle as SVG polygon points, clockwise from its top left as an SVG rect's outline runs, so
* a dashed stroke starts where a rect's would. A negative size counts as none, as a bar's rect
* writer clamped it. A rectangle of no width or height keeps its four corners, so it keeps its
* place and span; it has no area, and every bar's clip to its fill box hides its outline, so it
* draws nothing, as such a rect does. Bars draw as polygons because a polygon's points are no CSS
* property: moving one restyles nothing, where a rect's x, y, width and height are presentation
* attributes, and a write to one restyles its element.
*
* @param rect - The rectangle, in CSS pixels.
* @returns Its four corners.
*/
function boxPoints({ x, y, width, height }) {
	const w = Math.max(0, width);
	const h = Math.max(0, height);
	return [
		point(x, y),
		point(x + w, y),
		point(x + w, y + h),
		point(x, y + h)
	].join(" ");
}
/** The isometric faces of a snapped body, `depth` deep up and to the right, as SVG polygon points. */
function isometricFaces({ x, y, width, height }, depth) {
	return {
		top: [
			point(x, y),
			point(x + width, y),
			point(x + width + depth, y - depth),
			point(x + depth, y - depth)
		].join(" "),
		side: [
			point(x + width, y),
			point(x + width + depth, y - depth),
			point(x + width + depth, y + height - depth),
			point(x + width, y + height)
		].join(" ")
	};
}
/**
* The whole squares of a blocks column, 10 px each with a 2 px gap, counted from the column's base
* outward and each snapped through `snapBody`. Every segment counts from its own base, so a stacked
* segment shows whole squares wherever it starts, at rest and in every tween frame.
*/
function squares(frame, column, atStart, floor, within) {
	const { along, across } = axes(column, frame.orientation);
	const [from, length] = across;
	const count = Math.floor((length + BLOCK_GAP) / 12 + 1e-9);
	const base = atStart ? from + length : from;
	return Array.from({ length: count }, (_, index) => {
		const near = index * 12;
		const span = atStart ? [base - near - BLOCK, BLOCK] : [base + near, BLOCK];
		return snapBody(frame, join(along, span, frame.orientation), floor, within);
	});
}
/**
* The shapes one bar draws at a rectangle: its look's rectangles, each snapped through the plot
* frame's `snapBody` with its pixel floors, the blocks look's squares counted from the bar's own
* base, and the isometric faces built on the snapped body, their depth a whole number of device
* pixels. A tween frame's rectangle draws through here too.
*
* @param frame - The layout's frame.
* @param variant - The bar's look.
* @param rect - The bar's rectangle, a tween frame's or its target.
* @param bar - Whether the drawn bar hangs below its base, its drawn top weight, and whether it owns
*   its stack side's value-axis pixel floor, which grows away from its base. A weight above 0, a
*   stack's outer segment or one on its way there, runs its blocks track on to the plot's edge
*   over the empty column, and the track's opacity follows the weight.
* @returns The shapes, every rectangle edge on the device pixel grid.
*/
function drawnBar(frame, variant, rect, bar) {
	const { negative } = bar;
	const { orientation, box } = frame;
	const length = orientation === "vertical" ? box.height : box.width;
	const rects = barParts(variant, rect, {
		orientation,
		negative
	}, length);
	const [start, size] = axes(rect, orientation).along;
	const within = snapBarSpan(frame, start, start + size);
	const atStart = farAtStart({
		orientation,
		negative
	});
	const floor = bar.place === "outer" ? atStart ? "start" : "end" : "none";
	const body = snapBody(frame, rects.body, floor, within);
	const parts = {
		body,
		cap: rects.cap === void 0 ? void 0 : snapBody(frame, rects.cap, floor, within)
	};
	if (variant === "isometric") return {
		...parts,
		...isometricFaces(body, Math.round(DEPTH * box.dpr) / box.dpr)
	};
	if (variant !== "blocks" || rects.track === void 0) return parts;
	const blocks = squares(frame, rects.body, atStart, floor, within);
	return {
		...parts,
		blocks,
		track: bar.top > 0 ? squares(frame, rects.track, atStart, floor, within) : void 0
	};
}
/** Every shape name beyond the body, in the order a bar draws them. */
const DETAIL_PARTS = [
	"track",
	"cap",
	"top",
	"side",
	"blocks"
];
/**
* The shapes beyond the body that `drawnBar` draws for a look, without drawing them.
*
* @param variant - The bar's look.
* @param top - The bar's top weight. Only a weight above 0 runs a blocks track.
* @returns The present `DETAIL_PARTS`, joined by spaces, empty for a plain bar.
*/
function detailParts(variant, top) {
	if (variant === "striped") return "cap";
	if (variant === "isometric") return "top side";
	if (variant === "blocks") return top > 0 ? "track blocks" : "blocks";
	return "";
}
export { DETAIL_PARTS, boxPoints, detailParts, drawnBar };

//# sourceMappingURL=bar-shapes.js.map