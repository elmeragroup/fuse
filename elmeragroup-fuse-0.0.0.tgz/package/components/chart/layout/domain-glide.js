import { cubicBezier } from "./ease.js";
import { CHART_UPDATE_CURVE } from "./motion.js";
// src/components/chart/layout/domain-glide.ts
const ease = cubicBezier(CHART_UPDATE_CURVE);
function between(from, to, eased) {
	return [from[0] + (to[0] - from[0]) * eased, from[1] + (to[1] - from[1]) * eased];
}
function same(a, b) {
	return a.x[0] === b.x[0] && a.x[1] === b.x[1] && a.y[0] === b.y[0] && a.y[1] === b.y[1];
}
/**
* Create a Root's domain glide.
*
* @param initial - The domains the chart first draws under.
* @param host - The clock and the frame scheduler.
* @returns The glide.
*/
function createDomainGlide(initial, host) {
	let current = initial;
	let frame = null;
	const listeners = /* @__PURE__ */ new Set();
	const show = (next) => {
		if (same(next, current)) return;
		current = next;
		for (const listener of listeners) listener();
	};
	const stop = () => {
		if (frame !== null) host.cancelFrame(frame);
		frame = null;
	};
	return {
		get: () => current,
		subscribe(listener) {
			listeners.add(listener);
			return () => {
				listeners.delete(listener);
			};
		},
		to(target, how) {
			stop();
			if (how === "snap" || same(target, current)) {
				show(target);
				return;
			}
			const from = current;
			const start = host.now();
			const step = () => {
				const progress = Math.min(1, (host.now() - start) / 480);
				const eased = ease(progress);
				show(progress === 1 ? target : {
					x: between(from.x, target.x, eased),
					y: between(from.y, target.y, eased)
				});
				frame = progress === 1 ? null : host.requestFrame(step);
			};
			frame = host.requestFrame(step);
		},
		stop
	};
}
export { createDomainGlide };

//# sourceMappingURL=domain-glide.js.map