// src/components/chart/layout/color-bins.ts
const STEPS = [
	1,
	2,
	3,
	4,
	5,
	6,
	7
];
function step(index) {
	return STEPS[Math.max(0, Math.min(6, index))] ?? 4;
}
/**
* Build a series' bins from its readings.
*
* - `chart-diverging` keeps step 4 for magnitudes below M/7, where M is the largest magnitude in
*   the series, then steps 3 and 5 below 3M/7, 2 and 6 below 5M/7, and 1 and 7 beyond. Negative
*   values take the low steps. The bins are symmetric, so x and −x land on mirrored steps.
* - `chart-seq` splits the series' extent into 7 equal bins, so the lowest value takes step 1 and
*   the highest step 7.
* - A flat series, and an all-zero series under either scale, is all step 4.
*
* @param scale - The scale the series names.
* @param values - Every finite reading of the series across the whole data.
* @returns The value-to-step map.
*/
function colorBins(scale, values) {
	if (scale === "chart-diverging") {
		let largest = 0;
		for (const value of values) largest = Math.max(largest, Math.abs(value));
		if (largest === 0) return () => 4;
		return (value) => {
			const scaled = Math.abs(value) * 7;
			const offset = scaled < largest ? 0 : scaled < largest * 3 ? 1 : scaled < largest * 5 ? 2 : 3;
			return step(value < 0 ? 3 - offset : 3 + offset);
		};
	}
	let lo = Number.POSITIVE_INFINITY;
	let hi = Number.NEGATIVE_INFINITY;
	for (const value of values) {
		lo = Math.min(lo, value);
		hi = Math.max(hi, value);
	}
	if (!(hi > lo)) return () => 4;
	return (value) => step(Math.floor((value - lo) / (hi - lo) * 7));
}
/**
* The six values where a scale's steps change, ascending, so a line's or an area's gradient puts a
* hard stop on each. Step k covers the values from edge k − 1 to edge k, the first and the last
* reaching without end. A flat series, which is all step 4, has no edges.
*
* @param scale - The scale the series names.
* @param values - Every finite reading of the series across the whole data.
* @returns The edges, or none.
*/
function binEdges(scale, values) {
	if (scale === "chart-diverging") {
		let largest = 0;
		for (const value of values) largest = Math.max(largest, Math.abs(value));
		if (largest === 0) return [];
		return [
			-5,
			-3,
			-1,
			1,
			3,
			5
		].map((share) => share * largest / 7);
	}
	let lo = Number.POSITIVE_INFINITY;
	let hi = Number.NEGATIVE_INFINITY;
	for (const value of values) {
		lo = Math.min(lo, value);
		hi = Math.max(hi, value);
	}
	if (!(hi > lo)) return [];
	return [
		1,
		2,
		3,
		4,
		5,
		6
	].map((share) => lo + (hi - lo) * share / 7);
}
export { binEdges, colorBins };

//# sourceMappingURL=color-bins.js.map