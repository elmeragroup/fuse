import { pathNumber } from "./rounding.js";
import { polarPoint, toRadians } from "./polar-angle.js";
import { arc } from "d3-shape";
// src/components/chart/layout/arc-path.ts
/**
* The polar path writers. Each turns numbers in degrees and in the caller's radius unit into SVG
* path data through d3-shape, which takes radians, and keeps `PATH_DIGITS` digits, so the server's
* markup and the loop's last frame write the same string. A slice and a clock wedge are d3 arcs, and
* a ring is a stroked centre-line track. The radar's and the clock's curves have their own writers,
* in `radar.ts` and `clock-path.ts`.
*/
/** The d3 arc generator for one spec, its corner and pad radius set. */
function generatorOf(spec) {
	return arc().digits(3).cornerRadius(spec.cornerRadius ?? 0).padRadius(spec.padRadius ?? null);
}
/** One spec as d3's arc reads it. */
function inputOf(spec) {
	return {
		innerRadius: spec.innerRadius,
		outerRadius: spec.outerRadius,
		startAngle: toRadians(spec.startAngle),
		endAngle: toRadians(spec.endAngle),
		padAngle: toRadians(spec.padAngle ?? 0)
	};
}
/**
* The path of one arc, as d3's arc draws it, with its corner clamp and pad.
*
* @param spec - The arc.
* @returns The path data.
*/
function arcPath(spec) {
	return generatorOf(spec)(inputOf(spec)) ?? "";
}
/**
* One generator for many arcs that share a corner radius and a pad radius, such as a clock's
* wedges in one frame, which draws each arc as `arcPath` does.
*
* @param shared - The corner radius and the pad radius every arc takes.
* @returns A writer of each arc's path data.
*/
function arcWriter(shared) {
	const generator = generatorOf(shared);
	return (spec) => generator(inputOf(spec)) ?? "";
}
/**
* The centroid of one arc, d3's: the middle of its radii on the middle of its angles, where an
* inside label sits.
*
* @param spec - The arc.
* @returns The centroid's x and y from the centre.
*/
function arcCentroid(spec) {
	return generatorOf(spec).centroid(inputOf(spec));
}
/**
* A ring's centre-line track over a sweep, the path a ring strokes its value along. A full turn
* draws as two half arcs, because one arc command cannot close a circle.
*
* @param radius - The centre line's radius.
* @param sweep - The sweep.
* @returns The path data.
*/
function ringTrack(radius, sweep) {
	const point = (angle) => {
		const { x, y } = polarPoint(angle, radius);
		return `${pathNumber(x)},${pathNumber(y)}`;
	};
	const r = pathNumber(radius);
	const clockwise = sweep.direction === 1 ? 1 : 0;
	if (sweep.width >= 360) {
		const half = sweep.start + 180 * sweep.direction;
		return `M${point(sweep.start)}A${r},${r} 0 0 ${clockwise} ${point(half)}A${r},${r} 0 0 ${clockwise} ${point(sweep.end)}`;
	}
	const large = sweep.width > 180 ? 1 : 0;
	return `M${point(sweep.start)}A${r},${r} 0 ${large} ${clockwise} ${point(sweep.end)}`;
}
export { arcCentroid, arcPath, arcWriter, ringTrack };

//# sourceMappingURL=arc-path.js.map