import { ownSlot, ownSpan } from "./coarse-slots.js";
import { linearScale, scaleValue } from "./linear-scale.js";
import { slotCount } from "./x-domain.js";
import { bucketEdges } from "./decimate.js";
import { barSpan, floorBody, frameRect, valueAt } from "./plot-frame.js";
// src/components/chart/layout/bar-geometry.ts
/** Above this many domain slots, with `period` included, a Bar draws one path per series. */
const BAR_LIMIT = 100;
/**
* Which form a Bar draws in. The count covers the whole domain, so a brush never switches it.
* Horizontal bars always draw one element per bar, because each category gets a row of its own.
*
* @param model - The Root's model.
* @param orientation - Root's orientation.
* @returns "bars" for 100 slots or fewer or for horizontal bars, else "path".
*/
function barForm(model, orientation) {
	if (orientation === "horizontal") return "bars";
	return slotCount(model.domain) > BAR_LIMIT ? "path" : "bars";
}
/**
* The look a series' bars draw in a form. The path form knows the "default" and "gradient" looks
* only, so every other look draws the default one there.
*
* @param variant - The look the series' config names.
* @param form - The form its bars draw in, from `barForm`.
* @returns The drawn look.
*/
function drawnBarVariant(variant, form) {
	if (form === "bars") return variant;
	return variant === "gradient" ? "gradient" : "default";
}
/**
* Whether an extent hangs below zero.
*
* @param extent - A drawn extent.
* @returns Whether it lies at or below zero with a negative low end.
*/
function isNegative(extent) {
	return extent[0] < 0 && extent[1] <= 0;
}
/** The other series of a series' stack, which decide whether its segment is outermost. */
function stackOthers(model, series) {
	const keys = new Set(model.stacks.find(({ id }) => id === series.stack)?.keys ?? []);
	return model.series.filter((other) => other !== series && keys.has(other.key));
}
/** Whether an extent reaches farthest out on its side of zero among the other series' extents at a slot. */
function outermost(extent, others, slot) {
	const negative = isNegative(extent);
	return others.every((other) => {
		const span = other.extents[slot];
		if (!span || span[0] === span[1]) return true;
		return negative ? span[0] >= extent[0] || !isNegative(span) : span[1] <= extent[1] || isNegative(span);
	});
}
/**
* Whether a key draws its stack's outer segment on its side of zero at a slot, the segment that
* takes the rounded end. An unstacked key always does.
*
* @param model - The Root's model.
* @param series - The key's series.
* @param slot - A slot index.
* @returns Whether the segment is outermost.
*/
function isStackTop(model, series, slot) {
	const extent = series.extents[slot];
	if (!extent) return false;
	if (series.stack === void 0) return true;
	return outermost(extent, stackOthers(model, series), slot);
}
/** The floor place of a series' extent that is its stack's outer segment or not, as `floorPlaces` reads it. */
function placeOf(series, extent, top) {
	return series.stack === void 0 || top && extent[0] !== extent[1] ? "outer" : "inner";
}
/**
* Whether a series' segment at each slot owns the value-axis pixel floor of its stack's side at
* rest: a loose bar always does, and in a stack only the outer segment of a reading other than 0
* does, so each side of a stack has at most one owner. A segment of no length can still count as
* the outermost one, as `isStackTop` reads it. It agrees with `settleFloors` on a resting stack of
* one slot's segments, and serves a mark's first draw, which React renders before any frame's
* segments decide it. The series' stack is read once, so a layout reads every slot's place in
* time linear in the slots and the stack's series.
*
* @param model - The Root's model.
* @param series - The series.
* @returns The place at a slot: `"outer"` for the owner, `"inner"` otherwise.
*/
function floorPlaces(model, series) {
	if (series.stack === void 0) return () => "outer";
	const others = stackOthers(model, series);
	return (slot) => {
		const extent = series.extents[slot];
		return extent ? placeOf(series, extent, outermost(extent, others, slot)) : "inner";
	};
}
/**
* One series' bar at a slot of the window, or null where it draws nothing, such as a missing or
* pending reading or a slot outside the window. A coarse series' bar is the bar of its own slot
* that holds the Root slot.
*
* @param model - The Root's model.
* @param series - The series.
* @param slot - A slot index.
* @returns The cell, or null.
*/
function barCellAt(model, series, slot) {
	const window = model.window;
	if (window === null || slot < window.first || slot > window.last) return null;
	const [first] = ownSlot(series, slot);
	const extent = series.extents[first];
	if (!extent) return null;
	const stackTop = isStackTop(model, series, first);
	return {
		slot: first,
		...ownSpan(series, window, slot),
		extent,
		negative: isNegative(extent),
		stackTop,
		place: placeOf(series, extent, stackTop)
	};
}
/**
* The bars of one series inside the window, in x order, one per own slot.
*
* @param model - The Root's model.
* @param series - The series.
* @returns One cell per drawn bar.
*/
function barCells(model, series) {
	const window = model.window;
	if (window === null) return [];
	const cells = [];
	for (let slot = window.first; slot <= window.last; slot = ownSlot(series, slot)[1] + 1) {
		const cell = barCellAt(model, series, slot);
		if (cell !== null) cells.push(cell);
	}
	return cells;
}
/**
* A cell's geometry in the plot at rest.
*
* @param frame - The layout's frame.
* @param cell - The cell.
* @param metrics - The bar spacing.
* @param sub - The Bar's sub-band.
* @param seam - "cut" ends a stack's inner segment a seam short at its far end, as drawn bars do,
*   and "whole" keeps the full extent, as the active overlay does.
* @returns The geometry, its span on the device pixel grid and its base and tip unsnapped.
*/
function barGeometry(frame, cell, metrics, sub, seam) {
	const [alongStart, alongEnd] = barSpan(frame, cell.position, metrics, sub, cell.span);
	const [base, tip] = projectedEnds(frame, cell.extent, cell.negative);
	return [
		alongStart,
		alongEnd,
		base,
		tip,
		seam === "cut" && !cell.stackTop ? metrics.seam : 0,
		cell.stackTop ? 1 : 0
	];
}
/**
* Where an extent's base and its far end land along the value axis, unsnapped. A projection can
* round a reading other than 0 onto its base, as 0.01 on a domain up to 1e15 does, which would draw
* it as flat as a 0. Its far end then keeps the smallest step past the base on the reading's side
* that the coordinates hold, so the pixel floor still sees a body with length and its side.
*
* @param frame - The layout's frame.
* @param extent - The low and high value the body covers.
* @param negative - Whether the body hangs below zero, which puts its base at its high end.
* @returns The base and the far end, in CSS pixels from the plot's top or left edge.
*/
function projectedEnds(frame, extent, negative) {
	const [low, high] = extent;
	const base = valueAt(frame, negative ? high : low);
	const tip = valueAt(frame, negative ? low : high);
	if (tip !== base || low === high) return [base, tip];
	return [base, base + (frame.orientation === "vertical" ? -1 : 1) * (negative ? -1 : 1) * apart(base)];
}
/** A step past a coordinate that a float holds apart from it: a few units in its last place. */
function apart(at) {
	return Math.max(1, Math.abs(at)) * 4 * Number.EPSILON;
}
/**
* Hold a decimated column's two ends apart where its projection rounds one onto the other, as
* `projectedEnds` does for a bar: its upper end moves up for a column above zero, and its lower end
* down for one below it. Every column has length in value, as `bucketColumns` drops the rest.
*
* @param top - The column's upper end, in CSS pixels down a vertical frame.
* @param bottom - Its lower end.
* @param side - The side of zero the column's own reading lies on.
* @returns The upper and lower ends.
*/
function apartEnds(top, bottom, side) {
	if (top !== bottom) return [top, bottom];
	return side === "negative" ? [top, bottom + apart(bottom)] : [top - apart(top), bottom];
}
/**
* The geometry a tween frame's numbers stand for.
*
* @param values - The loop's numbers for a bar.
* @returns The geometry, with no seam and a full top weight where a number is missing.
*/
function geometryOf(values) {
	const [alongStart = 0, alongEnd = 0, base = 0, tip = 0, seam = 0, top = 1] = values;
	return [
		alongStart,
		alongEnd,
		base,
		tip,
		seam,
		top
	];
}
/**
* Whether a bar's drawn tip lies on the negative side of its drawn base: below it on a vertical
* frame and left of it on a horizontal one. It reads the unsnapped numbers, so a reading shorter
* than a device pixel keeps its side, and a bar crossing zero turns its far end over the moment its
* tip passes its base. A tip exactly on its base, a reading of 0, takes the positive side, as the
* model never calls a reading of 0 negative and the resting bar carries no `data-negative`.
*
* @param frame - The layout's frame.
* @param geometry - The drawn geometry.
* @returns Whether the bar hangs below its base.
*/
function hangs(frame, [, , base, tip]) {
	return frame.orientation === "vertical" ? tip > base : tip < base;
}
/**
* The rectangle a bar's drawn geometry stands for with no value-axis pixel floor, every edge on the
* device pixel grid. A stack's inner segment ends its seam short of its tip, so the surface shows
* between segments. Its span snaps through `snapBarSpan`, so a resting bar draws its grid span as
* it is and a tween frame draws whole device pixels between its two rests' widths.
*
* @param frame - The layout's frame.
* @param geometry - The drawn geometry, a tween frame's or the target's.
* @returns The rectangle.
*/
function plainRect(frame, geometry) {
	const [alongStart, alongEnd, base, tip, seam] = geometry;
	const end = tip + Math.sign(base - tip) * Math.min(Math.max(0, seam), Math.abs(tip - base));
	return frameRect(frame, [alongStart, alongEnd], [base, end]);
}
/**
* The rectangle a bar's drawn geometry stands for, every edge on the device pixel grid: its plain
* rectangle, and for the owner of its stack side's pixel floor, from `settleFloors` in each frame,
* the floor `floorBody` adds from its base toward its tip. Any other segment keeps its plain snap.
* A segment's base is its inner neighbour's tip, so both snap it alike and the segments keep
* tiling. The owner's pixel outlasts its seam: the floor reads the segment's whole length, so a
* seam that takes all of a segment with length leaves the floor its pixel, and a stack with length
* never draws nothing.
*
* @param frame - The layout's frame.
* @param geometry - The drawn geometry, a tween frame's or the target's.
* @param place - Whether the bar owns its stack side's pixel floor in this frame.
* @param plain - Its plain rectangle, where the caller has it already.
* @returns The rectangle.
*/
function geometryRect(frame, geometry, place, plain = plainRect(frame, geometry)) {
	const [, , base, tip] = geometry;
	return place === "outer" ? floorBody(frame, plain, [base, tip]) : plain;
}
/**
* The value a cell's own end stands for: the tip of a positive bar and the low end of a negative
* one, where a value label and the active value line belong.
*
* @param cell - The cell.
* @returns The value.
*/
function barEndValue(cell) {
	return cell.negative ? cell.extent[0] : cell.extent[1];
}
/**
* Where a cell's own value lands, unsnapped: the number a bar's tip and every follower at it tween,
* each writer snapping what it draws, so they meet on the same device pixel in every frame.
*
* @param frame - The layout's frame.
* @param cell - The cell.
* @returns CSS pixels from the plot's top or left edge.
*/
function barTip(frame, cell) {
	return valueAt(frame, barEndValue(cell));
}
/** The stack sides by model and stack, which every member's columns read. */
const stackSides = /* @__PURE__ */ new WeakMap();
/**
* The extent a stack column covers at every slot on each side of zero, from every segment of the
* stack, computed once per model and stack.
*/
function sidesOf(model, series) {
	const byStack = stackSides.get(model) ?? /* @__PURE__ */ new Map();
	stackSides.set(model, byStack);
	const id = series.stack ?? `key ${series.key}`;
	const cached = byStack.get(id);
	if (cached !== void 0) return cached;
	const keys = new Set(model.stacks.find((stack) => stack.id === series.stack)?.keys ?? [series.key]);
	const members = model.series.filter(({ key }) => keys.has(key));
	const count = Math.max(0, ...members.map(({ extents }) => extents.length));
	const positive = new Float64Array(count);
	const negative = new Float64Array(count);
	for (const member of members) member.extents.forEach((span, slot) => {
		if (!span) return;
		negative[slot] = Math.min(negative[slot] ?? 0, span[0]);
		positive[slot] = Math.max(positive[slot] ?? 0, span[1]);
	});
	const sides = {
		positive,
		negative
	};
	byStack.set(id, sides);
	return sides;
}
/**
* The path form's decimated columns of one series, which `layoutColumns` draws above
* `DECIMATE_ABOVE` slots, where every slot up to it draws its own entry. The window splits into M4
* buckets by slot index, each split into the BarGroup's sub-bands. A loose series draws each bucket's
* column from its lowest negative extent to its highest positive extent, and the column takes the
* slot of its larger extreme, so its colour step and quality are that reading's. A stacked series
* draws the segment of the bucket's slot with the largest total magnitude on each side of zero.
*
* @param model - The Root's model.
* @param series - The series.
* @param y - The layout's value domain.
* @param band - The Bar's sub-band, the whole band outside a BarGroup.
* @returns The columns in x order.
*/
function bucketColumns(model, series, y, band = {
	index: 0,
	count: 1
}) {
	const window = model.window;
	if (window === null) return [];
	const scale = linearScale(y, [100, 0]);
	const count = window.last - window.first + 1;
	const columns = [];
	const push = (from, to, extent, slot, at) => {
		if (!extent || extent[0] === extent[1]) return;
		const width = (to - from) / band.count;
		const x0 = from + band.index * width;
		columns.push({
			x0,
			x1: x0 + width,
			top: scaleValue(scale, extent[1]),
			bottom: scaleValue(scale, extent[0]),
			slot,
			...at
		});
	};
	const edges = bucketEdges(count);
	const sides = series.stack === void 0 ? null : sidesOf(model, series);
	for (let bucket = 0; bucket < 500; bucket += 1) {
		const from = edges[bucket] ?? count;
		const to = edges[bucket + 1] ?? count;
		if (to <= from) continue;
		if (series.stack === void 0) {
			let lowSlot = -1;
			let highSlot = -1;
			for (let index = from; index < to; index += 1) {
				const slot = window.first + index;
				const extent = series.extents[slot];
				if (!extent) continue;
				const lowest = series.extents[lowSlot];
				const highest = series.extents[highSlot];
				if (!lowest || extent[0] < lowest[0]) lowSlot = slot;
				if (!highest || extent[1] > highest[1]) highSlot = slot;
			}
			const lowest = series.extents[lowSlot];
			const highest = series.extents[highSlot];
			if (!lowest || !highest) continue;
			const low = Math.min(0, lowest[0]);
			const high = Math.max(0, highest[1]);
			push(from, to, [low, high], -low > high ? lowSlot : highSlot, {
				first: window.first + from,
				side: "across"
			});
			continue;
		}
		for (const negative of [false, true]) {
			const reach = (negative ? sides?.negative : sides?.positive) ?? [];
			let best = -1;
			let magnitude = 0;
			for (let index = from; index < to; index += 1) {
				const slot = window.first + index;
				const total = Math.abs(reach[slot] ?? 0);
				if (total > magnitude) {
					magnitude = total;
					best = slot;
				}
			}
			const extent = best === -1 ? void 0 : series.extents[best];
			if (extent && isNegative(extent) === negative) push(from, to, extent, best, {
				first: window.first + from,
				side: negative ? "below" : "above"
			});
		}
	}
	return columns;
}
/**
* One path's `d` from rectangles, each a closed subpath.
*
* @param rects - The rectangles.
* @returns The path data, empty for none.
*/
function rectsPath(rects) {
	return rects.map(({ x, y, width, height }) => `M${String(x)} ${String(y)}H${String(x + width)}V${String(y + height)}H${String(x)}Z`).join("");
}
/**
* The entrance delay step of the bar at a position. "left" counts up from the first bar, "right"
* from the last, "center" outward from the middle and "edges" inward from both ends. The step
* multiplies `--chart-stagger`.
*
* @param intro - Root's `data-intro`, "left" by default.
* @param position - The bar's place in the window, from 0.
* @param count - The window's slot count.
* @returns The step, 0 for the first bar to grow.
*/
function introStep(intro, position, count) {
	const last = count - 1;
	const centre = last / 2;
	switch (intro) {
		case "left": return position;
		case "right": return last - position;
		case "center": return Math.abs(position - centre);
		case "edges": return centre - Math.abs(position - centre);
	}
}
export { apartEnds, barCellAt, barCells, barEndValue, barForm, barGeometry, barTip, bucketColumns, drawnBarVariant, floorPlaces, geometryOf, geometryRect, hangs, introStep, isNegative, isStackTop, plainRect, projectedEnds, rectsPath };

//# sourceMappingURL=bar-geometry.js.map