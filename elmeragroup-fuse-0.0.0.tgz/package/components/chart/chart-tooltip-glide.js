"use client";
import { clientScale, writeStyle } from "./chart-dom.js";
import { CHART_SPRINGS } from "./layout/motion.js";
import { springTiming } from "./chart-spring.js";
// src/components/chart/chart-tooltip-glide.ts
/**
* The tooltip's glide between slots. Base UI places the popup by writing `translate(x, y)` to the
* positioner's inline style. A slot step arms the glider, and the next place Base UI writes plays
* as one Web Animation of the positioner's transform from where the popup shows, over the chart's
* `--chart-glide` on the tooltip spring, stiffness 100 and damping 20, which never overshoots. A
* route that follows a path, such as the cartesian popup's way over the marks it rests on, turns
* where the route says, and moves the popup at once where the route finds no way, as it does when
* the way would leave the viewport. Anything else that moves the popup, such as a scroll, a resize
* of the window, a data update or a change of side, stops the glide, and the popup shows Base UI's
* place at once. The positioner portals out of the chart, so the glider copies the chart's duration
* onto it. The stylesheet sets `--_glide` from it only while the reader has no preference for
* reduced motion, so under reduced motion every place shows at once.
*/
const TRANSLATE = /translate\(\s*(-?[\d.e+-]+)px\s*,\s*(-?[\d.e+-]+)px\s*\)/;
/**
* Glide a positioner after slot steps.
*
* @param positioner - The tooltip's positioner.
* @param chart - The chart Root's element, whose glide duration the positioner takes.
* @returns The glider.
*/
function createTooltipGlider(positioner, chart) {
	takeDuration(positioner, chart);
	let armed = null;
	let running = null;
	let placed = writtenShift(positioner);
	let placedSize = {
		width: positioner.offsetWidth,
		height: positioner.offsetHeight
	};
	const stop = () => {
		armed = null;
		running?.cancel();
		running = null;
	};
	const written = new MutationObserver(() => {
		const target = writtenShift(positioner);
		if (target === null || placed !== null && target.x === placed.x && target.y === placed.y) return;
		const size = {
			width: positioner.offsetWidth,
			height: positioner.offsetHeight
		};
		const shown = running === null ? placed : shownShift(positioner);
		const before = placedSize;
		placed = target;
		placedSize = size;
		if (armed === null || shown === null) {
			stop();
			return;
		}
		const side = positioner.getAttribute("data-side");
		const route = armed.route();
		if (side !== armed.side) {
			stop();
			return;
		}
		const from = facingKept(shown, before, size, side);
		const timing = glideTiming(positioner);
		const keyframes = timing === null ? null : glideKeyframes(positioner, from, target, armed.side, route);
		if (timing === null || keyframes === null) {
			stop();
			return;
		}
		const previous = running;
		running = positioner.animate(keyframes, timing);
		previous?.cancel();
		const own = running;
		own.onfinish = () => {
			if (running !== own) return;
			running = null;
			armed = null;
		};
	});
	written.observe(positioner, {
		attributes: true,
		attributeFilter: ["style"]
	});
	const view = positioner.ownerDocument.defaultView;
	view?.addEventListener("scroll", stop, {
		capture: true,
		passive: true
	});
	view?.addEventListener("resize", stop, { passive: true });
	return {
		arm: (route) => {
			const own = {
				side: positioner.getAttribute("data-side"),
				route
			};
			armed = own;
			view?.requestAnimationFrame(() => {
				if (armed === own && running === null) armed = null;
			});
		},
		stop,
		dispose: () => {
			written.disconnect();
			view?.removeEventListener("scroll", stop, { capture: true });
			view?.removeEventListener("resize", stop);
			stop();
		}
	};
}
/**
* A translation moved so a box that changed size keeps the edge that faces the plot: its bottom
* edge above the plot, its top edge below it, and its inner edge beside it.
*/
function facingKept(shift, before, after, side) {
	if (side === "top") return {
		x: shift.x,
		y: shift.y + before.height - after.height
	};
	if (side === "left") return {
		x: shift.x + before.width - after.width,
		y: shift.y
	};
	return shift;
}
/** Copy the chart's glide duration onto the positioner. */
function takeDuration(positioner, chart) {
	if (chart === null) return;
	const value = getComputedStyle(chart).getPropertyValue("--chart-glide");
	writeStyle(positioner, "--chart-glide", value === "" ? null : value);
}
/** The translation Base UI wrote to the positioner's inline style, or null before it placed it. */
function writtenShift(positioner) {
	const match = TRANSLATE.exec(positioner.style.transform);
	return match === null ? null : {
		x: Number(match[1]),
		y: Number(match[2])
	};
}
/** The translation the positioner shows now, a running glide's frame included. */
function shownShift(positioner) {
	const transform = getComputedStyle(positioner).transform;
	if (transform === "none" || transform === "") return null;
	const matrix = new DOMMatrixReadOnly(transform);
	return {
		x: matrix.e,
		y: matrix.f
	};
}
/**
* The glide's duration and the tooltip spring's curve, or null when it does not run: under reduced
* motion, where the stylesheet leaves `--_glide` unset, or for a duration of zero.
*/
function glideTiming(positioner) {
	const duration = milliseconds(getComputedStyle(positioner).getPropertyValue("--_glide"));
	if (duration === null || duration <= 0) return null;
	return {
		duration,
		easing: springTiming(CHART_SPRINGS.glide).easing
	};
}
/** A CSS time in milliseconds, or null for anything else. */
function milliseconds(value) {
	const match = /^\s*(-?[\d.]+(?:e[-+]?\d+)?)(ms|s)\s*$/i.exec(value);
	if (match === null) return null;
	const amount = Number(match[1]);
	return match[2]?.toLowerCase() === "s" ? amount * 1e3 : amount;
}
/**
* The keyframes from one translation to the next, evenly paced along the glide's path, or null when
* the popup moves at once. A path turns where its route turns it, measured in client pixels from
* the positioner's box and taken back into the positioner's own pixels.
*/
function glideKeyframes(positioner, from, to, side, route) {
	const straight = [{ transform: translate(from) }, { transform: translate(to) }];
	if (route.kind === "straight") return straight;
	const shownBox = positioner.getBoundingClientRect();
	const shown = animated(positioner) ? shownShift(positioner) : to;
	if (shown === null) return straight;
	const scale = clientScale(positioner).x;
	const end = {
		left: shownBox.left + (to.x - shown.x) * scale,
		bottom: shownBox.bottom + (to.y - shown.y) * scale
	};
	const start = {
		left: end.left + (from.x - to.x) * scale,
		bottom: end.bottom + (from.y - to.y) * scale
	};
	const size = {
		width: shownBox.width,
		height: shownBox.height
	};
	const turns = route.turns(start, end, size, side);
	if (turns === null) return null;
	const lengths = turns.map((turn, index) => {
		const before = turns[index - 1];
		return before === void 0 ? 0 : Math.hypot(turn.left - before.left, turn.bottom - before.bottom);
	});
	const total = lengths.reduce((sum, length) => sum + length, 0);
	if (total === 0) return straight;
	let travelled = 0;
	return turns.map((turn, index) => {
		travelled += lengths[index] ?? 0;
		return {
			transform: translate({
				x: from.x + (turn.left - start.left) / scale,
				y: from.y + (turn.bottom - start.bottom) / scale
			}),
			offset: travelled / total
		};
	});
}
/** Whether an animation drives the positioner's transform now. */
function animated(positioner) {
	return positioner.getAnimations().some((animation) => animation.playState === "running");
}
function translate({ x, y }) {
	return `translate(${String(x)}px, ${String(y)}px)`;
}
export { createTooltipGlider };

//# sourceMappingURL=chart-tooltip-glide.js.map