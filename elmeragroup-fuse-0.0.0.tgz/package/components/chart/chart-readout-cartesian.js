"use client";
import { barForm, drawnBarVariant } from "./layout/bar-geometry.js";
import { useCartesianPick } from "./chart-pick.js";
import { seriesReadoutOf } from "./chart-series-readout.js";
// src/components/chart/chart-readout-cartesian.ts
/**
* Build a cartesian Root's readout. Root memoises it on its context, so it changes with data,
* config and the effective window, and never with the pointer.
*
* @param context - The Root.
* @returns The readout.
*/
function cartesianReadout(context) {
	const { model, config, orientation } = context;
	return seriesReadoutOf(context, {
		id: context.id,
		root: context.root,
		store: context.store,
		followers: context.followers,
		select: context.select,
		registerToggleGroup: context.registerToggleGroup,
		highlight: context.highlight,
		warnOnce: context.warnOnce,
		usePick: () => useCartesianPick(context, "Chart.Tooltip")
	}, { look: (key) => {
		const look = drawnBarVariant(config[key]?.barVariant ?? "default", barForm(model, orientation));
		return look === "default" ? void 0 : look;
	} });
}
export { cartesianReadout };

//# sourceMappingURL=chart-readout-cartesian.js.map