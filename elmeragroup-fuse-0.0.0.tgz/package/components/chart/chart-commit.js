"use client";
import { layoutDomain } from "./layout/cartesian-model.js";
import { pathMotion } from "./layout/path-motion.js";
import { mountedSeries, relaysPlot } from "./layout/relay.js";
import { pairSlotKeys } from "./layout/slot-keys.js";
import { windowSlots } from "./layout/series-path.js";
import { useState } from "react";
// src/components/chart/chart-commit.ts
/**
* How Root classifies each change of its model, the one owner of `ChartUpdate`. Each render hands
* the classifier Root's model and the inputs it came from, and the classifier keeps the commit it
* saw last, so it tells a data update from a range step, a Panel's registration from either, and
* decides which keys glide between two domains and whether the update relays the plot. Marks read
* the result through Root's context and compare its identity to tell an update from a re-render.
*/
/**
* The value domain each config key draws in: its Panel's, or the default layout's without Panels.
* Root computes a Panel's domain from what the Panel registered, as the Panel computes it during
* render, so both read the same model.
*
* @param model - Root's model.
* @param stackOffset - Root's stack offset.
* @param panels - The mounted Panels.
* @returns Each key's domain.
*/
function keyDomains(model, stackOffset, panels) {
	if (panels.length === 0) return new Map(model.series.map(({ key }) => [key, model.y.domain]));
	const stacked = {
		...model,
		stackOffset
	};
	return new Map(panels.flatMap(({ layout }) => {
		const { domain } = layoutDomain(stacked, layout);
		return layout.keys.map((key) => [key, domain]);
	}));
}
/** Whether two key domain maps hold the same domain for a key. */
function sameDomain(a, b, key) {
	const [lowA, highA] = a.get(key) ?? [0, 1];
	const [lowB, highB] = b.get(key) ?? [0, 1];
	return lowA === lowB && highA === highB;
}
/** The commit of Root's first render, which draws every mark in place. */
function firstCommit({ model, data, config, range, domains }) {
	const keys = pairSlotKeys(null, model.domain);
	return {
		model,
		data,
		config,
		range,
		update: {
			kind: "initial",
			keys: keys.keys,
			relays: false,
			from: domains,
			mounted: /* @__PURE__ */ new Set(),
			gliding: /* @__PURE__ */ new Set(),
			layouts: {
				relays: false,
				moved: /* @__PURE__ */ new Set()
			},
			window: {
				mode: "tween",
				by: 0
			}
		},
		keys,
		domains,
		moved: /* @__PURE__ */ new Set()
	};
}
/** The commit after `seen` for this render's inputs, or `seen` itself when nothing changed. */
function nextCommit(seen, inputs, motion, bars) {
	const { model, data, config, range, domains, panels, orientation } = inputs;
	if (seen.model === model && seen.domains === domains) return seen;
	const rangeOnly = seen.data === data && seen.config === config && seen.range !== range;
	const keys = pairSlotKeys(seen.keys, model.domain);
	const gliding = motion.running() && !seen.update.layouts.relays ? /* @__PURE__ */ new Set([...seen.moved, ...seen.update.layouts.moved]) : /* @__PURE__ */ new Set();
	const panelKeys = new Set(panels.flatMap(({ layout }) => layout.keys));
	const own = new Map(domains);
	for (const key of panelKeys) own.set(key, seen.domains.get(key) ?? domains.get(key) ?? [0, 1]);
	const drawn = new Set([...bars.values()].map(({ key }) => key));
	const relays = !rangeOnly && relaysPlot({
		model: seen.model,
		keys: seen.update.keys,
		domains: seen.domains
	}, {
		model,
		keys: keys.keys,
		domains: own
	}, orientation, gliding, drawn);
	const registered = seen.model === model;
	return {
		model,
		data,
		config,
		range,
		update: registered ? seen.update : {
			kind: rangeOnly ? "range" : "data",
			keys: keys.keys,
			relays,
			from: seen.domains,
			mounted: mountedSeries({
				model: seen.model,
				keys: seen.update.keys
			}, {
				model,
				keys: keys.keys
			}, orientation, drawn),
			gliding,
			layouts: {
				relays: false,
				moved: /* @__PURE__ */ new Set()
			},
			window: pathMotion(windowSlots(seen.model, seen.update.keys), windowSlots(model, keys.keys))
		},
		keys,
		domains,
		moved: relays || rangeOnly ? /* @__PURE__ */ new Set() : registered ? gliding : /* @__PURE__ */ new Set([...gliding, ...[...domains.keys()].filter((key) => !panelKeys.has(key) && !sameDomain(seen.domains, domains, key))])
	};
}
/**
* Root's commit for this render: the first one, or the one after the commit Root saw last, kept
* until the model or the domains change again.
*
* @param inputs - Root's model and what it came from, its domains, its Panels and orientation.
* @param motion - Root's loop, which tells whether tweens still run as an update starts.
* @param bars - The mounted Bars, which name the keys an update finds drawn as bars.
* @returns The commit.
*/
function useChartCommit(inputs, motion, bars) {
	const [seen, setSeen] = useState(() => firstCommit(inputs));
	const commit = nextCommit(seen, inputs, motion, bars);
	if (commit !== seen) setSeen(commit);
	return commit;
}
export { keyDomains, useChartCommit };

//# sourceMappingURL=chart-commit.js.map