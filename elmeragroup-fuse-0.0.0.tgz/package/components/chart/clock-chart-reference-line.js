"use client";
import { CHART_STRINGS } from "./format/chart-strings.js";
import { formatSlot, isClockInterval } from "./format/time-format.js";
import { formatValue } from "./format/value-format.js";
import { clockDrawingIn, usePolarContext } from "./chart-polar-context.js";
import { slotLabel } from "./chart-text.js";
import { referenceSentence } from "./chart-reference-text.js";
import { viewBoxOf } from "./layout/polar-angle.js";
import { slotAngles } from "./layout/clock.js";
import { ringPath } from "./layout/clock-path.js";
import { labelPlace, slotOfX, spokePath } from "./clock-chart-dial.js";
import { PlacedLabel } from "./clock-chart-placed-label.js";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/clock-chart-reference-line.tsx
/**
* A ring at a value, as `y`, or a spoke at an instant's slot start, as `x`, with an optional label.
* A `y` at a series' threshold draws the ring the threshold paints at. A `y` outside the radius
* domain, inside the hole or past the rim, and an `x` outside the cycle draw nothing, the label
* included; `yInclude` widens the domain to hold one. Readers hear it as a visually hidden sentence
* that always carries the value, as the cartesian ReferenceLine's.
*
* @beta
*/
function ClockChartReferenceLine({ style, ...props }) {
	const { label, variant = "solid", tone = "default", className } = props;
	const { model, box, kernel } = usePolarContext("ClockChart.ReferenceLine", ["clock"]);
	const clock = clockDrawingIn(model, "ClockChart.ReferenceLine");
	let d;
	let value;
	let drawn;
	let place;
	if (props.y !== void 0) {
		const radius = clock.radius(props.y);
		const [min, max] = clock.domain;
		drawn = props.y >= min && props.y <= max && radius > 0;
		d = drawn ? ringPath(radius) : "";
		value = formatValue(kernel.locale, props.y, props.format ?? clock.format, "full");
		place = labelPlace(box, 0, radius);
	} else {
		const slot = slotOfX(clock, "ClockChart.ReferenceLine", props.x);
		const angle = slot === -1 ? 0 : slotAngles(slot, clock.count).start;
		d = slot === -1 ? "" : spokePath(angle, clock.inner, 1);
		const start = clock.starts[slot];
		const domain = clock.text.model.domain;
		const interval = domain.kind === "time" ? domain.interval : "hour";
		drawn = start !== void 0;
		if (start === void 0) value = {
			text: "",
			spoken: ""
		};
		else if (props.format === void 0 && !isClockInterval(interval)) value = slotLabel(clock.text, slot);
		else {
			const timeZone = domain.kind === "time" ? domain.timeZone : "UTC";
			value = formatSlot(kernel.locale, timeZone, start, interval, props.format ?? "time", "full");
		}
		place = labelPlace(box, angle, 1.02);
	}
	const text = referenceSentence(label, value, CHART_STRINGS[kernel.locale].referenceLine);
	return /* @__PURE__ */ jsxs("div", {
		"data-slot": "clock-chart-reference-line",
		"data-variant": variant,
		"data-tone": tone,
		"data-polar-layer": "",
		className,
		style,
		children: [
			/* @__PURE__ */ jsx("svg", {
				viewBox: viewBoxOf(box),
				"aria-hidden": "true",
				focusable: "false",
				children: /* @__PURE__ */ jsx("path", {
					"data-slot": "clock-chart-reference-path",
					"data-part": "line",
					d
				})
			}),
			label === void 0 || !drawn ? null : /* @__PURE__ */ jsx(PlacedLabel, {
				place,
				children: text.text
			}),
			/* @__PURE__ */ jsx("span", {
				"data-slot": "chart-reference-text",
				children: text.spoken
			})
		]
	});
}
Object.assign(ClockChartReferenceLine, { displayName: "ClockChart.ReferenceLine" });
export { ClockChartReferenceLine };

//# sourceMappingURL=clock-chart-reference-line.js.map