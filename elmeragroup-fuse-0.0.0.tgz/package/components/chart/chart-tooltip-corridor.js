"use client";
// src/components/chart/chart-tooltip-corridor.ts
const corridors = /* @__PURE__ */ new WeakMap();
/**
* Share the open popup's corridor on a Root's store, or take it away as the popup closes.
*
* @param store - The Root's store.
* @param corridor - The corridor, or null.
*/
function shareCorridor(store, corridor) {
	if (corridor === null) corridors.delete(store);
	else corridors.set(store, corridor);
}
/**
* The open popup's corridor on a Root's store.
*
* @param store - The Root's store.
* @returns The corridor, or undefined while no popup shows.
*/
function corridorOf(store) {
	return corridors.get(store);
}
export { corridorOf, shareCorridor };

//# sourceMappingURL=chart-tooltip-corridor.js.map