"use client";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-glow-filter.tsx
/**
* The halo of a Line or an Area. It matches the 9.5 px full-alpha shadow that `chart.css` gives
* `chart-line-series` and `chart-area-series` inside `Chart.Glow`, so change both together.
*/
const PATH_GLOW = {
	deviation: 9.5,
	alpha: 1
};
/**
* The halo of a Bar. It matches the 8 px half-alpha shadow that `chart.css` gives
* `chart-bar-series` inside `Chart.Glow`, so change both together.
*/
const BAR_GLOW = {
	deviation: 8,
	alpha: .5
};
/** How far a halo reaches, in standard deviations, before it fades below a 1 % alpha. */
const REACH = 3;
/** The filter a value-painted series' marks glow through. */
function ValueGlowFilter({ id, region, halo }) {
	const { alpha } = halo;
	const deviation = halo.deviation / region.unit;
	const margin = deviation * REACH;
	return /* @__PURE__ */ jsxs("filter", {
		id,
		filterUnits: "userSpaceOnUse",
		x: region.x - margin,
		y: region.y - margin,
		width: region.width + 2 * margin,
		height: region.height + 2 * margin,
		colorInterpolationFilters: "sRGB",
		children: [
			/* @__PURE__ */ jsx("feGaussianBlur", {
				in: "SourceGraphic",
				stdDeviation: deviation,
				result: "blur"
			}),
			/* @__PURE__ */ jsx("feComponentTransfer", {
				in: "blur",
				result: "halo",
				children: /* @__PURE__ */ jsx("feFuncA", {
					type: "linear",
					slope: alpha
				})
			}),
			/* @__PURE__ */ jsxs("feMerge", { children: [/* @__PURE__ */ jsx("feMergeNode", { in: "halo" }), /* @__PURE__ */ jsx("feMergeNode", { in: "SourceGraphic" })] })
		]
	});
}
Object.assign(ValueGlowFilter, { displayName: "Chart.ValueGlowFilter" });
/**
* The glow wiring of one series.
*
* @param paint - The series paint.
* @param prefix - The series' SVG id prefix.
* @param halo - `PATH_GLOW` or `BAR_GLOW`.
* @returns The wiring for a scale or a threshold, or null for a role or a role list, which glow
*   through the CSS shadow.
*/
function valueGlow(paint, prefix, halo) {
	if (paint.bins === void 0) return null;
	const id = `${prefix}-glow`;
	return {
		paint: "value",
		url: `url(#${id})`,
		filter: (region) => /* @__PURE__ */ jsx(ValueGlowFilter, {
			id,
			region,
			halo
		})
	};
}
/**
* A plot's glow region: its box, drawn in CSS pixels.
*
* @param box - The plot's width and height.
* @returns The region.
*/
function plotGlowRegion(box) {
	return {
		x: 0,
		y: 0,
		width: box.width,
		height: box.height,
		unit: 1
	};
}
export { BAR_GLOW, PATH_GLOW, plotGlowRegion, valueGlow };

//# sourceMappingURL=chart-glow-filter.js.map