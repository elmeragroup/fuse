"use client";
import { CHART_STRINGS } from "./format/chart-strings.js";
import { formatSlot, slotStart } from "./format/time-format.js";
import { formatUnitLabel, formatUnitless, formatValue } from "./format/value-format.js";
import { assertKnownKey } from "./layout/errors.js";
import { ownWindowSlots, rowSpans } from "./layout/coarse-slots.js";
import { slotX } from "./layout/x-domain.js";
import { isThresholdColor } from "./layout/color-key.js";
import { readingPaint, seriesPaintOf, swatchPaint } from "./chart-paint.js";
import "./chart-table-shell.js";
import { seriesLabel } from "./format/series-label.js";
import { seriesOf } from "./layout/series-of.js";
import { ownSlotLabel, qualityWords, slotLabel, stackTotalAt } from "./chart-text.js";
import { keywordSlots, nowSlotOf } from "./layout/datum.js";
import { roundShares } from "./layout/shares.js";
// src/components/chart/chart-series-readout.ts
/**
* One key's reading at one slot.
*
* @param context - The Root.
* @param key - A config key.
* @param slot - A slot index.
* @returns The reading, or undefined for an unknown key.
*/
function readingAt(context, key, slot) {
	return seriesOf(context.model, key)?.readings[slot];
}
/**
* A reading as a tooltip row prints it: the value with its quality word in parentheses, or the
* missing or pending word.
*
* @param context - The Root.
* @param key - A config key.
* @param slot - A slot index.
* @param format - A format that replaces the series' own.
* @returns The visual text.
*/
function readingText(context, key, slot, format) {
	const strings = CHART_STRINGS[context.locale];
	const reading = readingAt(context, key, slot);
	if (reading === void 0 || reading.kind === "pending") return strings.pending;
	if (reading.kind === "missing") return strings.missing;
	const value = formatValue(context.locale, reading.value, format ?? context.config[key]?.format ?? {}, "full").text;
	const own = ownSlotLabel(context, key, slot);
	const series = seriesOf(context.model, key);
	const words = [...own === null ? [] : [own.text], ...qualityWords(context.locale, reading.quality, series !== void 0 && slot >= series.projectedFrom)];
	return words.length === 0 ? value : `${value} (${words.join(", ")})`;
}
/**
* Each key's share of the sum of the absolute readings of every key at one slot, rounded together.
*
* @param context - The Root.
* @param slot - A slot index.
* @param digits - The fraction digits.
* @returns Each key's share in percent, or null for a zero denominator.
*/
function slotShares(context, slot, digits) {
	const { series } = context.model;
	const parts = series.map(({ readings }) => {
		const reading = readings[slot];
		return reading?.kind === "reading" ? reading.value : null;
	});
	const shares = roundShares(parts, digits);
	return new Map(series.map(({ key }, index) => [key, shares[index] ?? null]));
}
/**
* Each key's share of the sum of every key's absolute total over the effective window.
*
* @param context - The Root.
* @param digits - The fraction digits.
* @returns Each key's share in percent, or null for a zero denominator.
*/
function windowShares(context, digits) {
	const { series, window } = context.model;
	const totals = series.map((entry) => {
		if (window === null) return 0;
		let total = 0;
		for (const slot of ownWindowSlots(entry, window)) {
			const reading = entry.readings[slot];
			if (reading?.kind === "reading") total += reading.value;
		}
		return total;
	});
	const shares = roundShares(totals, digits);
	return new Map(series.map(({ key }, index) => [key, shares[index] ?? null]));
}
/**
* One stack's net total at a slot, the sum of its present parts.
*
* @param context - The Root.
* @param stack - A stack id that holds two or more keys.
* @param slot - A slot index.
* @returns The total and whether a part is missing, or null when no part has a reading.
*/
function stackTotal(context, stack, slot) {
	return stackTotalAt(context.model, context.model.stacks.find(({ id }) => id === stack)?.keys ?? [], slot);
}
/**
* The slot a fallback keyword selects for one key over the effective window: its first or last
* reading, its lowest or highest, or the slot that holds `now` while the window shows it.
*
* @param context - The Root.
* @param key - A config key.
* @param fallback - The keyword.
* @returns The slot, or null when the keyword selects nothing.
*/
function fallbackSlot(context, key, fallback) {
	const { model } = context;
	const { window } = model;
	if (window === null) return null;
	const values = (seriesOf(model, key)?.readings ?? []).map((reading) => reading.kind === "reading" ? reading.value : null);
	const [slot] = keywordSlots(fallback, {
		values,
		window,
		nowSlot: nowSlotOf(model.domain, context.now)
	});
	return slot ?? null;
}
/** The calendar period one page holds at each interval, the coarsest whose largest instance fits. */
const PAGE_PERIOD = {
	second: "minute",
	minute: "hour",
	"quarter-hour": "day",
	hour: "week",
	day: "year",
	week: "year",
	month: "year",
	year: "year"
};
/** The label each page period prints in the status, such as `uke 2`. */
const PAGE_LABEL = {
	minute: "time",
	hour: "hour",
	day: "date",
	week: "week",
	year: "year"
};
/** The slots the table lists: every slot that holds a reading or a missing reading in some series. */
function tableSlots(model) {
	const { series, domain } = model;
	const count = domain.kind === "time" ? domain.starts.length : domain.names.length;
	const slots = [];
	for (let slot = 0; slot < count; slot += 1) if (series.some(({ readings }) => readings[slot]?.kind !== "pending")) slots.push(slot);
	return slots;
}
/** The table's pages: one for 500 rows or fewer, else one per calendar period or per 500 categories. */
function tablePages(model, locale, slots) {
	const { domain } = model;
	const strings = CHART_STRINGS[locale];
	if (slots.length <= 500) return [{
		key: 0,
		slots,
		label: "",
		spoken: ""
	}];
	if (domain.kind === "category") {
		const pages = [];
		for (let from = 0; from < slots.length; from += 500) {
			const page = slots.slice(from, from + 500);
			const range = strings.rowRange(String(from + 1), String(from + page.length));
			pages.push({
				key: from,
				slots: page,
				label: range,
				spoken: range
			});
		}
		return pages;
	}
	const period = PAGE_PERIOD[domain.interval];
	const pages = /* @__PURE__ */ new Map();
	for (const slot of slots) {
		const start = slotStart(domain.starts[slot] ?? 0, period, domain.timeZone);
		const page = pages.get(start);
		if (page === void 0) pages.set(start, [slot]);
		else page.push(slot);
	}
	return [...pages].map(([key, list]) => {
		const label = formatSlot(locale, domain.timeZone, key, period, PAGE_LABEL[period], "full");
		return {
			key,
			slots: list,
			label: label.text,
			spoken: label.spoken
		};
	});
}
/**
* Each model's table index per locale. The slots and pages read the whole domain, so they wait for
* a new model or locale, and a new window of the same data reuses them.
*/
const tableIndexes = /* @__PURE__ */ new WeakMap();
/** The table index of a model in a locale, built on first read. */
function tableIndexOf(model, locale) {
	let byLocale = tableIndexes.get(model);
	if (byLocale === void 0) {
		byLocale = /* @__PURE__ */ new Map();
		tableIndexes.set(model, byLocale);
	}
	let index = byLocale.get(locale);
	if (index === void 0) {
		const slots = tableSlots(model);
		index = {
			slots,
			pages: tablePages(model, locale, slots)
		};
		byLocale.set(locale, index);
	}
	return index;
}
/** The caption: the chart name and the period the rows span. */
function captionText(context, slots) {
	const { domain } = context.model;
	const first = slots[0] ?? 0;
	const last = slots.at(-1) ?? first;
	let period;
	if (domain.kind === "category") period = CHART_STRINGS[context.locale].valueRange(domain.names[first] ?? "", domain.names[last] ?? "");
	else {
		const options = domain.interval === "year" ? { year: "numeric" } : domain.interval === "month" ? {
			month: "long",
			year: "numeric"
		} : {
			day: "numeric",
			month: "long",
			year: "numeric"
		};
		const label = (slot) => formatSlot(context.locale, domain.timeZone, domain.starts[slot] ?? 0, domain.interval, options, "full").text;
		const from = label(first);
		const to = label(last);
		period = from === to ? from : CHART_STRINGS[context.locale].valueRange(from, to);
	}
	return context.name === void 0 ? period : `${context.name}, ${period}`;
}
/** The first column's header, which the interval picks. */
function xHeaderText(context) {
	const strings = CHART_STRINGS[context.locale];
	const { domain } = context.model;
	if (domain.kind === "category") return strings.xHeaderCategory;
	switch (domain.interval) {
		case "second":
		case "minute":
		case "quarter-hour":
		case "hour": return strings.xHeaderTime;
		case "day": return strings.xHeaderDay;
		case "week": return strings.xHeaderWeek;
		case "month": return strings.xHeaderMonth;
		case "year": return strings.xHeaderYear;
	}
}
/** A series column's header, the label followed by the format's unit. */
function seriesHeader(context, key) {
	const label = seriesLabel(context, key);
	const unit = formatUnitLabel(context.locale, context.config[key]?.format ?? {});
	if (unit === null) return label;
	return {
		text: `${label.text} (${unit.text})`,
		spoken: `${label.spoken} (${unit.spoken})`
	};
}
/**
* One series cell: the unitless value with its quality and projection words, the missing dash, or
* the pending word for screen readers alone. A cell that a coarse series' span above covers renders
* nothing.
*/
function seriesCell(context, key, slot, rows) {
	if (rows === 0) return {
		kind: "covered",
		key
	};
	const strings = CHART_STRINGS[context.locale];
	const series = seriesOf(context.model, key);
	const reading = series?.readings[slot];
	if (series === void 0 || reading === void 0 || reading.kind === "pending") return {
		kind: "silent",
		key,
		spoken: strings.pending,
		rows
	};
	if (reading.kind === "missing") return {
		kind: "value",
		key,
		text: {
			text: "–",
			spoken: strings.missing
		},
		words: [],
		rows
	};
	return {
		kind: "value",
		key,
		text: formatUnitless(context.locale, reading.value, context.config[key]?.format ?? {}),
		words: qualityWords(context.locale, reading.quality, slot >= series.projectedFrom),
		rows
	};
}
/** One stack's total cell: the sum of the present parts, with the incomplete word for a missing part. */
function totalCell(context, stack, keys, slot) {
	const strings = CHART_STRINGS[context.locale];
	const sum = stackTotalAt(context.model, keys, slot);
	const key = `total-${stack}`;
	if (sum === null) return {
		kind: "value",
		key,
		text: {
			text: "–",
			spoken: strings.missing
		},
		words: [],
		rows: 1
	};
	return {
		kind: "value",
		key,
		text: formatUnitless(context.locale, sum.total, context.config[keys[0] ?? ""]?.format ?? {}),
		words: sum.incomplete ? [strings.incomplete] : [],
		rows: 1
	};
}
/**
* A series model's table: every slot of the full data that holds a reading or a missing reading,
* paged past 500 rows by calendar period or by 500 categories, with one column per series and per
* multi-series stack total. It builds rows for the shown page alone.
*
* @param context - The series model's words, the chart's name and the Root's rows.
* @param keys - The React key each domain slot's row renders under, by slot index.
* @returns The table model.
*/
function seriesTable(context, keys) {
	const { model, locale } = context;
	const strings = CHART_STRINGS[locale];
	return {
		pages: () => tableIndexOf(model, locale).pages,
		caption: () => captionText(context, tableIndexOf(model, locale).slots),
		xHeader: () => xHeaderText(context),
		heads: () => [...model.series.map(({ key }) => seriesHeader(context, key)), ...model.stacks.map(({ id }) => {
			const text = model.stacks.length > 1 ? `${strings.total} ${id}` : strings.total;
			return {
				text,
				spoken: text
			};
		})],
		rows: (page) => {
			const spans = new Map(model.series.flatMap(({ key, coarse }) => coarse === void 0 ? [] : [[key, rowSpans(page.slots, coarse)]]));
			return page.slots.map((slot, row) => ({
				key: keys[slot] ?? slot,
				slot,
				head: slotLabel(context, slot),
				cells: [...model.series.map(({ key }) => seriesCell(context, key, slot, spans.get(key)?.[row] ?? 1)), ...model.stacks.map(({ id, keys: parts }) => totalCell(context, id, parts, slot))]
			}));
		},
		cell: (slot, column) => {
			const index = model.rowAt[slot];
			return index === void 0 ? void 0 : context.rows[index]?.[column];
		},
		hasColumn: (column) => context.rows.some((entry) => Object.hasOwn(entry, column)),
		timeZone: model.domain.kind === "time" ? model.domain.timeZone : "UTC"
	};
}
/**
* The readout over a series model, which every family that builds a `CartesianModel` shares: an
* index is a slot, the legend lists every config key, a threshold series listing both sides, and the
* tooltip rows list every series at the active slot.
*
* @param context - The family's series model and words.
* @param host - The Root's identity, store, calls and pick.
* @param options - The readout's options.
* @param options.look - The look a key's marks draw in, which its swatch wears. None by default.
* @param options.known - The config a part's dataKey must name, the context's own by default. A
*   radar past its series cap draws a capped config, and a part may still name a key it leaves out,
*   which answers its label, icon and paint from this config at no index, and reads unselectable.
* @returns The readout.
*/
function seriesReadoutOf(context, host, { look = () => void 0, known = context.config } = {}) {
	const { model, config } = context;
	const legendKeys = Object.keys(config);
	const seriesKeys = model.series.map(({ key }) => key);
	const items = /* @__PURE__ */ new Map();
	const item = (key) => {
		const kept = items.get(key);
		if (kept !== void 0) return kept;
		const entry = known[key];
		if (entry === void 0) return void 0;
		const drawn = Object.hasOwn(config, key);
		const color = entry.color;
		const made = {
			index: drawn ? seriesOf(model, key)?.seriesIndex ?? legendKeys.indexOf(key) : void 0,
			label: seriesLabel({ config: known }, key),
			icon: entry.icon,
			selectable: drawn,
			sides: isThresholdColor(color) ? [color.above, color.below] : null
		};
		items.set(key, made);
		return made;
	};
	return {
		...host,
		locale: context.locale,
		window: model.window,
		empty: model.empty,
		legendKeys,
		toggleGroupName: CHART_STRINGS[context.locale].seriesGroup,
		item,
		assertKey: (part, key) => {
			assertKnownKey(part, known, key);
		},
		pointKey: (_active, near) => near === null ? null : model.series[near]?.key ?? null,
		itemsFollowActive: false,
		tooltipKeys: () => seriesKeys,
		activeLabel: (active, format) => slotLabel(context, active, format).text,
		valueText: (key, at, format) => readingText(context, key, at, format),
		share: (key, at, digits) => slotShares(context, at, digits).get(key) ?? null,
		legendAt: (key, active, fallback) => active ?? fallbackSlot(context, key, fallback),
		legendShare: (key, digits) => windowShares(context, digits).get(key) ?? null,
		swatch: (key, at) => {
			const paint = seriesPaintOf(key, known[key]?.color ?? "chart-1", seriesOf(model, key));
			const step = at === null ? void 0 : readingPaint(paint, readingAt(context, key, at));
			return {
				paint: swatchPaint(paint, step),
				look: look(key)
			};
		},
		point: (active, near) => {
			const values = {};
			const quality = {};
			for (const series of model.series) {
				const reading = series.readings[active];
				values[series.key] = reading?.kind === "reading" ? reading.value : null;
				if (reading?.kind === "reading") quality[series.key] = reading.quality;
				else if (reading?.kind === "missing") quality[series.key] = "missing";
			}
			return {
				index: active,
				x: slotX(model.domain, active),
				label: slotLabel(context, active),
				key: near === null ? null : model.series[near]?.key ?? null,
				values,
				quality
			};
		}
	};
}
export { fallbackSlot, readingAt, seriesReadoutOf, seriesTable, stackTotal };

//# sourceMappingURL=chart-series-readout.js.map