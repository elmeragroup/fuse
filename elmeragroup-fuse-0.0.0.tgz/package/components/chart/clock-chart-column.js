"use client";
import { m4Indexes } from "./layout/decimate.js";
import { useSvgIdPrefix, writeAttribute } from "./chart-dom.js";
import { useStackSeat } from "./chart-stack-floors.js";
import { BAR_GLOW, valueGlow } from "./chart-glow-filter.js";
import { viewBoxOf } from "./layout/polar-angle.js";
import { columnAxis, columnFloorSpan, columnSpan, wedgePad } from "./layout/clock.js";
import { clockWedges, entranceFrame, slotAt } from "./layout/clock-path.js";
import { PolarHatch } from "./chart-polar-hatch.js";
import { usePolarCommit, usePolarMark } from "./chart-polar-motion.js";
import { DIAL_REGION, assertClockBaseline, clockDatumSlots, groupOf, paintOf, retuneGlow, useClockPlacement, useClockSeries, writeReveal } from "./clock-chart-part.js";
import { useLayoutEffect, useMemo, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/clock-chart-column.tsx
/**
* The clock's Column: a series as wedges, one per slot, each painting its value's step, floored one
* device pixel along its radius, stacked through the stack floors, and past 2,000 slots
* decimated by M4 to the dial's circumference.
*/
/** The constant gap between two wedges, in CSS pixels. */
const WEDGE_GAP = 2;
/** The slots a series' columns draw at a radius: every slot, or past 2,000 M4's set at the dial's circumference. */
function shownAt(series, radius) {
	if (series.values.length <= 2e3) return series.shown;
	const known = decimations.get(series);
	const columns = Math.round(2 * Math.PI * radius);
	if (known?.columns === columns) return known.shown;
	const shown = m4Indexes(series.values, columns);
	decimations.set(series, {
		columns,
		shown
	});
	return shown;
}
/** Each series' decimated slots for the last dial width it drew at. */
const decimations = /* @__PURE__ */ new WeakMap();
/**
* A series' wedges in a frame, by group, at a measured dial: each wedge's pad and its floor along its
* radius, unless `keeps` says its stack's floor lies on another segment.
*/
function wedgeGroups(series, clock, values, measure, emphasised, keeps) {
	const radius = measure.scale > 0 ? measure.scale : 100;
	const { dpr } = measure;
	const axis = columnAxis(radius, dpr);
	const pad = wedgePad(clock.count, radius, WEDGE_GAP, dpr);
	const padded = {
		padAngle: pad.padAngle,
		padRadius: pad.padRadius / radius,
		devicePixels: radius * dpr
	};
	const span = (slot, base, tip) => {
		if (keeps === null || keeps.get(slot) === true) {
			const [from, to] = columnSpan(axis, base * radius, tip * radius);
			return [from / radius, to / radius];
		}
		const snap = (edge) => Math.round(edge * radius * dpr) / dpr / radius;
		return [snap(Math.min(base, tip)), snap(Math.max(base, tip))];
	};
	const shown = shownAt(series, radius);
	const groups = clockWedges(values, series.slots, shown, padded, span, (slot) => `${groupOf(series, clock, slot)}${series.slots.marked[slot] === true ? "-marked" : ""}`);
	const emphasis = clockWedges(values, series.slots, shown.filter((slot) => emphasised.has(slot)), padded, span, () => "emphasis");
	const all = new Map(groups);
	all.set("emphasis", emphasis.get("emphasis") ?? "");
	return all;
}
/** Draw a column's frame: every wedge with its pad and its floor, and its stack's floors settled. */
function drawColumns(group, look, values) {
	if (look === null) return;
	look.drawn.current = values;
	const frame = entranceFrame(values);
	const { series, clock, seat, emphasised } = look;
	const measure = look.measure.current;
	const write = (keeps) => {
		const groups = wedgeGroups(series, clock, frame.values, measure, emphasised, keeps);
		for (const path of group.querySelectorAll("path[data-group]")) writeAttribute(path, "d", groups.get(path.getAttribute("data-group") ?? "") ?? "");
		writeReveal(group, frame.reveal);
	};
	if (seat === null) {
		write(null);
		return;
	}
	const radius = measure.scale > 0 ? measure.scale : 100;
	const axis = columnAxis(radius, measure.dpr);
	const spans = shownAt(series, radius).flatMap((slot) => {
		if (series.slots.states[slot] !== "reading") return [];
		const [, , base, tip] = slotAt(frame.values, slot);
		return [columnFloorSpan(axis, slot, series.key, base * radius, tip * radius)];
	});
	seat.floors.draw(seat.mark, seat.stack, spans, axis, (kept) => {
		write(new Map(spans.map((span, index) => [span.from, kept[index] === 1])));
	});
}
/**
* One series as a column of wedges, one per slot, each with the slot's whole angle less a pad that
* keeps every gap one width from hole to rim. A negative wedge hangs inward from the zero ring.
* Each wedge paints its own value's step of a threshold or a scale, keeps one device pixel along its
* radius away from zero, and stacks through config `stack`. The wedges draw as one path per
* paint group at any slot count, and past 2,000 slots they decimate by M4 to the dial's
* circumference.
*
* @beta
*/
function ClockChartColumn({ dataKey, emphasis, emphasisLabel, className, style }) {
	const { polar, clock, series } = useClockSeries("ClockChart.Column", dataKey);
	assertClockBaseline(clock, "ClockChart.Column", "a wedge");
	const { kernel } = polar;
	const seat = useStackSeat(polar.motion, series?.stack, dataKey);
	const picked = useMemo(() => series === void 0 || emphasis === void 0 ? [] : clockDatumSlots(clock, "ClockChart.Column", series, emphasis), [
		clock,
		series,
		emphasis
	]);
	const emphasised = useMemo(() => new Set(picked), [picked]);
	useLayoutEffect(() => {
		if (picked.length === 0) return void 0;
		const { store } = kernel;
		store.set({ emphasis: {
			...store.get().emphasis,
			[dataKey]: {
				slots: picked,
				label: emphasisLabel
			}
		} });
		return () => {
			store.set({ emphasis: Object.fromEntries(Object.entries(store.get().emphasis).filter(([name]) => name !== dataKey)) });
		};
	}, [
		kernel,
		dataKey,
		picked,
		emphasisLabel
	]);
	const measure = useRef({
		scale: 0,
		dpr: 1
	});
	const drawn = useRef(null);
	const look = useMemo(() => series === void 0 ? null : {
		series,
		clock,
		measure,
		seat,
		emphasised,
		drawn
	}, [
		series,
		clock,
		seat,
		emphasised,
		drawn
	]);
	const { ref, place, node: anchor, drawn: drawnFrame } = usePolarMark(polar.motion, drawColumns, look);
	const commit = usePolarCommit(polar, anchor);
	useClockPlacement(clock, series, look, {
		commit,
		place,
		drawn: drawnFrame
	});
	const svg = useRef(null);
	const group = useRef(null);
	useLayoutEffect(() => {
		const node = svg.current;
		if (node === null) return void 0;
		const read = () => {
			const width = polar.box.right - polar.box.left;
			measure.current = {
				scale: width > 0 ? node.getBoundingClientRect().width / width : 0,
				dpr: window.devicePixelRatio || 1
			};
			retuneGlow(node, measure.current.scale, BAR_GLOW);
			const values = drawn.current;
			if (group.current !== null && values !== null) drawColumns(group.current, look, values);
		};
		read();
		const observer = new ResizeObserver(read);
		observer.observe(node);
		return () => {
			observer.disconnect();
		};
	}, [
		polar.box,
		look,
		drawn
	]);
	const prefix = useSvgIdPrefix("clock-chart-column");
	const paint = series === void 0 ? null : paintOf(clock, series);
	const glow = paint === null ? null : valueGlow(paint, prefix, BAR_GLOW);
	const steps = series?.steps ?? [{
		paint: series?.paint ?? "currentColor",
		from: 0
	}];
	const variant = clock.text.config[dataKey]?.barVariant === "gradient" ? "gradient" : "default";
	const [first] = useState(() => series === void 0 ? /* @__PURE__ */ new Map() : wedgeGroups(series, clock, series.rest, {
		scale: 100,
		dpr: 1
	}, emphasised, null));
	return /* @__PURE__ */ jsxs("svg", {
		ref: svg,
		"data-slot": "clock-chart-column",
		"data-variant": variant,
		"data-clock-series": "",
		"data-emphasis": picked.length > 0 ? "" : void 0,
		"data-paint": glow === null ? void 0 : "value",
		"data-polar-layer": "",
		"data-polar-mark": "",
		"aria-hidden": "true",
		focusable: "false",
		viewBox: viewBoxOf(polar.box),
		className,
		style: {
			"--chart-series": series?.index ?? 0,
			"--_base": series?.paint ?? "currentColor",
			"--_glow": glow?.url,
			...style
		},
		children: [/* @__PURE__ */ jsxs("defs", { children: [
			steps.map(({ paint: step }, index) => /* @__PURE__ */ jsx(PolarHatch, {
				id: `${prefix}-hatch-${String(index)}`,
				paint: step
			}, step)),
			glow?.filter(DIAL_REGION),
			/* @__PURE__ */ jsx("clipPath", {
				id: `${prefix}-reveal`,
				children: /* @__PURE__ */ jsx("path", {
					"data-part": "reveal",
					d: ""
				})
			}),
			/* @__PURE__ */ jsxs("mask", {
				id: `${prefix}-fade`,
				maskUnits: "userSpaceOnUse",
				x: "-1.5",
				y: "-1.5",
				width: "3",
				height: "3",
				children: [/* @__PURE__ */ jsxs("radialGradient", {
					id: `${prefix}-ramp`,
					gradientUnits: "userSpaceOnUse",
					cx: "0",
					cy: "0",
					r: "1",
					children: [
						/* @__PURE__ */ jsx("stop", {
							offset: clock.inner,
							"data-part": "far"
						}),
						/* @__PURE__ */ jsx("stop", {
							offset: Math.min(1, Math.max(clock.inner, clock.radius(0))),
							"data-part": "near"
						}),
						/* @__PURE__ */ jsx("stop", {
							offset: "1",
							"data-part": "far"
						})
					]
				}), /* @__PURE__ */ jsx("rect", {
					x: "-1.5",
					y: "-1.5",
					width: "3",
					height: "3",
					fill: `url(#${prefix}-ramp)`
				})]
			})
		] }), /* @__PURE__ */ jsxs("g", {
			ref: (element) => {
				group.current = element;
				ref(element);
			},
			"data-clip": `url(#${prefix}-reveal)`,
			children: [steps.flatMap(({ paint: step }, index) => ["", "-past"].flatMap((time) => ["", "-marked"].map((quality) => {
				const name = `step-${String(index)}${time}${quality}`;
				return /* @__PURE__ */ jsx("path", {
					"data-slot": "clock-chart-wedge",
					"data-group": name,
					"data-part": quality === "" ? void 0 : "marked",
					"data-time": time === "" ? void 0 : "past",
					d: first.get(name),
					style: {
						"--_wedge": step,
						"--_fade": `url(#${prefix}-fade)`,
						"--_hatch-paint": `url(#${prefix}-hatch-${String(index)})`
					}
				}, name);
			}))), /* @__PURE__ */ jsx("path", {
				"data-slot": "clock-chart-wedge",
				"data-group": "emphasis",
				"data-part": "emphasis",
				d: first.get("emphasis")
			})]
		})]
	});
}
Object.assign(ClockChartColumn, { displayName: "ClockChart.Column" });
export { ClockChartColumn };

//# sourceMappingURL=clock-chart-column.js.map