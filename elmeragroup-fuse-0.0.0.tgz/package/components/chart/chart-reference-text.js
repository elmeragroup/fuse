"use client";
// src/components/chart/chart-reference-text.ts
/**
* Fill `{value}` in a label, or join the label and the value, or use the dictionary's pattern.
*
* @param label - The reference's label, if it has one.
* @param value - The reference's value or range.
* @param pattern - The dictionary's sentence for a reference with no label.
* @returns The visible label's text and the sentence readers hear.
*/
function referenceSentence(label, value, pattern) {
	if (label === void 0) return {
		text: pattern(value.text),
		spoken: pattern(value.spoken)
	};
	if (label.includes("{value}")) return {
		text: label.replaceAll("{value}", value.text),
		spoken: label.replaceAll("{value}", value.spoken)
	};
	return {
		text: label,
		spoken: `${label}: ${value.spoken}`
	};
}
export { referenceSentence };

//# sourceMappingURL=chart-reference-text.js.map