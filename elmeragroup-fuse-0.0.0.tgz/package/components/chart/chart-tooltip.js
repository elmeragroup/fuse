"use client";
import { useChartRoot } from "./chart-context.js";
import { ChartTooltipTotal } from "./chart-tooltip-total.js";
import { ChartSeriesLabel, ChartSwatch } from "./chart-series.js";
import { useCartesianTooltipAnchor } from "./chart-tooltip-anchor.js";
import { ChartTooltipBody } from "./chart-tooltip-body.js";
import { ChartTooltipItems, ChartTooltipLabel, ChartTooltipShare, ChartTooltipValue } from "./chart-tooltip-parts.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-tooltip.tsx
const CARTESIAN_PLACER = { useAnchor: useCartesianTooltipAnchor };
/**
* The popup over the active slot, which a pointer can move into and pin. On a vertical chart it
* centres on the active slot, held inside the chart Root's box, and rests 8 px above the highest
* mark under its own width: bars, stack tops, line and area strokes between readings, and dots. A
* step that raises it raises it over the whole span it travels, and a step that would lower it by
* 16 px or less keeps its height. It flips below the plot when the viewport has no room above. On
* a horizontal chart it sits above or below the active row. When neither side has room, it sits
* beside the column, and when no side has room, it overlays the plot. It touches its anchor and
* stays inside the viewport, scrolling when its content is taller. A pointer, key or touch step to
* another slot glides it there over `--chart-glide` on a spring that never overshoots, unless the
* reader prefers reduced motion, and
* opening, scrolling, resizing, a data update, a change of side and a path over the marks that would
* leave the viewport move it at once. Touch passes
* through the popup to the plot, except on a popup that scrolls, where a drag scrolls it and a tap
* dismisses it. It may leave the chart. A pointer that moves straight up or down stays on the slot,
* so it reaches the popup with the content unchanged. The popup stays while the pointer is on the
* plot or inside the popup and while the option has focus. Escape closes it and keeps the reader's
* place. It is hidden from screen readers, which read the same values from the plot's option.
*
* @beta
*/
function ChartTooltip({ variant = "default", anchor = "point", children, ...props }) {
	return /* @__PURE__ */ jsx(ChartTooltipBody, {
		variant,
		placement: anchor,
		placer: CARTESIAN_PLACER,
		...props,
		children: children ?? /* @__PURE__ */ jsx(DefaultTooltip, {})
	});
}
/** The default popup content: the slot label, one row per config key and one total per stack. */
function DefaultTooltip() {
	const { model } = useChartRoot("Chart.Tooltip");
	return /* @__PURE__ */ jsxs(Fragment, { children: [
		/* @__PURE__ */ jsx(ChartTooltipLabel, {}),
		/* @__PURE__ */ jsxs(ChartTooltipItems, { children: [
			/* @__PURE__ */ jsx(ChartSwatch, {}),
			/* @__PURE__ */ jsx(ChartSeriesLabel, {}),
			/* @__PURE__ */ jsx(ChartTooltipValue, {})
		] }),
		model.stacks.map(({ id }) => /* @__PURE__ */ jsx(ChartTooltipTotal, { stack: id }, id))
	] });
}
Object.assign(ChartTooltip, { displayName: "Chart.Tooltip" });
export { ChartTooltip, ChartTooltipItems, ChartTooltipLabel, ChartTooltipShare, ChartTooltipValue };

//# sourceMappingURL=chart-tooltip.js.map