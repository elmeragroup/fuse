"use client";
import { useSvgIdPrefix } from "./chart-dom.js";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-background.tsx
/** The ring centres of the overlapping circles: the tile's middle and its four corners. */
const RINGS = [
	[8, 8],
	[0, 0],
	[16, 0],
	[0, 16],
	[16, 16]
];
/** The bubbles' centres and radii, each wholly inside the 40 px tile. */
const BUBBLES = [
	[
		9,
		10,
		3.5
	],
	[
		28,
		6,
		1.5
	],
	[
		33,
		25,
		2.5
	],
	[
		15,
		31,
		2.5
	],
	[
		23,
		17,
		1
	],
	[
		4,
		24,
		1.25
	],
	[
		37,
		37,
		1
	]
];
/**
* Each pattern's tile, in user-space pixels. Every tile paints `currentColor`, the border role, in
* strokes under a pixel wide or faint fills, so the pattern stays a texture under the marks.
*/
function PatternTile({ id, variant }) {
	switch (variant) {
		case "dots": return /* @__PURE__ */ jsx("pattern", {
			id,
			width: "16",
			height: "16",
			patternUnits: "userSpaceOnUse",
			children: /* @__PURE__ */ jsx("circle", {
				cx: "8",
				cy: "8",
				r: "0.9",
				fill: "currentColor"
			})
		});
		case "grid": return /* @__PURE__ */ jsx("pattern", {
			id,
			width: "24",
			height: "24",
			patternUnits: "userSpaceOnUse",
			children: /* @__PURE__ */ jsx("path", {
				d: "M12.25 0V24M0 12.25H24",
				fill: "none",
				stroke: "currentColor",
				strokeOpacity: "0.6",
				strokeWidth: "0.5"
			})
		});
		case "cross-hatch": return /* @__PURE__ */ jsx("pattern", {
			id,
			width: "12",
			height: "12",
			patternUnits: "userSpaceOnUse",
			patternTransform: "rotate(45)",
			children: /* @__PURE__ */ jsx("path", {
				d: "M6 0V12M0 6H12",
				fill: "none",
				stroke: "currentColor",
				strokeOpacity: "0.5",
				strokeWidth: "0.5"
			})
		});
		case "diagonal-lines": return /* @__PURE__ */ jsx("pattern", {
			id,
			width: "5",
			height: "5",
			patternUnits: "userSpaceOnUse",
			patternTransform: "rotate(45)",
			children: /* @__PURE__ */ jsx("path", {
				d: "M2.5 0V5",
				stroke: "currentColor",
				strokeOpacity: "0.5",
				strokeWidth: "0.5"
			})
		});
		case "plus": return /* @__PURE__ */ jsx("pattern", {
			id,
			width: "15",
			height: "15",
			patternUnits: "userSpaceOnUse",
			children: /* @__PURE__ */ jsx("path", {
				d: "M7.5 5V10M5 7.5H10",
				fill: "none",
				stroke: "currentColor",
				strokeOpacity: "0.8",
				strokeWidth: "0.6",
				strokeLinecap: "round"
			})
		});
		case "falling-triangles": return /* @__PURE__ */ jsx("pattern", {
			id,
			width: "16",
			height: "16",
			patternUnits: "userSpaceOnUse",
			children: /* @__PURE__ */ jsx("path", {
				d: "M2 3H7L4.5 7ZM10 11H15L12.5 15Z",
				fill: "currentColor",
				fillOpacity: "0.35"
			})
		});
		case "4-pointed-star": return /* @__PURE__ */ jsx("pattern", {
			id,
			width: "18",
			height: "18",
			patternUnits: "userSpaceOnUse",
			children: /* @__PURE__ */ jsx("polygon", {
				points: "9 5.5 9.9 8.1 12.5 9 9.9 9.9 9 12.5 8.1 9.9 5.5 9 8.1 8.1",
				fill: "currentColor",
				fillOpacity: "0.45"
			})
		});
		case "tiny-checkers": return /* @__PURE__ */ jsx("pattern", {
			id,
			width: "6",
			height: "6",
			patternUnits: "userSpaceOnUse",
			children: /* @__PURE__ */ jsx("path", {
				d: "M0 0H3V3H0ZM3 3H6V6H3Z",
				fill: "currentColor",
				fillOpacity: "0.15"
			})
		});
		case "overlapping-circles": return /* @__PURE__ */ jsx("pattern", {
			id,
			width: "16",
			height: "16",
			patternUnits: "userSpaceOnUse",
			children: RINGS.map(([cx, cy]) => /* @__PURE__ */ jsx("circle", {
				cx,
				cy,
				r: "7.5",
				fill: "none",
				stroke: "currentColor",
				strokeOpacity: "0.5",
				strokeWidth: "0.5"
			}, `${String(cx)} ${String(cy)}`))
		});
		case "wiggle-lines": return /* @__PURE__ */ jsx("pattern", {
			id,
			width: "16",
			height: "12",
			patternUnits: "userSpaceOnUse",
			children: /* @__PURE__ */ jsx("path", {
				d: "M-8 6Q-4 10 0 6T8 6T16 6T24 6",
				fill: "none",
				stroke: "currentColor",
				strokeOpacity: "0.7",
				strokeWidth: "0.6"
			})
		});
		case "bubbles": return /* @__PURE__ */ jsx("pattern", {
			id,
			width: "40",
			height: "40",
			patternUnits: "userSpaceOnUse",
			children: BUBBLES.map(([cx, cy, r]) => /* @__PURE__ */ jsx("circle", {
				cx,
				cy,
				r,
				fill: "currentColor",
				fillOpacity: "0.4"
			}, `${String(cx)} ${String(cy)}`))
		});
	}
}
/**
* A decorative pattern behind the marks, in the border role. A blurred alpha mask fades it out
* toward the plot's edges, so the pattern shows most in the plot's middle. It is plot output that
* readers skip, and it draws behind every mark wherever it sits among Root's children.
*
* @beta
*/
function ChartBackground({ variant = "dots", className, style }) {
	const id = useSvgIdPrefix("chart-bg");
	const pattern = `${id}-pattern`;
	const mask = `${id}-fade`;
	const soften = `${id}-soften`;
	return /* @__PURE__ */ jsxs("svg", {
		"data-slot": "chart-background",
		"data-variant": variant,
		"aria-hidden": "true",
		className,
		style,
		children: [/* @__PURE__ */ jsxs("defs", { children: [
			/* @__PURE__ */ jsx(PatternTile, {
				id: pattern,
				variant
			}),
			/* @__PURE__ */ jsx("filter", {
				id: soften,
				children: /* @__PURE__ */ jsx("feGaussianBlur", { stdDeviation: "25" })
			}),
			/* @__PURE__ */ jsx("mask", {
				id: mask,
				maskUnits: "userSpaceOnUse",
				"mask-type": "alpha",
				children: /* @__PURE__ */ jsx("rect", {
					x: "8%",
					y: "20%",
					width: "85%",
					height: "60%",
					fill: "currentColor",
					filter: `url(#${soften})`
				})
			})
		] }), /* @__PURE__ */ jsx("rect", {
			width: "100%",
			height: "100%",
			fill: `url(#${pattern})`,
			mask: `url(#${mask})`
		})]
	});
}
Object.assign(ChartBackground, { displayName: "Chart.Background" });
export { ChartBackground };

//# sourceMappingURL=chart-background.js.map