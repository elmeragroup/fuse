"use client";
import { writeStyle } from "./chart-dom.js";
import { CHART_SPRINGS } from "./layout/motion.js";
import { springEasing } from "./layout/spring.js";
import { sharePainted } from "./chart-polar-painted.js";
import { polarPoint } from "./layout/polar-angle.js";
import { arcPath } from "./layout/arc-path.js";
import { floorSlices } from "./layout/pie.js";
// src/components/chart/chart-pie-frame.ts
/**
* One pie's frame: the slices its loop draws, painted together. Each slice is a mark of its own on
* the loop, so it can enter on its own stagger and leave as a ghost, but the rim floor takes
* angle from the widest slice, so no one slice's writer can floor alone. While the loop writes a
* batch, such as one frame's moving slices, each slice only records its angles, and once the batch
* ends the frame floors every slice that stays, writes each path and each slice's pop, the unit
* vector along its bisector scaled to `--chart-slice-pop`, in the dial's units. A slice that draws
* outside a batch, as a commit's placements do, records too, and the frame paints in the next
* microtask, before the browser paints. A leaving slice's ghost draws as it is, with no floor, as it
* collapses to nothing. A mirror, such as `PieChart.Glow`'s halo, takes a slice's path and pop in
* every frame, so it follows the slice with no writer of its own, and a listener, such as
* `PieChart.Labels`, hears every slice's angles once each frame paints. One loop holds one pie's
* frame, which the Pie, the Glow and the Labels reach through `pieFrameOf`.
*/
/** A number for a style, kept short. */
function short(value) {
	return String(Math.round(value * 1e4) / 1e4);
}
/**
* The frame of one pie on its Root's loop.
*
* @param motion - The Root's loop.
* @param look - The pie's look as it first renders.
* @returns The frame.
*/
function createPieFrame(motion, look) {
	const entries = /* @__PURE__ */ new Map();
	const mirrors = /* @__PURE__ */ new Map();
	const tracks = /* @__PURE__ */ new Set();
	const listeners = /* @__PURE__ */ new Set();
	const painted = /* @__PURE__ */ new Map();
	sharePainted(motion, (key) => painted.get(key));
	let current = look;
	let measure = null;
	let batching = 0;
	let queued = false;
	const paint = () => {
		queued = false;
		for (const [key, entry] of entries) if (!entry.node.isConnected) entries.delete(key);
		const slices = [...entries.values()].sort((a, b) => a.order - b.order).filter((entry) => entry.kind === "slice");
		const raw = slices.map((entry) => entry.start === entry.end ? null : {
			start: entry.start,
			end: entry.end,
			pad: entry.pad
		});
		const floored = measure === null ? raw : floorSlices(raw, current.sweep, {
			radius: measure.scale,
			dpr: measure.dpr,
			seam: measure.seam
		});
		const angles = new Map(slices.map((entry, index) => [entry, floored[index] ?? null]));
		painted.clear();
		slices.forEach((entry, index) => painted.set(entry.key, floored[index] ?? null));
		const reach = measure === null || !(measure.scale > 0) ? 0 : measure.pop / measure.scale;
		for (const [key, entry] of entries) {
			const slice = entry.kind === "ghost" ? {
				start: entry.start,
				end: entry.end,
				pad: entry.pad
			} : angles.get(entry);
			const d = slice === null || slice === void 0 || slice.start === slice.end ? "" : arcPath({
				innerRadius: current.innerRadius,
				outerRadius: 1,
				startAngle: slice.start,
				endAngle: slice.end,
				padAngle: slice.pad,
				cornerRadius: current.cornerRadius
			});
			const way = slice === null || slice === void 0 ? null : polarPoint((slice.start + slice.end) / 2, reach);
			const targets = entry.kind === "ghost" ? [entry.node] : [entry.node, ...mirrors.get(key) ?? []];
			for (const node of targets) {
				node.setAttribute("d", d);
				if (entry.kind === "slice" && way !== null && node instanceof SVGElement) {
					writeStyle(node, "--_px", short(way.x));
					writeStyle(node, "--_py", short(way.y));
				}
			}
		}
		if (listeners.size === 0) return;
		const drawn = new Map(slices.map((entry, index) => [entry.key, floored[index] ?? null]));
		for (const listener of listeners) listener(drawn);
	};
	const paintTracks = () => {
		const d = arcPath({
			innerRadius: current.innerRadius,
			outerRadius: 1,
			startAngle: current.track.start,
			endAngle: current.track.end,
			cornerRadius: current.cornerRadius
		});
		for (const node of tracks) node.setAttribute("d", d);
	};
	const schedule = () => {
		if (batching > 0 || queued) return;
		queued = true;
		queueMicrotask(paint);
	};
	const party = {
		begin: () => {
			batching += 1;
		},
		end: () => {
			batching -= 1;
			if (batching === 0 && !queued) paint();
		}
	};
	return {
		record: (key, node, values, place) => {
			const [start = 0, end = start] = values;
			const known = entries.get(key);
			if (known === void 0) entries.set(key, {
				key,
				node,
				start,
				end,
				...place
			});
			else Object.assign(known, {
				node,
				start,
				end,
				...place
			});
			schedule();
		},
		last: (key) => {
			const entry = entries.get(key);
			return entry === void 0 ? null : [entry.start, entry.end];
		},
		update: (look, measured) => {
			current = look;
			measure = measured;
			paintTracks();
			schedule();
		},
		track: (node) => {
			tracks.add(node);
			paintTracks();
			return () => {
				tracks.delete(node);
			};
		},
		mirror: (key, node) => {
			const known = mirrors.get(key) ?? /* @__PURE__ */ new Set();
			known.add(node);
			mirrors.set(key, known);
			schedule();
			return () => {
				known.delete(node);
			};
		},
		listen: (listener) => {
			listeners.add(listener);
			return () => {
				listeners.delete(listener);
			};
		},
		attach: () => {
			batching = 0;
			return motion.batches(party);
		}
	};
}
const frames = /* @__PURE__ */ new WeakMap();
/**
* The pie's frame on a Root's loop, made on first use.
*
* @param motion - The Root's loop.
* @param look - The pie's look, for a frame made here.
* @returns The frame.
*/
function pieFrameOf(motion, look) {
	const known = frames.get(motion);
	if (known !== void 0) return known;
	const made = createPieFrame(motion, look);
	frames.set(motion, made);
	return made;
}
const POP = springEasing(CHART_SPRINGS.pop);
/** The pop's spring duration, which a slice's layer carries for the stylesheet's pop transition. */
const POP_DURATION = `${String(POP.duration)}ms`;
/** The pop's spring as a `linear()` easing, sampled once. */
const POP_EASING = POP.easing;
export { POP_DURATION, POP_EASING, pieFrameOf };

//# sourceMappingURL=chart-pie-frame.js.map