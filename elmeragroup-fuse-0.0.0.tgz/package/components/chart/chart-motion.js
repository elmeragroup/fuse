import { sameItems } from "./layout/same-items.js";
import { cubicBezier } from "./layout/ease.js";
import { CHART_UPDATE_CURVE } from "./layout/motion.js";
// src/components/chart/chart-motion.ts
/**
* Root's one animation loop, after `.scratch/charts-v1/reviews/motion-decision.md`. A mark hands
* its final numbers to `place` in a layout effect, before the browser paints, and the loop writes
* them to the DOM, at once or frame by frame. A tween rewinds the mark to what it last drew and walks it to
* the target in requestAnimationFrame, writing attributes straight to the DOM, so React commits
* nothing while marks move. A second update during a tween starts from the drawn numbers, so the
* mark continues without a jump.
*/
/** The scale of a commit that leaves the plot's box alone. */
const SAME_PLOT = {
	x: 1,
	y: 1
};
/**
* Make the token of one measured frame.
*
* @param frame - What draws in the frame.
* @returns A token no other frame holds.
*/
function createFrameOwner(frame) {
	return { frame };
}
/** The frame of a mark that names none, as the loop's own tests place them. */
const ANY_FRAME = createFrameOwner("loop");
/** The browser's clock and frames, which every Root's loop and a scatter Root's domain glide run on. */
const BROWSER_FRAMES = {
	now: () => performance.now(),
	requestFrame: (callback) => requestAnimationFrame(callback),
	cancelFrame: (handle) => {
		cancelAnimationFrame(handle);
	}
};
const ease = cubicBezier(CHART_UPDATE_CURVE);
/** The numbers a mark rests on once its tween ends. */
function restOf(mark) {
	return mark.tween?.rest ?? mark.tween?.to ?? mark.drawn;
}
/**
* Map a mark's numbers into a resized box. Every number is a pixel from the plot's left or top edge
* or a size, and the scales map pixels from an edge affinely, so a tween mapped this way draws in
* every frame what the old tween drew, mapped: interpolation commutes with an affine map. A mark
* with more numbers than axes repeats its declaration, as a path declares one vertex's axes for all.
*/
function rescaled(values, axes, scale) {
	const { slot } = scale;
	return values.map((value, index) => {
		const axis = axes.length === 0 ? "size" : axes[index % axes.length] ?? "size";
		if (axis === "size") return value;
		return slot?.axis === axis ? slot.to + (value - slot.from) * slot.ratio : value * scale[axis];
	});
}
/** Whether two numbers agree to within float error, as a mapped target and a fresh one do. */
function close(a, b) {
	return Math.abs(a - b) <= 1e-9 * Math.max(1, Math.abs(a), Math.abs(b));
}
/**
* A route retargeted onto a resized rest whose numbers along the slot axis moved off the route's
* mapped rest while every other number kept it, as a path form's column edges do when they round
* to a new slot grid. Each moved number's start shifts by its own correction, so the tween keeps
* its progress. Null when the route and the rest differ in length or in a number off the slot axis.
*/
function quantizedRoute(tween, axes, target, slot) {
	const { rest } = tween;
	if (slot === void 0 || rest?.length !== target.length || tween.to.length !== target.length) return null;
	const axisAt = (index) => axes.length === 0 ? "size" : axes[index % axes.length] ?? "size";
	if (!target.every((to, index) => axisAt(index) === slot || close(to, rest[index] ?? 0))) return null;
	const from = tween.from.map((value, index) => axisAt(index) === slot ? value + (target[index] ?? 0) - (tween.to[index] ?? 0) : value);
	return {
		...tween,
		from,
		to: target,
		rest: target
	};
}
/**
* The start a tween needs to reach a new target on its own clock, passing through what it drew at
* the eased progress it drew it at: `drawn = from + (to - from) * eased`, solved for `from`. The
* tween, which a resize has already mapped into the commit's box, keeps every number whose target
* is its mapped target, so marks with equal numbers keep drawing equal numbers. A number the tween
* wasn't moving starts at a new target of its own, as a mark at rest snaps there.
*/
function retargeted(tween, drawn, target, eased) {
	return target.map((to, index) => {
		const start = tween.from[index] ?? to;
		const end = tween.to[index] ?? to;
		if (close(to, end)) return start;
		if (start === end) return to;
		return ((drawn[index] ?? to) - to * eased) / (1 - eased);
	});
}
/**
* Create a Root's animation loop. The marks move as one group. Every mark a commit places starts
* on one clock, a data update restarts every running tween together from what it drew, and a
* resize retargets running tweens on the clock they share, so marks with equal numbers, such as a
* bar's top and a guide at its value, draw equal numbers in every frame.
*
* @param host - The clock and the frame scheduler.
* @param reducedAtStart - Whether the reader asked for reduced motion when Root mounted.
* @param rejoin - Called when a mark leaves while a follower draws from it, so each follower joins
*   what still draws its series, as Root repaints its followers.
* @returns The loop.
*/
function createChartMotion(host, reducedAtStart = false, rejoin = () => void 0) {
	const marks = /* @__PURE__ */ new Map();
	const parties = /* @__PURE__ */ new Set();
	const batch = (writes) => {
		for (const party of parties) party.begin();
		try {
			return writes();
		} finally {
			for (const party of parties) party.end();
		}
	};
	const moving = /* @__PURE__ */ new Set();
	const following = /* @__PURE__ */ new Set();
	/** Hold a mark under its id, in place of the one it replaces. */
	const hold = (id, mark) => {
		const old = marks.get(id);
		if (old !== void 0) {
			moving.delete(old);
			following.delete(old);
		}
		marks.set(id, mark);
		if (mark.tween !== null) moving.add(mark);
		if (mark.joined) following.add(mark);
	};
	const anchors = /* @__PURE__ */ new Map();
	let revision = 0;
	/** Forget the anchor a mark names, unless another mark has named it since. */
	const leave = (id, anchor) => {
		if (anchor !== void 0 && anchors.get(anchor) === id) anchors.delete(anchor);
	};
	let handle = null;
	let reduced = reducedAtStart;
	let held = false;
	let commitTime = null;
	let restartedAt = null;
	const rescaledFor = /* @__PURE__ */ new WeakMap();
	const startTime = () => {
		if (commitTime === null) {
			commitTime = host.now();
			queueMicrotask(() => {
				commitTime = null;
			});
		}
		return commitTime;
	};
	/**
	* Write a joined follower from what its leads drew, a resting lead's rest where it reads one, and
	* its own rest once no lead moves or a lead left.
	*/
	const project = (mark) => {
		const { joined } = mark;
		if (joined === null || joined === void 0) return;
		const sources = joined.leads.map(({ id }) => marks.get(id));
		if (!sources.some((source) => source !== void 0 && source.tween !== null) || sources.includes(void 0)) {
			mark.joined = null;
			following.delete(mark);
			mark.drawn = joined.resting;
		} else {
			const read = (lead, source) => {
				const values = source?.drawn ?? [];
				return source?.tween === null && lead.rest !== void 0 ? lead.rest(values) : lead.pick(values);
			};
			const [only] = joined.leads;
			if (joined.leads.length === 1 && only !== void 0 && !("clock" in only.lead)) mark.drawn = read(only.lead, sources[0]);
			else {
				const drawn = [];
				joined.leads.forEach(({ lead, own }, index) => {
					const source = sources[index];
					if ("clock" in lead) {
						const eased = source?.tween === null ? 1 : source?.eased ?? 1;
						own.to.forEach((to, at) => {
							const from = own.from[at] ?? to;
							drawn.push(from + (to - from) * eased);
						});
						return;
					}
					for (const value of read(lead, source)) drawn.push(value);
				});
				mark.drawn = drawn;
			}
		}
		mark.write(mark.drawn);
	};
	/** Whether a joined follower draws from the mark at an anchor. */
	const followed = (anchor) => {
		for (const mark of following) if (mark.joined?.leads.some(({ lead }) => lead.anchor === anchor) === true) return true;
		return false;
	};
	/** Write every joined follower after the marks it follows moved. */
	const projectAll = () => {
		for (const mark of following) project(mark);
	};
	const step = (time) => {
		handle = null;
		commitTime = null;
		const running = batch(() => {
			let moved = false;
			for (const mark of moving) {
				let tween = mark.tween;
				if (tween === null) {
					moving.delete(mark);
					continue;
				}
				if (tween.start === Number.POSITIVE_INFINITY) mark.tween = tween = {
					...tween,
					start: time
				};
				const progress = Math.min(1, Math.max(0, (time - tween.start - tween.delay) / (tween.duration ?? 480)));
				mark.eased = progress >= 1 ? 1 : tween.curve === "linear" ? progress : ease(progress);
				if (progress >= 1) mark.drawn = tween.rest ?? tween.to;
				else {
					mark.frames ??= [[], []];
					const at = mark.next ?? 0;
					const frame = mark.frames[at];
					mark.next = at === 0 ? 1 : 0;
					frame.length = tween.to.length;
					tween.to.forEach((to, index) => {
						const from = tween.from[index] ?? to;
						frame[index] = from + (to - from) * mark.eased;
					});
					mark.drawn = frame;
				}
				mark.write(mark.drawn);
				if (progress < 1) moved = true;
				else {
					mark.tween = null;
					moving.delete(mark);
				}
			}
			return moved;
		});
		projectAll();
		if (running) handle = host.requestFrame(step);
	};
	/** Draw a mark at its target at once. */
	const snap = (id, target, write, axes, owner) => {
		hold(id, {
			drawn: target,
			eased: 1,
			write,
			tween: null,
			axes,
			owner
		});
		write(target);
	};
	/** Start a tween and draw its first numbers before the browser paints. */
	const run = (id, write, tween, axes, owner) => {
		hold(id, {
			drawn: tween.from,
			eased: 0,
			write,
			tween,
			axes,
			owner
		});
		write(tween.from);
		if (!held) handle ??= host.requestFrame(step);
	};
	/** Place a mark: the body of `place`, once the mark's anchor names it. */
	const placeMark = (id, target, write, placement, info) => {
		const { axes = [], owner = ANY_FRAME } = info;
		if (placement.kind === "join") {
			const leads = placement.leads.map((lead) => {
				const leadId = anchors.get(lead.anchor) ?? "";
				return {
					lead,
					id: leadId,
					mark: marks.get(leadId)
				};
			});
			const found = leads.flatMap(({ lead, id, mark }) => mark === void 0 ? [] : [{
				lead,
				id,
				mark
			}]);
			if (found.length < leads.length) {
				snap(id, target, write, axes, owner);
				return;
			}
			const moves = !reduced && found.some(({ mark }) => mark.tween !== null);
			const previous = marks.get(id)?.drawn ?? null;
			const resting = [];
			const parts = [];
			let offset = 0;
			for (const { lead, id: leadId, mark } of found) {
				const end = offset + ("clock" in lead ? lead.clock : lead.size);
				const source = restOf(mark);
				const rest = "clock" in lead ? void 0 : lead.rest?.(source);
				if (rest === void 0) for (let at = offset; at < Math.min(end, target.length); at += 1) resting.push(target[at] ?? 0);
				else for (const value of rest) resting.push(value);
				if (moves) {
					const to = target.slice(offset, end);
					const from = previous?.length === target.length ? previous.slice(offset, end) : to;
					parts.push({
						lead,
						id: leadId,
						own: {
							from,
							to
						}
					});
				}
				offset = end;
			}
			if (!moves) {
				snap(id, resting, write, axes, owner);
				return;
			}
			const follower = {
				drawn: resting,
				eased: 0,
				write,
				tween: null,
				axes,
				owner,
				joined: {
					leads: parts,
					resting
				}
			};
			hold(id, follower);
			project(follower);
			return;
		}
		if (reduced || placement.kind === "snap" || held && placement.kind !== "enter") {
			snap(id, target, write, axes, owner);
			return;
		}
		if (placement.kind === "settle" && (placement.scale.x !== 1 || placement.scale.y !== 1 || placement.scale.slot !== void 0)) {
			const resize = placement.scale.to ?? startTime();
			if (rescaledFor.get(owner) !== resize) {
				rescaledFor.set(owner, resize);
				batch(() => {
					for (const running of moving) {
						if (running.tween === null || running.owner !== owner) continue;
						const { axes: kinds, tween } = running;
						const { scale } = placement;
						const from = rescaled(tween.from, kinds, scale);
						const to = rescaled(tween.to, kinds, scale);
						running.tween = tween.rest === void 0 ? {
							...tween,
							from,
							to
						} : {
							...tween,
							from,
							to,
							rest: rescaled(tween.rest, kinds, scale)
						};
						running.drawn = rescaled(running.drawn, kinds, scale);
						running.write(running.drawn);
					}
				});
				projectAll();
			}
		}
		if (placement.kind === "move") {
			const start = startTime();
			if (restartedAt !== start) {
				restartedAt = start;
				for (const mark of moving) {
					if (mark.tween === null) continue;
					const { duration: _entrance, ...restarted } = mark.tween;
					mark.tween = {
						...restarted,
						from: [...mark.drawn],
						start,
						delay: 0
					};
					mark.eased = 0;
				}
			}
		}
		const mark = marks.get(id);
		const tween = mark?.tween ?? null;
		if (placement.kind === "move" && placement.via !== void 0) {
			const { from, to } = placement.via;
			if (from.length !== to.length || sameItems(from, to)) {
				snap(id, target, write, axes, owner);
				return;
			}
			run(id, write, {
				from,
				to,
				rest: target,
				start: startTime(),
				delay: 0
			}, axes, owner);
			return;
		}
		if (placement.kind === "settle" && mark !== void 0 && tween?.rest !== void 0) {
			const { rest } = tween;
			if (rest.length === target.length && target.every((to, index) => close(to, rest[index] ?? 0))) {
				mark.write = write;
				write(mark.drawn);
				return;
			}
			const moved = quantizedRoute(tween, mark.axes, target, placement.scale.slot?.axis);
			if (moved !== null) {
				mark.tween = moved;
				mark.drawn = moved.to.map((to, index) => (moved.from[index] ?? to) + (to - (moved.from[index] ?? to)) * mark.eased);
				mark.write = write;
				write(mark.drawn);
				return;
			}
			snap(id, target, write, axes, owner);
			return;
		}
		if (mark !== void 0 && tween !== null && sameItems(tween.to, target)) {
			mark.write = write;
			write(mark.drawn);
			return;
		}
		if (placement.kind === "enter") {
			const entering = {
				from: placement.from,
				to: target,
				start: held ? Number.POSITIVE_INFINITY : startTime(),
				delay: placement.delay
			};
			const timed = placement.duration === void 0 ? entering : {
				...entering,
				duration: placement.duration
			};
			const tween = placement.curve === void 0 ? timed : {
				...timed,
				curve: placement.curve
			};
			run(id, write, tween, axes, owner);
			return;
		}
		if (mark === void 0 || mark.drawn.length !== target.length || sameItems(mark.drawn, target)) {
			snap(id, target, write, axes, owner);
			return;
		}
		if (placement.kind === "move") {
			run(id, write, {
				from: mark.drawn,
				to: target,
				start: startTime(),
				delay: 0
			}, axes, owner);
			return;
		}
		if (tween === null || 1 - mark.eased < 1e-6) {
			snap(id, target, write, axes, owner);
			return;
		}
		const from = retargeted(tween, mark.drawn, target, mark.eased);
		mark.axes = axes;
		mark.tween = {
			...tween,
			from,
			to: target
		};
		mark.drawn = target.map((to, index) => (from[index] ?? to) + (to - (from[index] ?? to)) * mark.eased);
		mark.write = write;
		write(mark.drawn);
	};
	return {
		place(id, target, write, placement, info = {}) {
			const { anchor } = info;
			const before = marks.get(id);
			const named = before?.anchor;
			const rested = before === void 0 ? void 0 : restOf(before);
			if (named !== anchor) leave(id, named);
			if (anchor !== void 0) anchors.set(anchor, id);
			placeMark(id, target, write, placement, info);
			const mark = marks.get(id);
			if (mark !== void 0) mark.anchor = anchor;
			if ((named ?? anchor) === void 0) return;
			const rests = mark === void 0 ? void 0 : restOf(mark);
			if (named !== anchor || !sameItems(rested, rests)) revision += 1;
		},
		forget(id) {
			const mark = marks.get(id);
			if (mark !== void 0) {
				moving.delete(mark);
				following.delete(mark);
			}
			marks.delete(id);
			const anchor = mark?.anchor;
			if (anchor !== void 0) revision += 1;
			const led = anchor !== void 0 && anchors.get(anchor) === id && followed(anchor);
			leave(id, anchor);
			if (handle !== null && moving.size === 0) {
				host.cancelFrame(handle);
				handle = null;
			}
			if (led) rejoin();
		},
		drawn: (id) => marks.get(id)?.drawn ?? null,
		restAt: (anchor) => {
			const mark = marks.get(anchors.get(anchor) ?? "");
			return mark === void 0 ? null : restOf(mark);
		},
		restRevision: () => revision,
		finish() {
			batch(() => {
				for (const mark of moving) {
					if (mark.tween === null) continue;
					mark.drawn = mark.tween.rest ?? mark.tween.to;
					mark.eased = 1;
					mark.tween = null;
					mark.write(mark.drawn);
				}
			});
			moving.clear();
			projectAll();
			if (handle !== null) host.cancelFrame(handle);
			handle = null;
		},
		setReduced(value) {
			reduced = value;
			if (value) this.finish();
		},
		reduced: () => reduced,
		snaps: () => reduced || held,
		wait() {
			held = true;
		},
		play() {
			held = false;
			if (moving.size > 0) handle ??= host.requestFrame(step);
		},
		size: () => marks.size,
		running: () => !held && moving.size > 0,
		batch,
		batches(party) {
			parties.add(party);
			return () => {
				parties.delete(party);
			};
		},
		eachLanding(visit) {
			for (const { tween, write, drawn, axes } of moving) if (tween !== null) visit(write, tween.rest ?? tween.to, drawn, axes, tween.to);
			for (const { joined, write, drawn } of following) if (joined) visit(write, joined.resting, drawn, [], joined.resting);
		}
	};
}
export { BROWSER_FRAMES, SAME_PLOT, createChartMotion, createFrameOwner };

//# sourceMappingURL=chart-motion.js.map