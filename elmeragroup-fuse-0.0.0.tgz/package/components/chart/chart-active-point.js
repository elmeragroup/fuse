"use client";
import { ChartHeldPointContext, ChartLiveContext } from "./chart-scope-contexts.js";
import { useChartStore } from "./chart-store.js";
import { use } from "react";
// src/components/chart/chart-active-point.ts
/**
* The active point every readout part reads: the one owner of the live scope, the store
* subscription, the window rule and the point a closing tooltip holds. A point is an index and the
* series nearest the pointer or focused there, and a closing tooltip holds both together, so its
* content keeps the slot and the series it showed until the popup has closed. The module reads only
* the scope contexts and the store, so the light model paths that import it ship no readout code.
*/
/** The index when it lies inside the window, else null. */
function inWindow(index, window) {
	return index !== null && window !== null && index >= window.first && index <= window.last ? index : null;
}
/** A part's `Following`, from its own `live` or its scope. */
function useFollow(live) {
	const scoped = use(ChartLiveContext);
	const held = use(ChartHeldPointContext);
	const follow = live ?? scoped;
	return {
		follow,
		held: follow ? held : null
	};
}
/**
* The active index inside the window, or null, for a part that prints no series key. It never
* renders when the pointer moves between series inside one slot. Outside a live scope it reads null
* and never renders on a pointer move. Inside a closing tooltip it reads the index the popup held.
*
* @param source - The Root's store and window.
* @param live - Whether to follow the store, which forces it on for parts such as LegendValue.
* @returns The active index.
*/
function useActiveIndex(source, live) {
	const { follow, held } = useFollow(live);
	return inWindow(useChartStore(source.store, (snapshot) => follow ? snapshot.active : null) ?? held?.index ?? null, source.window);
}
/**
* The active index inside the window and its near or focused series, for a part that prints the
* active point's key. Outside a live scope both read null. Inside a closing tooltip both read the
* point the popup held, together.
*
* @param source - The Root's store and window.
* @param live - Whether to follow the store.
* @returns The active point.
*/
function useActivePoint(source, live) {
	const { follow, held } = useFollow(live);
	const active = useChartStore(source.store, (snapshot) => follow ? snapshot.active : null);
	const near = useChartStore(source.store, (snapshot) => follow ? snapshot.near : null);
	if (active === null && held !== null) return {
		index: inWindow(held.index, source.window),
		near: held.near
	};
	return {
		index: inWindow(active, source.window),
		near
	};
}
export { useActiveIndex, useActivePoint };

//# sourceMappingURL=chart-active-point.js.map