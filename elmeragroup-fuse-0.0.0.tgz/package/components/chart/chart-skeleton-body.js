"use client";
import { useLocale } from "../../intl/locale-context.js";
import { CHART_STRINGS } from "./format/chart-strings.js";
import { Loader } from "../loader/loader.js";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-skeleton-body.tsx
/**
* A loading placeholder that renders in place of a Root. Its shapes are Fuse Skeleton shapes that
* readers skip, and one Fuse Loader names the wait. It renders outside any Root, so it reads the
* locale from the nearest LocaleProvider.
*
* @param props - The part's props, its variant, its label and its shapes.
* @returns The placeholder.
*/
function ChartSkeletonBody({ variant, label, marks, className, style, ...props }) {
	const { locale } = useLocale();
	return /* @__PURE__ */ jsxs("div", {
		"data-slot": "chart-skeleton",
		"data-variant": variant,
		className,
		style,
		...props,
		children: [marks, /* @__PURE__ */ jsx(Loader, { "aria-label": label ?? CHART_STRINGS[locale].loading })]
	});
}
Object.assign(ChartSkeletonBody, { displayName: "Chart.SkeletonBody" });
export { ChartSkeletonBody };

//# sourceMappingURL=chart-skeleton-body.js.map