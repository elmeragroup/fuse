"use client";
import { isThemeDevelopment } from "../../theme/validate-theme.js";
import { usePhase } from "./chart-store.js";
import { ChartCompositionError, assertKnownKey } from "./layout/errors.js";
import { sameItems } from "./layout/same-items.js";
import { WHOLE_BAND } from "./layout/plot-frame.js";
import { barForm, drawnBarVariant } from "./layout/bar-geometry.js";
import { assertLayoutKey, useChartRoot, usePlotLayout, useSeriesPart } from "./chart-context.js";
import { useSvgIdPrefix } from "./chart-dom.js";
import { seriesPaintOf } from "./chart-paint.js";
import { useBarMetrics, useChartFrame } from "./chart-plot.js";
import { seriesOf } from "./layout/series-of.js";
import { sameShallow, useSteady } from "./chart-steady.js";
import { useSeriesOwner } from "./chart-series-path.js";
import { SeriesPaths } from "./chart-bar-paths.js";
import { ActiveBar, SeriesBars } from "./chart-bar-series.js";
import { datumSlots } from "./chart-datum.js";
import { BAR_GLOW, plotGlowRegion, valueGlow } from "./chart-glow-filter.js";
import { createContext, use, useLayoutEffect, useMemo, useRef } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-bar.tsx
const ChartBarGroupContext = createContext(null);
/** The value a Bar draws at each slot, the stack total for a stacked key. */
function drawnValues(context, series) {
	const keys = context.model.stacks.find(({ id }) => id === series.stack)?.keys ?? [series.key];
	const members = context.model.series.filter(({ key }) => keys.includes(key));
	return series.readings.map((reading, slot) => {
		if (reading.kind !== "reading") return null;
		let total = 0;
		for (const member of members) {
			const other = member.readings[slot];
			if (other?.kind === "reading") total += other.value;
		}
		return total;
	});
}
/** The slots a Bar's `emphasis` selects, compared on the values it draws. */
function emphasisSlots(context, series, emphasis) {
	if (emphasis === void 0 || series === void 0) return [];
	return datumSlots(context, "Chart.Bar", series, emphasis, drawnValues(context, series));
}
/**
* One series' bars. Outside a BarGroup each bar fills its band, and series that share a `stack` id
* stack in it. Inside a BarGroup the bar takes its series' sub-band. Up to 100 domain slots each
* bar is its own SVG element that moves to its new geometry on a data update. Above 100 the series
* draws one SVG path per colour step, which snaps to new data until the path tween lands. A chart
* draws each series with one Bar, and a second Bar on the same `dataKey` throws
* `series-drawn-twice` once it mounts, in either form.
*
* @beta
*/
function ChartBar({ dataKey, emphasis, emphasisLabel, className, style }) {
	const { context, layout } = useSeriesPart("Chart.Bar", dataKey);
	useSeriesOwner(context.paths, "Chart.Bar", "columns", dataKey);
	const group = use(ChartBarGroupContext);
	if (layout.baseline === "none") throw new ChartCompositionError("Chart.Bar", "baseline-required", "draws in a layout with yBaseline=\"none\", but a bar encodes length from 0. Keep the zero baseline, or draw a Chart.Line.");
	if (context.xScale === "point") throw new ChartCompositionError("Chart.Bar", "bar-needs-band", "draws under xScale=\"point\", where slots have no width. Use the default xScale=\"band\".");
	if (group !== null && !group.index.has(dataKey)) throw new ChartCompositionError("Chart.Bar", "bar-not-in-group", `draws ${JSON.stringify(dataKey)} inside a Chart.BarGroup whose series do not list it. Add the key to the group's series, or move the Bar out of the group.`);
	const { model, registerBar, registerEmphasis } = context;
	const series = seriesOf(model, dataKey);
	const config = context.config[dataKey];
	const form = barForm(model, context.orientation);
	const grouped = group !== null;
	const phase = usePhase(context.store);
	const drawn = useChartFrame("Chart.Bar", layout);
	const prefix = useSvgIdPrefix("chart-bar");
	const picked = useSteady(emphasisSlots(context, series, emphasis), sameItems);
	const emphasised = useMemo(() => new Set(picked), [picked]);
	useLayoutEffect(() => registerEmphasis(dataKey, {
		slots: [...emphasised],
		label: emphasisLabel
	}), [
		registerEmphasis,
		dataKey,
		emphasised,
		emphasisLabel
	]);
	const variant = config?.barVariant ?? "default";
	const drawnVariant = drawnBarVariant(variant, form);
	useLayoutEffect(() => registerBar(dataKey, grouped, layout.owner), [
		registerBar,
		dataKey,
		grouped,
		layout.owner
	]);
	if (drawnVariant !== variant && isThemeDevelopment()) context.warnOnce("bar-variant-needs-html", dataKey, `Chart.Bar draws ${JSON.stringify(dataKey)} as one path above 100 slots, where its config's barVariant: "${variant}" has no path look, so it draws the default look. Narrow the period to 100 slots or fewer, or pick another barVariant.`);
	const color = config?.color ?? "chart-1";
	const paint = useMemo(() => seriesPaintOf(dataKey, color, series), [
		dataKey,
		color,
		series
	]);
	const { base, stops } = paint;
	const subIndex = group?.index.get(dataKey) ?? 0;
	const subCount = group?.count ?? 1;
	const sub = useMemo(() => grouped ? {
		index: subIndex,
		count: subCount
	} : WHOLE_BAND, [
		grouped,
		subIndex,
		subCount
	]);
	const seriesIndex = series?.seriesIndex ?? 0;
	const element = useRef(null);
	const steadyStyle = useSteady(style, sameShallow);
	const own = useBarMetrics(grouped ? null : element, [className, steadyStyle]);
	const metrics = group === null ? own : group.metrics;
	const ready = drawn === null || metrics === null || series === void 0 ? null : {
		drawn,
		metrics,
		series
	};
	const shared = ready === null ? null : {
		context,
		series: ready.series,
		frame: ready.drawn.frame,
		plot: ready.drawn.plot,
		metrics: ready.metrics,
		sub,
		paint,
		prefix,
		phase
	};
	const entering = context.entrance && phase === "waiting";
	const glow = valueGlow(paint, prefix, BAR_GLOW);
	return /* @__PURE__ */ jsxs("div", {
		ref: element,
		"data-slot": "chart-bar-series",
		"data-orientation": context.orientation,
		"data-variant": drawnVariant,
		"data-list": stops === void 0 ? void 0 : "",
		"data-paint": glow?.paint,
		"data-series": seriesIndex,
		"data-emphasis": emphasised.size > 0 ? "" : void 0,
		"aria-hidden": "true",
		className,
		style: {
			"--chart-series-paint": base,
			"--chart-series": seriesIndex,
			"--_glow": glow?.url,
			...style
		},
		children: [/* @__PURE__ */ jsxs("svg", { children: [shared === null || glow === null ? null : /* @__PURE__ */ jsx("defs", { children: glow.filter(plotGlowRegion(shared.frame.box)) }), shared === null ? null : form === "bars" ? /* @__PURE__ */ jsx(SeriesBars, {
			...shared,
			entering,
			variant: drawnVariant,
			emphasised
		}) : /* @__PURE__ */ jsx(SeriesPaths, {
			...shared,
			entering,
			variant: drawnVariant,
			emphasised
		})] }), /* @__PURE__ */ jsx("svg", { children: shared === null ? null : /* @__PURE__ */ jsx(ActiveBar, {
			...shared,
			variant: drawnVariant,
			form
		}) })]
	});
}
/**
* Bars side by side in one band, one sub-band per entry of `series`, with `--chart-bar-gap`
* between them. The group's own spacing holds for every Bar in it, so its `style` may set
* `--chart-band-gap`, `--chart-bar-gap` and `--chart-bar-seam` for all of them at once. Series that
* share a `stack` id share one sub-band, at the place of the first of them.
* Each Bar inside names a listed key, or it throws `bar-not-in-group`.
*
* @beta
*/
function ChartBarGroup({ series, className, style, children }) {
	const context = useChartRoot("Chart.BarGroup");
	if (use(ChartBarGroupContext) !== null) throw new ChartCompositionError("Chart.BarGroup", "nested-bar-group", "sits inside another Chart.BarGroup. List every key in one group's series.");
	const layout = usePlotLayout("Chart.BarGroup");
	for (const key of series) {
		assertKnownKey("Chart.BarGroup", context.config, key);
		assertLayoutKey("Chart.BarGroup", layout, key);
	}
	const { stacks } = context.model;
	const groupSeries = useSteady(series, sameItems);
	const element = useRef(null);
	const steadyStyle = useSteady(style, sameShallow);
	const metrics = useBarMetrics(element, [className, steadyStyle]);
	const value = useMemo(() => {
		const index = /* @__PURE__ */ new Map();
		const stackPlace = /* @__PURE__ */ new Map();
		let count = 0;
		for (const key of groupSeries) {
			const stack = stacks.find(({ keys }) => keys.includes(key))?.id;
			const shared = stack === void 0 ? void 0 : stackPlace.get(stack);
			if (shared !== void 0) {
				index.set(key, shared);
				continue;
			}
			index.set(key, count);
			if (stack !== void 0) stackPlace.set(stack, count);
			count += 1;
		}
		return {
			index,
			count,
			metrics
		};
	}, [
		groupSeries,
		stacks,
		metrics
	]);
	return /* @__PURE__ */ jsx("div", {
		ref: element,
		"data-slot": "chart-bar-group",
		"aria-hidden": "true",
		className,
		style,
		children: /* @__PURE__ */ jsx(ChartBarGroupContext, {
			value,
			children
		})
	});
}
Object.assign(ChartBar, { displayName: "Chart.Bar" });
Object.assign(ChartBarGroup, { displayName: "Chart.BarGroup" });
export { ChartBar, ChartBarGroup };

//# sourceMappingURL=chart-bar.js.map