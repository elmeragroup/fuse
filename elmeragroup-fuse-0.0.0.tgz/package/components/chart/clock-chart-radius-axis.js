"use client";
import { useLocale } from "../../intl/locale-context.js";
import { formatValue } from "./format/value-format.js";
import { clockDrawingIn, usePolarContext } from "./chart-polar-context.js";
import { boxPercent, turnOf } from "./layout/polar-angle.js";
import { ownerSlot, slotAt } from "./layout/clock-path.js";
import { ringAnchor } from "./layout/ring-labels.js";
import { labelBound } from "./layout/label-bound.js";
import { useMemo } from "react";
import { jsx } from "react/jsx-runtime";
// src/components/chart/clock-chart-radius-axis.tsx
/**
* The clock's RadiusAxis: the ring values along the 12 o'clock spoke, or the 6 o'clock one when
* the marks leave that more room, each shown only where it clears its neighbours. The first paint
* draws it at rest.
*/
/**
* Whether a clock's marks at rest cover a point: a slot's band between its base and its tip, at the
* slot's angles, in any series, as its Column, Area or Line would draw it. A Line draws only its tip,
* so the band is the most a series' mark can cover. The point's angle names its slot, as the pick
* finds it, and only the records that can hold that angle are read: the slot's and its two
* neighbours', which share its edges, each with every slot its coarse slot spans.
*/
function clockCover(clock) {
	const { count } = clock;
	return (x, y, radius) => {
		if (count === 0) return false;
		const share = Math.hypot(x, y) / radius;
		const angle = turnOf(Math.atan2(x, -y) * 180 / Math.PI);
		const slot = Math.min(count - 1, Math.floor(angle / 360 * count));
		const near = [
			(slot + count - 1) % count,
			slot,
			(slot + 1) % count
		];
		return clock.series.some(({ rest, slots }) => near.some((candidate) => {
			const owner = ownerSlot(slots.states, candidate);
			for (let at = owner; at < count && (at === owner || slots.states[at] === "covered"); at += 1) {
				const [start, end, base, tip] = slotAt(rest, at);
				if (angle >= start && angle <= end && share >= Math.min(base, tip) && share <= Math.max(base, tip)) return true;
			}
			return false;
		}));
	};
}
/**
* The ring values beside the 12 o'clock spoke, each on its ring, or beside the 6 o'clock spoke
* when the marks leave that more room. A value shows only at the widths where it clears its
* neighbours, the marks, the cycle labels the AngleAxis shows and the centre's text, so a crowded
* dial shows fewer values, or none.
*
* @beta
*/
function ClockChartRadiusAxis({ format, className, style }) {
	const { model, box } = usePolarContext("ClockChart.RadiusAxis", ["clock"]);
	const clock = clockDrawingIn(model, "ClockChart.RadiusAxis");
	const { locale } = useLocale();
	const { rings, anchor, shown } = useMemo(() => {
		const kept = clock.ticks.flatMap((tick) => {
			const radius = clock.radius(tick);
			return radius < clock.inner - 1e-9 || radius > 1 + 1e-9 ? [] : [{
				tick,
				radius
			}];
		});
		const values = kept.map(({ tick, radius }) => ({
			radius,
			width: labelBound(formatValue(locale, tick, format ?? clock.format, "tick").text)
		}));
		return {
			rings: kept,
			...ringAnchor(values, {
				inner: clock.inner * Math.SQRT2 / 2,
				angles: clock.labels.map((label) => ({
					angle: label.angle,
					width: labelBound(label.text.text),
					shownAt: label.visibility
				})),
				marks: clockCover(clock)
			})
		};
	}, [
		clock,
		format,
		locale
	]);
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "clock-chart-radius-axis",
		"data-polar-layer": "",
		"aria-hidden": "true",
		className,
		style,
		children: rings.map(({ tick, radius }, index) => {
			const [left, top] = boxPercent(box, 0, anchor === 180 ? radius : -radius);
			const min = shown[index] ?? "none";
			return /* @__PURE__ */ jsx("span", {
				"data-slot": "clock-chart-radius-label",
				"data-min": min === "none" ? void 0 : min,
				"data-hidden": min === "none" ? "" : void 0,
				style: {
					"--_x": left,
					"--_y": top
				},
				children: formatValue(locale, tick, format ?? clock.format, "tick").text
			}, tick);
		})
	});
}
Object.assign(ClockChartRadiusAxis, { displayName: "ClockChart.RadiusAxis" });
export { ClockChartRadiusAxis };

//# sourceMappingURL=clock-chart-radius-axis.js.map