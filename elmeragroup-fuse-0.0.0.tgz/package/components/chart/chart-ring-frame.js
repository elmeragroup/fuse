"use client";
import { writeAttribute } from "./chart-dom.js";
import { ringStroke } from "./layout/rings.js";
// src/components/chart/chart-ring-frame.ts
/**
* One radial chart's frame: every ring, track and halo its loop paints, with the measured scale,
* device pixel ratio and `--chart-ring-fill` they all share. A ring is a stroked centre line over
* the whole sweep whose `pathLength` is the sweep's width in degrees, and its value is the dash:
* round caps sit inside the value's angle, an arc shorter than its stroke draws butt caps at
* its true length, and every value above 0 keeps one device pixel of arc along its centre line.
* A dotted ring fills whole dots, `round(40 · share)` of them and at least one above 0,
* through a mask whose dash carries that count. Each ring records its angle in a frame, and
* the frame paints it in the next microtask outside a batch, or once the batch ends, as the pie's
* does. One loop holds one radial frame, which Bar, Track and Glow reach through `ringFrameOf`.
*/
/** How many dots a dotted ring holds over its sweep. */
const RING_DOTS = 40;
/** A dash long enough to cover any sweep, in the sweep's degrees. */
const GAP = 1e4;
/**
* The dash that draws an angle along a ring of the sweep.
*
* @param angle - The filled angle in degrees.
* @param place - The ring's radius and band, and whether it fills whole dots.
* @param sweep - The sweep.
* @param measure - The scale, the dpr and the fill, or null where nothing measures, as on the
*   server, which reads the default fill and keeps no pixel floor.
* @returns The dash.
*/
function ringDash(angle, place, sweep, measure) {
	if (place.mode === "dots") {
		const cell = sweep.width / 40;
		const share = Math.round(40 * Math.min(angle, sweep.width) / sweep.width);
		return {
			dasharray: `${short((angle > 0 ? Math.max(1, share) : 0) * cell)} ${String(GAP)}`,
			dashoffset: "0",
			linecap: "butt"
		};
	}
	const fill = measure?.fill ?? .7;
	const scale = measure?.scale ?? 1;
	const stroke = ringStroke(angle, {
		radius: place.radius * scale,
		width: place.band * fill * scale,
		dpr: measure?.dpr ?? 0
	});
	if (stroke.cap === "none") return {
		dasharray: `0 ${String(GAP)}`,
		dashoffset: "0",
		linecap: "butt"
	};
	return {
		dasharray: `${short(stroke.length)} ${String(GAP)}`,
		dashoffset: short(-stroke.start),
		linecap: stroke.cap
	};
}
/** A number for an attribute, kept short. */
function short(value) {
	return String(Math.round(value * 1e4) / 1e4);
}
/** Write a dash onto a ring's path. */
function writeDash(node, dash) {
	writeAttribute(node, "stroke-dasharray", dash.dasharray);
	writeAttribute(node, "stroke-dashoffset", dash.dashoffset);
	writeAttribute(node, "stroke-linecap", dash.linecap);
}
/**
* The frame of one radial chart on its Root's loop.
*
* @param motion - The Root's loop.
* @param sweep - The chart's sweep as it first renders.
* @returns The frame.
*/
function createRingFrame(motion, sweep) {
	const rings = /* @__PURE__ */ new Map();
	const tracks = /* @__PURE__ */ new Map();
	const mirrors = /* @__PURE__ */ new Map();
	let current = sweep;
	let measure = null;
	let batching = 0;
	let queued = false;
	const paint = () => {
		queued = false;
		for (const [key, ring] of rings) {
			if (!ring.node.isConnected) {
				rings.delete(key);
				continue;
			}
			const dash = ringDash(ring.angle, ring.place, current, measure);
			writeDash(ring.node, dash);
			for (const mirror of mirrors.get(key) ?? []) writeDash(mirror, ringDash(ring.angle, {
				...ring.place,
				mode: "dash"
			}, current, measure));
		}
		for (const [node, place] of tracks) writeDash(node, ringDash(current.width, place, current, measure));
	};
	const schedule = () => {
		if (batching > 0 || queued) return;
		queued = true;
		queueMicrotask(paint);
	};
	const party = {
		begin: () => {
			batching += 1;
		},
		end: () => {
			batching -= 1;
			if (batching === 0 && !queued) paint();
		}
	};
	return {
		record: (key, node, values, place) => {
			rings.set(key, {
				node,
				angle: values[0] ?? 0,
				place
			});
			schedule();
		},
		track: (node, place) => {
			tracks.set(node, place);
			schedule();
			return () => {
				tracks.delete(node);
			};
		},
		mirror: (key, node) => {
			const known = mirrors.get(key) ?? /* @__PURE__ */ new Set();
			known.add(node);
			mirrors.set(key, known);
			schedule();
			return () => {
				known.delete(node);
			};
		},
		update: (next, measured) => {
			current = next;
			measure = measured;
			schedule();
		},
		attach: () => {
			batching = 0;
			return motion.batches(party);
		}
	};
}
const frames = /* @__PURE__ */ new WeakMap();
/**
* The radial chart's frame on a Root's loop, made on first use.
*
* @param motion - The Root's loop.
* @param sweep - The sweep, for a frame made here.
* @returns The frame.
*/
function ringFrameOf(motion, sweep) {
	const known = frames.get(motion);
	if (known !== void 0) return known;
	const made = createRingFrame(motion, sweep);
	frames.set(motion, made);
	return made;
}
export { RING_DOTS, ringDash, ringFrameOf };

//# sourceMappingURL=chart-ring-frame.js.map