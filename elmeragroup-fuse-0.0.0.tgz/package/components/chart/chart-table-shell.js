"use client";
import { cn } from "../../styles/cn.js";
import { useLocalizedStrings } from "../../hooks/use-localized-strings.js";
import { Button } from "../button/button.js";
import { CaretRight } from "../../icons/generated/caret-right.js";
import { CaretLeft } from "../../icons/generated/caret-left.js";
import { CaretDoubleLeft } from "../../icons/generated/caret-double-left.js";
import { CaretDoubleRight } from "../../icons/generated/caret-double-right.js";
import { pageStatus } from "../data-table/data-table-pagination-status.js";
import { dataTableStrings } from "../data-table/intl/index.js";
import { Table } from "../table/table.js";
import { Fragment, useEffect, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-table-shell.tsx
/**
* The table disclosure every chart family shares: the "Vis som tabell" toggle, the table that stays
* in the accessibility tree while it is visually collapsed, and the pagination past 500 rows. A
* family's table passes its caption, header cells, rows and pages. The module reads no Root
* context, so a scatter route ships no cartesian module through it.
*/
/** Above this many rows a chart's table pages, after CONTRACT section 9.6. */
const PAGE_ROWS = 500;
/**
* The words a twin cell shows and speaks.
*
* @param props - The cell's text in both forms.
*/
function Twin({ text }) {
	if (text.text === text.spoken) return text.text;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("span", {
		"aria-hidden": "true",
		children: text.text
	}), /* @__PURE__ */ jsx("span", {
		className: "sr-only",
		children: text.spoken
	})] });
}
/**
* A table's disclosure, which a family's table holds above its empty state, so a chart whose data
* empties and fills again keeps its table shown or hidden.
*
* @returns The disclosure, collapsed at first.
*/
function useTableDisclosure() {
	const [shown, setShown] = useState(false);
	const table = useRef(null);
	const focusTable = useRef(false);
	useEffect(() => {
		if (!focusTable.current) return;
		focusTable.current = false;
		table.current?.focus();
	}, [shown]);
	return {
		shown,
		toggle: () => {
			focusTable.current = !shown;
			setShown(!shown);
		},
		table
	};
}
/**
* The pagination: first, back, the status, forward and last, after the data table's moves. While
* the table is collapsed it is visually hidden and its buttons take no Tab stop.
*/
function TablePagination({ pages, shown }) {
	const tableStrings = useLocalizedStrings(dataTableStrings);
	const { index, count, status, go } = pages;
	const state = pageStatus(index, {
		kind: "known",
		pageCount: count
	});
	const moves = [
		{
			key: "first",
			label: "goToFirstPage",
			Icon: CaretDoubleLeft,
			target: 0,
			enabled: state.canPrevious
		},
		{
			key: "previous",
			label: "goToPreviousPage",
			Icon: CaretLeft,
			target: index - 1,
			enabled: state.canPrevious
		},
		{
			key: "next",
			label: "goToNextPage",
			Icon: CaretRight,
			target: index + 1,
			enabled: state.canNext
		},
		{
			key: "last",
			label: "goToLastPage",
			Icon: CaretDoubleRight,
			target: count - 1,
			enabled: state.canNext
		}
	];
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "chart-table-pagination",
		className: shown ? void 0 : cn("sr-only"),
		children: moves.map(({ key, label, Icon, target, enabled }) => /* @__PURE__ */ jsxs(Fragment, { children: [key === "next" ? /* @__PURE__ */ jsx("span", { children: status }) : null, /* @__PURE__ */ jsx(Button, {
			variant: "outline",
			size: "icon-xs",
			"aria-label": tableStrings.format(label),
			tabIndex: shown ? void 0 : -1,
			disabled: !enabled,
			onClick: () => {
				go(target);
			},
			children: /* @__PURE__ */ jsx(Icon, { "aria-hidden": "true" })
		})] }, key))
	});
}
/**
* A "Vis som tabell" button and a table, which stays in the accessibility tree while it is
* visually collapsed. Showing it moves focus to the table, which then takes a Tab stop, so a
* keyboard can scroll a table wider than its box. Past one page it adds the pagination.
*
* @param props - The family's caption, header cells, rows and pages.
*/
function ChartTableShell({ disclosure, tableId, showLabel, hideLabel, className, style, caption, head, children, pages }) {
	const { shown, toggle, table } = disclosure;
	return /* @__PURE__ */ jsxs("div", {
		"data-slot": "chart-table",
		className,
		style,
		children: [
			/* @__PURE__ */ jsx(Button, {
				"data-slot": "chart-table-toggle",
				variant: "outline",
				size: "xs",
				"aria-controls": tableId,
				onClick: toggle,
				children: shown ? hideLabel : showLabel
			}),
			/* @__PURE__ */ jsxs(Table.Root, {
				id: tableId,
				ref: table,
				tabIndex: shown ? 0 : -1,
				"data-slot": "chart-table-content",
				className: shown ? void 0 : cn("sr-only"),
				children: [
					/* @__PURE__ */ jsx(Table.Caption, { children: caption }),
					/* @__PURE__ */ jsx(Table.Header, { children: /* @__PURE__ */ jsx(Table.Row, { children: head }) }),
					/* @__PURE__ */ jsx(Table.Body, { children })
				]
			}),
			pages.count > 1 ? /* @__PURE__ */ jsx(TablePagination, {
				pages,
				shown
			}) : null
		]
	});
}
Object.assign(ChartTableShell, { displayName: "Chart.TableShell" });
Object.assign(Twin, { displayName: "Chart.TableTwin" });
export { ChartTableShell, PAGE_ROWS, Twin, useTableDisclosure };

//# sourceMappingURL=chart-table-shell.js.map