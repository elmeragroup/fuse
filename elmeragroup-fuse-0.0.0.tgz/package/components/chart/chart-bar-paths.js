"use client";
import { floorAxisOf, frameRect, snapY, tickWidth, valueAt } from "./layout/plot-frame.js";
import { partsCache, writeAttribute, writeAttributes } from "./chart-dom.js";
import { floorSpanOf } from "./layout/floor-settle.js";
import { useStackSeat } from "./chart-stack-floors.js";
import { ListFills } from "./chart-bar-fills.js";
import { placementOf, useCommitMotion, useFirstDraw, useMotionMark } from "./chart-motion-mark.js";
import { pastSpanEnd } from "./chart-bar-draw.js";
import { COLUMN_AXES, columnBody, columnEnds, columnKind, columnsDrawing, emphasisSpan, layoutColumns } from "./chart-bar-columns.js";
import { topologyAt } from "./chart-path-draw.js";
import { usePathMark } from "./chart-series-path.js";
import { useCallback, useLayoutEffect, useMemo, useRef } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-bar-paths.tsx
/**
* The path form of one Bar above 100 slots: per colour step a solid path, a projected path and an
* estimated path, then the missing ticks and the emphasised overlays. The series grows from the zero
* line in Root's entrance as one transform, which holds one registration with Root's loop.
*/
/**
* Scale the path form's marks from the zero line by the loop's number. The paths draw the latest
* frame at once, so the zero line they grow from is that frame's, snapped as the paths snap it.
*/
function drawGrow(node, look, values) {
	const [scale = 1] = values;
	const { frame } = look;
	const zero = snapY(frame.box, valueAt(frame, 0));
	writeAttribute(node, "transform", scale === 1 ? null : `translate(0 ${String(zero)}) scale(1 ${String(scale)}) translate(0 ${String(-zero)})`);
}
/** The parts a paint step's paths take, which a path's `data-part` names. */
const STEP_PARTS = [
	"fill",
	"projected",
	"estimated"
];
/** The columns' paths, each with what it draws, and the emphasis boxes, in order. */
const columnParts = partsCache((group) => ({
	paths: [...group.querySelectorAll("[data-slot=\"chart-bar-path\"]")].map((path) => ({
		path,
		part: STEP_PARTS.find((part) => part === path.getAttribute("data-part")),
		fill: Number(path.getAttribute("data-fill") ?? "-1")
	})),
	boxes: [...group.querySelectorAll("[data-slot=\"chart-bar-emphasis\"]")]
}));
/** Draw the columns, their quality paths, the missing ticks and the emphasis boxes from the loop's numbers. */
function drawColumns(group, look, values) {
	if (look === null) return;
	const topology = topologyAt(look.moving.current, look.topology, values.length / 9);
	const { seat } = look;
	if (seat === null || group.closest("[data-outgoing]") !== null) {
		paintColumns(group, columnsDrawing(look.frame, topology, values));
		return;
	}
	const own = [...values];
	const { frame } = look;
	const spans = [];
	/** Each entry's column with no floor, which the batch's own paint reuses and then lets go. */
	let bodies = [];
	/** Each entry's span's position in `spans`, -1 for an entry with no column. */
	const spanAt = new Int32Array(topology.entries.length).fill(-1);
	/** Each column-less emphasis box's span, which reads the place of its series' spans under it. */
	const boxes = [];
	topology.entries.forEach((entry, index) => {
		const ends = columnEnds(own, index, entry);
		if (entry.fill < 0) {
			if (!entry.emphasis) return;
			const box = frameRect(frame, emphasisSpan(frame, own, index), ends);
			boxes[index] = floorSpanOf(frame, box, seat.series, ends);
			return;
		}
		const plain = columnBody(frame, own, index, entry);
		if (bodies !== void 0) bodies[index] = plain;
		spanAt[index] = spans.length;
		spans.push(floorSpanOf(frame, plain, seat.series, ends));
	});
	seat.floors.draw(seat.mark, seat.stack, spans, floorAxisOf(frame), (kept) => {
		const placeOf = (entry, index) => {
			const at = spanAt[index] ?? -1;
			if (at !== -1) return kept[at] === 1 ? "outer" : "inner";
			const box = boxes[index];
			return (box === void 0 ? void 0 : seat.floors.placeOver(seat.stack, box, floorAxisOf(frame))) ?? entry.place;
		};
		paintColumns(group, columnsDrawing(frame, topology, own, placeOf, bodies));
		bodies = void 0;
	});
}
/** Write a drawing onto the columns' paths and emphasis boxes. */
function paintColumns(group, drawing) {
	const { paths, boxes } = columnParts(group);
	for (const { path, part, fill } of paths) writeAttribute(path, "d", (part === void 0 ? drawing.missing : drawing[part][fill]) ?? "");
	boxes.forEach((rect, index) => {
		const box = drawing.emphasis[index];
		if (box !== void 0) writeAttributes(rect, box);
	});
}
/** The attribute chart.css draws each quality path by: projected lighter, estimated dashed. */
const PART_QUALITY = {
	fill: {},
	projected: { "data-projected": "" },
	estimated: { "data-quality": "estimated" }
};
/**
* One path per paint step for one part. A step's position is its identity, since a threshold's two
* sides may share a role, and a projected or estimated reading keeps its step's paint, so each step
* has a path of each part.
*/
function StepPaths({ part, fills, resting, seriesIndex, listFill }) {
	return /* @__PURE__ */ jsx(Fragment$1, { children: fills.map((fill, index) => /* @__PURE__ */ jsx("path", {
		"data-slot": "chart-bar-path",
		"data-part": part,
		"data-fill": index,
		"data-series": seriesIndex,
		...PART_QUALITY[part],
		d: resting[part][index] ?? "",
		style: {
			"--chart-bar-paint": fill === "" ? void 0 : fill,
			"--_fill": fill === "" && part === "fill" ? listFill : void 0
		}
	}, index)) });
}
/**
* One series as paths. The gradient look fades through one mask, and `data-fade="past"` dims the
* past span through one more. On a data update the columns move through the modes of
* `layout/path-motion.ts`, as a line's vertices do.
*/
function SeriesPaths({ context, series, frame, plot, metrics, sub, variant, paint, emphasised, prefix, entering }) {
	const { motion, update, model, now, fade } = context;
	const { box } = frame;
	const pastEnd = useMemo(() => pastSpanEnd({
		model,
		fade,
		now
	}, series, frame), [
		model,
		fade,
		now,
		series,
		frame
	]);
	const zero = snapY(box, valueAt(frame, 0));
	const columns = useMemo(() => layoutColumns({
		model,
		update
	}, series, frame, metrics, sub, paint, emphasised), [
		model,
		update,
		series,
		frame,
		metrics,
		sub,
		paint,
		emphasised
	]);
	const { topology, fills } = columns;
	const listFill = paint.stops === void 0 ? void 0 : `url(#${prefix}-list)`;
	const growLook = useMemo(() => ({ frame }), [frame]);
	const { ref: growRef, place: placeGrow } = useMotionMark(motion, drawGrow, growLook, ["size"]);
	const growCommit = useCommitMotion(update, plot, frame.orientation, frame);
	useLayoutEffect(() => {
		const asked = growCommit();
		placeGrow([1], entering ? {
			kind: "enter",
			from: [0],
			delay: 0
		} : asked.kind === "move" ? { kind: "snap" } : placementOf(asked));
	});
	const moving = useRef(null);
	const seat = useStackSeat(motion, series.stack, series.key);
	const look = useMemo(() => ({
		frame,
		topology,
		moving,
		seat
	}), [
		frame,
		topology,
		seat
	]);
	const kind = useMemo(() => columnKind(frame.grid.step, valueAt(frame, 0)), [frame]);
	const placed = useMemo(() => ({
		look,
		kind,
		path: columns,
		topology,
		rest: columns.values
	}), [
		look,
		kind,
		columns,
		topology
	]);
	const { markRef: columnsRef, outgoingRef } = usePathMark(drawColumns, {
		context,
		plot,
		frame,
		axes: COLUMN_AXES,
		seriesIndex: series.seriesIndex,
		route: "columns",
		placed
	});
	const resting = useFirstDraw(() => columnsDrawing(frame, topology, columns.values));
	const steps = {
		fills,
		resting,
		seriesIndex: series.seriesIndex,
		listFill
	};
	const setRefs = useCallback((element) => {
		growRef(element);
		columnsRef(element);
	}, [growRef, columnsRef]);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [
		/* @__PURE__ */ jsxs("defs", { children: [
			paint.stops === void 0 ? null : /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("linearGradient", {
				id: `${prefix}-list`,
				gradientUnits: "userSpaceOnUse",
				x1: "0",
				y1: "0",
				x2: "0",
				y2: zero,
				children: paint.stops.map((stop, index, stops) => /* @__PURE__ */ jsx("stop", {
					offset: index / Math.max(1, stops.length - 1),
					style: { "--chart-stop": stop }
				}, index))
			}), /* @__PURE__ */ jsx(ListFills, {
				prefix,
				stops: paint.stops,
				orientation: frame.orientation
			})] }),
			variant === "gradient" ? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs("linearGradient", {
				id: `${prefix}-fade-ramp`,
				gradientUnits: "userSpaceOnUse",
				x1: "0",
				y1: "0",
				x2: "0",
				y2: box.height,
				children: [/* @__PURE__ */ jsx("stop", { offset: "0.2" }), /* @__PURE__ */ jsx("stop", {
					offset: "0.9",
					style: { "--chart-stop-opacity": 0 }
				})]
			}), /* @__PURE__ */ jsx("mask", {
				id: `${prefix}-fade`,
				maskUnits: "userSpaceOnUse",
				x: "0",
				y: "0",
				width: box.width,
				height: box.height,
				children: /* @__PURE__ */ jsx("rect", {
					width: box.width,
					height: box.height,
					fill: `url(#${prefix}-fade-ramp)`
				})
			})] }) : null,
			pastEnd === null ? null : /* @__PURE__ */ jsxs("mask", {
				id: `${prefix}-past`,
				maskUnits: "userSpaceOnUse",
				x: "0",
				y: "0",
				width: box.width,
				height: box.height,
				children: [/* @__PURE__ */ jsx("rect", {
					width: pastEnd,
					height: box.height,
					fillOpacity: "0.4"
				}), /* @__PURE__ */ jsx("rect", {
					x: pastEnd,
					width: Math.max(box.width - pastEnd, 0),
					height: box.height
				})]
			})
		] }),
		/* @__PURE__ */ jsxs("g", {
			ref: setRefs,
			"data-slot": "chart-bar-marks",
			mask: pastEnd === null ? void 0 : `url(#${prefix}-past)`,
			children: [
				/* @__PURE__ */ jsxs("g", {
					mask: variant === "gradient" ? `url(#${prefix}-fade)` : void 0,
					children: [/* @__PURE__ */ jsx(StepPaths, {
						part: "fill",
						...steps
					}), /* @__PURE__ */ jsx(StepPaths, {
						part: "projected",
						...steps
					})]
				}),
				/* @__PURE__ */ jsx(StepPaths, {
					part: "estimated",
					...steps
				}),
				/* @__PURE__ */ jsx("path", {
					"data-slot": "chart-bar-path",
					"data-part": "missing",
					"data-series": series.seriesIndex,
					"data-quality": "missing",
					style: { "--_tick-width": `${String(tickWidth(box))}px` },
					d: resting.missing
				}),
				columns.emphasis.map(({ key, paint: own }, index) => /* @__PURE__ */ jsx("rect", {
					"data-slot": "chart-bar-emphasis",
					"data-series": series.seriesIndex,
					...resting.emphasis[index],
					style: own === void 0 ? void 0 : { "--chart-bar-paint": own }
				}, key))
			]
		}),
		/* @__PURE__ */ jsx("g", {
			ref: outgoingRef,
			"data-part": "outgoing"
		})
	] });
}
Object.assign(SeriesPaths, { displayName: "Chart.Bar.Paths" });
export { SeriesPaths };

//# sourceMappingURL=chart-bar-paths.js.map