"use client";
import { useState } from "react";
// src/components/chart/chart-tap-lift.ts
/**
* Create a surface's lift record.
*
* @returns The record, with no lift.
*/
function createTapLift() {
	let lifted = false;
	let focusing = false;
	return {
		press() {
			lifted = false;
			focusing = false;
		},
		lift() {
			lifted = true;
		},
		mouseDown() {
			focusing = true;
			setTimeout(() => {
				focusing = false;
			}, 0);
		},
		tapFocus: () => focusing,
		clickActs(event) {
			const native = event.nativeEvent;
			const touch = native instanceof globalThis.PointerEvent && native.pointerType !== "mouse";
			const compatibility = event.detail > 0 && (touch || lifted);
			lifted = false;
			return !compatibility;
		}
	};
}
/**
* A surface's lift record for its life.
*
* @returns The record.
*/
function useTapLift() {
	const [lift] = useState(createTapLift);
	return lift;
}
export { useTapLift };

//# sourceMappingURL=chart-tap-lift.js.map