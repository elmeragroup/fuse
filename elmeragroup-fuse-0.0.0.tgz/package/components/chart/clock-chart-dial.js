"use client";
import { pathNumber } from "./layout/rounding.js";
import { ChartCompositionError } from "./layout/errors.js";
import { boxPercent, polarPoint } from "./layout/polar-angle.js";
import { angleLabel, rayLabelOffset } from "./layout/polar-labels.js";
// src/components/chart/clock-chart-dial.ts
/** A label's place past the rim at an angle, reading away from the centre. */
function labelPlace(box, angle, reach) {
	const { point, alignX, alignY } = angleLabel(angle, reach);
	const [x, y] = boxPercent(box, point.x, point.y);
	return {
		x,
		y,
		alignX: `${String(-alignX * 100)}%`,
		alignY: `${String(-alignY * 100)}%`
	};
}
/**
* A label's place on its ray: its centre at the rim point plus the gap and its support along the
* ray, past the rim or inside it, so it sits centred on its spoke at a constant gap.
*
* @param box - The sweep's box.
* @param angle - The ray's angle in degrees.
* @param width - The label's estimated width in CSS pixels.
* @param side - "outside" past the rim, "inside" toward the centre.
* @returns The place, centred on its point.
*/
function rayPlace(box, angle, width, side) {
	const rim = polarPoint(angle, 1);
	const [x, y] = boxPercent(box, rim.x, rim.y);
	const offset = rayLabelOffset(angle, width, side);
	return {
		x: `calc(${x} + ${offset.x})`,
		y: `calc(${y} + ${offset.y})`,
		alignX: "-50%",
		alignY: "-50%"
	};
}
/** The narrowest width a label or its spoke shows at, for the stylesheet's container rules. */
function minOf(visibility) {
	return visibility === "always" || visibility === "none" ? void 0 : visibility;
}
/** A spoke from the hole to the rim at an angle. */
function spokePath(angle, inner, outer) {
	const a = polarPoint(angle, inner);
	const b = polarPoint(angle, outer);
	return `M${pathNumber(a.x)},${pathNumber(a.y)}L${pathNumber(b.x)},${pathNumber(b.y)}`;
}
/** The slot of an instant, rejecting a string x, which a dial cannot read. */
function slotOfX(clock, part, x) {
	if (typeof x === "string") throw new ChartCompositionError(part, "x-type-mismatch", "received a string x on a clock dial. Pass a Date or epoch milliseconds, because a date-only string parses as UTC midnight and lands on the wrong day.");
	return clock.slotOf(x);
}
export { labelPlace, minOf, rayPlace, slotOfX, spokePath };

//# sourceMappingURL=clock-chart-dial.js.map