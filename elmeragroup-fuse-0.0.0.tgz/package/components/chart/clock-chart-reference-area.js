"use client";
import { CHART_STRINGS } from "./format/chart-strings.js";
import { formatSlot, isClockInterval, nextSlotStart } from "./format/time-format.js";
import { formatValue } from "./format/value-format.js";
import { clockDrawingIn, usePolarContext } from "./chart-polar-context.js";
import { slotLabel } from "./chart-text.js";
import { referenceSentence } from "./chart-reference-text.js";
import { viewBoxOf } from "./layout/polar-angle.js";
import { slotAngles } from "./layout/clock.js";
import { sectorPath } from "./layout/clock-path.js";
import { labelPlace, slotOfX } from "./clock-chart-dial.js";
import { PlacedLabel } from "./clock-chart-placed-label.js";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/clock-chart-reference-area.tsx
/**
* An annulus between two values, as `y1` and `y2`, or a sector from one instant's slot to another's,
* as `x1` and `x2`, with an optional label. The annulus clips to the radius domain, from the hole
* to the rim, and one outside it draws nothing, as a sector outside the cycle draws nothing, the
* label included. Readers hear it as a visually hidden sentence with the range, as the cartesian
* ReferenceArea's.
*
* @beta
*/
function ClockChartReferenceArea({ style, ...props }) {
	const { label, tone = "default", className } = props;
	const { model, box, kernel } = usePolarContext("ClockChart.ReferenceArea", ["clock"]);
	const clock = clockDrawingIn(model, "ClockChart.ReferenceArea");
	const strings = CHART_STRINGS[kernel.locale];
	let d;
	let value;
	let drawn;
	let place;
	if (props.y1 !== void 0) {
		const [min, max] = clock.domain;
		const from = Math.max(min, Math.min(props.y1, props.y2));
		const to = Math.min(max, Math.max(props.y1, props.y2));
		drawn = to > from;
		const low = clock.radius(from);
		const high = clock.radius(to);
		d = drawn ? sectorPath(0, 360, low, high) : "";
		const valueFormat = props.format ?? clock.format;
		const first = formatValue(kernel.locale, props.y1, valueFormat, "full");
		const second = formatValue(kernel.locale, props.y2, valueFormat, "full");
		const [lowEnd, highEnd] = props.y1 <= props.y2 ? [first, second] : [second, first];
		value = {
			text: `${first.text}\u2013${second.text}`,
			spoken: strings.valueRange(lowEnd.spoken, highEnd.spoken)
		};
		place = labelPlace(box, 0, high);
	} else {
		const first = slotOfX(clock, "ClockChart.ReferenceArea", props.x1);
		const last = slotOfX(clock, "ClockChart.ReferenceArea", props.x2);
		const ok = first !== -1 && last !== -1;
		const start = ok ? slotAngles(Math.min(first, last), clock.count).start : 0;
		const end = ok ? slotAngles(Math.max(first, last), clock.count).end : 0;
		d = ok ? sectorPath(start, end, clock.inner, 1) : "";
		const domain = clock.text.model.domain;
		const timeZone = domain.kind === "time" ? domain.timeZone : "UTC";
		const interval = domain.kind === "time" ? domain.interval : "hour";
		const from = clock.starts[Math.min(first, last)];
		const until = clock.starts[Math.max(first, last)];
		const format = props.format === "hour-range" ? "hour" : props.format === "time-range" ? "time" : props.format;
		const instants = format !== void 0 || isClockInterval(interval);
		drawn = ok && from !== void 0 && until !== void 0;
		if (!ok || from === void 0 || until === void 0) value = {
			text: "",
			spoken: ""
		};
		else {
			const at = (instant) => formatSlot(kernel.locale, timeZone, instant, interval, format ?? "time", "full");
			const [head, tail] = instants ? [at(from), at(nextSlotStart(until, interval, timeZone))] : [slotLabel(clock.text, Math.min(first, last)), slotLabel(clock.text, Math.max(first, last))];
			value = {
				text: `${head.text}\u2013${tail.text}`,
				spoken: strings.valueRange(head.spoken, tail.spoken)
			};
		}
		place = labelPlace(box, (start + end) / 2, 1.02);
	}
	const text = referenceSentence(label, value, strings.referenceArea);
	return /* @__PURE__ */ jsxs("div", {
		"data-slot": "clock-chart-reference-area",
		"data-tone": tone,
		"data-polar-layer": "",
		className,
		style,
		children: [
			/* @__PURE__ */ jsx("svg", {
				viewBox: viewBoxOf(box),
				"aria-hidden": "true",
				focusable: "false",
				children: /* @__PURE__ */ jsx("path", {
					"data-slot": "clock-chart-reference-path",
					"data-part": "area",
					d
				})
			}),
			label === void 0 || !drawn ? null : /* @__PURE__ */ jsx(PlacedLabel, {
				place,
				children: text.text
			}),
			/* @__PURE__ */ jsx("span", {
				"data-slot": "chart-reference-text",
				children: text.spoken
			})
		]
	});
}
Object.assign(ClockChartReferenceArea, { displayName: "ClockChart.ReferenceArea" });
export { ClockChartReferenceArea };

//# sourceMappingURL=clock-chart-reference-area.js.map