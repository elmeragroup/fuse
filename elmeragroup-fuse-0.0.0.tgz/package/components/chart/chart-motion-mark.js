"use client";
import { ChartLayoutContext } from "./chart-scope-contexts.js";
import { sameItems } from "./layout/same-items.js";
import { refreshParts } from "./chart-dom.js";
import { SAME_PLOT } from "./chart-motion.js";
import { use, useCallback, useId, useLayoutEffect, useMemo, useRef, useState } from "react";
// src/components/chart/chart-motion-mark.ts
/**
* How one mark binds to Root's animation loop. `useMotionMark` owns a mark's registration for the
* mark's whole life: it draws into whichever node the mark renders now, so a node that React
* replaces keeps its motion, and it forgets the mark when the mark unmounts. React writes a mark's
* geometry on its first draw only, through `useFirstDraw`, and the loop writes it from then on, so
* a commit writes no geometry React would then rewind. `useCommitMotion` tells a mark how to reach
* the geometry of each commit it draws.
*/
/**
* The geometry React renders for a mark: the first value `make` returns that is not null, kept for
* the mark's life, so React writes it once and the loop, which writes before every paint, owns it
* after. A new `key` takes a new value, as a look that adds a part must render that part.
*
* @param make - Builds the geometry, or null before the mark can draw. It runs only to latch.
* @param key - What the kept geometry's shape depends on, such as the parts a bar draws.
* @returns The geometry to render, null while `make` gives none.
*/
function useFirstDraw(make, key) {
	const [kept, setKept] = useState(() => ({
		value: make(),
		key
	}));
	if (kept.value !== null && kept.value !== void 0 && kept.key === key) return kept.value;
	const value = make();
	if (value !== null && value !== void 0) setKept({
		value,
		key
	});
	return value;
}
/**
* Register a mark with Root's loop for as long as it is mounted. The mark draws in the frame of the
* nearest layout, Root's default one or its Panel's, so a resize of that frame alone maps its tween.
*
* @param motion - Root's loop.
* @param write - Writes the loop's numbers onto the mark's node: a function bound at module scope,
*   so it reads only its node, its look and the numbers.
* @param look - The writer's look, the latest one drawing, with no target coordinate in it.
* @param axes - What each of the mark's numbers measures, in order, so a resize maps them into the
*   new box: a pixel along x or y from the plot's edge, or a size the box leaves alone. The latest
*   declaration counts, as a reference that changes axis changes it, and its length types the
*   numbers the mark places.
* @param partsKey - What the children the writer draws depend on, such as the parts a bar's look
*   draws. A commit that keeps it finds no parts again and skips a write that changes nothing.
*   Without it, every commit finds the parts again and draws once.
* @returns The ref to pass to the mark's node and the placement function.
*/
function useMotionMark(motion, write, look, axes, partsKey) {
	const id = useId();
	const owner = use(ChartLayoutContext)?.owner;
	const node = useRef(null);
	const latest = useRef({
		write,
		look
	});
	const declared = useRef(axes);
	const written = useRef({
		node: null,
		look: null,
		values: []
	});
	const parts = useRef(void 0);
	useLayoutEffect(() => {
		latest.current = {
			write,
			look
		};
		declared.current = axes;
		if (partsKey === void 0 || partsKey !== parts.current) {
			refreshParts(node.current);
			written.current.node = null;
		}
		parts.current = partsKey;
	});
	useLayoutEffect(() => () => {
		motion.forget(id);
		written.current.node = null;
	}, [motion, id]);
	const ref = useCallback((element) => {
		node.current = element;
	}, []);
	const current = useCallback(() => node.current, []);
	const drawn = useCallback(() => motion.drawn(id), [motion, id]);
	const place = useCallback((target, placement, anchor) => {
		motion.place(id, target, (values) => {
			const shown = node.current;
			if (shown === null) return;
			const { write: draw, look: drawnLook } = latest.current;
			const last = written.current;
			if (last.node === shown && last.look === drawnLook && sameItems(last.values, values)) return;
			last.node = shown;
			last.look = drawnLook;
			last.values.length = values.length;
			values.forEach((value, index) => {
				last.values[index] = value;
			});
			draw(shown, drawnLook, values);
		}, placement, {
			axes: declared.current,
			anchor,
			owner
		});
	}, [
		motion,
		id,
		owner
	]);
	return useMemo(() => ({
		ref,
		node: current,
		drawn,
		place
	}), [
		ref,
		current,
		drawn,
		place
	]);
}
/**
* How the plot's box scaled from one measurement to the next, 1 where either has no size, and how
* the slot axis maps from the old frame's slot grid into the new one's.
*/
function scaleOf(previous, plot, before, frame) {
	if (previous === null || plot === null || previous === plot) return SAME_PLOT;
	const ratio = (now, then) => then > 0 && now > 0 ? now / then : 1;
	const scale = {
		x: ratio(plot.box.width, previous.box.width),
		y: ratio(plot.box.height, previous.box.height),
		to: plot
	};
	if (before === null || frame === null || before.orientation !== frame.orientation) return scale;
	const slot = {
		axis: frame.orientation === "vertical" ? "x" : "y",
		from: before.grid.start,
		to: frame.grid.start,
		ratio: ratio(frame.grid.step, before.grid.step)
	};
	return {
		...scale,
		slot
	};
}
/**
* Track the commits a mark has drawn, so its layout effect can tell a data update from a resize.
*
* @param update - Root's current update.
* @param plot - Root's current measurement.
* @param space - The coordinate space the mark's numbers live in: Root's orientation, and for a
*   reference its axis too. A change of space reinterprets every number the mark drew, so it snaps.
* @param frame - The frame the mark draws in, whose slot grid a resize maps slot-axis numbers
*   through, or null before the plot is measured.
* @returns A function the mark's layout effect calls once per draw.
*/
function useCommitMotion(update, plot, space, frame) {
	const last = useRef(null);
	useLayoutEffect(() => () => {
		last.current = null;
	}, []);
	return () => {
		const previous = last.current;
		last.current = {
			update,
			plot,
			frame,
			space
		};
		const commit = (kind) => ({
			kind,
			scale: scaleOf(previous?.plot ?? null, plot, previous?.frame ?? null, frame)
		});
		if (previous === null) return commit("snap");
		if (previous.space !== space) return commit("snap");
		if (previous.update === update || previous.plot !== plot) return commit("settle");
		return commit(update.kind === "data" && !update.relays && !update.layouts.relays ? "move" : "snap");
	};
}
/**
* The loop's placement for a commit, the one owner every mark asks. A data update moves, along a
* path's own route when it brings one. A settle carries the commit's scale, and a snap, a first
* draw's included, snaps, while a mark in Root's waiting entrance places its entrance instead.
*
* @param commit - What the commit asks of the mark, from `useCommitMotion`.
* @param options - A path's route to its rest when a data update aligns its old and new vertices
*   itself.
* @returns The placement.
*/
function placementOf(commit, options = {}) {
	const { kind, scale } = commit;
	if (kind === "move") return options.via === void 0 ? { kind: "move" } : {
		kind: "move",
		via: options.via
	};
	if (kind === "settle") return {
		kind: "settle",
		scale
	};
	return { kind: "snap" };
}
/**
* How a follower reaches its geometry each time Root paints it: a pointer or key step snaps, and a
* commit asks the follower's commit classifier. A follower calls the result first in every paint,
* before it decides whether it shows, so the classifier sees every commit.
*
* @param update - Root's current update.
* @param plot - Root's current measurement.
* @param space - The coordinate space the follower's numbers live in, as `useCommitMotion` reads it.
* @param frame - The frame the follower draws in, as `useCommitMotion` reads it.
* @returns The placement for a paint's cause. A follower with a mark to join, its anchor and the
*   follower's numbers from that mark's, joins the mark's tween in every paint, a step's or a
*   commit's, or snaps where the mark rests, so it draws on its bar or its vertex whatever it drew
*   before, as when it steps onto a bar mid-update or shows again.
*/
function useFollowerPlacement(update, plot, space, frame) {
	const commit = useCommitMotion(update, plot, space, frame);
	return (cause, join) => {
		const placement = cause === "step" ? { kind: "snap" } : placementOf(commit());
		return join === void 0 ? placement : {
			kind: "join",
			leads: join.leads
		};
	};
}
export { placementOf, useCommitMotion, useFirstDraw, useFollowerPlacement, useMotionMark };

//# sourceMappingURL=chart-motion-mark.js.map