"use client";
import { useChartReadout } from "./chart-readout.js";
import { useLayoutEffect, useRef } from "react";
// src/components/chart/chart-followers.ts
/**
* The marks that follow the active slot: the crosshair, the active bar overlays, ActiveValue and
* ActiveValueLine. Each one registers a paint function with Root, and Root calls them with the
* active slot on every pointer or key step, so a step writes attributes and renders nothing in
* React. Every commit calls them once more after Root has carried the active slot over to new data,
* and each follower asks the shared commit classifier how to get there, so it moves with the bars
* on a data update and snaps on a range step or an orientation change.
*/
/**
* Create a Root's follower registry. Root paints it on every pointer or key step and after every
* commit, so the slot it last painted is the current one.
*
* @returns The registry.
*/
function createChartFollowers() {
	const followers = /* @__PURE__ */ new Set();
	let current = null;
	let queued = false;
	const flush = () => {
		queued = false;
		for (const follower of followers) {
			if (!follower.stale) continue;
			follower.stale = false;
			follower.paint(current, "commit");
		}
	};
	return {
		add(follower) {
			followers.add(follower);
			return () => {
				followers.delete(follower);
			};
		},
		invalidate(follower) {
			follower.stale = true;
			if (queued) return;
			queued = true;
			queueMicrotask(flush);
		},
		refresh() {
			for (const follower of followers) this.invalidate(follower);
		},
		paint(active, cause) {
			current = active;
			for (const follower of followers) {
				follower.stale = false;
				follower.paint(active, cause);
			}
		}
	};
}
/**
* Follow the active slot. The paint function may change on every render, and the latest one paints.
*
* @param part - The calling part's display name.
* @param paint - Draws the follower.
* @returns A repaint of this follower as a commit, for a change that renders nothing, such as a
*   font that loads.
*/
function useChartFollower(part, paint) {
	const { followers } = useChartReadout(part);
	const follower = useRef({
		paint,
		stale: true
	});
	useLayoutEffect(() => {
		follower.current.paint = paint;
		followers.invalidate(follower.current);
	});
	useLayoutEffect(() => followers.add(follower.current), [followers]);
	return () => {
		followers.invalidate(follower.current);
	};
}
export { createChartFollowers, useChartFollower };

//# sourceMappingURL=chart-followers.js.map