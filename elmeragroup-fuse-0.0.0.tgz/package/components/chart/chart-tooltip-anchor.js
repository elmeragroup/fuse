"use client";
import { WHOLE_BAND, barSpan, centreOf, optionBand } from "./layout/plot-frame.js";
import { useChartRoot } from "./chart-context.js";
import { clientScale, writeStyle } from "./chart-dom.js";
import { useRootFrame } from "./chart-plot.js";
import { useCartesianPick } from "./chart-pick.js";
import { glidePath, roofRest, tooltipSideOffset } from "./layout/tooltip-place.js";
import { viewportSize } from "./chart-tooltip-popup.js";
import { roofOver } from "./layout/tooltip-roof.js";
import { createChartRoof } from "./chart-tooltip-roof.js";
import { useCallback, useMemo, useState } from "react";
// src/components/chart/chart-tooltip-anchor.ts
/**
* Where a cartesian tooltip rests. On a vertical chart the popup centres on the active slot, held
* inside the chart Root's box, and rests 8 px above the highest mark under its own width: bars,
* stack tops, line and area strokes between readings, and dots. A step that raises it raises it over
* the whole span it travels, and a step that would lower it by 16 px or less keeps its height. Under
* `anchor="top"` and with Panels it keeps the plot's top lane, and on a horizontal chart it sits
* above or below the active row. A step's glide follows the roof, so it clears every mark on the way.
*/
const STRAIGHT = { kind: "straight" };
/** The popup's resting place at a slot, which remembers it as the next step's start. */
function restAt(memory, slot, place) {
	if (memory.slot !== slot) {
		memory.from = memory.last;
		memory.slot = slot;
	}
	const rest = place(memory.from);
	memory.last = rest;
	return rest;
}
/**
* The cartesian tooltip's anchor over the active slot, measured from the plot surface at position
* time.
*
* @param input - The tooltip's active slot, positioner, placement and measure count.
* @returns The anchor.
*/
function useCartesianTooltipAnchor(input) {
	const { active: slot, positioner, placement, measures } = input;
	const context = useChartRoot("Chart.Tooltip");
	const { store, model, id, xScale, orientation, root: rootOf, motion, riders } = context;
	const window = model.window;
	const drawn = useRootFrame("Chart.Tooltip");
	const pick = useCartesianPick(context, "Chart.Tooltip");
	const [memory] = useState(() => ({
		slot: null,
		from: null,
		last: null
	}));
	const [roofs] = useState(createChartRoof);
	const roofed = placement === "point" && orientation === "vertical" && context.panels.length === 0;
	const virtual = useMemo(() => {
		if (slot === null || window === null || drawn === null) return null;
		const { frame, metrics } = drawn;
		const position = slot - window.first;
		const surfaceOf = () => document.getElementById(`${id}-surface`);
		const measure = () => {
			const surface = surfaceOf()?.getBoundingClientRect();
			if (surface === void 0) return {
				box: new DOMRect(),
				shift: 0,
				route: STRAIGHT
			};
			const { box } = frame;
			const scaleX = box.width === 0 ? 1 : surface.width / box.width;
			const scaleY = box.height === 0 ? 1 : surface.height / box.height;
			const client = (x, y, width, height) => new DOMRect(surface.left + x * scaleX, surface.top + y * scaleY, width * scaleX, height * scaleY);
			const along = () => {
				if (xScale === "point") {
					const centre = centreOf(frame, position, "point");
					return [centre, centre];
				}
				if (orientation === "vertical") return optionBand(frame, position, "band");
				return barSpan(frame, position, metrics, WHOLE_BAND);
			};
			const [start, end] = along();
			if (orientation === "horizontal") return {
				box: client(0, start, box.width, end - start),
				shift: 0,
				route: STRAIGHT
			};
			const root = roofed ? rootOf() : null;
			if (root === null) return {
				box: client(start, 0, end - start, box.height),
				shift: 0,
				route: STRAIGHT
			};
			const outer = root.getBoundingClientRect();
			const width = (positioner.current?.getBoundingClientRect() ?? new DOMRect()).width / scaleX;
			const centre = (start + end) / 2;
			const plotX = (x) => (x - surface.left) / scaleX;
			const within = [plotX(outer.left), plotX(outer.right)];
			const viewport = viewportSize();
			const profile = roofs.read({
				root,
				surface,
				scale: {
					x: scaleX,
					y: scaleY
				},
				stretch: [Math.min(0, within[0]), Math.max(box.width, within[1])],
				frame,
				motion,
				riders
			});
			const roof = (spanStart, spanEnd) => roofOver(profile, spanStart, spanEnd);
			const rest = restAt(memory, slot, (from) => roofRest({
				centre,
				width,
				within,
				viewport: [plotX(8), plotX(viewport.width - 8)],
				roof,
				floor: box.height,
				from
			}));
			const column = client(start, rest.bottom, end - start, box.height - rest.bottom);
			const node = positioner.current;
			if (node !== null) {
				const bridge = Math.max(0, -rest.bottom) * scaleY / clientScale(node).x;
				writeStyle(node, "--_bridge", `${String(bridge)}px`);
			}
			const clientRoof = (left, right) => {
				const top = roof(plotX(left), plotX(right));
				return top === null ? null : surface.top + top * scaleY;
			};
			return {
				box: column,
				shift: (rest.left + width / 2 - centre) * scaleX,
				route: {
					kind: "path",
					turns: (from, to, size, side) => side === "top" ? glidePath(from, to, size, clientRoof, 8) : [from, to]
				}
			};
		};
		let latest = null;
		return {
			getBoundingClientRect: () => {
				latest = measure();
				return latest.box;
			},
			get contextElement() {
				return surfaceOf() ?? void 0;
			},
			placed: () => latest ?? measure()
		};
	}, [
		slot,
		window,
		xScale,
		model,
		roofed,
		id,
		orientation,
		drawn,
		rootOf,
		motion,
		roofs,
		measures
	]);
	const revision = useMemo(() => ({
		model,
		drawn
	}), [model, drawn]);
	const forget = useCallback((reason) => {
		roofs.forget();
		if (reason === "closed") {
			memory.slot = null;
			memory.from = null;
			memory.last = null;
		}
	}, [roofs, memory]);
	const watch = useCallback((again) => {
		const root = rootOf();
		if (!roofed || root === null) return void 0;
		const measureAgain = () => {
			roofs.forget();
			again();
		};
		const unwatch = roofs.watch(root, measureAgain, () => motion.running());
		let frame = 0;
		if (motion.running()) frame = requestAnimationFrame(function landing() {
			if (motion.running()) frame = requestAnimationFrame(landing);
			else measureAgain();
		});
		return () => {
			unwatch();
			cancelAnimationFrame(frame);
		};
	}, [
		roofed,
		motion,
		model,
		drawn,
		roofs,
		rootOf
	]);
	const freezes = (from, to, side) => {
		const start = pick(from.x, from.y);
		const dx = Math.abs(to.x - from.x);
		const dy = Math.abs(to.y - from.y);
		const toward = side === "top" || side === "bottom" ? dy > dx : dx > dy;
		return start !== null && start.slot === store.get().active && toward;
	};
	const sideOffset = (placed, size) => virtual === null ? 0 : tooltipSideOffset(placed, virtual.placed().box, size, viewportSize());
	const alignOffset = (placed, node) => {
		if (virtual === null || placed !== "top" && placed !== "bottom") return 0;
		const mirror = getComputedStyle(node).direction === "rtl" ? -1 : 1;
		return virtual.placed().shift / clientScale(node).x * mirror;
	};
	return {
		virtual,
		side: "top",
		bridge: roofed,
		revision,
		forget,
		watch,
		freezes,
		sideOffset,
		alignOffset
	};
}
export { useCartesianTooltipAnchor };

//# sourceMappingURL=chart-tooltip-anchor.js.map