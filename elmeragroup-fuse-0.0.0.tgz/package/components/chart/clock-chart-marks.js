"use client";
import { useSvgIdPrefix } from "./chart-dom.js";
import { clockDrawingIn, usePolarContext } from "./chart-polar-context.js";
import { stackedScaleError } from "./chart-paint.js";
import { PATH_GLOW, valueGlow } from "./chart-glow-filter.js";
import { viewBoxOf } from "./layout/polar-angle.js";
import { clockArea, clockLine, entranceFrame } from "./layout/clock-path.js";
import { PolarHatch } from "./chart-polar-hatch.js";
import { usePolarCommit, usePolarMark } from "./chart-polar-motion.js";
import { DIAL_REGION, assertClockBaseline, paintOf, retuneGlow, useClockPlacement, useClockSeries, useSeriesCurve, writeParts, writeReveal } from "./clock-chart-part.js";
import { useLayoutEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/clock-chart-marks.tsx
/**
* The clock's curves. Line and Area each draw one series as a mark of its own on the Root's loop,
* whose numbers are a progress and each slot's start and end angle, base radius and tip. The
* entrance runs the progress over 1.25 s: a clockwise wedge opens over 750 ms and each slot rises
* from its base over 500 ms on an ease-out cubic as the wedge reaches it. An update moves every
* number over 480 ms, and a switch between 24- and 25-hour days pairs the slots by their start
* instants, so the slot angles tween and the dial turns rather than cut chords. A Line or an Area
* painted by value paints through a radial gradient centred on the dial with a hard stop at each
* threshold's radius. Column, Dots, Marker, ValueLabel, ActiveDot and Glow live in their own
* modules, so a route that names one part ships only its own.
*/
/** Draw a line's frame. */
function drawLine(group, look, values) {
	const frame = entranceFrame(values);
	const { solid, marked, lone } = clockLine(frame.values, look.series.slots, look.curve);
	writeParts(group, /* @__PURE__ */ new Map([
		["solid", solid],
		["marked", marked],
		["lone", lone]
	]));
	writeReveal(group, frame.reveal);
}
/** Draw an area's frame. */
function drawArea(group, look, values) {
	look.drawn.current = values;
	const frame = entranceFrame(values);
	const { solid, marked } = clockArea(frame.values, look.series.slots, look.curve, look.columns.current);
	writeParts(group, /* @__PURE__ */ new Map([["solid", solid], ["marked", marked]]));
	writeReveal(group, frame.reveal);
}
/** A line's paths at rest. */
function lineAtRest(series, curve) {
	const { solid, marked, lone } = clockLine(series.rest, series.slots, curve);
	return /* @__PURE__ */ new Map([
		["solid", solid],
		["marked", marked],
		["lone", lone]
	]);
}
/** An area's paths at rest. */
function areaAtRest(series, curve) {
	const { solid, marked } = clockArea(series.rest, series.slots, curve);
	return /* @__PURE__ */ new Map([["solid", solid], ["marked", marked]]);
}
/** The radial gradient a series painted by value strokes or fills with, hard at each step's radius. */
function StepGradient({ id, series }) {
	const steps = series.steps;
	if (steps === null) return null;
	return /* @__PURE__ */ jsx("radialGradient", {
		id,
		gradientUnits: "userSpaceOnUse",
		cx: "0",
		cy: "0",
		r: "1",
		"data-steps": "",
		children: steps.flatMap(({ paint, from }, index) => {
			const to = steps[index + 1]?.from ?? 1;
			return [/* @__PURE__ */ jsx("stop", {
				offset: Math.min(1, from),
				style: { "--_stop": paint }
			}, `${String(index)}-from`), /* @__PURE__ */ jsx("stop", {
				offset: Math.min(1, to),
				style: { "--_stop": paint }
			}, `${String(index)}-to`)];
		})
	});
}
/** The paint a role list's line strokes: a diagonal gradient across its box. */
function RoleGradient({ id, stops }) {
	return /* @__PURE__ */ jsx("linearGradient", {
		id,
		x1: "0",
		y1: "0",
		x2: "1",
		y2: "1",
		children: stops.map((stop, index) => /* @__PURE__ */ jsx("stop", {
			offset: stops.length < 2 ? 0 : index / (stops.length - 1),
			style: { "--_stop": stop }
		}, index))
	});
}
/** One series layer bound to the loop: its svg, its paint servers, its clip and its drawing group. */
function SeriesLayer({ dataSlot, part, dataKey, variant, curve, draw, rest, halo, className, style, children, areaVariant }) {
	const { polar, clock, series } = useClockSeries(part, dataKey);
	const color = clock.text.config[dataKey]?.color;
	if (series !== void 0 && color !== void 0) {
		const error = stackedScaleError(part, color, series.stack !== void 0, clock.stackOffset);
		if (error !== null) throw error;
	}
	const columns = useRef(void 0);
	const drawn = useRef(null);
	const look = useMemo(() => series === void 0 ? null : {
		series,
		clock,
		curve,
		columns,
		drawn
	}, [
		series,
		clock,
		curve
	]);
	const { ref, place, node: anchor, drawn: drawnFrame } = usePolarMark(polar.motion, writeLook(draw), look);
	const commit = usePolarCommit(polar, anchor);
	useClockPlacement(clock, series, look, {
		commit,
		place,
		drawn: drawnFrame
	});
	const prefix = useSvgIdPrefix("clock-chart-series");
	const glow = series === void 0 ? null : valueGlow(paintOf(clock, series), prefix, halo);
	const [first] = useState(() => series === void 0 ? /* @__PURE__ */ new Map() : rest(series, curve));
	const svg = useRef(null);
	const glowing = glow !== null;
	useLayoutEffect(() => {
		const node = svg.current;
		if (node === null || !glowing) return void 0;
		const read = () => {
			const width = polar.box.right - polar.box.left;
			retuneGlow(node, width > 0 ? node.getBoundingClientRect().width / width : 0, halo);
		};
		read();
		const observer = new ResizeObserver(read);
		observer.observe(node);
		return () => {
			observer.disconnect();
		};
	}, [
		polar.box,
		glowing,
		halo
	]);
	useLayoutEffect(() => {
		const node = svg.current;
		if (node === null || look === null) return void 0;
		const read = () => {
			const width = polar.box.right - polar.box.left;
			const radius = width > 0 ? node.getBoundingClientRect().width / width : 0;
			const count = radius > 0 ? Math.round(2 * Math.PI * radius * (window.devicePixelRatio || 1)) : void 0;
			if (count === columns.current) return;
			columns.current = count;
			const group = anchor();
			if (group !== null && drawn.current !== null) draw(group, look, drawn.current);
		};
		read();
		const observer = new ResizeObserver(read);
		observer.observe(node);
		return () => {
			observer.disconnect();
		};
	}, [
		polar.box,
		look,
		draw,
		anchor
	]);
	const paint = series === void 0 ? "currentColor" : series.steps !== null ? `url(#${prefix}-steps)` : series.stops !== void 0 ? `url(#${prefix}-role)` : series.paint;
	return /* @__PURE__ */ jsxs("svg", {
		ref: svg,
		"data-slot": dataSlot,
		"data-variant": variant,
		"data-clock-series": "",
		"data-paint": glow === null ? void 0 : "value",
		"data-polar-layer": "",
		"data-polar-mark": "",
		"aria-hidden": "true",
		focusable: "false",
		viewBox: viewBoxOf(polar.box),
		className,
		style: {
			"--chart-series": series?.index ?? 0,
			"--_paint": paint,
			"--_base": series?.paint ?? "currentColor",
			"--_quality": `url(#${prefix}-quality)`,
			"--_look": `url(#${prefix}-look)`,
			"--_glow": glow?.url,
			...style
		},
		children: [/* @__PURE__ */ jsxs("defs", { children: [
			series === void 0 ? null : /* @__PURE__ */ jsx(StepGradient, {
				id: `${prefix}-steps`,
				series
			}),
			series?.stops === void 0 ? null : /* @__PURE__ */ jsx(RoleGradient, {
				id: `${prefix}-role`,
				stops: series.stops
			}),
			/* @__PURE__ */ jsx(PolarHatch, {
				id: `${prefix}-quality-stripes`,
				paint: "var(--_quality-ink)"
			}),
			/* @__PURE__ */ jsx("mask", {
				id: `${prefix}-quality`,
				maskUnits: "userSpaceOnUse",
				x: "-1.5",
				y: "-1.5",
				width: "3",
				height: "3",
				children: /* @__PURE__ */ jsx("rect", {
					x: "-1.5",
					y: "-1.5",
					width: "3",
					height: "3",
					fill: `url(#${prefix}-quality-stripes)`
				})
			}),
			glow?.filter(DIAL_REGION),
			/* @__PURE__ */ jsx("clipPath", {
				id: `${prefix}-reveal`,
				children: /* @__PURE__ */ jsx("path", {
					"data-part": "reveal",
					d: ""
				})
			}),
			areaVariant === void 0 ? null : /* @__PURE__ */ jsx(AreaMask, {
				id: `${prefix}-look`,
				variant: areaVariant,
				clock
			})
		] }), /* @__PURE__ */ jsx("g", {
			ref,
			"data-clip": `url(#${prefix}-reveal)`,
			children: children(first)
		})]
	});
}
/** A loop writer over a look that may be null before the series exists. */
function writeLook(draw) {
	const known = writers.get(draw);
	if (known !== void 0) return known;
	const made = (group, look, values) => {
		if (look !== null) draw(group, look, values);
	};
	writers.set(draw, made);
	return made;
}
const writers = /* @__PURE__ */ new Map();
/**
* One series as a curve round the dial, through d3's curve in unrolled angle and radius, so a run of
* equal values draws an arc. The loop closes across 12 o'clock when both end slots hold readings.
* A missing reading leaves a gap unless the series' config sets `missing: "connect"`, which
* bridges it dashed, and the segments that touch an estimated or projected reading dash too. A
* series painted by a threshold or a scale strokes through a radial gradient that turns hard at each
* threshold's radius.
*
* @beta
*/
function ClockChartLine({ dataKey, variant = "default", curve = "monotone", className, style }) {
	const polar = usePolarContext("ClockChart.Line", ["clock"]);
	useSeriesCurve(polar.motion, dataKey, curve, "line");
	return /* @__PURE__ */ jsx(SeriesLayer, {
		dataSlot: "clock-chart-line",
		part: "ClockChart.Line",
		dataKey,
		variant,
		curve,
		draw: drawLine,
		rest: lineAtRest,
		halo: PATH_GLOW,
		className,
		style,
		children: (first) => /* @__PURE__ */ jsxs(Fragment$1, { children: [
			/* @__PURE__ */ jsx("path", {
				"data-slot": "clock-chart-line-path",
				"data-part": "solid",
				d: first.get("solid")
			}),
			/* @__PURE__ */ jsx("path", {
				"data-slot": "clock-chart-line-path",
				"data-part": "marked",
				d: first.get("marked")
			}),
			/* @__PURE__ */ jsx("path", {
				"data-slot": "clock-chart-line-path",
				"data-part": "lone",
				d: first.get("lone")
			})
		] })
	});
}
/** An area's look as a mask over its fill: a ramp along the radius or a texture. */
function AreaMask({ id, variant, clock }) {
	if (variant === "solid") return null;
	if (variant === "gradient" || variant === "gradient-reverse") {
		const zero = Math.min(1, Math.max(clock.inner, clock.radius(0)));
		const [ends, middle] = variant === "gradient" ? ["far", "near"] : ["near", "far"];
		return /* @__PURE__ */ jsxs("mask", {
			id,
			maskUnits: "userSpaceOnUse",
			x: "-1.5",
			y: "-1.5",
			width: "3",
			height: "3",
			children: [/* @__PURE__ */ jsxs("radialGradient", {
				id: `${id}-ramp`,
				gradientUnits: "userSpaceOnUse",
				cx: "0",
				cy: "0",
				r: "1",
				children: [
					/* @__PURE__ */ jsx("stop", {
						offset: clock.inner,
						"data-part": ends
					}),
					/* @__PURE__ */ jsx("stop", {
						offset: zero,
						"data-part": middle
					}),
					/* @__PURE__ */ jsx("stop", {
						offset: "1",
						"data-part": ends
					})
				]
			}), /* @__PURE__ */ jsx("rect", {
				x: "-1.5",
				y: "-1.5",
				width: "3",
				height: "3",
				fill: `url(#${id}-ramp)`
			})]
		});
	}
	const stride = 5 / 100;
	return /* @__PURE__ */ jsxs("mask", {
		id,
		maskUnits: "userSpaceOnUse",
		x: "-1.5",
		y: "-1.5",
		width: "3",
		height: "3",
		children: [/* @__PURE__ */ jsx("pattern", {
			id: `${id}-texture`,
			patternUnits: "userSpaceOnUse",
			width: stride,
			height: stride,
			patternTransform: variant === "hatched" ? "rotate(45)" : void 0,
			children: variant === "dotted" ? /* @__PURE__ */ jsx("circle", {
				cx: stride / 2,
				cy: stride / 2,
				r: stride / 5
			}) : /* @__PURE__ */ jsx("rect", {
				width: stride / 3,
				height: stride
			})
		}), /* @__PURE__ */ jsx("rect", {
			x: "-1.5",
			y: "-1.5",
			width: "3",
			height: "3",
			fill: `url(#${id}-texture)`
		})]
	});
}
/**
* One series as an area between its curve and its base: the zero ring, or the stack under it.
* Filled even-odd, the area changes side where its curve crosses the zero ring, and a closed loop
* fills the band between two rings. The spans beside an estimated or projected reading hatch over
* the fill.
*
* @beta
*/
function ClockChartArea({ dataKey, variant = "gradient", curve = "monotone", className, style }) {
	const { model, motion } = usePolarContext("ClockChart.Area", ["clock"]);
	assertClockBaseline(clockDrawingIn(model, "ClockChart.Area"), "ClockChart.Area", "a band");
	useSeriesCurve(motion, dataKey, curve, "area");
	return /* @__PURE__ */ jsx(SeriesLayer, {
		dataSlot: "clock-chart-area",
		part: "ClockChart.Area",
		dataKey,
		variant,
		curve,
		draw: drawArea,
		rest: areaAtRest,
		halo: PATH_GLOW,
		className,
		style,
		areaVariant: variant,
		children: (first) => /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("path", {
			"data-slot": "clock-chart-area-path",
			"data-part": "solid",
			d: first.get("solid")
		}), /* @__PURE__ */ jsx("path", {
			"data-slot": "clock-chart-area-path",
			"data-part": "marked",
			d: first.get("marked")
		})] })
	});
}
Object.assign(ClockChartLine, { displayName: "ClockChart.Line" });
Object.assign(ClockChartArea, { displayName: "ClockChart.Area" });
export { ClockChartArea, ClockChartLine };

//# sourceMappingURL=clock-chart-marks.js.map