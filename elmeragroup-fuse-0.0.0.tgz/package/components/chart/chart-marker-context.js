"use client";
import { createContext } from "react";
// src/components/chart/chart-marker-context.ts
/**
* The marker a clock ValueLabel sits beside, in a light leaf of its own, so every Root's own scope
* resets it without importing the clock's placement or geometry.
*/
/**
* The marker a clock ValueLabel sits beside: its series, the slots it marks and the labels its
* ValueLabels register in, so its writer flags them while its dots move. A Marker sets it for
* its children, and every Root's own scope resets it, so a nested Root's ValueLabel never reads an
* outer chart's Marker.
*/
const ClockMarkerContext = createContext(null);
export { ClockMarkerContext };

//# sourceMappingURL=chart-marker-context.js.map