"use client";
import { useChartStore } from "./chart-store.js";
import { useChartReadout } from "./chart-readout.js";
import { writeStyle } from "./chart-dom.js";
import { PolarContext } from "./chart-polar-context.js";
import { inTriangle, laneNeed, laneRest, laneSide, laneWidth, laneY, nearEdge } from "./layout/polar-lane.js";
import { use, useCallback, useLayoutEffect, useMemo, useRef, useState } from "react";
// src/components/chart/chart-polar-anchor.ts
/**
* Where a polar tooltip rests. The popup sits in a side lane beside the dial, outside the labels
* past the rim and inside the Root's figure, centred on the active ray's height at the rim, or below
* or above the dial, and every lane stays inside the viewport where any lane can hold it
* (`laneRest`). The scene is measured again on a resize of the figure, the popup or the viewport and
* on any scroll, once per frame, so a scroll or a resize moves the popup to a lane that fits. A step
* moves it with the Root's angle follower: the popup rests at the target ray's height and shows the
* follower's height through a vertical `translate`, so the popup, the hand and the dots move as one.
* A change of lane fades the popup in over 120 ms instead of travelling, and so does a step that
* leaps across the dial faster than the pointer's pace. A side lane takes the popup only when its
* room holds the popup's content, so no value is cut; the positioner takes the lane's width, and
* the popup fills it, so new text never makes Base UI place it again. A popup stays transparent
* until Base UI has placed it in its lane and its item has been active at two frame checks, so its
* first frame never paints elsewhere. A pointer that moves toward the popup past the rim, inside the
* triangle from where it left the plot to the popup's near edge, keeps the active part.
*/
const STRAIGHT = { kind: "straight" };
/**
* The labels a lane stays outside of, past the rim: angle, outside pie, Now, reference, value and
* ring-value labels, such as a radar's "200" hanging below the rim at 6 o'clock.
*/
const LABELS = "[data-slot$=\"angle-label\"], [data-slot=\"pie-chart-label\"], [data-slot=\"clock-chart-now\"] [data-part=\"label\"], [data-slot$=\"value-label\"], [data-slot$=\"reference-label\"], [data-slot$=\"radius-label\"]";
/**
* The Root's own controls, which the bottom lane rests below and a side lane above, so the popup
* never covers the control a pointer reaches for next.
*/
const CONTROLS = "[data-slot=\"chart-legend\"], [data-slot=\"chart-legend-toggle-group\"], [data-slot=\"chart-table-toggle\"]";
/** How a lane switch fades the popup in. */
const LANE_FADE = {
	duration: 120,
	easing: "cubic-bezier(0.23, 1, 0.32, 1)"
};
/**
* The opacity a lane change or a leap fades the popup in from: never blank, so the readout never
* blinks out between two items.
*/
const LANE_FADE_FROM = .5;
/** The most frames a popup waits, transparent, for Base UI to place it in its lane. */
const PLACE_FRAMES = 6;
/** The popup inside a positioner. */
function popupOf(positioner) {
	return positioner?.querySelector("[data-slot=\"chart-tooltip\"]") ?? null;
}
/** One canvas the label measures share, made on first use. */
let measuring;
/**
* The label any item prints that is widest in the popup's label font, measured once per readout and
* font, or null for a popup with no label line.
*/
function widestLabel(label, readout, cache) {
	if (readout.window === null) return null;
	if (measuring === void 0) measuring = document.createElement("canvas").getContext("2d");
	if (measuring === null) return null;
	const style = getComputedStyle(label);
	const font = `${style.fontStyle} ${style.fontWeight} ${style.fontSize} ${style.fontFamily}`;
	if (cache.current?.readout !== readout || cache.current.font !== font) {
		measuring.font = font;
		let text = "";
		let width = -1;
		for (let index = readout.window.first; index <= readout.window.last; index += 1) {
			const next = readout.activeLabel(index, void 0);
			const measured = measuring.measureText(next).width;
			if (measured > width) {
				width = measured;
				text = next;
			}
		}
		cache.current = {
			readout,
			font,
			text
		};
	}
	return cache.current.text;
}
/**
* The widest the popup's content will be on any step: its max-content width with the widest item
* label in place of the current one, wherever the popup prints it, in the label line and in the rows
* that name the item, each in its own font. A popup's lines are its item's label and rows that name
* it, so its width follows the label, and a lane chosen for the widest label never has to change
* for a longer one later. The text goes back before the measure returns, in the same task, so
* nothing paints it and React's text nodes end as they were.
*
* @param popup - The popup.
* @param readout - The Root's readout, whose items' labels the popup prints.
* @param cache - The widest label measured last.
* @returns The width in CSS pixels.
*/
function widestContent(popup, readout, cache) {
	const label = popup?.querySelector("[data-slot=\"chart-tooltip-label\"]");
	if (popup == null || label == null) return contentWidth(popup ?? null);
	const now = label.textContent;
	const widest = widestLabel(label, readout, cache);
	if (widest === null || widest === now || now === "") return contentWidth(popup);
	const swapped = [];
	const walker = document.createTreeWalker(popup, NodeFilter.SHOW_TEXT);
	for (let node = walker.nextNode(); node !== null; node = walker.nextNode()) if (node instanceof Text && node.data === now) swapped.push(node);
	for (const node of swapped) node.data = widest;
	const width = contentWidth(popup);
	for (const node of swapped) node.data = now;
	return width;
}
/**
* The popup's max-content width, its widest unwrapped line with its padding, measured by lifting its
* width for one forced layout and putting it back.
*/
function contentWidth(popup) {
	if (popup === null) return 0;
	const { width, maxWidth, minWidth } = popup.style;
	popup.style.setProperty("width", "max-content");
	popup.style.setProperty("max-width", "none");
	popup.style.setProperty("min-width", "0");
	const style = getComputedStyle(popup);
	const sides = style.boxSizing === "border-box" ? 0 : Number.parseFloat(style.paddingLeft) + Number.parseFloat(style.paddingRight) + Number.parseFloat(style.borderLeftWidth) + Number.parseFloat(style.borderRightWidth);
	const used = Number.parseFloat(style.width);
	const measured = Number.isFinite(used) ? Math.ceil(used + sides - .001) : popup.offsetWidth;
	popup.style.setProperty("width", width);
	popup.style.setProperty("max-width", maxWidth);
	popup.style.setProperty("min-width", minWidth);
	return measured;
}
/**
* Place the popup in its lane. Base UI puts the popup's corner at the lane's anchor: a side lane's
* top at the dial's height, the bottom or top lane's left at its bounds' left, the figure cut to
* the visible area. The positioner's own `translate`, which composes with the `transform` Base UI
* writes and which no open or close animation touches, then centres it by its own size in CSS, so
* new text keeps it centred in the same frame: a side lane's popup on the height of the ray at the
* follower's angle, so it moves with the hand and the dots, and the bottom lane's on the dial, each
* clamped into the figure by the size measured last. A pie's or a radial chart's side lane rests at
* the dial's height. Reduced motion snaps the follower, so the popup shows the target's height at
* once.
*/
function shiftPopup(positioner, lane, shown) {
	if (positioner === null || lane === null) return;
	const { radius } = lane.scene;
	const { bounds } = lane;
	const { width, height } = lane.size;
	if (lane.side === "bottom" || lane.side === "top") {
		const left = Math.min(bounds.right - width, Math.max(bounds.left, -width / 2));
		const x = left === -width / 2 ? `calc(${(-bounds.left).toFixed(2)}px - 50%)` : `${(left - bounds.left).toFixed(2)}px`;
		writeStyle(positioner, "translate", `${x} 0px`);
		return;
	}
	const dial = {
		centre: {
			x: 0,
			y: 0
		},
		radius
	};
	const angle = !lane.turns ? 90 : lane.holds ? lane.angle : shown ?? lane.angle;
	const middle = laneY(angle, dial, height, bounds);
	writeStyle(positioner, "translate", `0px calc(${middle.toFixed(2)}px - 50%)`);
}
/** The smallest box holding a box and another, or the box alone. */
function union(into, box) {
	return into === null ? box : {
		left: Math.min(into.left, box.left),
		top: Math.min(into.top, box.top),
		right: Math.max(into.right, box.right),
		bottom: Math.max(into.bottom, box.bottom)
	};
}
/** A box moved by an offset. */
function shifted(box, x, y) {
	return {
		left: box.left + x,
		top: box.top + y,
		right: box.right + x,
		bottom: box.bottom + y
	};
}
/** Whether a box reaches past a circle about the origin. */
function pastRim(box, radius) {
	return [box.left, box.right].some((x) => [box.top, box.bottom].some((y) => Math.hypot(x, y) > radius));
}
/**
* The union of the boxes of some elements, each moved by an offset, skipping an element that is
* missing or draws no box, and one `keep` turns down.
*
* @param nodes - The elements, null where one is missing.
* @param x - The offset to the right.
* @param y - The offset down.
* @param keep - Whether a moved box counts, every one by default.
* @returns The union, or null when no box counts.
*/
function unionOf(nodes, x, y, keep = () => true) {
	let into = null;
	for (const element of nodes) {
		const rect = element?.getBoundingClientRect();
		if (rect === void 0 || rect.width === 0 || rect.height === 0) continue;
		const own = shifted(rect, x, y);
		if (keep(own)) into = union(into, own);
	}
	return into;
}
/**
* A polar Root's tooltip anchor in a side lane.
*
* @param input - The tooltip's active option, positioner and measure count.
* @returns The anchor.
*/
function usePolarTooltipAnchor(input) {
	const polar = use(PolarContext);
	if (polar === null) throw new Error("A polar Tooltip renders inside its polar Root, which provides the context.");
	const { model, kernel, box, motion, labelledBy } = polar;
	const readout = useChartReadout("Chart.Tooltip");
	const spread = useRef(null);
	const { active, positioner, measures } = input;
	const near = useChartStore(kernel.store, (snapshot) => snapshot.near);
	const angle = (active === null ? null : model.ray(active, near))?.angle ?? null;
	const surfaceOf = useCallback(() => document.getElementById(`${kernel.id}-surface`), [kernel.id]);
	/** The dial's centre and CSS pixels per unit of the outer radius, in client pixels. */
	const dialOf = useCallback(() => {
		const rect = surfaceOf()?.getBoundingClientRect();
		const width = box.right - box.left;
		if (rect === void 0 || !(width > 0)) return null;
		const scale = rect.width / width;
		return {
			centre: {
				x: rect.left - box.left * scale,
				y: rect.top - box.top * scale
			},
			scale
		};
	}, [surfaceOf, box]);
	const [scene, setScene] = useState(null);
	const widest = useRef(0);
	useLayoutEffect(() => {
		widest.current = 0;
	}, [model]);
	const open = angle !== null;
	useLayoutEffect(() => {
		if (!open) return void 0;
		const measure = () => {
			const dial = dialOf();
			const figure = kernel.root();
			const node = positioner.current;
			if (dial === null || figure === null) return;
			const { x, y } = dial.centre;
			const pop = model.drawing.kind === "pie" ? Number.parseFloat(getComputedStyle(figure).getPropertyValue("--chart-slice-pop")) || 0 : 0;
			const radius = dial.scale + pop;
			const labels = unionOf(figure.querySelectorAll(LABELS), -x, -y, (own) => pastRim(own, dial.scale));
			const controls = unionOf(figure.querySelectorAll(CONTROLS), -x, -y);
			const title = unionOf([...(labelledBy ?? "").split(/\s+/u).filter((id) => id !== "").map((id) => document.getElementById(id)), ...figure.querySelectorAll("[data-slot=\"chart-headline\"]")], -x, -y);
			const visual = window.visualViewport;
			const visibleTop = visual?.offsetTop ?? 0;
			const visibleBottom = visual == null ? window.innerHeight : visual.offsetTop + visual.height;
			const visibleLeft = visual?.offsetLeft ?? 0;
			const visibleRight = visual == null ? window.innerWidth : visual.offsetLeft + visual.width;
			const size = {
				width: node?.offsetWidth ?? 0,
				height: node?.offsetHeight ?? 0
			};
			const popup = popupOf(node);
			widest.current = Math.max(widest.current, widestContent(popup, readout, spread));
			const content = widest.current;
			setScene({
				radius,
				labels,
				controls,
				bounds: shifted(figure.getBoundingClientRect(), -x, -y),
				viewportBottom: visibleBottom - y,
				viewportTop: visibleTop - y,
				viewportLeft: visibleLeft - x,
				viewportRight: visibleRight - x,
				title,
				size,
				content
			});
		};
		measure();
		const sizes = new ResizeObserver(measure);
		const figure = kernel.root();
		if (figure !== null) sizes.observe(figure);
		if (positioner.current !== null) sizes.observe(positioner.current);
		let pending = null;
		const soon = (event) => {
			if (figure !== null && event.target instanceof Node && !event.target.contains(figure)) return;
			pending ??= requestAnimationFrame(() => {
				pending = null;
				measure();
			});
		};
		const passive = { passive: true };
		document.addEventListener("scroll", soon, {
			capture: true,
			passive: true
		});
		window.addEventListener("resize", soon, passive);
		window.visualViewport?.addEventListener("resize", soon, passive);
		window.visualViewport?.addEventListener("scroll", soon, passive);
		return () => {
			sizes.disconnect();
			document.removeEventListener("scroll", soon, { capture: true });
			window.removeEventListener("resize", soon);
			window.visualViewport?.removeEventListener("resize", soon);
			window.visualViewport?.removeEventListener("scroll", soon);
			if (pending !== null) cancelAnimationFrame(pending);
		};
	}, [
		open,
		measures,
		dialOf,
		kernel,
		positioner,
		readout,
		model,
		labelledBy
	]);
	const keepsLane = model.drawing.kind === "radial";
	const turns = model.drawing.kind === "clock" || model.drawing.kind === "radar";
	const [held, setHeld] = useState(null);
	const preferred = angle === null ? null : keepsLane && held !== null ? held : laneSide(angle, held);
	if (preferred !== null && preferred !== held) setHeld(preferred);
	const origin = scene === null ? null : {
		centre: {
			x: 0,
			y: 0
		},
		radius: scene.radius,
		bottom: box.bottom * scene.radius
	};
	const [shownSide, setShownSide] = useState("right");
	const placed = angle === null || preferred === null || scene === null || origin === null ? null : laneRest({
		angle,
		side: preferred,
		dial: origin,
		labels: scene.labels,
		controls: scene.controls,
		size: scene.size,
		bounds: scene.bounds,
		content: scene.content,
		viewportBottom: scene.viewportBottom,
		viewportTop: scene.viewportTop,
		viewportLeft: scene.viewportLeft,
		viewportRight: scene.viewportRight,
		title: scene.title,
		keep: shownSide
	});
	if (placed !== null && placed.side !== shownSide) setShownSide(placed.side);
	const side = placed?.side ?? shownSide;
	const room = placed?.room ?? null;
	const width = placed === null ? null : placed.box.right - placed.box.left;
	const ceiling = placed?.bounds.top ?? null;
	const floor = placed?.bounds.bottom ?? null;
	const leftEdge = placed?.bounds.left ?? null;
	const rightEdge = placed?.bounds.right ?? null;
	const anchorX = placed === null ? null : placed.side === "right" ? placed.box.left : placed.side === "left" ? placed.box.right : leftEdge ?? 0;
	const anchorY = placed === null ? null : placed.side === "bottom" ? placed.box.top : placed.side === "top" ? placed.box.bottom : 0;
	const corner = useRef(null);
	useLayoutEffect(() => {
		corner.current = anchorX === null || anchorY === null ? null : {
			side,
			x: anchorX,
			y: anchorY
		};
	}, [
		side,
		anchorX,
		anchorY
	]);
	const virtual = useMemo(() => {
		if (anchorX === null || anchorY === null) return null;
		const measure = () => {
			const dial = dialOf();
			if (dial === null) return {
				box: new DOMRect(),
				shift: 0,
				route: STRAIGHT
			};
			return {
				box: new DOMRect(dial.centre.x + anchorX, dial.centre.y + anchorY, 0, 0),
				shift: 0,
				route: STRAIGHT
			};
		};
		let latest = null;
		return {
			getBoundingClientRect: () => {
				latest = measure();
				return latest.box;
			},
			get contextElement() {
				return surfaceOf() ?? void 0;
			},
			placed: () => latest ?? measure()
		};
	}, [
		anchorX,
		anchorY,
		dialOf,
		surfaceOf
	]);
	const lane = useRef(null);
	const before = useRef(null);
	const sizing = useRef(null);
	const placing = useRef(null);
	/** The popup and the opacity it showed when its item closed, read before the close commits. */
	const closing = useRef(null);
	/**
	* The lane fade that runs, which a close, a new open or the next fade cancels: a script animation
	* composites above the popup's CSS exit and its hold, so it would run out its 120 ms over either.
	*/
	const fade = useRef(null);
	useLayoutEffect(() => {
		let last = kernel.store.get().active;
		return kernel.store.subscribe(() => {
			const now = kernel.store.get().active;
			if (last !== null && now === null) {
				const popup = popupOf(positioner.current);
				closing.current = popup?.style.opacity === "" ? {
					popup,
					opacity: Number(getComputedStyle(popup).opacity)
				} : null;
			}
			last = now;
		});
	}, [kernel.store, positioner]);
	useLayoutEffect(() => () => {
		if (sizing.current !== null) cancelAnimationFrame(sizing.current);
		if (placing.current !== null) cancelAnimationFrame(placing.current);
	}, []);
	/**
	* Whether Base UI has put the positioner's near edge on the lane's corner: a side lane's inner edge,
	* the bottom lane's top or the top lane's bottom, within a pixel.
	*/
	const onLane = useCallback(() => {
		const node = positioner.current;
		const want = corner.current;
		const dial = dialOf();
		if (node === null || want === null || dial === null) return false;
		const rect = node.getBoundingClientRect();
		const at = want.side === "right" ? rect.left - (dial.centre.x + want.x) : want.side === "left" ? rect.right - (dial.centre.x + want.x) : want.side === "bottom" ? rect.top - (dial.centre.y + want.y) : rect.bottom - (dial.centre.y + want.y);
		return Math.abs(at) <= 1;
	}, [positioner, dialOf]);
	useLayoutEffect(() => {
		if (angle === null) {
			before.current = null;
			fade.current?.cancel();
			fade.current = null;
			const reached = closing.current;
			closing.current = null;
			if (reached !== null && reached.opacity < 1) writeStyle(reached.popup, "opacity", String(reached.opacity));
			return;
		}
		const was = before.current;
		before.current = side;
		const opening = was === null;
		const switched = was !== null && was !== side;
		const last = lane.current;
		const leaped = turns && (side === "right" || side === "left") && (last === null || last.angle !== angle) && kernel.follow.leaps();
		const holds = switched || leaped || last !== null && last.holds && (last.angle === angle || kernel.follow.leaps());
		if (scene !== null) lane.current = {
			angle,
			side,
			scene,
			bounds: ceiling === null || floor === null || leftEdge === null || rightEdge === null ? scene.bounds : {
				top: ceiling,
				bottom: floor,
				left: leftEdge,
				right: rightEdge
			},
			holds,
			turns,
			size: lane.current?.size ?? scene.size
		};
		shiftPopup(positioner.current, lane.current, kernel.follow.shown());
		sizing.current ??= requestAnimationFrame(() => {
			sizing.current = null;
			const node = positioner.current;
			const now = lane.current;
			if (node === null || now === null) return;
			lane.current = {
				...now,
				size: {
					width: node.offsetWidth,
					height: node.offsetHeight
				}
			};
			shiftPopup(node, lane.current, kernel.follow.shown());
			const popup = popupOf(node);
			widest.current = Math.max(widest.current, widestContent(popup, readout, spread));
			const content = widest.current;
			const across = now.side === "bottom" || now.side === "top";
			const outgrows = !across && room !== null && laneNeed(content + 12) > room;
			if (room !== null && width !== null && content > width) writeStyle(node, "width", `${laneWidth(room, content, across ? room : 256).toFixed(2)}px`);
			if (outgrows || width !== null && content > width) setScene((last) => last === null || last.content >= content ? last : {
				...last,
				content
			});
		});
		const node = positioner.current;
		const popup = popupOf(node);
		if (node !== null && width !== null) writeStyle(node, "width", `${width.toFixed(2)}px`);
		if ((switched || leaped) && popup !== null && !motion.reduced()) {
			fade.current?.cancel();
			fade.current = popup.animate([{ opacity: LANE_FADE_FROM }, { opacity: 1 }], LANE_FADE);
		}
		if (opening && popup !== null) {
			if (placing.current !== null) cancelAnimationFrame(placing.current);
			fade.current?.cancel();
			fade.current = null;
			writeStyle(popup, "opacity", "0");
			writeStyle(popup, "pointer-events", "none");
			let frames = 0;
			let survived = 0;
			const check = () => {
				frames += 1;
				if (kernel.store.get().active === null) {
					placing.current = null;
					writeStyle(popup, "pointer-events", null);
					return;
				}
				survived += 1;
				if (survived >= 2 && (onLane() || frames >= PLACE_FRAMES)) {
					placing.current = null;
					writeStyle(popup, "opacity", null);
					writeStyle(popup, "pointer-events", null);
					return;
				}
				placing.current = requestAnimationFrame(check);
			};
			placing.current = requestAnimationFrame(check);
		}
	}, [
		angle,
		side,
		room,
		width,
		ceiling,
		floor,
		leftEdge,
		rightEdge,
		scene,
		turns,
		kernel.follow,
		kernel.store,
		positioner,
		motion,
		onLane,
		readout
	]);
	useLayoutEffect(() => kernel.follow.subscribe((shown) => {
		shiftPopup(positioner.current, lane.current, shown);
	}), [kernel.follow, positioner]);
	const revision = useMemo(() => ({ model }), [model]);
	const forget = useCallback(() => void 0, []);
	const watch = useCallback(() => void 0, []);
	const freezes = (from, to) => {
		const node = positioner.current;
		if (node === null) return false;
		const rect = node.getBoundingClientRect();
		const [a, b] = nearEdge(from, rect);
		return inTriangle(to, from, a, b);
	};
	return {
		virtual,
		side,
		bridge: false,
		revision,
		forget,
		watch,
		freezes,
		sideOffset: () => 0,
		alignOffset: () => 0
	};
}
export { usePolarTooltipAnchor };

//# sourceMappingURL=chart-polar-anchor.js.map