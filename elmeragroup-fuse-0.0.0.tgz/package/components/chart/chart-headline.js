"use client";
import { ChartHeadlineContext } from "./chart-scope-contexts.js";
import { jsx } from "react/jsx-runtime";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
// src/components/chart/chart-headline.tsx
/**
* The key figure above the chart, such as `1,78 kr` over `Spotpris nå 16:00–16:15`. Format a static
* figure with `formatChartValue` and `formatChartSlot`, or place an `ActiveValue`, which is exposed
* text here. The headline's own text takes the theme's heading 2 role, as the Figma Spotpris card
* sets its figure, and every child after the first takes the small muted paragraph role of the
* card's caption.
*
* @beta
*/
function ChartHeadline({ render, className, children, ...props }) {
	const element = useRender({
		defaultTagName: "div",
		render,
		props: {
			"data-slot": "chart-headline",
			...mergeProps({
				className,
				children
			}, props)
		}
	});
	return /* @__PURE__ */ jsx(ChartHeadlineContext, {
		value: true,
		children: element
	});
}
/**
* The takeaway in words, such as `Prisen er lavest kl. 03`. Fuse never writes one and never copies
* it into the description. It takes the theme's default paragraph role.
*
* @beta
*/
function ChartTakeaway({ render, className, children, ...props }) {
	const text = Array.isArray(children) ? children.join("") : String(children);
	return useRender({
		defaultTagName: "p",
		render,
		props: {
			"data-slot": "chart-takeaway",
			...mergeProps({
				className,
				children: text
			}, props)
		}
	});
}
Object.assign(ChartHeadline, { displayName: "Chart.Headline" });
Object.assign(ChartTakeaway, { displayName: "Chart.Takeaway" });
export { ChartHeadline, ChartTakeaway };

//# sourceMappingURL=chart-headline.js.map