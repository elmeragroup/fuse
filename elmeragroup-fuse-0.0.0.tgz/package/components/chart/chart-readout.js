"use client";
import { formatValue } from "./format/value-format.js";
import { ChartLegendSideContext, ChartRowContext } from "./chart-scope-contexts.js";
import { useActivePoint } from "./chart-active-point.js";
import { ChartReadoutContext } from "./chart-readout-port.js";
import { ChartCompositionError } from "./layout/errors.js";
import { use } from "react";
// src/components/chart/chart-readout.ts
/**
* How the shared readout parts read their Root: the hooks over the Root's readout port, which give
* every part the same active index and key the option names. The contexts that say where a part
* sits live in `chart-scope-contexts`, which every Root's own scope resets. A template row supplies
* its own key. The module reads
* no family's model, so a family's route ships only its own.
*/
/**
* The threshold side a Swatch or a SeriesLabel of one series shows: its legend entry's side, or
* null outside a threshold series' legend entry and for a part that shows another series. It
* compares the part's key with the entry's own key, never the nearest row's, so a row of another
* series nested inside the entry keeps that series' paint and label.
*
* @param key - The series the part shows, or null.
* @returns The side, or null.
*/
function useLegendSide(key) {
	const entry = use(ChartLegendSideContext);
	return entry?.key === key ? entry.side : null;
}
/**
* Read the enclosing Root's readout.
*
* @param part - The calling part's display name, which the error names.
* @returns The Root's readout.
* @throws {ChartCompositionError} `part-outside-root` when no Root with a readout encloses the part.
*/
function useChartReadout(part) {
	const readout = use(ChartReadoutContext);
	if (readout === null) throw new ChartCompositionError(part, "part-outside-root", "must be used within a chart's Root. Wrap the chart's parts in Chart.Root, BarChart.Root, AreaChart.Root, LineChart.Root, PieChart.Root, RadialChart.Root, RadarChart.Root or ClockChart.Root.");
	return readout;
}
/**
* The key a readout part prints: its own `dataKey`, else its template row's, else the active
* point's nearest or focused key. An explicit `dataKey` must name a config key.
*
* @param part - The part's display name, which the error names.
* @param readout - The Root's readout.
* @param own - The part's `dataKey`.
* @param near - The active point's key, or null under "all series".
* @returns The key, or null when none applies.
* @throws {ChartCompositionError} `unknown-key` for an explicit key the config lacks.
*/
function useReadoutKey(part, readout, own, near) {
	const row = use(ChartRowContext);
	if (own !== void 0) readout.assertKey(part, own);
	return own ?? row ?? near;
}
/**
* The active index inside the readout's window and the nearest or focused key there, or null.
* Outside a live scope it reads null and never renders on a pointer move, and inside a closing
* tooltip it reads the point the popup held. A part that prints no key reads `useActiveIndex`.
*
* @param readout - The Root's readout.
* @param live - Whether to follow the store, which forces it on for parts such as LegendValue.
* @returns The active index and its key.
*/
function useActiveItem(readout, live) {
	const { index, near } = useActivePoint(readout, live);
	return {
		index,
		key: readout.pointKey(index, near)
	};
}
/**
* A share as a percentage at the format's digits, or the dictionary dash.
*
* @param locale - The Root's locale.
* @param share - The share in percent, or null for a zero denominator.
* @param format - The share's digits.
* @returns The visual text.
*/
function shareText(locale, share, format) {
	if (share === null) return "–";
	return formatValue(locale, share / 100, {
		style: "percent",
		minimumFractionDigits: format?.minimumFractionDigits ?? 0,
		maximumFractionDigits: shareDigits(format)
	}, "full").text;
}
/**
* The share digits of a format, which decide how a share set rounds together.
*
* @param format - The share's digits.
* @returns The fraction digits of the printed percentage.
*/
function shareDigits(format) {
	return format?.maximumFractionDigits ?? format?.minimumFractionDigits ?? 0;
}
export { shareDigits, shareText, useActiveItem, useChartReadout, useLegendSide, useReadoutKey };

//# sourceMappingURL=chart-readout.js.map