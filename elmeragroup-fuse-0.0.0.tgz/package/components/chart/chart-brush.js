"use client";
import { Fragment, jsx } from "react/jsx-runtime";
// src/components/chart/chart-brush.tsx
/**
* Two thumbs and a pan window that edit Root's `xRange`, as three native range inputs with spoken
* value text.
*
* @beta
*/
function ChartBrush(_props) {
	return /* @__PURE__ */ jsx(Fragment, {});
}
/**
* The marks drawn small over the whole domain inside the brush track. The preview is its own
* layout. Its x spans the full domain, and its y domain covers every config key over the full data
* under the default layout's zero rule, whatever the window or the Panels.
*
* @beta
*/
function ChartBrushPreview(_props) {
	return /* @__PURE__ */ jsx(Fragment, {});
}
Object.assign(ChartBrush, { displayName: "Chart.Brush" });
Object.assign(ChartBrushPreview, { displayName: "Chart.BrushPreview" });
export { ChartBrush, ChartBrushPreview };

//# sourceMappingURL=chart-brush.js.map