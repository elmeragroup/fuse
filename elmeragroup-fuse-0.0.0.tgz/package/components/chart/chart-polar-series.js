"use client";
import { countOf } from "../../intl/count-of.js";
import { CHART_STRINGS } from "./format/chart-strings.js";
import { isRoleList, seriesPaint, singleRole } from "./layout/color-key.js";
import { extremesSentence, optionName, slotLabel } from "./chart-text.js";
import { seriesReadoutOf } from "./chart-series-readout.js";
import { pointerAngle } from "./layout/polar-angle.js";
import { POLAR_STRINGS } from "./format/polar-strings.js";
import { nearestHeld } from "./layout/near-series.js";
import { radarDomain, radarRadius, radarVertices, spokeAngle, spokeAt } from "./layout/radar.js";
// src/components/chart/chart-polar-series.ts
/** The most series a radar compares, CONTRACT section 8.4's cap. */
const RADAR_SERIES_CAP = 4;
/** The spoken extremes of each series, the radar description's sentences after its opening. */
function seriesSentences(context) {
	return context.model.series.flatMap(({ key, readings }) => {
		let low = null;
		let high = null;
		for (const [slot, reading] of readings.entries()) {
			if (reading.kind !== "reading") continue;
			if (low === null || reading.value < low.value) low = {
				slot,
				value: reading.value
			};
			if (high === null || reading.value > high.value) high = {
				slot,
				value: reading.value
			};
		}
		return low === null || high === null ? [] : [extremesSentence(context, key, low, high)];
	});
}
/**
* A radar's model: one spoke per category, the series as polygons over a radius domain that never
* clamps a reading, with the cartesian option grammar, the description, the pick by nearest spoke
* and then nearest vertex, and the series table.
*
* @param input - The Root's cartesian model over its spokes, config, rows and props.
* @returns The model.
*/
function radarModel(input) {
	const { model, config, locale, sweep } = input;
	const context = {
		config,
		locale,
		model,
		xFormat: void 0,
		now: void 0
	};
	const strings = CHART_STRINGS[locale];
	const polarStrings = POLAR_STRINGS[locale];
	const count = model.domain.kind === "category" ? model.domain.names.length : 0;
	const values = model.series.flatMap(({ readings }) => readings.flatMap((reading) => reading.kind === "reading" ? [reading.value] : []));
	const { domain, ticks } = radarDomain(values, input.max);
	const radius = radarRadius(domain, 1);
	const vertices = model.series.map(({ readings }) => radarVertices(readings.map((reading) => reading.kind === "reading" ? reading.value : null), radius));
	const keys = model.domain.kind === "category" ? model.domain.names : [];
	const empty = model.empty;
	return {
		family: "radar",
		sweep,
		count,
		keys,
		empty,
		description: empty ? `${strings.noData}.` : [polarStrings.descriptionRadar(countOf(locale, model.series.length, polarStrings.seriesWord), countOf(locale, count, strings.slots.category)), ...seriesSentences(context)].join(" "),
		instructions: "cartesian",
		orientation: "horizontal",
		wrap: true,
		series: model.series.length,
		page: null,
		optionName: (index, focus, order) => optionName(context, index, focus, order),
		pick: (point, pixels) => {
			if (count === 0) return null;
			const spoke = spokeAt(pointerAngle(point.x, point.y), count);
			const gaps = vertices.map((series) => {
				const vertex = series[spoke] ?? null;
				return vertex === null ? null : Math.hypot(vertex.x - point.x, vertex.y - point.y);
			});
			return {
				slot: spoke,
				near: model.series.length > 1 ? nearestHeld(gaps, pixels.near ?? null, pixels.nearFirm === true) : null
			};
		},
		ray: (index) => index < 0 || index >= count ? null : {
			angle: spokeAngle(index, count),
			radius: 1
		},
		selectKey: (_index, focus) => model.series[focus]?.key ?? null,
		selectable: Object.keys(config),
		table: {
			kind: "series",
			context: {
				...context,
				name: input.name,
				rows: input.rows
			},
			keys
		},
		readout: (kernel) => seriesReadout(context, kernel, input.known),
		issues: input.issues,
		drawing: {
			kind: "radar",
			radar: {
				count,
				labels: keys.map((_, index) => slotLabel(context, index)),
				domain,
				ticks,
				zero: domain[0] < 0 ? radius(0) : null,
				series: model.series.map(({ key, readings }, index) => {
					const color = config[key]?.color;
					return {
						key,
						index,
						paint: seriesPaint(key, singleRole(color)),
						stops: color !== void 0 && isRoleList(color) ? color.map((stop) => seriesPaint(key, stop)) : void 0,
						values: readings.map((reading) => reading.kind === "reading" ? reading.value : null),
						qualities: readings.map((reading) => reading.kind === "missing" ? "missing" : reading.kind === "reading" && reading.quality !== "measured" ? reading.quality : void 0)
					};
				}),
				format: config[model.series[0]?.key ?? ""]?.format ?? {}
			}
		}
	};
}
/**
* A series family's readout, a radar's or a clock's: the shared series readout over the family's
* slots, through the polar Root's kernel.
*
* @param context - The family's series model and words.
* @param kernel - The polar Root's kernel.
* @param known - The config a part's dataKey must name, the context's own by default.
* @returns The readout.
*/
function seriesReadout(context, kernel, known = context.config) {
	return seriesReadoutOf(context, {
		id: kernel.id,
		root: kernel.root,
		store: kernel.store,
		followers: kernel.followers,
		select: kernel.select,
		registerToggleGroup: kernel.registerToggleGroup,
		highlight: kernel.highlight,
		warnOnce: kernel.warnOnce,
		usePick: kernel.usePick
	}, { known });
}
export { RADAR_SERIES_CAP, radarModel, seriesReadout };

//# sourceMappingURL=chart-polar-series.js.map