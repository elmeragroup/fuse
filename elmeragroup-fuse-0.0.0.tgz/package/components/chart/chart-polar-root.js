"use client";
import { useMergedRefs } from "../../hooks/use-merged-refs.js";
import { definedProps } from "../../internal/defined-props.js";
import { useReducedMotion } from "../../hooks/use-reduced-motion.js";
import { CHART_STRINGS } from "./format/chart-strings.js";
import { openDrawingSoon, useClientMount } from "./chart-draw-gate.js";
import { createChartStore, useChartStore } from "./chart-store.js";
import { ChartReadoutContext, ChartSelectionContext } from "./chart-readout-port.js";
import { issueKey } from "./layout/errors.js";
import { writeAttribute, writeStyle } from "./chart-dom.js";
import { useEntrance } from "./chart-entrance.js";
import { createChartFollowers } from "./chart-followers.js";
import { CHART_SPRINGS } from "./layout/motion.js";
import { BROWSER_FRAMES, createChartMotion } from "./chart-motion.js";
import { PolarContext } from "./chart-polar-context.js";
import { ChartOwnScope, useChartDepth } from "./chart-own-scope.js";
import { StatusRegion } from "./chart-listbox.js";
import { springEasing } from "./layout/spring.js";
import { leapSpring, stepSpring } from "./chart-spring.js";
import { paintedOf } from "./chart-polar-painted.js";
import { sweepBox } from "./layout/polar-angle.js";
import { POLAR_STRINGS } from "./format/polar-strings.js";
import { entranceSpan } from "./layout/polar-motion.js";
import { createPolarFollow } from "./chart-polar-follow.js";
import { introPace } from "./chart-polar-motion.js";
import { PolarSurface } from "./chart-polar-surface.js";
import { use, useCallback, useEffect, useId, useLayoutEffect, useMemo, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-polar-root.tsx
/**
* The polar Root kernel: what PieChart, RadialChart and RadarChart share under their own model.
* It owns the store, the follower registry, the motion loop and its entrance, the selection, the
* highlight and the warnings, and renders the figure: the description, the instructions, the
* aspect-locked cell with its listbox, the parts and the status region, in CONTRACT section 9.2's
* order. A family hands it a `PolarModel`, which carries the family's geometry, words, pick, table
* and readout, so the kernel never reads a family's data.
*
* First paint: with JavaScript on, every polar mark stays hidden behind the tracks and grid
* until the chart comes into view and its entrance starts, which writes `data-drawn` on the
* figure. With JavaScript off, and in print, the stylesheet shows the full chart.
*/
/** The figure's slot per family, which the stylesheet and the density roles read. */
const SLOTS = {
	pie: { "data-slot": "pie-chart" },
	radial: { "data-slot": "radial-chart" },
	radar: { "data-slot": "radar-chart" },
	clock: { "data-slot": "clock-chart" }
};
/** The spring settle times a radar's grid entrance takes, sampled once. */
const ENTRANCE_SPRINGS = {
	grow: springEasing(CHART_SPRINGS.grow).duration,
	extend: springEasing(CHART_SPRINGS.extend).duration
};
/** What an entrance's span counts: the slices, the rings, or a radar's series, rings and spokes. */
function entranceItems(model) {
	const { drawing } = model;
	if (drawing.kind !== "radar") return {
		family: model.family,
		items: model.count,
		rings: 0,
		spokes: 0
	};
	return {
		family: "radar",
		items: drawing.radar.series.length,
		rings: drawing.radar.ticks.length,
		spokes: drawing.radar.count
	};
}
/** The angle the follower turns to for the active option, or null while none is active. */
function rayAngle(model, active) {
	return active === null ? null : model.ray(active.slot, active.near)?.angle ?? null;
}
/** The active option and series, or null while nothing is active. */
function activeOf(snapshot, count) {
	const { active, near } = snapshot;
	if (active === null || active < 0 || active >= count) return null;
	return {
		slot: active,
		near
	};
}
/** Write the active state onto the figure, where the dim rules read it. */
function markActive(figure, snapshot, active) {
	writeAttribute(figure, "data-active", active === null ? null : snapshot.source ?? "");
	writeAttribute(figure, "data-pinned", snapshot.pinned && active !== null ? "" : null);
	writeAttribute(figure, "data-near", active !== null && snapshot.near !== null ? snapshot.near : null);
	writeAttribute(figure, "data-drawn", snapshot.phase === "started" ? "" : null);
	writeStyle(figure, "--chart-active", active === null ? null : String(active.slot));
	writeStyle(figure, "--chart-near", active === null || snapshot.near === null ? null : String(snapshot.near));
}
/**
* The Root every polar family renders through, as `usePolarRoot` wires it. It never inspects its
* children.
*
* @param props - The family's model, the figure's props, the selection props and the parts.
* @returns The figure.
*/
function PolarRoot(props) {
	const { model, kernel, motion, entrance, update, figureRef, cellRef, selected, strings, figureProps } = usePolarRoot(props);
	const box = useMemo(() => sweepBox(model.sweep), [model.sweep]);
	const labelledBy = props.figure["aria-labelledby"];
	const context = useMemo(() => ({
		model,
		kernel,
		motion,
		box,
		update,
		entrance,
		labelledBy
	}), [
		model,
		kernel,
		motion,
		box,
		update,
		entrance,
		labelledBy
	]);
	const width = box.right - box.left;
	const height = box.bottom - box.top;
	const depth = useChartDepth();
	return /* @__PURE__ */ jsx(ChartOwnScope, { children: /* @__PURE__ */ jsx(PolarContext, {
		value: context,
		children: /* @__PURE__ */ jsx(PolarReadoutScope, { children: /* @__PURE__ */ jsx(ChartSelectionContext, {
			value: selected,
			children: /* @__PURE__ */ jsxs("figure", {
				ref: figureRef,
				...SLOTS[model.family],
				"data-polar": "",
				"data-chart-depth": depth,
				"data-selected": selected === null ? void 0 : "",
				...figureProps,
				children: [
					/* @__PURE__ */ jsx("p", {
						id: `${kernel.id}-description`,
						"data-slot": "chart-description",
						children: props.description ?? model.description
					}),
					/* @__PURE__ */ jsx("p", {
						id: `${kernel.id}-instructions`,
						"data-slot": "chart-instructions",
						children: model.instructions === "polar" ? strings.instructionsPolar : model.instructions === "clock" ? POLAR_STRINGS[kernel.locale].instructionsClock : strings.instructionsCartesian
					}),
					/* @__PURE__ */ jsxs("div", {
						"data-slot": "chart-polar-frame",
						style: {
							"--chart-selected": selected === null ? void 0 : model.selectable.indexOf(selected),
							"--chart-polar-aspect": `${String(width)} / ${String(height)}`
						},
						children: [/* @__PURE__ */ jsxs("div", {
							ref: cellRef,
							"data-slot": "chart-polar-cell",
							children: [/* @__PURE__ */ jsx("svg", {
								"data-slot": "chart-polar-plot",
								"aria-hidden": "true",
								focusable: "false",
								viewBox: `${String(box.left)} ${String(box.top)} ${String(width)} ${String(height)}`
							}), /* @__PURE__ */ jsx(PolarSurface, {})]
						}), props.children]
					}),
					/* @__PURE__ */ jsx(PolarStatus, { store: kernel.store })
				]
			})
		}) })
	}) });
}
/** The Root's status region, which announces what the store says. */
function PolarStatus({ store }) {
	const text = useChartStore(store, (snapshot) => snapshot.announcement.text);
	const count = useChartStore(store, (snapshot) => snapshot.announcement.count);
	return /* @__PURE__ */ jsx(StatusRegion, {
		text,
		count
	});
}
/**
* Provide the family's readout, which the shared parts read the Root through. It changes with the
* model alone, so a pointer move renders no part that reads only the readout.
*/
function PolarReadoutScope({ children }) {
	const polar = use(PolarContext);
	const model = polar?.model;
	const kernel = polar?.kernel;
	const readout = useMemo(() => model === void 0 || kernel === void 0 ? null : model.readout(kernel), [model, kernel]);
	return /* @__PURE__ */ jsx(ChartReadoutContext, {
		value: readout,
		children
	});
}
/**
* Wire a polar Root: its store, followers, loop, entrance, selection, highlight and warnings, and
* the kernel its family's readout closes over.
*
* @param props - The Root's props.
* @returns What the Root renders with.
*/
function usePolarRoot(props) {
	const { model, locale } = props;
	const { ref, ...figure } = props.figure;
	const figureProps = definedProps(figure);
	const name = props.figure["aria-label"];
	const id = useId();
	const [store] = useState(() => createChartStore(props.defaultActive));
	const [followers] = useState(createChartFollowers);
	const reduced = useReducedMotion();
	const entrance = figureProps["data-intro"] !== "none" && !reduced;
	const [motion] = useState(() => {
		const loop = createChartMotion(BROWSER_FRAMES, reduced, () => {
			followers.refresh();
		});
		if (entrance) loop.wait();
		return loop;
	});
	const [follow] = useState(() => createPolarFollow({
		frames: BROWSER_FRAMES,
		reduced: () => motion.reduced(),
		spring: () => stepSpring(store),
		leapSpring,
		maxTurn: (radius) => maxTurn(radius, store)
	}));
	const rootRef = useRef(null);
	const figureRef = useMergedRefs(rootRef, ref);
	const cellRef = useRef(null);
	const strings = CHART_STRINGS[locale];
	const clientMount = useClientMount();
	useLayoutEffect(() => {
		if (clientMount) store.drawing.openNow();
		else openDrawingSoon(store.drawing);
	}, [store, clientMount]);
	useLayoutEffect(() => {
		motion.setReduced(reduced);
		followers.refresh();
	}, [
		motion,
		reduced,
		followers
	]);
	const [seen, setSeen] = useState(model);
	const [update, setUpdate] = useState(() => ({ kind: "initial" }));
	if (seen !== model) {
		setSeen(model);
		setUpdate({ kind: "data" });
	}
	const countRef = useRef(model.count);
	const latestModel = useRef(model);
	const paintedRef = useRef([null, null]);
	useLayoutEffect(() => {
		const cell = cellRef.current;
		if (cell === null) return void 0;
		const read = () => {
			const box = sweepBox(latestModel.current.sweep);
			const width = box.right - box.left;
			follow.measure(width > 0 ? cell.getBoundingClientRect().width / width : 0);
		};
		read();
		const sizes = new ResizeObserver(read);
		sizes.observe(cell);
		return () => {
			sizes.disconnect();
		};
	}, [follow]);
	useLayoutEffect(() => {
		countRef.current = model.count;
		latestModel.current = model;
		const snapshot = store.get();
		if (snapshot.active !== null && snapshot.active >= model.count) store.set({ active: model.count === 0 ? null : model.count - 1 });
		const active = activeOf(store.get(), model.count);
		if (rootRef.current) markActive(rootRef.current, store.get(), active);
		follow.retarget(rayAngle(model, active), "commit");
		followers.paint(active, "commit");
	}, [
		model,
		store,
		followers,
		follow
	]);
	useLayoutEffect(() => store.subscribe(() => {
		const snapshot = store.get();
		const active = activeOf(snapshot, countRef.current);
		if (rootRef.current) markActive(rootRef.current, snapshot, active);
		const [was, near] = paintedRef.current;
		if (snapshot.active === was && snapshot.near === near) return;
		paintedRef.current = [snapshot.active, snapshot.near];
		follow.retarget(rayAngle(latestModel.current, active), "step");
		followers.paint(active, "step");
	}), [
		store,
		followers,
		follow
	]);
	useEntrance(store, motion, rootRef, cellRef, entrance);
	const items = useRef(entranceItems(model));
	const [served] = useState(() => !clientMount);
	const wasEmpty = useRef(model.empty);
	const marking = useRef(() => void 0);
	useLayoutEffect(() => {
		items.current = entranceItems(model);
	});
	const [pacing] = useState(() => ({ kind: "initial" }));
	useLayoutEffect(() => {
		if (!entrance) return void 0;
		const marked = rootRef.current;
		let timer = null;
		const mark = (grow) => {
			const figure = rootRef.current;
			if (figure === null) return;
			if (timer !== null) window.clearTimeout(timer);
			writeAttribute(figure, "data-entering", "");
			writeAttribute(figure, "data-grow", grow ? "" : null);
			const span = entranceSpan(items.current, ENTRANCE_SPRINGS, introPace(figure, pacing));
			timer = window.setTimeout(() => {
				timer = null;
				writeAttribute(figure, "data-entering", null);
				writeAttribute(figure, "data-grow", null);
			}, span);
		};
		marking.current = mark;
		let started = store.get().phase === "started";
		const watch = () => {
			if (started || store.get().phase !== "started") return;
			started = true;
			mark(!served);
		};
		const stop = store.subscribe(watch);
		return () => {
			stop();
			marking.current = () => void 0;
			if (timer === null) return;
			window.clearTimeout(timer);
			if (marked === null) return;
			writeAttribute(marked, "data-entering", null);
			writeAttribute(marked, "data-grow", null);
		};
	}, [
		store,
		entrance,
		served,
		pacing
	]);
	useLayoutEffect(() => {
		const before = wasEmpty.current;
		wasEmpty.current = model.empty;
		if (before && !model.empty && store.get().phase === "started") marking.current(true);
	}, [model.empty, store]);
	const warned = useRef(/* @__PURE__ */ new Set());
	const warnOnce = useCallback((rule, subject, message) => {
		const key = issueKey(rule, subject);
		if (warned.current.has(key)) return;
		warned.current.add(key);
		console.warn(message);
	}, []);
	useEffect(() => {
		for (const { rule, subject, message } of model.issues) warnOnce(rule, subject, message);
	}, [model.issues, warnOnce]);
	const [ownSelected, setOwnSelected] = useState(props.defaultSelectedKey ?? null);
	const requested = props.selectedKey === void 0 ? ownSelected : props.selectedKey;
	const selected = requested !== null && model.selectable.includes(requested) ? requested : null;
	const selection = useRef({
		selected,
		onSelectedKeyChange: props.onSelectedKeyChange,
		labelOf: props.labelOf,
		locale
	});
	useLayoutEffect(() => {
		selection.current = {
			selected,
			onSelectedKeyChange: props.onSelectedKeyChange,
			labelOf: props.labelOf,
			locale
		};
	});
	const select = useCallback((key, reason, event) => {
		const latest = selection.current;
		if (key === latest.selected) return;
		setOwnSelected(key);
		latest.onSelectedKeyChange?.(key, {
			reason,
			event
		});
		const words = CHART_STRINGS[latest.locale];
		store.announce(key === null ? words.selectionCleared : words.selected(latest.labelOf(key)));
	}, [store]);
	const toggleGroups = useRef(0);
	const registerToggleGroup = useCallback(() => {
		toggleGroups.current += 1;
		return () => {
			toggleGroups.current -= 1;
		};
	}, []);
	const hasToggles = useCallback(() => toggleGroups.current > 0, []);
	const getRoot = useCallback(() => rootRef.current, []);
	const hiddenRef = useRef(false);
	useLayoutEffect(() => {
		hiddenRef.current = false;
		return () => {
			hiddenRef.current = true;
		};
	}, []);
	const hidden = useCallback(() => hiddenRef.current, []);
	const keysRef = useRef(model.selectable);
	useLayoutEffect(() => {
		keysRef.current = model.selectable;
	});
	const highlight = useCallback((key) => {
		const root = rootRef.current;
		if (root === null) return;
		const index = key === null ? -1 : keysRef.current.indexOf(key);
		writeAttribute(root, "data-highlight", index === -1 ? null : "");
		writeStyle(root, "--chart-highlight", index === -1 ? null : String(index));
	}, []);
	const modelRef = useRef(model);
	useLayoutEffect(() => {
		modelRef.current = model;
	});
	const usePick = useCallback(() => polarPick(id, modelRef, motion), [id, motion]);
	return {
		model,
		kernel: useMemo(() => ({
			id,
			name,
			locale,
			root: getRoot,
			hidden,
			store,
			followers,
			follow,
			select,
			registerToggleGroup,
			hasToggles,
			highlight,
			warnOnce,
			usePick
		}), [
			id,
			name,
			locale,
			getRoot,
			hidden,
			store,
			followers,
			follow,
			select,
			registerToggleGroup,
			hasToggles,
			highlight,
			warnOnce,
			usePick
		]),
		motion,
		entrance,
		update,
		figureRef,
		cellRef,
		selected,
		strings,
		figureProps
	};
}
/**
* The most CSS pixels a mark on the dial may travel in one frame of a step, by the pointer's speed:
* 8 at 200 px/s or slower, 20 at 800 and 48 at 2,000 or faster, straight between,
* and the fastest for a keyboard step. Each is read at a tenth above its speed, since the speed the
* Root reads from the pointer's events runs a few percent over its true speed. A step that reaches
* far, such as a radar's spoke or a month of a year, glides no faster than the pointer moves it,
* unless it would take longer than the follower's leap allows.
*/
const FRAME_TRAVEL = [
	[220, 8],
	[880, 20],
	[2200, 48]
];
/** CSS pixels a frame may carry a mark at a pointer speed in CSS pixels per second. */
function frameTravel(speed) {
	const [first, ...rest] = FRAME_TRAVEL;
	if (speed <= first[0]) return first[1];
	let previous = first;
	for (const point of rest) {
		if (speed <= point[0]) return previous[1] + (point[1] - previous[1]) * (speed - previous[0]) / (point[0] - previous[0]);
		previous = point;
	}
	return previous[1];
}
/** The most degrees the follower turns in a frame: a frame's travel at the outer radius. */
function maxTurn(radius, store) {
	if (!(radius > 0)) return Number.POSITIVE_INFINITY;
	return frameTravel(store.get().source === "keyboard" ? Number.POSITIVE_INFINITY : (store.pointer()?.speed ?? 0) * 1e3) / radius * (180 / Math.PI);
}
/** The dead band round a pick's edge, in CSS pixels. */
const DEAD_BAND = 2;
/**
* The pick over a polar cell: a client point maps through the listbox's client box, which spans the
* cell and so the sweep's box, into units of the outer radius from the centre. A pointer that holds
* an option keeps it while a point 2 CSS px along its arc or its radius still picks it, so a hand's
* tremor near a dense dial's hole changes nothing. Within 2 CSS px of the centre a point has no
* angle to read, so it picks nothing new and keeps the option the pointer holds.
*
* @param id - The Root's id prefix.
* @param model - The latest model.
* @param motion - The Root's loop, whose frame shares the angles it painted once it rests.
* @returns The pick, null before the listbox mounts.
*/
function polarPick(id, model, motion) {
	return (clientX, clientY, held) => {
		const surface = document.getElementById(`${id}-surface`);
		if (surface === null) return null;
		const rect = surface.getBoundingClientRect();
		const box = sweepBox(model.current.sweep);
		const width = box.right - box.left;
		if (!(rect.width > 0) || !(width > 0)) return null;
		const scale = rect.width / width;
		const point = {
			x: box.left + (clientX - rect.left) / scale,
			y: box.top + (clientY - rect.top) / scale
		};
		const pixels = {
			scale,
			dpr: window.devicePixelRatio || 1,
			painted: motion.running() ? void 0 : paintedOf(motion),
			near: held?.near ?? null,
			nearFirm: held?.firm ?? false
		};
		const distance = Math.hypot(point.x, point.y);
		const reach = DEAD_BAND / scale;
		if (distance < reach) return held == null ? null : {
			slot: held.slot,
			near: held.near
		};
		const found = model.current.pick(point, pixels);
		if (held == null || found === null || found.slot === held.slot) return found;
		const radial = {
			x: point.x / distance,
			y: point.y / distance
		};
		const offsets = [
			{
				x: -radial.y,
				y: radial.x
			},
			{
				x: radial.y,
				y: -radial.x
			},
			radial,
			{
				x: -radial.x,
				y: -radial.y
			}
		];
		for (const { x, y } of offsets) {
			const kept = model.current.pick({
				x: point.x + x * reach,
				y: point.y + y * reach
			}, pixels);
			if (kept?.slot === held.slot) return kept;
		}
		return found;
	};
}
Object.assign(PolarRoot, { displayName: "PolarChart.Root" });
export { PolarRoot };

//# sourceMappingURL=chart-polar-root.js.map