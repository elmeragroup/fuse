"use client";
import { Skeleton } from "../skeleton/skeleton.js";
import { Loader } from "../loader/loader.js";
import { ChartSkeletonBody } from "./chart-skeleton-body.js";
import { jsx } from "react/jsx-runtime";
// src/components/chart/chart-skeleton.tsx
/**
* The bar heights of the placeholder in percent of the plot, 12 bars between 20 and 80 %. The list
* is fixed, so the server and the client agree.
*/
const SKELETON_BARS = [
	42,
	64,
	35,
	78,
	52,
	30,
	68,
	46,
	74,
	38,
	58,
	26
];
/**
* A loading placeholder that renders in place of Root, for example as a Suspense fallback. Its
* marks are Fuse Skeleton shapes that readers skip, and one Fuse Loader names the wait.
*
* @beta
*/
function ChartSkeleton({ variant = "bar", label, ...props }) {
	return /* @__PURE__ */ jsx(ChartSkeletonBody, {
		variant,
		label,
		marks: variant === "bar" ? SKELETON_BARS.map((height, index) => /* @__PURE__ */ jsx(Skeleton, {
			"data-slot": "chart-skeleton-mark",
			style: { "--chart-skeleton-height": `${String(height)}%` }
		}, index)) : /* @__PURE__ */ jsx(Skeleton, { "data-slot": "chart-skeleton-mark" }),
		...props
	});
}
/**
* The plot's placeholder inside a Root or a Panel, from the server render until the browser
* measures the plot and draws the marks. It is a Fuse Loader in the plot's middle, which CSS keeps
* hidden for a moment, so a fast hydration shows nothing. Root never reads its children, so it
* sketches no mark of its own, and the axes, the legend and the table around it are already
* final. Each chart already has its name and its table, so the wait is not announced.
*/
function PlotLoader() {
	return /* @__PURE__ */ jsx(Loader, {
		"aria-hidden": "true",
		label: ""
	});
}
Object.assign(ChartSkeleton, { displayName: "Chart.Skeleton" });
export { ChartSkeleton, PlotLoader };

//# sourceMappingURL=chart-skeleton.js.map