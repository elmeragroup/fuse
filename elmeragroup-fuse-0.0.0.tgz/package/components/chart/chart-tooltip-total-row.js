"use client";
import { CHART_STRINGS } from "./format/chart-strings.js";
import { formatValue } from "./format/value-format.js";
import { ChartCompositionError } from "./layout/errors.js";
import { stackTotal } from "./chart-series-readout.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
// src/components/chart/chart-tooltip-total-row.tsx
/**
* One stack's total at the active slot as a tooltip row.
*
* @param props - The part's props, its series model and the active slot.
* @returns The row.
* @throws {ChartCompositionError} `unknown-key` for a stack that names no stack of two or more series.
*/
function TooltipTotalRow({ part, context, at, stack, label, format, render, className, ...props }) {
	const stacks = context.model.stacks;
	const id = stack ?? stacks[0]?.id;
	const entry = stacks.find((candidate) => candidate.id === id);
	if (stack !== void 0 && entry === void 0) throw new ChartCompositionError(part, "unknown-key", `received stack ${JSON.stringify(stack)}, which names no stack of two or more series. Use one of ${stacks.map(({ id: name }) => JSON.stringify(name)).join(", ")}.`);
	const strings = CHART_STRINGS[context.locale];
	const first = entry?.keys[0];
	const total = entry === void 0 || at === null ? null : stackTotal(context, entry.id, at);
	const value = total === null ? strings.pending : `${formatValue(context.locale, total.total, format ?? (first === void 0 ? {} : context.config[first]?.format) ?? {}, "full").text}${total.incomplete ? ` (${strings.incomplete})` : ""}`;
	return useRender({
		defaultTagName: "div",
		render,
		props: {
			"data-slot": "chart-tooltip-total",
			...mergeProps({
				className,
				children: /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx("span", { children: label ?? strings.total }), /* @__PURE__ */ jsx("span", { children: value })] })
			}, props)
		}
	});
}
Object.assign(TooltipTotalRow, { displayName: "Chart.TooltipTotalRow" });
export { TooltipTotalRow };

//# sourceMappingURL=chart-tooltip-total-row.js.map