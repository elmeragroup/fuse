"use client";
import { usePolarContext } from "./chart-polar-context.js";
import { jsx } from "react/jsx-runtime";
// src/components/chart/clock-chart-glow.tsx
/**
* Wraps clock marks and glows them: a series of one paint casts its colour as a line's or a bar's
* glow does, and a series painted by value glows through a filter that blurs its own pixels, so each
* halo takes its mark's step.
*
* @beta
*/
function ClockChartGlow({ children, className, style }) {
	usePolarContext("ClockChart.Glow", ["clock"]);
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "clock-chart-glow",
		className,
		style,
		children
	});
}
Object.assign(ClockChartGlow, { displayName: "ClockChart.Glow" });
export { ClockChartGlow };

//# sourceMappingURL=clock-chart-glow.js.map