"use client";
import { writeAttribute, writeStyle } from "./chart-dom.js";
import { useChartFollower } from "./chart-followers.js";
import { clockDrawingIn, usePolarContext } from "./chart-polar-context.js";
import { viewBoxOf } from "./layout/polar-angle.js";
import { sectorPath } from "./layout/clock-path.js";
import { spokePath } from "./clock-chart-dial.js";
import { useLayoutEffect, useRef } from "react";
import { jsx } from "react/jsx-runtime";
// src/components/chart/clock-chart-scrubber.tsx
/**
* The clock's Scrubber: the active slot's hand, or its sector, which turns with the Root's angle
* follower, so the active dots and the tooltip turn with it. The first paint draws it at rest.
*/
/**
* The active slot's hand, or its whole sector under "band". It turns to the next slot the short way
* round on the Root's angle follower, which keeps its speed across steps and stiffens with a fast
* pointer, so it turns with the active dots.
*
* @beta
*/
function ClockChartScrubber({ variant = "line", className, style }) {
	const { model, box, kernel } = usePolarContext("ClockChart.Scrubber", ["clock"]);
	const clock = clockDrawingIn(model, "ClockChart.Scrubber");
	const hand = useRef(null);
	const { count } = clock;
	useChartFollower("ClockChart.Scrubber", (active) => {
		const node = hand.current;
		if (node !== null) writeAttribute(node, "data-shown", active === null || count === 0 ? null : "");
	});
	const lead = variant === "band" && count > 0 ? 180 / count : 0;
	const { follow } = kernel;
	useLayoutEffect(() => {
		const turn = (angle) => {
			const node = hand.current;
			if (node !== null) writeStyle(node, "rotate", `${String(angle - lead)}deg`);
		};
		const shown = follow.shown();
		if (shown !== null) turn(shown);
		return follow.subscribe(turn);
	}, [follow, lead]);
	const width = count === 0 ? 0 : 360 / count;
	return /* @__PURE__ */ jsx("svg", {
		"data-slot": "clock-chart-scrubber",
		"data-variant": variant,
		"data-polar-layer": "",
		"aria-hidden": "true",
		focusable: "false",
		viewBox: viewBoxOf(box),
		className,
		style,
		children: /* @__PURE__ */ jsx("g", {
			ref: hand,
			"data-part": "hand",
			children: /* @__PURE__ */ jsx("path", {
				"data-slot": "clock-chart-scrubber-path",
				"data-part": variant === "band" ? "band" : "line",
				d: variant === "band" ? sectorPath(0, width, clock.inner, 1) : spokePath(0, clock.inner, 1)
			})
		})
	});
}
Object.assign(ClockChartScrubber, { displayName: "ClockChart.Scrubber" });
export { ClockChartScrubber };

//# sourceMappingURL=clock-chart-scrubber.js.map