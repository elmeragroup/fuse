"use client";
import { ChartCrosshairContext, ChartDatumContext, ChartDepthContext, ChartHeadlineContext, ChartHeldPointContext, ChartLayoutContext, ChartLegendSideContext, ChartLiveContext, ChartPlotContext, ChartRootContext, ChartRootPlotContext, ChartRowContext, LiveLinePlotContext, LiveLineRootContext, NO_PLOT_READS, PlotReadsContext, ScatterPlotContext, ScatterRootContext } from "./chart-scope-contexts.js";
import { ChartReadoutContext, ChartSelectionContext } from "./chart-readout-port.js";
import { ClockMarkerContext } from "./chart-marker-context.js";
import { PolarContext } from "./chart-polar-context.js";
import { use } from "react";
import { jsx } from "react/jsx-runtime";
// src/components/chart/chart-own-scope.tsx
/**
* The scope every chart Root starts, cartesian and polar alike. It lives in a light leaf, so a polar
* Root takes it without importing the cartesian Root.
*/
/**
* A Root starts its own scope, so an outer chart's row, legend side, Tooltip and the index its closing popup holds, Headline, Crosshair,
* Marker or ActiveValueLine, an outer Root of any family with its readout, selection, layout and
* plots, or an outer clock Marker never reaches a part of this one, such as a sparkline in a legend
* item or a pie in a tooltip. A part of another family under this Root therefore throws
* `part-outside-root`, as it does alone. This chart's own Tooltip, Headline, Crosshair, Marker and
* ActiveValueLine set theirs again for their children, and the Root provides its own contexts
* inside it. A BarGroup's and a Table row's contexts stay out, because a Root can't sit in a
* BarGroup's aria-hidden plot layer or inside a table row.
*
* @param props - The Root's tree.
* @returns The tree in a scope of its own.
*/
function ChartOwnScope({ children }) {
	const depth = use(ChartDepthContext);
	return /* @__PURE__ */ jsx(ChartDepthContext, {
		value: depth + 1,
		children: /* @__PURE__ */ jsx(ChartRowContext, {
			value: null,
			children: /* @__PURE__ */ jsx(ChartLegendSideContext, {
				value: null,
				children: /* @__PURE__ */ jsx(ChartLiveContext, {
					value: false,
					children: /* @__PURE__ */ jsx(ChartHeldPointContext, {
						value: null,
						children: /* @__PURE__ */ jsx(ChartHeadlineContext, {
							value: false,
							children: /* @__PURE__ */ jsx(ChartCrosshairContext, {
								value: false,
								children: /* @__PURE__ */ jsx(ChartDatumContext, {
									value: null,
									children: /* @__PURE__ */ jsx(RootContexts, { children })
								})
							})
						})
					})
				})
			})
		})
	});
}
/**
* How many chart Roots enclose this one, 0 for the outermost, which its figure writes as
* `data-chart-depth`. A Root reads it outside its own scope.
*
* @returns The depth.
*/
function useChartDepth() {
	return use(ChartDepthContext);
}
/** Every family's Root contexts, reset, so each Root sets only its own again inside the scope. */
function RootContexts({ children }) {
	return /* @__PURE__ */ jsx(ChartReadoutContext, {
		value: null,
		children: /* @__PURE__ */ jsx(ChartSelectionContext, {
			value: null,
			children: /* @__PURE__ */ jsx(ChartRootContext, {
				value: null,
				children: /* @__PURE__ */ jsx(ChartLayoutContext, {
					value: null,
					children: /* @__PURE__ */ jsx(ChartRootPlotContext, {
						value: null,
						children: /* @__PURE__ */ jsx(ChartPlotContext, {
							value: null,
							children: /* @__PURE__ */ jsx(PlotReadsContext, {
								value: NO_PLOT_READS,
								children: /* @__PURE__ */ jsx(ScatterRootContext, {
									value: null,
									children: /* @__PURE__ */ jsx(ScatterPlotContext, {
										value: null,
										children: /* @__PURE__ */ jsx(LiveLineRootContext, {
											value: null,
											children: /* @__PURE__ */ jsx(LiveLinePlotContext, {
												value: null,
												children: /* @__PURE__ */ jsx(PolarContext, {
													value: null,
													children: /* @__PURE__ */ jsx(ClockMarkerContext, {
														value: null,
														children
													})
												})
											})
										})
									})
								})
							})
						})
					})
				})
			})
		})
	});
}
Object.assign(RootContexts, { displayName: "Chart.RootContexts" });
Object.assign(ChartOwnScope, { displayName: "Chart.OwnScope" });
export { ChartOwnScope, useChartDepth };

//# sourceMappingURL=chart-own-scope.js.map