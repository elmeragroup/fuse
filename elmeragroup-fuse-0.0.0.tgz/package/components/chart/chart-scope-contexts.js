"use client";
import { createContext } from "react";
// src/components/chart/chart-scope-contexts.ts
/**
* The contexts every Root's own scope resets. The first say where a shared readout part sits: its
* template row, its legend side, a live readout, a Crosshair, a Headline, or a datum. The rest are
* what a Root provides for its own parts: the cartesian Root's model, layout, plots and plot reads,
* the scatter Root's model and plot, and the live line Root's readings and plot. They live in a light leaf, so each Root's scope resets them
* without importing the readout hooks or another family's Root, and a part under a nested Root of
* another family reaches no outer Root's context and throws `part-outside-root`, as it does alone.
*/
/** The config key a template row renders for, such as one TooltipItems row. */
const ChartRowContext = createContext(null);
/**
* The legend entry of a threshold side around a part, null outside the legend entries of a
* threshold series. The series key travels with the side because a nested row, such as a
* LegendToggle or a TooltipItems row, replaces `ChartRowContext` and leaves this context alone.
*/
const ChartLegendSideContext = createContext(null);
/**
* Whether the readout parts below follow the active point. The tooltip does, and a static legend
* does not, so a pointer move renders no legend swatch or label.
*/
const ChartLiveContext = createContext(false);
/**
* The point a closing tooltip keeps showing while it fades out, so its content never empties,
* shrinks or turns to another series before the fade, or null while it is open or shut.
*/
const ChartHeldPointContext = createContext(null);
/** Whether a part sits inside a Crosshair, which a SlotLabel needs. */
const ChartCrosshairContext = createContext(false);
/** Whether a part sits inside a Headline, where an ActiveValue is exposed text. */
const ChartHeadlineContext = createContext(false);
/**
* The datum a ValueLabel prints, which the enclosing ActiveValueLine or Marker provides: a key and
* a slot, or the active slot when `slot` is null.
*/
const ChartDatumContext = createContext(null);
/**
* How many chart Roots enclose the next one: 0 outside every Root. Each Root writes its own depth on
* its figure, so a hover rule bound to the nearest Root picks that Root out by its depth, which no
* other Root on the chain shares, and the hover restyles only the parts it styles.
*/
const ChartDepthContext = createContext(0);
/** The enclosing cartesian Root, or null outside one. */
const ChartRootContext = createContext(null);
/** The enclosing cartesian layout, Root's or a Panel's, or null outside one. */
const ChartLayoutContext = createContext(null);
/** The nearest measured plot, Root's or a Panel's, or null before the browser measures it. */
const ChartPlotContext = createContext(null);
/** Root's own measured plot, which spans every Panel and gives each one its x frame. */
const ChartRootPlotContext = createContext(null);
/** The plot reads outside every measured plot: none, so a read registers nowhere. */
const NO_PLOT_READS = { add: () => () => void 0 };
/** The reads of the nearest measured plot, Root's or a Panel's. */
const PlotReadsContext = createContext(NO_PLOT_READS);
/** The enclosing scatter Root, or null outside one. */
const ScatterRootContext = createContext(null);
/** The scatter Root's measured plot, or null before the browser measures it. */
const ScatterPlotContext = createContext(null);
/** The enclosing live line Root, or null outside one. */
const LiveLineRootContext = createContext(null);
/** The live line Root's measured plot, or null before the browser measures it. */
const LiveLinePlotContext = createContext(null);
export { ChartCrosshairContext, ChartDatumContext, ChartDepthContext, ChartHeadlineContext, ChartHeldPointContext, ChartLayoutContext, ChartLegendSideContext, ChartLiveContext, ChartPlotContext, ChartRootContext, ChartRootPlotContext, ChartRowContext, LiveLinePlotContext, LiveLineRootContext, NO_PLOT_READS, PlotReadsContext, ScatterPlotContext, ScatterRootContext };

//# sourceMappingURL=chart-scope-contexts.js.map