"use client";
import { useLocale } from "../../intl/locale-context.js";
import { useMergedRefs } from "../../hooks/use-merged-refs.js";
import { definedProps } from "../../internal/defined-props.js";
import { isThemeDevelopment } from "../../theme/validate-theme.js";
import { useReducedMotion } from "../../hooks/use-reduced-motion.js";
import { CHART_STRINGS } from "./format/chart-strings.js";
import { ChartLayoutContext, ChartPlotContext, ChartRootContext, ChartRootPlotContext, PlotReadsContext } from "./chart-scope-contexts.js";
import { openDrawingSoon, useClientMount } from "./chart-draw-gate.js";
import { createChartStore } from "./chart-store.js";
import { ChartReadoutContext, ChartSelectionContext } from "./chart-readout-port.js";
import { ChartCompositionError, ChartDataError, DATA_MESSAGES, dataMessage, issueGroups, issueKey } from "./layout/errors.js";
import { createAxisRecord } from "./chart-axis-format.js";
import { intervalNests } from "./layout/coarse-slots.js";
import { numberOf, stringOf } from "./layout/scalar.js";
import { sameItems } from "./layout/same-items.js";
import { createRowPlacer, instantOf, slotOf, slotX } from "./layout/x-domain.js";
import { keepSlot } from "./layout/slot-window.js";
import { buildCartesianModel } from "./layout/cartesian-model.js";
import { keyDomains, useChartCommit } from "./chart-commit.js";
import { partOutsidePanel, useChartRoot } from "./chart-context.js";
import { writeAttribute, writeStyle } from "./chart-dom.js";
import { useEntrance } from "./chart-entrance.js";
import { createChartFollowers } from "./chart-followers.js";
import { createChartLabels } from "./chart-labels.js";
import { BROWSER_FRAMES, createChartMotion, createFrameOwner } from "./chart-motion.js";
import { ChartOwnScope, useChartDepth } from "./chart-own-scope.js";
import { colourFamilyError, nonFiniteThresholds } from "./chart-paint.js";
import { createChartPaths } from "./chart-paths.js";
import { useMeasuredPlot } from "./chart-plot-measure.js";
import { usePanelSpan } from "./chart-plot.js";
import { seriesLabel } from "./format/series-label.js";
import { chartDescription } from "./chart-text.js";
import { cartesianReadout } from "./chart-readout-cartesian.js";
import { createChartRiders } from "./chart-riders.js";
import { PlotLoader } from "./chart-skeleton.js";
import { discardStackFloors, flushStackFloors } from "./chart-stack-floors.js";
import { sameConfig, sameShallow, useSteady } from "./chart-steady.js";
import { ChartStatus, ChartSurface } from "./chart-surface.js";
import { useCallback, useEffect, useId, useLayoutEffect, useMemo, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-root.tsx
/** Order two Panels as their plots sit on the page. */
function inPageOrder(a, b) {
	const [first, second] = [a.plot(), b.plot()];
	if (first === null || second === null || first === second) return 0;
	return first.compareDocumentPosition(second) & Node.DOCUMENT_POSITION_FOLLOWING ? -1 : 1;
}
/**
* The error of Panels that break section 8.3's layouts: a key listed by two Panels and a config key
* that no Panel lists. It reads every Panel of the current tree, so it runs once their effects
* have registered them all.
*
* @returns The error, or null when the Panels cover every key once.
*/
function panelsError(config, panels) {
	const owners = /* @__PURE__ */ new Set();
	for (const { layout } of panels) for (const key of layout.keys) {
		if (owners.has(key)) return new ChartCompositionError("Chart.Panel", "series-in-two-panels", `lists ${JSON.stringify(key)}, which another Chart.Panel lists too, so it would have two y domains. List each config key in one Panel.`);
		owners.add(key);
	}
	const outside = Object.keys(config).find((key) => !owners.has(key));
	return outside === void 0 ? null : new ChartCompositionError("Chart.Root", "key-outside-panels", `has config key ${JSON.stringify(outside)}, which no Chart.Panel lists, so it has no y domain. Add it to one Panel's series.`);
}
/** One end of an x range as a comparable string. */
function rangePart(value) {
	if (value instanceof Date) return `t${String(value.getTime())}`;
	return stringOf(value) === void 0 ? `n${String(numberOf(value))}` : `s${stringOf(value) ?? ""}`;
}
/** Whether two ranges name the same two values, compared as tuples. */
function sameRange(a, b) {
	if (a === void 0 || b === void 0) return a === b;
	return rangePart(a[0]) === rangePart(b[0]) && rangePart(a[1]) === rangePart(b[1]);
}
/** What `non-finite-threshold` says after the part, naming the series. */
function thresholdMessage(key) {
	return `${DATA_MESSAGES["non-finite-threshold"]} Series ${JSON.stringify(key)}.`;
}
/** Throw for config that cannot draw: a key that names no column of any row. */
function assertConfigFits(config, data) {
	const keys = Object.keys(config);
	if (data.length > 0) {
		const absent = keys.find((key) => data.every((row) => !Object.hasOwn(row, key)));
		if (absent !== void 0) throw new ChartCompositionError("Chart.Root", "unknown-key", `has config key ${JSON.stringify(absent)}, which names no column of any row. Name a number column of the rows.`);
	}
}
/** Whether an animation ends, so `finish()` can jump it to its end. */
function isFinite(animation) {
	return Number.isFinite(animation.effect?.getComputedTiming().endTime ?? Number.POSITIVE_INFINITY);
}
/** The active slot inside the effective window, which the followers draw. */
function activeSlot(snapshot, model) {
	const window = model.window;
	const { active, near } = snapshot;
	if (window === null || active === null || active < window.first || active > window.last) return null;
	return {
		slot: active,
		near
	};
}
/**
* Write the active state onto Root, where the dim rules read it. Only these attributes change on
* enter and leave, so a pointer move restyles no mark.
*/
function markActive(root, snapshot, active) {
	writeAttribute(root, "data-active", active === null ? null : snapshot.source ?? "");
	writeAttribute(root, "data-pinned", snapshot.pinned && active !== null ? "" : null);
	writeAttribute(root, "data-near", active !== null && snapshot.near !== null ? snapshot.near : null);
}
/**
* Provide the Root's readout, which the shared parts read the Root through. It changes with the
* Root's context alone, so a pointer move renders no part that reads only the readout.
*/
function ReadoutScope({ children }) {
	const context = useChartRoot("Chart.Root");
	const readout = useMemo(() => cartesianReadout(context), [context]);
	return /* @__PURE__ */ jsx(ChartReadoutContext, {
		value: readout,
		children
	});
}
/**
* Root's animation loop on the browser's frame clock. A mark that leaves while followers draw from
* it repaints them, so each joins what still draws its series.
*/
function browserMotion(reduced, followers) {
	return createChartMotion(BROWSER_FRAMES, reduced, () => {
		followers.refresh();
	});
}
/**
* The root of every cartesian chart, also exported as `AreaChart.Root`, `BarChart.Root` and
* `LineChart.Root`. It reads the series from `config`, never from its children, and renders a
* named `figure` that holds the description, the instructions, the plot's single tab stop, the
* parts and the status region, in that order.
*
* @template TRow - The row type, inferred from `data`.
* @template TConfig - The config, inferred with its literal keys.
* @template TXKey - The x column, inferred from `xKey`.
* @beta
*/
function ChartRoot({ data, config, xKey, xScale = "band", orientation = "vertical", stackOffset = "diverging", yBaseline = "zero", yInclude, xRange, defaultXRange, onXRangeChange: _onXRangeChange, onXRangeCommitted: _onXRangeCommitted, defaultActiveX, selectedKey, defaultSelectedKey, onSelectedKeyChange, interval, period, now, timeZone: ownZone, xFormat, description, children, style, ref, ...figure }) {
	const { locale, timeZone: providerZone } = useLocale();
	const timeZone = ownZone ?? providerZone;
	if (interval !== void 0 && timeZone === void 0) throw new ChartCompositionError("Chart.Root", "time-axis-without-zone", "draws a time axis with no time zone. Pass timeZone on the Root or on LocaleProvider, the IANA zone of the data's market, such as \"Europe/Oslo\".");
	assertConfigFits(config, data);
	for (const [key, entry] of Object.entries(config)) {
		if (entry.interval !== void 0 && (interval === void 0 || !intervalNests(interval, entry.interval))) throw new ChartCompositionError("Chart.Root", "interval-not-nested", interval === void 0 ? `has config ${JSON.stringify(key)} interval ${JSON.stringify(entry.interval)} on a category axis. A series interval needs Root's time axis, so pass interval on Chart.Root.` : `has config ${JSON.stringify(key)} interval ${JSON.stringify(entry.interval)}, which does not nest Root's ${JSON.stringify(interval)}. Root's interval is the finest in the chart, so give Root the finest one, and give a series an interval that holds whole Root slots.`);
		if (entry.projectedFrom === void 0 || interval !== void 0 !== (stringOf(entry.projectedFrom) !== void 0)) continue;
		throw new ChartCompositionError("Chart.Root", "x-type-mismatch", interval === void 0 ? `received a Date or number as config ${JSON.stringify(key)} projectedFrom on a category axis. Pass the category string.` : `received a string as config ${JSON.stringify(key)} projectedFrom on a time axis. Pass a Date or epoch milliseconds, because a date-only string parses as UTC midnight and lands on the wrong day.`);
	}
	const nowInstant = now === void 0 ? void 0 : instantOf(now);
	const windowRange = useSteady(xRange ?? defaultXRange, sameRange);
	const include = useSteady(yInclude, sameItems);
	const modelPeriod = useSteady(period, sameRange);
	const modelConfig = useSteady(config, sameConfig);
	const [placeRows] = useState(createRowPlacer);
	const model = useMemo(() => buildCartesianModel({
		rows: data,
		series: Object.entries(modelConfig).map(([key, entry]) => [key, {
			stack: entry.stack,
			qualityKey: entry.qualityKey,
			projectedFrom: entry.projectedFrom,
			interval: entry.interval
		}]),
		xKey,
		time: interval === void 0 || timeZone === void 0 ? void 0 : {
			interval,
			timeZone,
			period: modelPeriod === void 0 ? void 0 : [instantOf(modelPeriod[0]), instantOf(modelPeriod[1])],
			now: nowInstant
		},
		stackOffset,
		baseline: yBaseline,
		include: include ?? [],
		xRange: windowRange
	}, placeRows), [
		placeRows,
		data,
		modelConfig,
		xKey,
		interval,
		timeZone,
		modelPeriod,
		nowInstant,
		stackOffset,
		yBaseline,
		include,
		windowRange
	]);
	const reduced = useReducedMotion();
	const [followers] = useState(createChartFollowers);
	const [motion] = useState(() => browserMotion(reduced, followers));
	useLayoutEffect(() => {
		flushStackFloors(motion);
	});
	useLayoutEffect(() => () => {
		discardStackFloors(motion);
	}, [motion]);
	const [registry] = useState(() => /* @__PURE__ */ new Set());
	const [panels, setPanels] = useState([]);
	const domains = useMemo(() => keyDomains(model, stackOffset, panels), [
		model,
		stackOffset,
		panels
	]);
	const colourRule = useMemo(() => colourFamilyError("Chart.Root", modelConfig, Object.keys(modelConfig)), [modelConfig]);
	const [bars] = useState(() => /* @__PURE__ */ new Map());
	const commit = useChartCommit({
		model,
		data,
		config: modelConfig,
		range: windowRange,
		domains,
		panels,
		orientation
	}, motion, bars);
	const firstIssue = model.issues[0];
	if (firstIssue !== void 0 && isThemeDevelopment()) throw new ChartDataError("Chart.Root", firstIssue.rule, dataMessage(firstIssue, model.rowAt));
	const thresholdKeys = useMemo(() => nonFiniteThresholds(modelConfig), [modelConfig]);
	const [firstThreshold] = thresholdKeys;
	if (firstThreshold !== void 0 && isThemeDevelopment()) throw new ChartDataError("Chart.Root", "non-finite-threshold", thresholdMessage(firstThreshold));
	const warned = useRef(/* @__PURE__ */ new Set());
	const warnOnce = useCallback((rule, subject, message) => {
		const key = issueKey(rule, subject);
		if (warned.current.has(key)) return;
		warned.current.add(key);
		console.warn(message);
	}, []);
	useEffect(() => {
		for (const { rule, subject, first, count } of issueGroups(model.issues)) warnOnce(rule, subject, `Chart.Root ${dataMessage(first, model.rowAt, count)}`);
	}, [
		model.issues,
		model.rowAt,
		warnOnce
	]);
	useEffect(() => {
		for (const key of thresholdKeys) warnOnce("non-finite-threshold", key, `Chart.Root ${thresholdMessage(key)}`);
	}, [thresholdKeys, warnOnce]);
	const id = useId();
	const [store] = useState(() => {
		const slot = defaultActiveX === void 0 ? -1 : slotOf(model.domain, defaultActiveX);
		return createChartStore(slot === -1 ? null : slot);
	});
	const rootRef = useRef(null);
	const figureRef = useMergedRefs(rootRef, ref);
	const frameRef = useRef(null);
	const plotRef = useRef(null);
	const span = usePanelSpan(frameRef, panels);
	const placeSpan = span.follow;
	const { plot, probe, reads } = useMeasuredPlot(plotRef, span.place);
	const clientMount = useClientMount();
	useLayoutEffect(() => {
		if (clientMount) store.drawing.openNow();
		else openDrawingSoon(store.drawing);
	}, [store, clientMount]);
	const modelRef = useRef(model);
	useLayoutEffect(() => {
		motion.setReduced(reduced);
		followers.refresh();
	}, [
		motion,
		reduced,
		followers
	]);
	const [labels] = useState(createChartLabels);
	const [paths] = useState(createChartPaths);
	const [riders] = useState(createChartRiders);
	const [axis] = useState(createAxisRecord);
	const [owner] = useState(() => createFrameOwner("root"));
	const paintedRef = useRef([null, null]);
	useLayoutEffect(() => {
		const previous = modelRef.current;
		modelRef.current = model;
		const { active } = store.get();
		if (previous !== model && active !== null) {
			const window = model.window;
			const kept = window === null ? null : keepSlot(model.domain, window, slotX(previous.domain, active));
			paintedRef.current = [kept, store.get().near];
			store.set({ active: kept });
		}
		const slot = activeSlot(store.get(), model);
		if (rootRef.current) markActive(rootRef.current, store.get(), slot);
		followers.paint(slot, "commit");
	}, [
		model,
		store,
		followers,
		commit.update,
		plot,
		orientation
	]);
	useLayoutEffect(() => {
		const root = rootRef.current;
		if (store.get().phase === "waiting") return;
		if (commit.update.relays) motion.finish();
		if (commit.update.kind !== "range" || root === null) return;
		motion.finish();
		for (const animation of root.getAnimations({ subtree: true })) if (isFinite(animation)) animation.finish();
	}, [
		commit.update,
		motion,
		store
	]);
	useLayoutEffect(() => store.subscribe(() => {
		const snapshot = store.get();
		const slot = activeSlot(snapshot, modelRef.current);
		if (rootRef.current) markActive(rootRef.current, snapshot, slot);
		const [active, near] = paintedRef.current;
		if (snapshot.active === active && snapshot.near === near) return;
		paintedRef.current = [snapshot.active, snapshot.near];
		followers.paint(slot, "step");
	}), [store, followers]);
	const figureProps = definedProps(figure);
	const name = "aria-label" in figureProps ? figureProps["aria-label"] : void 0;
	const labelledBy = "aria-labelledby" in figureProps ? figureProps["aria-labelledby"] : void 0;
	const [ownSelected, setOwnSelected] = useState(defaultSelectedKey ?? null);
	const requested = selectedKey === void 0 ? ownSelected : selectedKey;
	const selected = requested !== null && Object.hasOwn(modelConfig, requested) ? requested : null;
	const strings = CHART_STRINGS[locale];
	const steadyFormat = useSteady(xFormat, sameShallow);
	const text = useMemo(() => ({
		config: modelConfig,
		locale,
		model,
		xFormat: steadyFormat,
		now: nowInstant
	}), [
		modelConfig,
		locale,
		model,
		steadyFormat,
		nowInstant
	]);
	const selection = useRef({
		selected,
		onSelectedKeyChange,
		text
	});
	useLayoutEffect(() => {
		selection.current = {
			selected,
			onSelectedKeyChange,
			text
		};
	});
	const select = useCallback((key, reason, event) => {
		const latest = selection.current;
		if (key === latest.selected) return;
		setOwnSelected(key);
		latest.onSelectedKeyChange?.(key, {
			reason,
			event
		});
		const words = CHART_STRINGS[latest.text.locale];
		store.announce(key === null || !Object.hasOwn(latest.text.config, key) ? words.selectionCleared : words.selected(seriesLabel(latest.text, key).text));
	}, [store]);
	const toggleGroups = useRef(0);
	const registerToggleGroup = useCallback(() => {
		toggleGroups.current += 1;
		return () => {
			toggleGroups.current -= 1;
		};
	}, []);
	const getRoot = useCallback(() => rootRef.current, []);
	const hasToggles = useCallback(() => toggleGroups.current > 0, []);
	const highlight = useCallback((key) => {
		const root = rootRef.current;
		if (root === null) return;
		const seriesIndex = key === null ? -1 : Object.keys(modelConfig).indexOf(key);
		writeAttribute(root, "data-highlight", seriesIndex === -1 ? null : "");
		writeStyle(root, "--chart-highlight", seriesIndex === -1 ? null : String(seriesIndex));
	}, [modelConfig]);
	const registerBar = useCallback((key, grouped, layout) => {
		const token = {};
		bars.set(token, {
			key,
			grouped,
			layout
		});
		if (isThemeDevelopment()) {
			const loose = [...bars.values()].filter((bar) => !bar.grouped && bar.layout === layout).map((bar) => bar.key);
			const stackOf = new Map(Object.entries(modelConfig).map(([name, entry]) => [name, entry.stack]));
			const pair = loose.flatMap((first, index) => loose.slice(index + 1).filter((second) => second !== first).filter((second) => stackOf.get(first) === void 0 || stackOf.get(first) !== stackOf.get(second)).map((second) => [first, second]))[0];
			if (pair !== void 0) warnOnce("bars-overlap", pair.join(" "), `Chart.Bar draws ${JSON.stringify(pair[0])} and ${JSON.stringify(pair[1])} over each other, because they sit outside a Chart.BarGroup and share no stack id. Wrap them in <Chart.BarGroup series={[…]}> to draw them side by side.`);
		}
		return () => {
			bars.delete(token);
		};
	}, [
		bars,
		modelConfig,
		warnOnce
	]);
	const drawsBar = useCallback((key) => [...bars.values()].some((bar) => bar.key === key), [bars]);
	const registerEmphasis = useCallback((key, entry) => {
		store.set({ emphasis: {
			...store.get().emphasis,
			[key]: entry
		} });
		return () => {
			store.set({ emphasis: Object.fromEntries(Object.entries(store.get().emphasis).filter(([name]) => name !== key)) });
		};
	}, [store]);
	const [rootParts] = useState(() => /* @__PURE__ */ new Map());
	const [rootPartsSeen, setRootPartsSeen] = useState(0);
	const registerRootPart = useCallback((part) => {
		const token = {};
		rootParts.set(token, part);
		if (registry.size > 0) setRootPartsSeen((count) => count + 1);
		return () => {
			rootParts.delete(token);
		};
	}, [registry, rootParts]);
	const registerPanel = useCallback((panel) => {
		registry.add(panel);
		setPanels([...registry].sort(inPageOrder));
		return () => {
			registry.delete(panel);
			setPanels([...registry].sort(inPageOrder));
		};
	}, [registry, setPanels]);
	useLayoutEffect(() => {
		if (registry.size === 0) return;
		const [stray] = rootParts.values();
		if (stray !== void 0) throw partOutsidePanel(stray);
		if ((rootRef.current?.querySelectorAll(":scope > [data-slot=\"chart-frame\"] > [data-slot=\"chart-panel\"]").length ?? 0) > registry.size) return;
		const error = panelsError(modelConfig, [...registry]);
		if (error !== null) throw error;
	}, [
		modelConfig,
		panels,
		registry,
		rootParts,
		rootPartsSeen
	]);
	const intro = figureProps["data-intro"];
	const fade = figureProps["data-fade"];
	const entrance = intro !== "none" && !reduced;
	useEntrance(store, motion, rootRef, plotRef, entrance);
	const context = useMemo(() => ({
		...text,
		xScale,
		orientation,
		stackOffset,
		baseline: yBaseline,
		store,
		id,
		name,
		select,
		registerToggleGroup,
		hasToggles,
		highlight,
		root: getRoot,
		rows: data,
		warnOnce,
		intro,
		entrance,
		fade,
		update: commit.update,
		motion,
		followers,
		paths,
		riders,
		axis,
		registerBar,
		drawsBar,
		registerEmphasis,
		registerPanel,
		registerRootPart,
		placeSpan,
		panels,
		domains,
		colourRule
	}), [
		colourRule,
		placeSpan,
		registerPanel,
		registerRootPart,
		panels,
		domains,
		data,
		warnOnce,
		intro,
		entrance,
		fade,
		commit.update,
		motion,
		followers,
		paths,
		riders,
		axis,
		registerBar,
		drawsBar,
		registerEmphasis,
		text,
		xScale,
		orientation,
		stackOffset,
		yBaseline,
		store,
		id,
		name,
		select,
		registerToggleGroup,
		hasToggles,
		highlight,
		getRoot
	]);
	const layout = useMemo(() => ({
		kind: "root",
		keys: Object.keys(modelConfig),
		y: model.y,
		baseline: yBaseline,
		owner,
		labels
	}), [
		modelConfig,
		model.y,
		yBaseline,
		owner,
		labels
	]);
	const slots = model.window === null ? 0 : model.window.last - model.window.first + 1;
	const spokenDescription = useMemo(() => description ?? chartDescription(text), [description, text]);
	const depth = useChartDepth();
	return /* @__PURE__ */ jsx(ChartOwnScope, { children: /* @__PURE__ */ jsx(ChartRootContext, {
		value: context,
		children: /* @__PURE__ */ jsx(ReadoutScope, { children: /* @__PURE__ */ jsx(ChartSelectionContext, {
			value: selected,
			children: /* @__PURE__ */ jsx(ChartLayoutContext, {
				value: layout,
				children: /* @__PURE__ */ jsxs("figure", {
					ref: figureRef,
					"data-slot": "chart",
					"data-chart-depth": depth,
					"data-orientation": orientation,
					"data-x-scale": xScale,
					"data-selected": selected === null ? void 0 : "",
					style: {
						"--chart-selected": selected === null ? void 0 : Object.keys(modelConfig).indexOf(selected),
						...style
					},
					...figureProps,
					children: [
						/* @__PURE__ */ jsx("p", {
							id: `${id}-description`,
							"data-slot": "chart-description",
							children: spokenDescription
						}),
						/* @__PURE__ */ jsx("p", {
							id: `${id}-instructions`,
							"data-slot": "chart-instructions",
							children: strings.instructionsCartesian
						}),
						/* @__PURE__ */ jsxs("div", {
							ref: frameRef,
							"data-slot": "chart-frame",
							style: { "--chart-slots": slots },
							children: [/* @__PURE__ */ jsxs("div", {
								ref: plotRef,
								"data-slot": "chart-plot",
								"aria-hidden": "true",
								children: [probe, plot === null && !model.empty ? /* @__PURE__ */ jsx(PlotLoader, {}) : null]
							}), /* @__PURE__ */ jsx(ChartRootPlotContext, {
								value: plot,
								children: /* @__PURE__ */ jsx(ChartPlotContext, {
									value: plot,
									children: /* @__PURE__ */ jsxs(PlotReadsContext, {
										value: reads,
										children: [/* @__PURE__ */ jsx(ChartSurface, {
											name,
											labelledBy
										}), children]
									})
								})
							})]
						}),
						/* @__PURE__ */ jsx(ChartStatus, {})
					]
				})
			})
		}) })
	}) });
}
Object.assign(ChartRoot, { displayName: "Chart.Root" });
export { ChartRoot };

//# sourceMappingURL=chart-root.js.map