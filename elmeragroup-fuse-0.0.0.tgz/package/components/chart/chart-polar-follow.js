"use client";
import { springTiming } from "./chart-spring.js";
import { followSettled, followStep, shortTarget } from "./layout/angle-follow.js";
// src/components/chart/chart-polar-follow.ts
/** The longest frame the follower advances by, so a frame after a stall never leaps. */
const LONGEST_FRAME_MS = 64;
/**
* The most frames a step's turn takes at its capped pace: 12 for a step of up to 90°, such as a
* radar's spoke, which at the docs' dial size keeps the pointer's pace, and 10 for a wider one, so
* a step across the dial lands within 300 ms with the fastest spring's tail.
*/
const LEAP_FRAMES = {
	near: 12,
	far: 10
};
/** The widest step, in degrees, that takes the near leap. */
const LEAP_NEAR = 90;
/**
* How near half a turn, in degrees, a step lands from the chased target to have no way of its own.
*/
const HALF_TURN_TIE = .5;
/**
* The most a mark's stretch slows the pace, so a stepped curve's riser, which a dot climbs in one
* frame whatever the pace, never holds the hand back.
*/
const STRETCH_MOST = 4;
/**
* How much more a dot's stretch counts than it reads: the stretch is read at a frame's two ends and
* its middle, and a curve that bends between them carries the dot a little further.
*/
const STRETCH_MARGIN = 1.07;
/** Half the angle, in degrees, over which a mark's stretch is read. */
const STRETCH_SPAN = .5;
/**
* Create a Root's follower.
*
* @param host - The frames, the motion preference and the step's spring.
* @returns The follower.
*/
function createPolarFollow(host) {
	const listeners = /* @__PURE__ */ new Set();
	const stretches = /* @__PURE__ */ new Set();
	let state = null;
	let target = null;
	let spring = null;
	let pace = Number.POSITIVE_INFINITY;
	let floor = 0;
	let leaping = false;
	let radius = 0;
	let frame = null;
	let last = 0;
	const call = (angle) => {
		for (const listener of listeners) listener(angle);
	};
	/**
	* The most any mark stretches between two angles, read at a frame's two ends and its middle, at
	* least the rim's 1 and at most 4.
	*/
	const widest = (from, to) => {
		let most = 1;
		const reads = 2;
		for (const stretch of stretches) for (let read = 0; read <= reads; read += 1) {
			const value = stretch(from + (to - from) * read / reads);
			if (value !== null && value * STRETCH_MARGIN > most) most = value * STRETCH_MARGIN;
		}
		return Math.min(most, STRETCH_MOST);
	};
	const stop = () => {
		if (frame !== null) host.frames.cancelFrame(frame);
		frame = null;
	};
	const tick = (time) => {
		frame = null;
		if (state === null || target === null || spring === null) return;
		const dt = Math.min(time - last, LONGEST_FRAME_MS);
		const next = followStep(state, target, dt, spring);
		const turn = next.angle - state.angle;
		const maxTurn = Math.max(pace / (stretches.size === 0 ? 1 : widest(state.angle, next.angle)), floor);
		state = Math.abs(turn) > maxTurn && dt > 0 ? {
			angle: state.angle + Math.sign(turn) * maxTurn,
			velocity: Math.sign(turn) * maxTurn * 1e3 / dt
		} : next;
		last = time;
		if (followSettled(state, target)) {
			leaping = false;
			state = {
				angle: target,
				velocity: 0
			};
			call(target);
			return;
		}
		call(state.angle);
		frame = host.frames.requestFrame(tick);
	};
	return {
		retarget(angle, cause) {
			if (angle === null) {
				stop();
				target = null;
				return;
			}
			const chased = target ?? state?.angle ?? angle;
			const ahead = shortTarget(chased, angle);
			const next = state !== null && Math.abs(Math.abs(ahead - chased) - 180) < HALF_TURN_TIE ? shortTarget(state.angle, angle) : ahead;
			if (state !== null) {
				const laps = Math.trunc((next - state.angle) / 360);
				if (laps !== 0) state = {
					...state,
					angle: state.angle + 360 * laps
				};
			}
			const shown = state?.angle ?? angle;
			const stepSpring = host.spring();
			if (!(cause === "step" && state !== null && target !== null && !host.reduced() && springTiming(stepSpring).spring)) {
				stop();
				leaping = false;
				state = {
					angle: next,
					velocity: 0
				};
				target = next;
				call(next);
				return;
			}
			const stepPace = host.maxTurn(radius);
			const span = Math.abs(next - shown);
			const stepFloor = span / (span > LEAP_NEAR ? LEAP_FRAMES.far : LEAP_FRAMES.near);
			const leaps = stepFloor > stepPace;
			const chosen = leaps ? host.leapSpring() : stepSpring;
			if (next === target && spring === chosen) return;
			target = next;
			spring = chosen;
			pace = stepPace;
			floor = stepFloor;
			leaping = leaps;
			if (frame === null) {
				last = host.frames.now();
				frame = host.frames.requestFrame(tick);
			}
		},
		subscribe(listener) {
			listeners.add(listener);
			return () => {
				listeners.delete(listener);
			};
		},
		stretch(stretch) {
			stretches.add(stretch);
			return () => {
				stretches.delete(stretch);
			};
		},
		shown: () => state?.angle ?? null,
		leaps: () => leaping,
		measure(next) {
			radius = next;
		}
	};
}
export { STRETCH_SPAN, createPolarFollow };

//# sourceMappingURL=chart-polar-follow.js.map