"use client";
import { sameItems } from "./layout/same-items.js";
import { useSvgIdPrefix, writeAttribute } from "./chart-dom.js";
import { ClockMarkerContext } from "./chart-marker-context.js";
import { useSteady } from "./chart-steady.js";
import { viewBoxOf } from "./layout/polar-angle.js";
import { clockDots, entranceFrame, slotVertex } from "./layout/clock-path.js";
import { usePolarCommit, usePolarMark } from "./chart-polar-motion.js";
import { clockDatumSlots, groupOf, useClockPlacement, useClockSeries, writeReveal } from "./clock-chart-part.js";
import { useLayoutEffect, useMemo, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/clock-chart-dots.tsx
/**
* The clock's dots: Dots on every reading, and Marker on the slots a datum names, each in its
* value's step at the vertices the series draws in each frame.
*/
/** A series' dots in a frame, in their step groups: every reading, or the slots a Marker names. */
function dotGroups(look, values) {
	const { series, clock, only } = look;
	const slots = only === null ? series.slots : {
		...series.slots,
		states: series.slots.states.map((state, slot) => only.has(slot) ? state : "pending")
	};
	return clockDots(values, slots, (slot) => groupOf(series, clock, slot).replace("-past", ""));
}
/**
* Whether a Marker's dots sit anywhere but at rest in a frame: the entrance still opens, or a marked
* slot's vertex has not reached its rest. Its ValueLabels' pills sit at rest, so they hide meanwhile.
*/
function markerMoving(look, frame) {
	if (look.only === null) return false;
	if (frame.reveal < 360) return true;
	const { rest } = look.series;
	if (frame.values.length !== rest.length) return true;
	for (const slot of look.only) {
		const drawn = slotVertex(frame.values, slot);
		const resting = slotVertex(rest, slot);
		if (Math.abs(drawn.angle - resting.angle) > 1e-6 || Math.abs(drawn.radius - resting.radius) > 1e-6) return true;
	}
	return false;
}
/** Draw a series' dots, in their step groups, at the vertices this frame draws. */
function drawDots(group, look, values) {
	if (look === null) return;
	const frame = entranceFrame(values);
	const groups = dotGroups(look, frame.values);
	for (const path of group.querySelectorAll("path[data-group]")) writeAttribute(path, "d", groups.get(path.getAttribute("data-group") ?? "") ?? "");
	writeReveal(group, frame.reveal);
	look.labels.moving = markerMoving(look, frame);
	for (const node of look.labels.nodes) writeAttribute(node, "data-moving", look.labels.moving ? "" : null);
}
/** Whether two picks name the same slots, or both name every slot. */
function sameSlots(a, b) {
	return a === null || b === null ? a === b : sameItems(a, b);
}
/** A dot layer over a series' vertices: every reading, or the slots a Marker names. */
function DotLayer({ dataSlot, part, dataKey, variant, only, className, style, children }) {
	const { polar, clock, series } = useClockSeries(part, dataKey);
	const picked = useSteady(useMemo(() => series === void 0 ? null : only(clock, series), [
		only,
		clock,
		series
	]), sameSlots);
	const [labels] = useState(() => ({
		nodes: /* @__PURE__ */ new Set(),
		moving: false
	}));
	const look = useMemo(() => series === void 0 ? null : {
		series,
		clock,
		only: picked === null ? null : new Set(picked),
		labels
	}, [
		series,
		clock,
		picked,
		labels
	]);
	const { ref, place, node: anchor, drawn } = usePolarMark(polar.motion, drawDots, look);
	const [first] = useState(() => look === null ? /* @__PURE__ */ new Map() : dotGroups(look, look.series.rest));
	const commit = usePolarCommit(polar, anchor);
	useClockPlacement(clock, series, look, {
		commit,
		place,
		drawn
	});
	const painted = useRef(variant);
	useLayoutEffect(() => {
		if (painted.current === variant) return;
		painted.current = variant;
		const group = anchor();
		if (group !== null && look !== null) drawDots(group, look, drawn() ?? look.series.rest);
	}, [
		variant,
		anchor,
		look,
		drawn
	]);
	const prefix = useSvgIdPrefix("clock-chart-dots");
	const steps = series?.steps ?? [{
		paint: series?.paint ?? "currentColor",
		from: 0
	}];
	return /* @__PURE__ */ jsxs(ClockMarkerContext, {
		value: series === void 0 || picked === null ? null : {
			series,
			slots: picked,
			labels
		},
		children: [/* @__PURE__ */ jsxs("svg", {
			"data-slot": dataSlot,
			"data-variant": variant,
			"data-clock-series": "",
			"data-polar-layer": "",
			"data-polar-mark": "",
			"aria-hidden": "true",
			focusable: "false",
			viewBox: viewBoxOf(polar.box),
			className,
			style: {
				"--chart-series": series?.index ?? 0,
				"--_base": series?.paint ?? "currentColor",
				...style
			},
			children: [/* @__PURE__ */ jsx("defs", { children: /* @__PURE__ */ jsx("clipPath", {
				id: `${prefix}-reveal`,
				children: /* @__PURE__ */ jsx("path", {
					"data-part": "reveal",
					d: ""
				})
			}) }), /* @__PURE__ */ jsx("g", {
				ref,
				"data-clip": `url(#${prefix}-reveal)`,
				children: steps.map(({ paint }, index) => /* @__PURE__ */ jsxs("g", {
					style: { "--_dot": paint },
					children: [
						variant === "ping" ? /* @__PURE__ */ jsx("path", {
							"data-slot": "clock-chart-dot",
							"data-part": "ping",
							"data-group": `step-${String(index)}`,
							d: first.get(`step-${String(index)}`)
						}) : null,
						/* @__PURE__ */ jsx("path", {
							"data-slot": "clock-chart-dot",
							"data-part": "halo",
							"data-group": `step-${String(index)}`,
							d: first.get(`step-${String(index)}`)
						}),
						/* @__PURE__ */ jsx("path", {
							"data-slot": "clock-chart-dot",
							"data-part": "dots",
							"data-group": `step-${String(index)}`,
							d: first.get(`step-${String(index)}`)
						})
					]
				}, index))
			})]
		}), children]
	});
}
/** Every slot, for Dots. */
const everyReading = () => null;
/**
* A dot on every reading of one series, at the vertex its curve passes. A series painted by value
* paints each dot in its own value's step.
*
* @beta
*/
function ClockChartDots({ dataKey, variant = "default", className, style }) {
	return /* @__PURE__ */ jsx(DotLayer, {
		dataSlot: "clock-chart-dots",
		part: "ClockChart.Dots",
		dataKey,
		variant,
		only: everyReading,
		className,
		style
	});
}
/**
* A dot on the slots `at` names, with an optional `ValueLabel` beside each.
*
* @beta
*/
function ClockChartMarker({ dataKey, at, variant = "default", className, style, children }) {
	const only = useMemo(() => (clock, series) => clockDatumSlots(clock, "ClockChart.Marker", series, at), [at]);
	return /* @__PURE__ */ jsx(DotLayer, {
		dataSlot: "clock-chart-marker",
		part: "ClockChart.Marker",
		dataKey,
		variant,
		only,
		className,
		style,
		children
	});
}
Object.assign(ClockChartDots, { displayName: "ClockChart.Dots" });
Object.assign(ClockChartMarker, { displayName: "ClockChart.Marker" });
export { ClockChartDots, ClockChartMarker };

//# sourceMappingURL=clock-chart-dots.js.map