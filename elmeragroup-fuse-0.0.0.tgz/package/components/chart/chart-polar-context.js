"use client";
import { ChartCompositionError } from "./layout/errors.js";
import { createContext, use } from "react";
// src/components/chart/chart-polar-context.ts
/**
* What a polar Root shares with its parts and its family's model: the model's contract, the
* kernel's, and the context the parts read. A light leaf, so a part reaches its Root without the
* Root's module.
*/
/**
* The enclosing polar Root, or null outside one. Every Root's own scope resets it, so a polar part
* under a cartesian or scatter Root nested in a polar chart reaches no Root of its own and throws
* `part-outside-root`, and each polar Root sets it again inside its scope.
*/
const PolarContext = createContext(null);
/**
* Read the enclosing polar Root.
*
* @param part - The calling part's display name, which the error names.
* @param families - The families the part belongs to.
* @returns The Root's polar context.
* @throws {ChartCompositionError} `part-outside-root` when no Root of the family encloses the part.
*/
function usePolarContext(part, families) {
	const value = use(PolarContext);
	if (value === null || !families.includes(value.model.family)) {
		const roots = families.map((name) => `${ROOTS[name]}`).join(" or ");
		throw new ChartCompositionError(part, "part-outside-root", `must be used within ${roots}. Wrap the chart's parts in it.`);
	}
	return value;
}
/** Each family's Root, as an error names it. */
const ROOTS = {
	pie: "PieChart.Root",
	radial: "RadialChart.Root",
	radar: "RadarChart.Root",
	clock: "ClockChart.Root"
};
/**
* A pie's drawing, which only a pie model holds.
*
* @param model - The Root's model.
* @returns The drawing, or null under a family that draws no pie, where a shared part renders nothing.
*/
function pieDrawingOf(model) {
	return model.drawing.kind === "pie" ? model.drawing.pie : null;
}
/**
* A pie's drawing, for a part only a pie holds.
*
* @param model - The Root's model, a pie's, as `usePolarContext` admitted the part under a pie only.
* @param part - The part, which a defect names.
* @returns The drawing.
* @throws When the model holds no pie, a defect.
*/
function pieDrawingIn(model, part) {
	const pie = pieDrawingOf(model);
	if (pie === null) throw new Error(`${part} read a ${model.family} model, which holds no pie.`);
	return pie;
}
/**
* A radial chart's drawing, which only a radial model holds.
*
* @param model - The Root's model.
* @returns The drawing, or null under another family.
*/
function radialDrawingOf(model) {
	return model.drawing.kind === "radial" ? model.drawing.radial : null;
}
/**
* The numbers a pie's or a radial chart's centre prints.
*
* @param model - The Root's model.
* @returns The centre's numbers, or null under a family with no centre.
*/
function centreOf(model) {
	return model.drawing.kind === "pie" || model.drawing.kind === "radial" ? model.drawing.centre : null;
}
/**
* A clock's drawing, for a part only a clock holds.
*
* @param model - The Root's model, a clock's, as `usePolarContext` admitted the part.
* @param part - The part, which a defect names.
* @returns The drawing.
* @throws When the model holds no clock, a defect.
*/
function clockDrawingIn(model, part) {
	if (model.drawing.kind !== "clock") throw new Error(`${part} read a ${model.family} model, which holds no clock.`);
	return model.drawing.clock;
}
/**
* A radar's drawing, for a part only a radar holds.
*
* @param model - The Root's model, a radar's, as `usePolarContext` admitted the part.
* @param part - The part, which a defect names.
* @returns The drawing.
* @throws When the model holds no radar, a defect.
*/
function radarDrawingIn(model, part) {
	if (model.drawing.kind !== "radar") throw new Error(`${part} read a ${model.family} model, which holds no radar.`);
	return model.drawing.radar;
}
/**
* A radial chart's drawing, for a part only a radial chart holds.
*
* @param model - The Root's model, a radial chart's, as `usePolarContext` admitted the part.
* @param part - The part, which a defect names.
* @returns The drawing.
* @throws When the model holds no rings, a defect.
*/
function radialDrawingIn(model, part) {
	const radial = radialDrawingOf(model);
	if (radial === null) throw new Error(`${part} read a ${model.family} model, which holds no rings.`);
	return radial;
}
export { PolarContext, centreOf, clockDrawingIn, pieDrawingIn, pieDrawingOf, radarDrawingIn, radialDrawingIn, radialDrawingOf, usePolarContext };

//# sourceMappingURL=chart-polar-context.js.map