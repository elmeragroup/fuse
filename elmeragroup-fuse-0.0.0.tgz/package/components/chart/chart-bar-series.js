"use client";
import { introFor } from "./chart-store.js";
import { floorAxisOf, tickWidth, valueAt } from "./layout/plot-frame.js";
import { barCellAt, barGeometry, geometryOf, geometryRect, hangs, plainRect, rectsPath } from "./layout/bar-geometry.js";
import { partsCache, writeAttribute, writeAttributes, writeStyle } from "./chart-dom.js";
import { useChartFollower } from "./chart-followers.js";
import { readingPaint } from "./chart-paint.js";
import { pathAnchor, routeIndex } from "./chart-paths.js";
import { floorSpanOf } from "./layout/floor-settle.js";
import { stackFloorsOf, useStackSeat } from "./chart-stack-floors.js";
import { BarFills, ListFills } from "./chart-bar-fills.js";
import { placementOf, useCommitMotion, useFirstDraw, useFollowerPlacement, useMotionMark } from "./chart-motion-mark.js";
import { barAnchor, barAxes, barPlacement, fillPlot, layoutBars, overlayFills, tickEnds } from "./chart-bar-draw.js";
import { columnOverlay } from "./chart-bar-columns.js";
import { DETAIL_PARTS, boxPoints, detailParts, drawnBar } from "./layout/bar-shapes.js";
import { memo, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-bar-series.tsx
/**
* The element form of one Bar, an SVG element per bar, and the active overlay every Bar draws over
* the active slot. Each bar and the overlay hold one registration with Root's animation loop for
* as long as they are mounted, through `useMotionMark`.
*/
/**
* Mark a drawn bar's body, or the active overlay, with what its drawn geometry says now: the side
* its tip lies on, which turns its far end over, and its top weight, which scales its rounded end.
*/
function writeSide(body, negative, top) {
	if (body === null) return;
	writeAttribute(body, "data-negative", negative ? "" : null);
	writeStyle(body, "--_top", String(top));
}
/** A bar's top weight, from its drawn geometry, between 0 and 1. */
function topWeight(geometry) {
	return Math.min(1, Math.max(0, geometry[5] ?? 0));
}
/** Write a rectangle onto a polygon's points, as a bar's JSX writes them. */
function writeBox(node, rect) {
	writeAttribute(node, "points", boxPoints(rect));
}
/**
* A bar's elements, found once per commit of its mark. A plain bar is its polygon alone, whatever
* it holds, such as a title. A look with details renders a group, whose body and details carry
* their slots.
*/
const barElements = partsCache((node) => node.tagName === "polygon" ? {
	body: node,
	details: []
} : {
	body: node.querySelector(":scope > [data-slot=\"chart-bar\"]"),
	details: [...node.querySelectorAll(":scope > [data-slot=\"chart-bar-detail\"]")]
});
/**
* Draw one bar from the loop's numbers. Every shape it draws comes from the numbers: its rectangle,
* seam, side, rounded end, cap and blocks track, and which side's fill it takes. A stacked bar
* records its segment with the stack floors, which paint it with the place they decide.
*/
function drawBar(node, look, values) {
	const { frame, seat } = look;
	const geometry = geometryOf(values);
	const plain = plainRect(frame, geometry);
	if (seat === null) {
		paintBar(node, look, geometry, "outer", plain);
		return;
	}
	const [, , base, tip] = geometry;
	seat.floors.draw(seat.mark, seat.stack, [floorSpanOf(frame, plain, seat.series, [base, tip])], floorAxisOf(frame), (kept) => paintBar(node, look, geometry, kept[0] === 1 ? "outer" : "inner", plain));
}
/** Paint one bar from its geometry and plain rectangle, owning its stack side's pixel floor or not. */
function paintBar(node, look, geometry, place, plain) {
	const { frame, variant, fills } = look;
	const negative = hangs(frame, geometry);
	const top = topWeight(geometry);
	const drawn = drawnBar(frame, variant, geometryRect(frame, geometry, place, plain), {
		negative,
		top,
		place
	});
	const { body, details } = barElements(node);
	if (body instanceof SVGElement) {
		writeBox(body, drawn.body);
		writeSide(body, negative, top);
	}
	for (const detail of details) {
		const part = detail.getAttribute("data-part");
		if (part === "top" || part === "side") writeAttribute(detail, "points", drawn[part] ?? "");
		else if (part === "track" || part === "blocks") writeAttribute(detail, "d", rectsPath(drawn[part] ?? []));
		else if (part === "cap" && drawn.cap !== void 0) writeBox(detail, drawn.cap);
		if (part === "track" && detail instanceof SVGElement) writeStyle(detail, "--_top", String(top));
	}
	writeStyle(node, "--_fill", (negative ? fills.negative : fills.positive) ?? null);
}
/** Draw the active overlay from the loop's numbers, as `drawBar` draws a bar, with no seam. */
function drawOverlay(overlay, look, values) {
	const { frame, seat } = look;
	const fills = look.fills.current;
	const geometry = geometryOf(values);
	const negative = hangs(frame, geometry);
	const plain = plainRect(frame, geometry);
	const [, , base, tip] = geometry;
	const place = seat === null ? "outer" : seat.floors.placeOver(seat.stack, floorSpanOf(frame, plain, seat.series, [base, tip]), floorAxisOf(frame)) ?? look.rest.current;
	writeBox(overlay, geometryRect(frame, geometry, place, plain));
	writeSide(overlay, negative, topWeight(geometry));
	writeStyle(overlay, "--_fill", (negative ? fills.negative : fills.positive) ?? null);
}
/**
* One bar. It keys by its slot, so a pan keeps every surviving node, and it keeps the
* `data-intro` value its first render chose. Each commit that renders it places it through the
* loop, which grows it in the entrance, moves it on a data update and snaps it otherwise.
*/
const BarMark = memo(function BarMark({ bar, series, stack, seriesKey, look, intro, motion, update, plot }) {
	const [firstIntro] = useState(intro);
	const negative = bar.cell.negative;
	const { positive, negative: negativeFill } = bar.fills;
	const seat = useStackSeat(motion, stack, seriesKey);
	const writerLook = useMemo(() => ({
		frame: look.frame,
		variant: look.variant,
		fills: {
			positive,
			negative: negativeFill
		},
		seat
	}), [
		look,
		positive,
		negativeFill,
		seat
	]);
	const detail = detailParts(look.variant, bar.geometry[5]);
	const { ref: barRef, place } = useMotionMark(motion, drawBar, writerLook, barAxes(look.frame.orientation), detail);
	const commit = useCommitMotion(update, plot, look.frame.orientation, look.frame);
	useLayoutEffect(() => {
		place(bar.geometry, barPlacement(bar, commit()), barAnchor(series, bar.cell.slot));
	});
	const { parts, top } = useFirstDraw(() => ({
		parts: drawnBar(look.frame, look.variant, bar.rect, {
			negative: hangs(look.frame, bar.geometry),
			top: bar.geometry[5],
			place: bar.cell.place
		}),
		top: String(topWeight(bar.geometry))
	}), detail);
	const fill = negative ? negativeFill : positive;
	const paint = {
		"--chart-bar-paint": bar.paint,
		"--_fill": fill
	};
	const shared = {
		"data-emphasis": bar.emphasis ? "" : void 0,
		"data-time": bar.time
	};
	const plain = DETAIL_PARTS.every((part) => parts[part] === void 0);
	const body = /* @__PURE__ */ jsx("polygon", {
		ref: plain ? barRef : void 0,
		"data-slot": "chart-bar",
		"data-series": series,
		"data-stack-top": bar.cell.stackTop ? "" : void 0,
		"data-negative": negative ? "" : void 0,
		"data-quality": bar.quality,
		"data-projected": bar.projected ? "" : void 0,
		"data-intro": firstIntro,
		...shared,
		points: boxPoints(parts.body),
		style: plain ? {
			...paint,
			"--_top": top
		} : { "--_top": top }
	});
	if (plain) return body;
	return /* @__PURE__ */ jsxs("g", {
		ref: barRef,
		"data-intro": firstIntro,
		style: paint,
		children: [
			look.variant === "blocks" ? /* @__PURE__ */ jsx("path", {
				"data-slot": "chart-bar-detail",
				"data-part": "track",
				...shared,
				d: rectsPath(parts.track ?? []),
				style: { "--_top": top }
			}) : null,
			body,
			parts.cap === void 0 ? null : /* @__PURE__ */ jsx("polygon", {
				"data-slot": "chart-bar-detail",
				"data-part": "cap",
				...shared,
				points: boxPoints(parts.cap)
			}),
			parts.top === void 0 ? null : /* @__PURE__ */ jsx("polygon", {
				"data-slot": "chart-bar-detail",
				"data-part": "top",
				...shared,
				points: parts.top
			}),
			parts.side === void 0 ? null : /* @__PURE__ */ jsx("polygon", {
				"data-slot": "chart-bar-detail",
				"data-part": "side",
				...shared,
				points: parts.side
			}),
			parts.blocks === void 0 ? null : /* @__PURE__ */ jsx("path", {
				"data-slot": "chart-bar-detail",
				"data-part": "blocks",
				...shared,
				d: rectsPath(parts.blocks)
			})
		]
	});
});
/** Draw a missing tick from the loop's numbers: its span along the slot axis and its zero line. */
function drawTick(line, look, values) {
	const [start = 0, end = 0, base = 0] = values;
	writeAttributes(line, tickEnds(look.frame, [start, end], base));
}
/**
* One missing reading's tick on the zero line. It moves with the bars on a data update, its zero
* line with their base, and snaps as they do on a range step or an orientation change.
*/
const MissingTick = memo(function MissingTick({ span, zero, series, frame, motion, update, plot }) {
	const vertical = frame.orientation === "vertical";
	const tickLook = useMemo(() => ({ frame }), [frame]);
	const { ref, place } = useMotionMark(motion, drawTick, tickLook, vertical ? [
		"x",
		"x",
		"y"
	] : [
		"y",
		"y",
		"x"
	]);
	const commit = useCommitMotion(update, plot, frame.orientation, frame);
	useLayoutEffect(() => {
		place([
			span[0],
			span[1],
			zero
		], placementOf(commit()));
	});
	const ends = useFirstDraw(() => tickEnds(frame, span, zero));
	return /* @__PURE__ */ jsx("line", {
		ref,
		"data-slot": "chart-bar-missing",
		"data-series": series,
		style: { "--_tick-width": `${String(tickWidth(frame.box))}px` },
		...ends
	});
});
/**
* The bars of one series, one SVG element per bar. Each bar waits at its base while Root's
* entrance waits and grows from it as the entrance plays, moves to its new geometry on a data
* update and snaps on a range step or a resize.
*/
function SeriesBars({ context, series, frame, plot, metrics, sub, variant, paint, emphasised, prefix, phase, entering }) {
	const { model, update, now, intro: origin, motion } = context;
	const { bars, needs, missing } = useMemo(() => layoutBars({
		context: {
			model,
			update,
			now,
			intro: origin
		},
		series,
		frame,
		metrics,
		sub,
		variant,
		paint,
		emphasised,
		prefix,
		entering
	}), [
		model,
		update,
		now,
		origin,
		series,
		frame,
		metrics,
		sub,
		variant,
		paint,
		emphasised,
		prefix,
		entering
	]);
	const look = useMemo(() => ({
		variant,
		frame
	}), [variant, frame]);
	const intro = introFor(phase, update.kind, true);
	const zero = valueAt(frame, 0);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsxs("defs", { children: [/* @__PURE__ */ jsx(BarFills, {
		prefix,
		needs,
		plot: fillPlot(frame)
	}), paint.stops === void 0 ? null : /* @__PURE__ */ jsx(ListFills, {
		prefix,
		stops: paint.stops,
		orientation: frame.orientation
	})] }), /* @__PURE__ */ jsxs("g", {
		"data-slot": "chart-bar-marks",
		children: [bars.map((bar) => /* @__PURE__ */ jsx(BarMark, {
			bar,
			series: series.seriesIndex,
			stack: series.stack,
			seriesKey: series.key,
			look,
			intro,
			motion,
			update,
			plot
		}, bar.key)), missing.map(({ key, span }) => /* @__PURE__ */ jsx(MissingTick, {
			span,
			zero,
			series: series.seriesIndex,
			frame,
			motion,
			update,
			plot
		}, key))]
	})] });
}
/**
* How the active overlay joins the mark that draws its slot: the bar at the series and slot in the
* element form, and the series' columns in the path form, whose route the paths record keeps.
*/
function overlayJoin(context, series, slot, target, form) {
	if (form === "bars") {
		const pick = (values) => values.map((value, index) => index === 4 ? 0 : value);
		return { leads: [{
			anchor: barAnchor(series.seriesIndex, slot),
			pick,
			size: target.length
		}] };
	}
	const route = context.paths.get(series.seriesIndex, "columns");
	const index = route === void 0 ? void 0 : routeIndex(route, context.update.keys[slot] ?? "");
	if (route === void 0 || index === void 0) return void 0;
	return { leads: [{
		anchor: pathAnchor(series.seriesIndex, "columns"),
		pick: (values) => columnOverlay(values, index, target[5] ?? 1),
		size: target.length
	}] };
}
/**
* The series' bar over the active slot, drawn over the dimmed bars at full strength. Root paints
* it at pointer rate, so a pointer move renders nothing in React.
*/
function ActiveBar({ context, series, frame, plot, metrics, sub, variant, paint, prefix, form }) {
	const { model, motion } = context;
	const fills = useRef({
		positive: void 0,
		negative: void 0
	});
	const rest = useRef("outer");
	const { stack, key } = series;
	const overlayLook = useMemo(() => ({
		frame,
		fills,
		rest,
		seat: stack === void 0 ? null : {
			floors: stackFloorsOf(motion),
			stack,
			series: key
		}
	}), [
		frame,
		motion,
		stack,
		key
	]);
	const { ref: activeRef, node, drawn, place } = useMotionMark(motion, drawOverlay, overlayLook, barAxes(frame.orientation));
	useLayoutEffect(() => {
		const { seat } = overlayLook;
		if (seat === null) return void 0;
		return seat.floors.watch(seat.stack, () => {
			const overlay = node();
			const values = drawn();
			if (overlay !== null && values !== null) drawOverlay(overlay, overlayLook, values);
		});
	}, [
		overlayLook,
		node,
		drawn
	]);
	const placeFor = useFollowerPlacement(context.update, plot, frame.orientation, frame);
	useChartFollower("Chart.Bar", (active, cause) => {
		const cell = active === null ? null : barCellAt(model, series, active.slot);
		const target = cell === null ? null : barGeometry(frame, cell, metrics, sub, "whole");
		const placement = placeFor(cause, cell === null || target === null ? void 0 : overlayJoin(context, series, cell.slot, target, form));
		const overlay = node();
		if (overlay === null) return;
		if (cell === null) {
			writeAttribute(overlay, "visibility", "hidden");
			return;
		}
		const reading = series.readings[cell.slot];
		const own = readingPaint(paint, reading);
		const projected = cell.slot >= series.projectedFrom;
		const quality = reading?.kind === "reading" && reading.quality !== "measured" ? reading.quality : null;
		writeAttributes(overlay, {
			visibility: "visible",
			"data-stack-top": cell.stackTop ? "" : null,
			"data-projected": projected ? "" : null,
			"data-quality": quality
		});
		fills.current = overlayFills(prefix, form, variant, paint, {
			own,
			projected
		});
		rest.current = cell.place;
		writeStyle(overlay, "--chart-bar-paint", own ?? null);
		if (target !== null) place(target, placement);
	});
	return /* @__PURE__ */ jsx("polygon", {
		ref: activeRef,
		"data-slot": "chart-bar-active",
		"data-series": series.seriesIndex,
		visibility: "hidden"
	});
}
Object.assign(SeriesBars, { displayName: "Chart.Bar.Series" });
Object.assign(ActiveBar, { displayName: "Chart.Bar.Active" });
export { ActiveBar, SeriesBars };

//# sourceMappingURL=chart-bar-series.js.map