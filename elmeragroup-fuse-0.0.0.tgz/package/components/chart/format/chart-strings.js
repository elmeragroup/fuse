/** The chart strings of every supported locale. */
const CHART_STRINGS = {
	"nb-NO": {
		surfaceName: (name) => `${name}, datapunkter`,
		allSeries: "Alle serier",
		seriesGroup: "Serier",
		instructionsCartesian: "Bruk venstre og høyre pil for å gå mellom punktene, og opp og ned for å velge serie.",
		instructionsPolar: "Bruk piltastene for å gå mellom delene.",
		selected: (label) => `${label} valgt`,
		selectionCleared: "Ingen serie valgt",
		estimated: "estimert",
		corrected: "korrigert",
		missing: "mangler",
		pending: "ingen data ennå",
		incomplete: "ufullstendig",
		projected: "prognose",
		emphasised: "uthevet",
		now: "nå",
		descriptionNow: (x) => `Nå: ${x}.`,
		total: "Totalt",
		referenceLine: (value) => `Referanselinje: ${value}`,
		referenceArea: (value) => `Område: ${value}`,
		valueRange: (from, to) => `${from} til ${to}`,
		other: "Annet",
		ofMax: (value, max) => `${value} av ${max}`,
		showTable: "Vis som tabell",
		hideTable: "Skjul tabell",
		pageStatus: (page, count, period) => `Side ${page} av ${count} · ${period}`,
		rowRange: (from, to) => `Rad ${from} til ${to}`,
		xHeaderTime: "Tidspunkt",
		xHeaderDay: "Dag",
		xHeaderWeek: "Uke",
		xHeaderMonth: "Måned",
		xHeaderYear: "År",
		xHeaderCategory: "Kategori",
		brushGroup: "Periode",
		brushStart: "fra",
		brushEnd: "til",
		brushWindow: "Flytt periode",
		brushRange: (from, to) => `Viser ${from} til ${to}`,
		brushWindowValue: (from, to) => `fra ${from} til og med ${to}`,
		loading: "Laster diagram",
		noData: "Ingen data for perioden",
		sparklineRange: (min, max) => `Lavest ${min}, høyest ${max}.`,
		sparklineRangeAt: (min, minAt, max, maxAt) => `Lavest ${min} ${minAt}, høyest ${max} ${maxAt}.`,
		descriptionSpan: (from, to, count) => to === void 0 ? `${from}, ${count}.` : `Fra ${from} til ${to}, ${count}.`,
		descriptionSeries: (label, low, lowAt, high, highAt) => `${label}: lavest ${low} ${lowAt}, høyest ${high} ${highAt}.`,
		descriptionLabel: (label, unit) => `${label} i ${unit}`,
		descriptionStack: (label, low, lowAt, high, highAt) => `${label}: lavest ${low} ${lowAt}, høyest ${high} ${highAt}.`,
		descriptionQuality: (count, state) => `${count} ${state === "missing" ? "mangler" : state === "estimated" ? "er estimert" : "er korrigert"}.`,
		descriptionProjection: (label, from) => `${label} er prognose fra ${from}.`,
		slots: {
			second: {
				one: "sekund",
				other: "sekunder"
			},
			minute: {
				one: "minutt",
				other: "minutter"
			},
			"quarter-hour": {
				one: "kvarter",
				other: "kvarter"
			},
			hour: {
				one: "time",
				other: "timer"
			},
			day: {
				one: "dag",
				other: "dager"
			},
			week: {
				one: "uke",
				other: "uker"
			},
			month: {
				one: "måned",
				other: "måneder"
			},
			year: {
				one: "år",
				other: "år"
			},
			category: {
				one: "kategori",
				other: "kategorier"
			}
		},
		points: {
			one: "punkt",
			other: "punkter"
		},
		scatterSeries: (label, count, x, y) => `${label}: ${count}, ${x}, ${y}.`,
		xValue: "x-verdi",
		yValue: "y-verdi",
		seriesHeader: "Serie",
		instructionsLive: "Bruk venstre og høyre pil for å gå mellom målingene, og End for å gå til den siste.",
		liveValue: "Verdi",
		liveLatest: (value, at) => `Siste verdi ${value} ${at}.`
	},
	"sv-SE": {
		surfaceName: (name) => `${name}, datapunkter`,
		allSeries: "Alla serier",
		seriesGroup: "Serier",
		instructionsCartesian: "Använd vänster- och högerpil för att gå mellan punkterna, och upp och ner för att välja serie.",
		instructionsPolar: "Använd piltangenterna för att gå mellan delarna.",
		selected: (label) => `${label} vald`,
		selectionCleared: "Ingen serie vald",
		estimated: "uppskattad",
		corrected: "korrigerad",
		missing: "saknas",
		pending: "inga data ännu",
		incomplete: "ofullständig",
		projected: "prognos",
		emphasised: "framhävd",
		now: "nu",
		descriptionNow: (x) => `Nu: ${x}.`,
		total: "Totalt",
		referenceLine: (value) => `Referenslinje: ${value}`,
		referenceArea: (value) => `Område: ${value}`,
		valueRange: (from, to) => `${from} till ${to}`,
		other: "Övrigt",
		ofMax: (value, max) => `${value} av ${max}`,
		showTable: "Visa som tabell",
		hideTable: "Dölj tabell",
		pageStatus: (page, count, period) => `Sida ${page} av ${count} · ${period}`,
		rowRange: (from, to) => `Rad ${from} till ${to}`,
		xHeaderTime: "Tidpunkt",
		xHeaderDay: "Dag",
		xHeaderWeek: "Vecka",
		xHeaderMonth: "Månad",
		xHeaderYear: "År",
		xHeaderCategory: "Kategori",
		brushGroup: "Period",
		brushStart: "från",
		brushEnd: "till",
		brushWindow: "Flytta period",
		brushRange: (from, to) => `Visar ${from} till ${to}`,
		brushWindowValue: (from, to) => `från ${from} till och med ${to}`,
		loading: "Laddar diagram",
		noData: "Ingen data för perioden",
		sparklineRange: (min, max) => `Lägst ${min}, högst ${max}.`,
		sparklineRangeAt: (min, minAt, max, maxAt) => `Lägst ${min} ${minAt}, högst ${max} ${maxAt}.`,
		descriptionSpan: (from, to, count) => to === void 0 ? `${from}, ${count}.` : `Från ${from} till ${to}, ${count}.`,
		descriptionSeries: (label, low, lowAt, high, highAt) => `${label}: lägst ${low} ${lowAt}, högst ${high} ${highAt}.`,
		descriptionLabel: (label, unit) => `${label} i ${unit}`,
		descriptionStack: (label, low, lowAt, high, highAt) => `${label}: lägst ${low} ${lowAt}, högst ${high} ${highAt}.`,
		descriptionQuality: (count, state) => `${count} ${state === "missing" ? "saknas" : state === "estimated" ? "är uppskattade" : "är korrigerade"}.`,
		descriptionProjection: (label, from) => `${label} är prognos från ${from}.`,
		slots: {
			second: {
				one: "sekund",
				other: "sekunder"
			},
			minute: {
				one: "minut",
				other: "minuter"
			},
			"quarter-hour": {
				one: "kvart",
				other: "kvartar"
			},
			hour: {
				one: "timme",
				other: "timmar"
			},
			day: {
				one: "dag",
				other: "dagar"
			},
			week: {
				one: "vecka",
				other: "veckor"
			},
			month: {
				one: "månad",
				other: "månader"
			},
			year: {
				one: "år",
				other: "år"
			},
			category: {
				one: "kategori",
				other: "kategorier"
			}
		},
		points: {
			one: "punkt",
			other: "punkter"
		},
		scatterSeries: (label, count, x, y) => `${label}: ${count}, ${x}, ${y}.`,
		xValue: "x-värde",
		yValue: "y-värde",
		seriesHeader: "Serie",
		instructionsLive: "Använd vänster- och högerpil för att gå mellan mätningarna, och End för att gå till den senaste.",
		liveValue: "Värde",
		liveLatest: (value, at) => `Senaste värde ${value} ${at}.`
	},
	"fi-FI": {
		surfaceName: (name) => `${name}, datapisteet`,
		allSeries: "Kaikki sarjat",
		seriesGroup: "Sarjat",
		instructionsCartesian: "Siirry pisteestä toiseen vasemmalla ja oikealla nuolella. Valitse sarja ylä- ja alanuolella.",
		instructionsPolar: "Siirry osasta toiseen nuolinäppäimillä.",
		selected: (label) => `${label} valittu`,
		selectionCleared: "Ei valittua sarjaa",
		estimated: "arvioitu",
		corrected: "korjattu",
		missing: "puuttuu",
		pending: "ei vielä tietoja",
		incomplete: "epätäydellinen",
		projected: "ennuste",
		emphasised: "korostettu",
		now: "nyt",
		descriptionNow: (x) => `Nyt: ${x}.`,
		total: "Yhteensä",
		referenceLine: (value) => `Viiteviiva: ${value}`,
		referenceArea: (value) => `Alue: ${value}`,
		valueRange: (from, to) => `${from}–${to}`,
		other: "Muut",
		ofMax: (value, max) => `${value} / ${max}`,
		showTable: "Näytä taulukkona",
		hideTable: "Piilota taulukko",
		pageStatus: (page, count, period) => `Sivu ${page}/${count} · ${period}`,
		rowRange: (from, to) => `Rivit ${from}–${to}`,
		xHeaderTime: "Ajankohta",
		xHeaderDay: "Päivä",
		xHeaderWeek: "Viikko",
		xHeaderMonth: "Kuukausi",
		xHeaderYear: "Vuosi",
		xHeaderCategory: "Luokka",
		brushGroup: "Jakso",
		brushStart: "alku",
		brushEnd: "loppu",
		brushWindow: "Siirrä jaksoa",
		brushRange: (from, to) => `Näytetään ${from}–${to}`,
		brushWindowValue: (from, to) => `${from}–${to}`,
		loading: "Ladataan kaaviota",
		noData: "Ei tietoja jaksolta",
		sparklineRange: (min, max) => `Alin ${min}, korkein ${max}.`,
		sparklineRangeAt: (min, minAt, max, maxAt) => `Alin ${min} ${minAt}, korkein ${max} ${maxAt}.`,
		descriptionSpan: (from, to, count) => to === void 0 ? `${from}, ${count}.` : `${from} – ${to}, ${count}.`,
		descriptionSeries: (label, low, lowAt, high, highAt) => `${label}: alin ${low} ${lowAt}, korkein ${high} ${highAt}.`,
		descriptionLabel: (label, unit) => `${label}, ${unit}`,
		descriptionStack: (label, low, lowAt, high, highAt) => `${label}: alin ${low} ${lowAt}, korkein ${high} ${highAt}.`,
		descriptionQuality: (count, state) => `${count} ${state === "missing" ? "puuttuu" : state === "estimated" ? "on arvioitu" : "on korjattu"}.`,
		descriptionProjection: (label, from) => `${label} on ennuste alkaen ${from}.`,
		slots: {
			second: {
				one: "sekunti",
				other: "sekuntia"
			},
			minute: {
				one: "minuutti",
				other: "minuuttia"
			},
			"quarter-hour": {
				one: "vartti",
				other: "varttia"
			},
			hour: {
				one: "tunti",
				other: "tuntia"
			},
			day: {
				one: "päivä",
				other: "päivää"
			},
			week: {
				one: "viikko",
				other: "viikkoa"
			},
			month: {
				one: "kuukausi",
				other: "kuukautta"
			},
			year: {
				one: "vuosi",
				other: "vuotta"
			},
			category: {
				one: "luokka",
				other: "luokkaa"
			}
		},
		points: {
			one: "piste",
			other: "pistettä"
		},
		scatterSeries: (label, count, x, y) => `${label}: ${count}, ${x}, ${y}.`,
		xValue: "x-arvo",
		yValue: "y-arvo",
		seriesHeader: "Sarja",
		instructionsLive: "Siirry mittausten välillä vasemmalla ja oikealla nuolella ja viimeisimpään End-näppäimellä.",
		liveValue: "Arvo",
		liveLatest: (value, at) => `Viimeisin arvo ${value} ${at}.`
	},
	"en-US": {
		surfaceName: (name) => `${name}, data points`,
		allSeries: "All series",
		seriesGroup: "Series",
		instructionsCartesian: "Use the left and right arrows to move between points, and up and down to choose a series.",
		instructionsPolar: "Use the arrow keys to move between parts.",
		selected: (label) => `${label} selected`,
		selectionCleared: "No series selected",
		estimated: "estimated",
		corrected: "corrected",
		missing: "missing",
		pending: "no data yet",
		incomplete: "incomplete",
		projected: "projected",
		emphasised: "highlighted",
		now: "now",
		descriptionNow: (x) => `Now: ${x}.`,
		total: "Total",
		referenceLine: (value) => `Reference line: ${value}`,
		referenceArea: (value) => `Range: ${value}`,
		valueRange: (from, to) => `${from} to ${to}`,
		other: "Other",
		ofMax: (value, max) => `${value} of ${max}`,
		showTable: "Show as table",
		hideTable: "Hide table",
		pageStatus: (page, count, period) => `Page ${page} of ${count} · ${period}`,
		rowRange: (from, to) => `Rows ${from} to ${to}`,
		xHeaderTime: "Time",
		xHeaderDay: "Day",
		xHeaderWeek: "Week",
		xHeaderMonth: "Month",
		xHeaderYear: "Year",
		xHeaderCategory: "Category",
		brushGroup: "Period",
		brushStart: "start",
		brushEnd: "end",
		brushWindow: "Move period",
		brushRange: (from, to) => `Showing ${from} to ${to}`,
		brushWindowValue: (from, to) => `from ${from} through ${to}`,
		loading: "Loading chart",
		noData: "No data for the period",
		sparklineRange: (min, max) => `Lowest ${min}, highest ${max}.`,
		sparklineRangeAt: (min, minAt, max, maxAt) => `Lowest ${min} ${minAt}, highest ${max} ${maxAt}.`,
		descriptionSpan: (from, to, count) => to === void 0 ? `${from}, ${count}.` : `From ${from} to ${to}, ${count}.`,
		descriptionSeries: (label, low, lowAt, high, highAt) => `${label}: lowest ${low} ${lowAt}, highest ${high} ${highAt}.`,
		descriptionLabel: (label, unit) => `${label} in ${unit}`,
		descriptionStack: (label, low, lowAt, high, highAt) => `${label}: lowest ${low} ${lowAt}, highest ${high} ${highAt}.`,
		descriptionQuality: (count, state) => `${count} ${state === "missing" ? "missing" : state === "estimated" ? "estimated" : "corrected"}.`,
		descriptionProjection: (label, from) => `${label} is projected from ${from}.`,
		slots: {
			second: {
				one: "second",
				other: "seconds"
			},
			minute: {
				one: "minute",
				other: "minutes"
			},
			"quarter-hour": {
				one: "quarter-hour",
				other: "quarter-hours"
			},
			hour: {
				one: "hour",
				other: "hours"
			},
			day: {
				one: "day",
				other: "days"
			},
			week: {
				one: "week",
				other: "weeks"
			},
			month: {
				one: "month",
				other: "months"
			},
			year: {
				one: "year",
				other: "years"
			},
			category: {
				one: "category",
				other: "categories"
			}
		},
		points: {
			one: "point",
			other: "points"
		},
		scatterSeries: (label, count, x, y) => `${label}: ${count}, ${x}, ${y}.`,
		xValue: "x value",
		yValue: "y value",
		seriesHeader: "Series",
		instructionsLive: "Use the left and right arrows to move between readings, and End to go to the latest.",
		liveValue: "Value",
		liveLatest: (value, at) => `Latest value ${value} ${at}.`
	}
};
export { CHART_STRINGS };

//# sourceMappingURL=chart-strings.js.map