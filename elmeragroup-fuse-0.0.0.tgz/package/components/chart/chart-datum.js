"use client";
import { ownFirsts } from "./layout/coarse-slots.js";
import { keywordSlots, listedSlots, nowSlotOf } from "./layout/datum.js";
import { childSlot } from "./chart-reference.js";
// src/components/chart/chart-datum.ts
/** Whether a datum names x values rather than a keyword. */
function isListed(datum) {
	return datum !== "first" && datum !== "last" && datum !== "min" && datum !== "max" && datum !== "now";
}
/**
* The slots a datum selects for a series, each the first Root slot of the series' own slot, once.
*
* @param context - The Root.
* @param part - The selecting part's display name, which an x of the wrong type names.
* @param series - The series.
* @param datum - A keyword or explicit x values.
* @param values - The value a keyword compares at each Root slot, null where none draws.
* @returns The selected slots, ascending.
* @throws {ChartCompositionError} `x-type-mismatch` for an x of the axis' other type.
*/
function datumSlots(context, part, series, datum, values) {
	const { model } = context;
	if (model.window === null) return [];
	if (isListed(datum)) {
		const xs = Array.isArray(datum.x) ? datum.x : [datum.x];
		return ownFirsts(series, listedSlots(xs.map((x) => childSlot(context, part, x)), model.window));
	}
	const nowSlot = nowSlotOf(model.domain, context.now);
	return ownFirsts(series, keywordSlots(datum, {
		values,
		window: model.window,
		nowSlot
	}));
}
export { datumSlots };

//# sourceMappingURL=chart-datum.js.map