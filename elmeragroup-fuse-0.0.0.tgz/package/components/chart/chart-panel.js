"use client";
import { ChartLayoutContext, ChartPlotContext, PlotReadsContext } from "./chart-scope-contexts.js";
import { ChartCompositionError, assertKnownKey } from "./layout/errors.js";
import { sameItems } from "./layout/same-items.js";
import { layoutDomain } from "./layout/cartesian-model.js";
import { reportLayoutDomain, useChartRoot } from "./chart-context.js";
import { createChartLabels } from "./chart-labels.js";
import { createFrameOwner } from "./chart-motion.js";
import { colourFamilyError } from "./chart-paint.js";
import { usePanelPlot } from "./chart-plot.js";
import { PlotLoader } from "./chart-skeleton.js";
import { useSteady } from "./chart-steady.js";
import { use, useInsertionEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-panel.tsx
/**
* The error of a stack whose keys this Panel lists only some of. A stack sums its parts slot by
* slot, so one split over two Panels would float each Panel's part on parts its plot doesn't draw.
*
* @param config - The Root's config.
* @param keys - The Panel's series.
* @returns The error, or null when the Panel holds each of its stacks whole.
*/
function splitStackError(config, keys) {
	const listed = new Set(keys);
	for (const key of keys) {
		const stack = config[key]?.stack;
		if (stack === void 0) continue;
		const missing = Object.keys(config).find((other) => config[other]?.stack === stack && !listed.has(other));
		if (missing !== void 0) return new ChartCompositionError("Chart.Panel", "stack-across-panels", `lists ${JSON.stringify(key)} without ${JSON.stringify(missing)}, which share stack ${JSON.stringify(stack)}. List every key of a stack in one Panel.`);
	}
	return null;
}
/**
* A row with its own y axis and y domain. All Panels share Root's x grid, surface and tooltip. With
* Panels, every config key sits in exactly one Panel, every plot part sits in a Panel, and the
* x axis goes in the last Panel. A Panel under `orientation="horizontal"` throws `horizontal-panels`.
* The Panels align their plots through CSS subgrid, so each takes the widest value axis and every
* slot lands on the same pixels in every Panel. Each Panel's plot is `--chart-plot-height` tall,
* 12.5rem by default, which Root or the Panel can set. A Root stacks any number of Panels in
* source order.
*
* @beta
*/
function ChartPanel({ series, yBaseline = "zero", yInclude, className, style, children }) {
	const context = useChartRoot("Chart.Panel");
	if (use(ChartLayoutContext)?.kind === "panel") throw new ChartCompositionError("Chart.Panel", "nested-panel", "sits inside another Chart.Panel. Place every Panel directly under Chart.Root, one per row.");
	if (context.orientation === "horizontal") throw new ChartCompositionError("Chart.Panel", "horizontal-panels", "sits under orientation=\"horizontal\", where the categories already fill the rows. Draw horizontal bars in one Root with no Panel.");
	for (const key of series) assertKnownKey("Chart.Panel", context.config, key);
	const colourRule = colourFamilyError("Chart.Panel", context.config, series);
	if (colourRule !== null) throw colourRule;
	const stackRule = splitStackError(context.config, series);
	if (stackRule !== null) throw stackRule;
	const keys = useSteady(series, sameItems);
	const include = useSteady(yInclude, sameItems);
	const { model, stackOffset, registerPanel } = context;
	const input = useMemo(() => ({
		keys,
		baseline: yBaseline,
		include: include ?? []
	}), [
		keys,
		yBaseline,
		include
	]);
	const y = useMemo(() => layoutDomain({
		...model,
		stackOffset
	}, input), [
		model,
		stackOffset,
		input
	]);
	const { update } = context;
	const decided = useRef(update);
	useInsertionEffect(() => {
		if (decided.current === update) return;
		decided.current = update;
		reportLayoutDomain(update, keys, y.domain);
	}, [
		update,
		keys,
		y.domain
	]);
	const [labels] = useState(createChartLabels);
	const [owner] = useState(() => createFrameOwner("panel"));
	const layout = useMemo(() => ({
		kind: "panel",
		keys,
		y,
		baseline: yBaseline,
		owner,
		labels
	}), [
		keys,
		y,
		yBaseline,
		owner,
		labels
	]);
	const plotRef = useRef(null);
	const { plot, probe, reads } = usePanelPlot(plotRef);
	useLayoutEffect(() => registerPanel({
		layout: input,
		plot: () => plotRef.current
	}), [registerPanel, input]);
	const { placeSpan } = context;
	useLayoutEffect(() => {
		placeSpan();
	});
	return /* @__PURE__ */ jsx(ChartLayoutContext, {
		value: layout,
		children: /* @__PURE__ */ jsxs("div", {
			"data-slot": "chart-panel",
			className,
			style,
			children: [/* @__PURE__ */ jsxs("div", {
				ref: plotRef,
				"data-slot": "chart-plot",
				"aria-hidden": "true",
				children: [probe, plot === null && !model.empty ? /* @__PURE__ */ jsx(PlotLoader, {}) : null]
			}), /* @__PURE__ */ jsx(ChartPlotContext, {
				value: plot,
				children: /* @__PURE__ */ jsx(PlotReadsContext, {
					value: reads,
					children
				})
			})]
		})
	});
}
Object.assign(ChartPanel, { displayName: "Chart.Panel" });
export { ChartPanel };

//# sourceMappingURL=chart-panel.js.map