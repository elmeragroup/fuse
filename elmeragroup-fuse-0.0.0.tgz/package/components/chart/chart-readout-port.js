"use client";
import { createContext } from "react";
// src/components/chart/chart-readout-port.ts
/**
* The readout port: what every Root that has a readout provides to the parts every family shares,
* the Tooltip's and the Legend's parts, Empty, Swatch, SeriesLabel, SeriesIcon and `useChartPoint`.
* A shared part reads its Root through this port alone, so a family ships its own model and pick
* and never another family's. Each Root memoises its port on its own context, which changes with
* data, config and the effective window and never with the pointer, so a pointer move commits no
* shared part that reads only the port.
*
* Two capabilities ride with a family's own part instead, so a route that renders neither ships
* neither: the Tooltip part hands the shared tooltip body its `TooltipPlacer`, and the Table part
* hands the shared table body its `ChartTableModel`.
*
* An index names what the readout steps through: a slot on a cartesian Root, an item such as a
* slice or a ring on a pie or radial Root. A key names a config key, a series or a category.
*/
/** The enclosing Root's readout, or null outside every Root that has one. */
const ChartReadoutContext = createContext(null);
/**
* Root's selected config key, or null. It lives apart from the readout, so a selection renders the
* legend, the tooltip and the surface that show it, and no mark.
*/
const ChartSelectionContext = createContext(null);
export { ChartReadoutContext, ChartSelectionContext };

//# sourceMappingURL=chart-readout-port.js.map