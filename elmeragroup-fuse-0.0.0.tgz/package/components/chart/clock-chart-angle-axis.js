"use client";
import { formatSlot } from "./format/time-format.js";
import { clockDrawingIn, usePolarContext } from "./chart-polar-context.js";
import { labelWidth } from "./layout/label-width.js";
import { useLabelWidths } from "./chart-label-widths.js";
import { minOf, rayPlace } from "./clock-chart-dial.js";
import { PlacedLabel } from "./clock-chart-placed-label.js";
import { jsx } from "react/jsx-runtime";
// src/components/chart/clock-chart-angle-axis.tsx
/**
* The cycle's labels past the rim: hours on their slot's start round a day, weekdays and months
* centred on their span. They never rotate, they thin by stride as the dial narrows, keeping the
* cycle's first, by the widths of the text they print, a `format`'s included, and they take the
* frame's gutter beside the dial.
*
* @beta
*/
function ClockChartAngleAxis({ format, className, style }) {
	const { model, box, kernel } = usePolarContext("ClockChart.AngleAxis", ["clock"]);
	const clock = clockDrawingIn(model, "ClockChart.AngleAxis");
	const timeZone = clock.text.model.domain.kind === "time" ? clock.text.model.domain.timeZone : "UTC";
	const text = (label) => format === void 0 ? label.text.text : formatSlot(kernel.locale, timeZone, label.start, label.unit, format, "tick").text;
	const visibility = format === void 0 ? clock.labels.map((label) => label.visibility) : clock.fitLabels(clock.labels.map(text));
	const measured = useLabelWidths();
	return /* @__PURE__ */ jsx("div", {
		ref: measured,
		"data-slot": "clock-chart-angle-axis",
		"data-polar-layer": "",
		"data-outside": "",
		"aria-hidden": "true",
		className,
		style,
		children: clock.labels.map((label, index) => /* @__PURE__ */ jsx(PlacedLabel, {
			dataSlot: "clock-chart-angle-label",
			min: minOf(visibility[index] ?? "none"),
			hidden: (visibility[index] ?? "none") === "none",
			place: rayPlace(box, label.angle, labelWidth(text(label)), "outside"),
			children: text(label)
		}, label.start))
	});
}
Object.assign(ClockChartAngleAxis, { displayName: "ClockChart.AngleAxis" });
export { ClockChartAngleAxis };

//# sourceMappingURL=clock-chart-angle-axis.js.map