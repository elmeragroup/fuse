"use client";
import { createDrawGate, subscribeNever } from "./chart-draw-gate.js";
import { useState, useSyncExternalStore } from "react";
// src/components/chart/chart-store.ts
/**
* Root's external store for state that changes at pointer or key rate. Marks never subscribe to
* it. Root writes the active slot onto its own element and hands it to the followers of
* `chart-followers.ts`, and only the parts that print the active point read it through a selector,
* so a pointer move inside one slot commits nothing.
*
* The store also holds the phase of Root's entrance, which `chart-entrance.ts` moves on. A mark
* reads it through `usePhase` as it draws, so a mark that draws while the entrance waits joins it,
* and one that draws after it started snaps or fades in. The server and hydration snapshot is
* `"waiting"`, so a hydrating mark matches the server HTML wherever its Suspense boundary resolves.
*/
/**
* What a mark writes on `data-intro`, from the phase it first draws in. While the entrance waits it
* writes nothing, so the entrance animates it, and "none" when Root has no entrance. A mark that
* draws after the entrance started writes "fade" in a data update and "none" in any other commit.
*
* @param phase - The phase the mark first drew in.
* @param kind - The commit that mounted it.
* @param entrance - Whether Root has an entrance, which Root's CSS or the loop, as a bar's grows,
*   runs.
* @returns The attribute's value, or undefined to write none.
*/
function introFor(phase, kind, entrance) {
	if (phase === "waiting") return entrance ? void 0 : "none";
	return kind === "data" ? "fade" : "none";
}
/**
* How much of a pointer's speed each move takes from its own distance and time, the rest from the
* speed before it, so one quick event among slow ones counts for less than a flick.
*/
const SPEED_WEIGHT = .5;
const INITIAL = {
	phase: "waiting",
	active: null,
	source: null,
	near: null,
	pinned: false,
	dismissed: null,
	frozen: false,
	announcement: {
		text: "",
		count: 0
	},
	emphasis: {}
};
/**
* Create a Root's store.
*
* @param defaultActive - The slot active before any pointer or key moves, from `defaultActiveX`.
* @returns The store.
*/
function createChartStore(defaultActive = null) {
	const initial = defaultActive === null ? INITIAL : {
		...INITIAL,
		active: defaultActive,
		source: "default"
	};
	let state = initial;
	const listeners = /* @__PURE__ */ new Set();
	const keys = Object.keys(INITIAL);
	let last = null;
	return {
		initial,
		drawing: createDrawGate(),
		pointer: () => last,
		track(x, y, type, time) {
			const gap = last === null || last.type !== type ? 0 : time - last.time;
			last = {
				x,
				y,
				type,
				time,
				speed: last === null || gap <= 0 ? 0 : SPEED_WEIGHT * (Math.hypot(x - last.x, y - last.y) / gap) + .5 * last.speed
			};
		},
		get: () => state,
		set(patch) {
			const reopened = patch.source === "keyboard" || patch.active !== void 0 && patch.active !== null && patch.active !== state.dismissed;
			const next = {
				...state,
				...patch,
				dismissed: patch.dismissed !== void 0 ? patch.dismissed : reopened ? null : state.dismissed
			};
			if (keys.every((key) => Object.is(next[key], state[key]))) return;
			state = next;
			for (const listener of listeners) listener();
		},
		dismiss() {
			if (state.active === null && !state.pinned) return;
			this.set({
				active: null,
				source: null,
				near: null,
				pinned: false,
				frozen: false,
				dismissed: state.active
			});
		},
		announce(text) {
			this.set({ announcement: {
				text,
				count: state.announcement.count + 1
			} });
		},
		subscribe(listener) {
			listeners.add(listener);
			return () => {
				listeners.delete(listener);
			};
		}
	};
}
/**
* Read one value of the store. The server and hydration snapshot reads the initial state.
*
* @param store - The Root's store.
* @param select - Picks the value. Return a primitive, so equal values skip the render.
* @returns The selected value.
*/
function useChartStore(store, select) {
	return useSyncExternalStore(store.subscribe, () => select(store.get()), () => select(store.initial));
}
/**
* Root's entrance phase as a mark draws now. Root moves it outside any render, and no mark renders
* again for it, so a mark reads where the entrance is in each render it draws in. Hydration reads
* `"waiting"`, as the server did.
*
* @param store - The Root's store.
* @returns The phase.
*/
function usePhase(store) {
	return useSyncExternalStore(subscribeNever, () => store.get().phase, () => store.initial.phase);
}
/**
* What a mark writes on `data-intro` for its life, by the one rule every mark follows. While it
* hydrates it matches the server, which read the entrance waiting. In the first render it draws in
* it keeps what `introFor` says from Root's live phase, so a mark that draws while the entrance
* waits joins it, and one that first draws after the entrance started, as a series whose Suspense
* boundary hydrates late, takes its place at once. A bar or a dot mounts only once it draws, so
* it keeps the value of its first render, which is the same rule.
*
* @param store - The Root's store.
* @param kind - The commit the mark renders in.
* @param entrance - Whether Root has an entrance.
* @param drawn - Whether the mark draws in this render, which a measured plot and an open draw gate
*   allow.
* @returns The attribute's value, or undefined to write none.
*/
function useIntro(store, kind, entrance, drawn) {
	return useKeptIntro(introFor(usePhase(store), kind, entrance), drawn);
}
/**
* The `data-intro` value of a mark's first drawn render, as `useIntro` keeps it, from the value
* `introFor` gives the current render.
*
* @param live - What `introFor` says for this render.
* @param drawn - Whether the mark draws in this render.
* @returns The attribute's value, or undefined to write none.
*/
function useKeptIntro(live, drawn) {
	const [kept, setKept] = useState(null);
	if (kept !== null) return kept;
	if (drawn) setKept(live);
	return live;
}
export { createChartStore, introFor, useChartStore, useIntro, useKeptIntro, usePhase };

//# sourceMappingURL=chart-store.js.map