"use client";
// src/components/chart/chart-riders.ts
/**
* Create a Root's rider registry.
*
* @returns The registry.
*/
function createChartRiders() {
	const riders = /* @__PURE__ */ new WeakMap();
	let revision = 0;
	return {
		register: (layer, track) => {
			riders.set(layer, track);
			revision += 1;
			return () => {
				if (riders.get(layer) !== track) return;
				riders.delete(layer);
				revision += 1;
			};
		},
		track: (layer) => riders.get(layer)?.() ?? null,
		revision: () => revision
	};
}
export { createChartRiders };

//# sourceMappingURL=chart-riders.js.map