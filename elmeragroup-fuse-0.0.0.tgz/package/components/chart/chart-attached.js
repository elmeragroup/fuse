"use client";
import { ownCentre, ownSlot } from "./layout/coarse-slots.js";
import { pointAlong, slotCentreAt, snapAcross, valueAt } from "./layout/plot-frame.js";
import { geometryOf } from "./layout/bar-geometry.js";
import { joinPath } from "./chart-paths.js";
import { useFollowerPlacement, useMotionMark } from "./chart-motion-mark.js";
import { barAnchor } from "./chart-bar-draw.js";
import { crossfade } from "./chart-crossfade.js";
import { useRef } from "react";
// src/components/chart/chart-attached.ts
/**
* Where the marks attached to a series sit, and how they join its motion. Dots, a Marker, the
* active dot and the active value sit on the series' drawn point at a slot: a Line's or an Area's
* vertex, or a Bar's tip. During a data update each one joins the tween of what it sits on, so it
* draws on its vertex or its bar in every frame.
*/
/**
* The value a series draws its point at: the reading, or a stacked series' outer end.
*
* @param series - The series.
* @param slot - The domain slot.
* @returns The value, or null where the series has no reading.
*/
function pointValue(series, slot) {
	const extent = series.extents[slot];
	if (series.readings[slot]?.kind !== "reading" || extent === null || extent === void 0) return null;
	const [low, high] = extent;
	return low < 0 && high <= 0 ? low : high;
}
/**
* A series' resting point at a slot, unsnapped, the numbers its attached marks place and tween.
*
* @param place - The model's window and Root's x scale.
* @param frame - The layout's frame.
* @param series - The series.
* @param slot - The domain slot.
* @returns The point along the slot axis and across the value axis, or null without a reading.
*/
function restingPoint(place, frame, series, slot) {
	const { window, xScale } = place;
	const value = pointValue(series, slot);
	if (window === null || value === null) return null;
	return [slotCentreAt(frame, ownCentre(series, window, slot), xScale), valueAt(frame, value)];
}
/**
* Draw a point mark's centre from its numbers, on the column of the slot's crosshair and the device
* pixel of its value, as the path's vertex draws.
*
* @param frame - The layout's frame.
* @param xScale - Root's x scale.
* @param along - The unsnapped coordinate along the slot axis.
* @param across - The unsnapped coordinate along the value axis.
* @returns The centre as SVG `cx` and `cy`.
*/
function pointCentre(frame, xScale, along, across) {
	const x = pointAlong(frame, along, xScale);
	const y = snapAcross(frame, across);
	return frame.orientation === "vertical" ? {
		cx: x,
		cy: y
	} : {
		cx: y,
		cy: x
	};
}
/**
* Which drawing of a series an attached mark follows, first to last, when the series draws several.
* A point mark sits on the line, then the area, then the columns, then the bars. A value on bars
* sits on the columns or the bars first.
*/
const FOLLOWS = {
	line: [
		"line",
		"area",
		"columns",
		"bars"
	],
	bar: [
		"columns",
		"bars",
		"line",
		"area"
	]
};
/**
* Which drawing of a series its attached marks sit on: the first in `FOLLOWS` order that draws the
* series, or undefined when none does. Attaching and an active dot's ride both read it, so a dot
* rides the drawing it joins.
*
* @param context - Root's context.
* @param series - The series.
* @param prefer - What the marks sit on first, where the series draws both.
* @returns The drawing's kind, or undefined.
*/
function followedKind(context, series, prefer) {
	return FOLLOWS[prefer].find((kind) => kind === "bars" ? context.drawsBar(series.key) : context.paths.get(series.seriesIndex, kind) !== void 0);
}
/**
* A bar's drawn middle along the slot axis, then its tip, in its sub-band, at rest as in motion.
*
* @param values - The bar's numbers.
* @returns The middle and the tip, in plot pixels.
*/
function barTip(values) {
	const geometry = geometryOf(values);
	return [(geometry[0] + geometry[1]) / 2, geometry[3]];
}
/**
* How marks at some of a series' slots join the motion of what they sit on, the drawing
* `followedKind` names. Every selected slot joins its own bar, so tied extrema and a listed
* selection each rest on their bar's middle.
*
* @param context - Root's context.
* @param series - The series.
* @param slots - The marks' domain slots, in the order of their numbers.
* @param rest - The marks' resting numbers, a place and a value each.
* @param prefer - What the marks sit on first, where the series draws both.
* @returns The join, or undefined when nothing the marks sit on moves.
*/
function attachJoin(context, series, slots, rest, prefer) {
	const window = context.model.window ?? {
		first: 0,
		last: 0
	};
	const owned = slots.map((slot) => ownSlot(series, slot)[0]);
	const marks = owned.map((slot) => ({
		key: context.update.keys[slot] ?? String(slot),
		position: ownCentre(series, window, slot)
	}));
	const kind = followedKind(context, series, prefer);
	if (kind === void 0) return void 0;
	if (kind === "bars") return slots.length === 0 ? void 0 : {
		leads: owned.map((slot) => ({
			anchor: barAnchor(series.seriesIndex, slot),
			pick: barTip,
			rest: barTip,
			size: 2
		})),
		crossfade: null
	};
	const route = context.paths.get(series.seriesIndex, kind);
	return route === void 0 ? void 0 : {
		leads: joinPath(route, series.seriesIndex, kind, marks, rest),
		crossfade: route.crossfade
	};
}
/** Each value label's text, the update it rendered last and its text before that update. */
const shownTexts = /* @__PURE__ */ new WeakMap();
/**
* Note the text a label rendered under an update, in its layout effect, so a crossfade that copies
* the label's mark can fade out the text it showed before the update.
*
* @param node - The label's node, or null before it mounts.
* @param text - The text it rendered.
* @param update - Root's update it rendered under.
*/
function noteShownText(node, text, update) {
	if (node === null) return;
	const last = shownTexts.get(node);
	const before = last === void 0 ? text : last.update === update ? last.before : last.now;
	shownTexts.set(node, {
		update,
		before,
		now: text
	});
}
/**
* Copy a mark that holds value labels as it showed before an update: a deep copy of the live node
* whose labels take the text they showed before it.
*
* @param live - The mark's live node.
* @param update - The update that crossfades.
* @returns The copy.
*/
function copyBefore(live, update) {
	const copy = deepCopy(live);
	const selector = "[data-slot=\"chart-value-label\"]";
	const labels = [...copy.querySelectorAll(selector)];
	live.querySelectorAll(selector).forEach((label, index) => {
		const shown = shownTexts.get(label);
		const copied = labels[index];
		if (shown === void 0 || copied === void 0) return;
		copied.textContent = shown.update === update ? shown.before : shown.now;
	});
	return copy;
}
/**
* Place an attached mark. When the path commit it follows crossfades the path, the mark crossfades
* with it, once: the copy it kept of how it last showed, its pills' old text included, fades out
* where the loop last drew it, in an element beside the live one, and the mark lands on its new
* place and fades in. A pointer or key step never starts one. Otherwise it takes its placement.
* It keeps a copy of its live node as its `copy` says, for the next crossfade.
*
* @param input - The mark's join, node, outgoing element and writer, and what it showed last.
*/
function placeAttached(input) {
	const { node, outgoing, before, shown, copy } = input;
	const old = shown.current;
	const fade = input.join?.crossfade ?? null;
	const fades = input.cause === "commit" && fade !== null && fade !== old?.crossfade && node !== null && outgoing !== null && before !== null && old !== null && !input.motion.snaps();
	const source = fades ? copy.outgoing?.(old.node, before, input.update) ?? old.node : null;
	if (fades && source !== null) {
		crossfade(node, outgoing, (drawing) => input.draw(drawing, old.look, before), source);
		input.place(input.placement.kind === "join" ? input.placement : { kind: "snap" });
	} else input.place(input.placement);
	if (node === null) {
		shown.current = null;
		return;
	}
	if (input.cause === "commit" || old === null) shown.current = {
		node: copy.keep?.(node) ?? deepCopy(node),
		look: input.look,
		crossfade: fade
	};
	else {
		copy.sync?.(old.node, node);
		shown.current = {
			...old,
			crossfade: fade
		};
	}
}
/** A deep copy of a node, text included. */
function deepCopy(node) {
	const copy = node.cloneNode(true);
	return copy instanceof Element ? copy : node;
}
/** Whether a copy is the same kind of element as the live node it copies. */
function sameKind(copy, live) {
	return live !== null && copy.constructor === live.constructor;
}
/**
* How attached point marks reach a commit's geometry: they join what they sit on, and snap when
* nothing they sit on moves, so a dot never tweens on a route of its own.
*/
function attachedPlacement(placement, join) {
	return join === void 0 && placement.kind === "move" ? { kind: "snap" } : placement;
}
/**
* Register a mark that sits on a series' drawn point, as Dots, a Marker, the active dot and the
* value followers do: its motion mark, its follower placement, the element its crossfade fades out
* in and the copy it keeps for it.
*
* @param context - Root's context.
* @param drawn - The frame the mark draws in, or null before the plot is measured.
* @param draw - The mark's writer, bound at module scope in the mark's module.
* @param look - The writer's look.
* @param axes - What each of the mark's numbers measures.
* @param options - Whether it is a point mark, which never tweens on a route of its own, and how
*   it keeps its copy, on commit paints with a deep clone by default.
* @returns The mark.
*/
function useAttachedMark(context, drawn, draw, look, axes, options = {}) {
	const { motion } = context;
	const mark = useMotionMark(motion, draw, look, axes);
	const placeFor = useFollowerPlacement(context.update, drawn?.plot ?? null, context.orientation, drawn?.frame ?? null);
	const outgoingRef = useRef(null);
	const shown = useRef(null);
	const { point = false, copy = COMMIT_COPY } = options;
	const attach = (cause, joined, target) => {
		const asked = placeFor(cause, joined);
		if (target === null) return;
		const live = mark.node();
		placeAttached({
			motion,
			cause,
			join: joined,
			placement: point ? attachedPlacement(asked, joined) : asked,
			place: (placement) => mark.place(target, placement),
			node: live,
			outgoing: outgoingRef.current,
			before: mark.drawn(),
			look,
			shown,
			draw: (drawing, old, values) => {
				if (sameKind(drawing, live)) draw(drawing, old, values);
			},
			copy,
			update: context.update
		});
	};
	return {
		ref: mark.ref,
		node: mark.node,
		outgoingRef,
		attach,
		drawn: mark.drawn
	};
}
/** The default copy: a deep clone, kept on commit paints. */
const COMMIT_COPY = {};
/**
* What each number of a point mark measures, a place along the slot axis then a value, which the
* loop repeats for a mark that holds several points.
*
* @param orientation - Root's orientation.
* @returns One point's axes.
*/
function pointAxes(orientation) {
	return orientation === "vertical" ? ["x", "y"] : ["y", "x"];
}
export { attachJoin, barTip, copyBefore, followedKind, noteShownText, pointAxes, pointCentre, restingPoint, useAttachedMark };

//# sourceMappingURL=chart-attached.js.map