"use client";
import { valueAt } from "./layout/plot-frame.js";
import { jsx } from "react/jsx-runtime";
// src/components/chart/chart-path-paint.tsx
/**
* The stops of a scale's or a threshold's steps along the value axis, from the gradient's start at
* the plot's top or left.
*/
function scaleStops(paint, ramp, frame) {
	const { edges } = paint;
	if (edges.length === 0) return [{
		offset: 0,
		paint: paint.base
	}];
	const length = frame.orientation === "vertical" ? frame.box.height : frame.box.width;
	const share = (value) => length === 0 ? 0 : Math.min(1, Math.max(0, valueAt(frame, value) / length));
	const regions = ramp.map((step, index) => ({
		step,
		low: index === 0 ? Number.NEGATIVE_INFINITY : edges[index - 1] ?? 0,
		high: index === ramp.length - 1 ? Number.POSITIVE_INFINITY : edges[index] ?? 0
	}));
	return (frame.orientation === "vertical" ? regions.toReversed() : regions).flatMap(({ step, low, high }) => {
		const [start = 0, end = 0] = [share(Number.isFinite(low) ? low : -Number.MAX_VALUE), share(Number.isFinite(high) ? high : Number.MAX_VALUE)].toSorted((a, b) => a - b);
		return [{
			offset: start,
			paint: step
		}, {
			offset: end,
			paint: step
		}];
	});
}
/**
* The gradient a series path paints from, or nothing for a single role, which paints through the
* series' own colour.
*
* @param props - The gradient's id, the series paint and the frame it draws in.
* @returns The gradient, or null.
*/
function PathPaint({ id, paint, frame }) {
	const vertical = frame.orientation === "vertical";
	const { width, height } = frame.box;
	let stops;
	let ends;
	if (paint.stops !== void 0) {
		const list = paint.stops;
		stops = list.map((stop, index) => ({
			offset: index / Math.max(1, list.length - 1),
			paint: stop
		}));
		ends = vertical ? {
			x2: width,
			y2: 0
		} : {
			x2: 0,
			y2: height
		};
	} else if (paint.ramp !== void 0) {
		stops = scaleStops(paint, paint.ramp, frame);
		ends = vertical ? {
			x2: 0,
			y2: height
		} : {
			x2: width,
			y2: 0
		};
	} else return null;
	return /* @__PURE__ */ jsx("linearGradient", {
		id,
		gradientUnits: "userSpaceOnUse",
		x1: "0",
		y1: "0",
		x2: ends.x2,
		y2: ends.y2,
		children: stops.map((stop, index) => /* @__PURE__ */ jsx("stop", {
			offset: stop.offset,
			style: { "--chart-stop": stop.paint }
		}, index))
	});
}
/**
* Whether a series paints through a gradient.
*
* @param paint - The series paint.
* @returns Whether `PathPaint` draws one.
*/
function hasPathPaint(paint) {
	return paint.stops !== void 0 || paint.ramp !== void 0;
}
Object.assign(PathPaint, { displayName: "Chart.PathPaint" });
export { PathPaint, hasPathPaint };

//# sourceMappingURL=chart-path-paint.js.map