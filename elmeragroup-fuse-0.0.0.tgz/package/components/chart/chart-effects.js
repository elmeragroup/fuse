"use client";
import { pointAlong, slotCentreAt } from "./layout/plot-frame.js";
import { useChartRoot, usePlotLayout } from "./chart-context.js";
import { writeStyle } from "./chart-dom.js";
import { useChartFollower } from "./chart-followers.js";
import { useChartFrame } from "./chart-plot.js";
import { glideLength, snapGlide, stepSpring } from "./chart-spring.js";
import { useLayoutEffect, useRef } from "react";
import { jsx } from "react/jsx-runtime";
// src/components/chart/chart-effects.tsx
/**
* Wraps marks and glows their drawn layer, so the glow follows the mark's curve, group slot and
* shape. Each bar series casts a halo of its own colour at half alpha, and each line or area series
* one at full alpha.
*
* @beta
*/
function ChartGlow({ className, style, children }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "chart-glow",
		"aria-hidden": "true",
		className,
		style,
		children
	});
}
/** The series a Reveal masks, which each take the active slot's place. */
const MASKED = /* @__PURE__ */ new Set([
	"chart-line-series",
	"chart-area-series",
	"chart-dots"
]);
/** The series a Reveal's wrapper holds that its mask dims. */
function masked(element) {
	return [...element.children].flatMap((series) => series instanceof SVGElement && MASKED.has(series.getAttribute("data-slot") ?? "") ? [series] : []);
}
/**
* Wraps lines, areas and dots and shows them at full strength up to the active slot, as a hover
* trace. Past the active slot they draw at `--chart-hover-dim`, in their own colour, so forced
* colours and colour-vision deficiency keep each series apart. With no slot active they draw
* whole. Root writes the active slot's place on each series it masks, and a step glides the edge
* there on the crosshair's spring, so it moves with the crosshair and the active dot. Showing, a
* commit and reduced motion place it at once, and a pointer move renders nothing in React.
*
* @beta
*/
function ChartReveal({ className, style, children }) {
	const context = useChartRoot("Chart.Reveal");
	const drawn = useChartFrame("Chart.Reveal", usePlotLayout("Chart.Reveal"));
	const node = useRef(null);
	const shown = useRef(null);
	useChartFollower("Chart.Reveal", (active, cause) => {
		const element = node.current;
		const window = context.model.window;
		if (element === null) return;
		const at = active === null || drawn === null || window === null ? null : pointAlong(drawn.frame, slotCentreAt(drawn.frame, active.slot - window.first, context.xScale), context.xScale);
		const from = shown.current;
		shown.current = at;
		const spring = at !== null && from !== null && cause === "step" && !context.motion.snaps() ? stepSpring(context.store) : null;
		for (const series of masked(element)) {
			writeStyle(series, "--chart-active-x", at === null ? null : `${String(at)}px`);
			if (at === null || from === null || spring === null) snapGlide(series);
			else glideLength(series, "--chart-active-x", at, from - at, spring);
		}
	});
	useLayoutEffect(() => {
		const element = node.current;
		return () => {
			if (element !== null) for (const series of masked(element)) snapGlide(series);
		};
	}, []);
	return /* @__PURE__ */ jsx("div", {
		ref: node,
		"data-slot": "chart-reveal",
		"data-follow": "",
		"aria-hidden": "true",
		className,
		style,
		children
	});
}
Object.assign(ChartGlow, { displayName: "Chart.Glow" });
Object.assign(ChartReveal, { displayName: "Chart.Reveal" });
export { ChartGlow, ChartReveal };

//# sourceMappingURL=chart-effects.js.map