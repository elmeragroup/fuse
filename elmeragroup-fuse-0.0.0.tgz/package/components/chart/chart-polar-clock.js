"use client";
import { countOf } from "../../intl/count-of.js";
import { formatSlot, wallTimes } from "./format/time-format.js";
import { slotOf } from "./layout/x-domain.js";
import { isRoleList } from "./layout/color-key.js";
import { seriesPaintOf } from "./chart-paint.js";
import { chartDescription, optionName } from "./chart-text.js";
import { labelWidth } from "./layout/label-width.js";
import { pointerAngle, sweepOf } from "./layout/polar-angle.js";
import { POLAR_STRINGS } from "./format/polar-strings.js";
import { nearestHeld } from "./layout/near-series.js";
import { seriesReadout } from "./chart-polar-series.js";
import { clockRadius, instantAngle, slotAngles } from "./layout/clock.js";
import { clockLabelSlots, clockTier, fitClockLabels, pageSlot } from "./layout/clock-labels.js";
import { ownerSlot, slotAt } from "./layout/clock-path.js";
// src/components/chart/chart-polar-clock.ts
/** The radius a spoke label sits at, as a share of the outer radius. */
const CLOCK_LABEL_REACH = 1.1;
/** A series' numbers at rest and what its slots hold. */
function clockSeries(context, key, count, radius, inner) {
	const { model, config } = context;
	const series = model.series.find((entry) => entry.key === key);
	if (series === void 0) return null;
	const color = config[key]?.color ?? "chart-1";
	const paint = seriesPaintOf(key, color, series);
	const rest = [1];
	const states = [];
	const marked = [];
	const values = [];
	const stepAt = [];
	const placed = (value) => Math.max(inner, radius(value));
	for (let slot = 0; slot < count; slot += 1) {
		const first = series.coarse?.first[slot] ?? slot;
		const last = series.coarse?.last[slot] ?? slot;
		const { start } = slotAngles(first, count);
		const { end } = slotAngles(last, count);
		const reading = series.readings[slot];
		const extent = series.extents[slot] ?? null;
		let base = placed(0);
		let tip = base;
		if (reading?.kind === "reading" && extent !== null) {
			const [low, high] = extent;
			[base, tip] = reading.value < 0 ? [placed(high), placed(low)] : [placed(low), placed(high)];
		}
		rest.push(start, end, base, tip);
		states.push(first === slot ? reading?.kind ?? "pending" : "covered");
		marked.push(reading?.kind === "reading" && reading.quality === "estimated" || reading?.kind === "reading" && slot >= series.projectedFrom);
		const value = reading?.kind === "reading" ? reading.value : null;
		values.push(value);
		stepAt.push(value === null || paint.bins === void 0 ? 0 : paint.bins(value) - 1);
	}
	const ramp = paint.ramp;
	const steps = ramp === void 0 ? null : ramp.map((step, index) => ({
		paint: step,
		from: index === 0 ? 0 : Math.max(0, radius(paint.edges[index - 1] ?? 0))
	}));
	const missing = config[key]?.missing ?? "gap";
	return {
		key,
		index: series.seriesIndex,
		paint: paint.base,
		stops: isRoleList(color) ? paint.stops : void 0,
		steps,
		stepAt,
		stack: series.stack,
		slots: {
			states,
			marked,
			missing
		},
		rest,
		values,
		shown: Array.from({ length: count }, (_, slot) => slot)
	};
}
/** The cycle's labels, printed and fitted, and the fit for texts of a format of its own. */
function labelsOf(starts, timeZone, cycle, locale) {
	const tier = clockTier(cycle);
	const slots = clockLabelSlots(starts, timeZone, cycle);
	const fitLabels = (texts) => fitClockLabels(slots, texts.map((text) => labelWidth(text)), cycle, CLOCK_LABEL_REACH);
	const texts = slots.map(({ slot }) => formatSlot(locale, timeZone, starts[slot] ?? 0, tier.unit, tier.preset, "tick"));
	const shown = fitLabels(texts.map(({ text }) => text));
	return {
		labels: slots.map(({ slot, angle }, index) => ({
			angle,
			start: starts[slot] ?? 0,
			unit: tier.unit,
			text: texts[index] ?? {
				text: "",
				spoken: ""
			},
			visibility: shown[index] ?? "none"
		})),
		fitLabels
	};
}
/**
* A clock's model.
*
* @param input - The Root's cartesian model over the cycle's slots, its config, rows and props.
* @returns The model.
*/
function clockModel(input) {
	const { model, config, locale, timeZone, cycle, inner, scale } = input;
	const context = {
		config,
		locale,
		model,
		xFormat: input.xFormat,
		now: input.now
	};
	const starts = model.domain.kind === "time" ? model.domain.starts : [];
	const ends = model.domain.kind === "time" ? model.domain.ends : [];
	const count = starts.length;
	const { domain, ticks } = model.y;
	const radius = clockRadius({
		inner,
		outer: 1,
		domain,
		scale
	});
	const series = model.series.flatMap(({ key }) => clockSeries(context, key, count, radius, inner) ?? []);
	const nowSlot = input.now === void 0 ? -1 : slotOf(model.domain, input.now);
	const now = nowSlot === -1 || input.now === void 0 ? null : {
		slot: nowSlot,
		angle: instantAngle(nowSlot, (input.now - (starts[nowSlot] ?? 0)) / ((ends[nowSlot] ?? 1) - (starts[nowSlot] ?? 0) || 1), count)
	};
	const walls = wallTimes(starts, timeZone);
	const seen = /* @__PURE__ */ new Set();
	const clock = {
		count,
		starts,
		pairs: walls.map((wall) => {
			const offset = String(wall - (walls[0] ?? 0));
			const key = seen.has(offset) ? `${offset}#2` : offset;
			seen.add(offset);
			return key;
		}),
		inner,
		scale,
		domain,
		ticks,
		radius,
		zero: domain[0] < 0 && domain[1] > 0 ? radius(0) : null,
		series,
		...labelsOf(starts, timeZone, cycle, locale),
		now,
		format: config[model.series[0]?.key ?? ""]?.format ?? {},
		stackOffset: input.stackOffset,
		baseline: input.baseline,
		text: context,
		slotOf: (x) => slotOf(model.domain, x)
	};
	const keys = starts.map((start) => String(start));
	const polarStrings = POLAR_STRINGS[locale];
	const empty = model.empty;
	return {
		family: "clock",
		sweep: sweepOf(0, 360),
		count,
		keys,
		empty,
		description: empty ? chartDescription(context) : `${polarStrings.descriptionClock(countOf(locale, model.series.length, polarStrings.seriesWord))} ${chartDescription(context)}`,
		instructions: "clock",
		orientation: "horizontal",
		wrap: true,
		series: model.series.length,
		page: (index, direction) => pageSlot(starts, timeZone, cycle, index, direction),
		optionName: (index, focus, order, emphasis) => optionName(context, index, focus, order, emphasis),
		pick: (point, pixels) => {
			if (count === 0) return null;
			const slot = Math.min(count - 1, Math.floor(pointerAngle(point.x, point.y) / 360 * count));
			if (series.length < 2) return {
				slot,
				near: null
			};
			const distance = Math.hypot(point.x, point.y);
			const gaps = series.map((entry) => {
				const own = ownerSlot(entry.slots.states, slot);
				if (entry.slots.states[own] !== "reading") return null;
				return Math.abs(slotAt(entry.rest, own)[3] - distance);
			});
			return {
				slot,
				near: nearestHeld(gaps, pixels.near ?? null, pixels.nearFirm === true)
			};
		},
		ray: (index) => index < 0 || index >= count ? null : {
			angle: slotAngles(index, count).centre,
			radius: 1
		},
		selectKey: (_index, focus) => model.series[focus]?.key ?? null,
		selectable: Object.keys(config),
		table: {
			kind: "series",
			context: {
				...context,
				name: input.name,
				rows: input.rows
			},
			keys
		},
		readout: (kernel) => seriesReadout(context, kernel),
		issues: input.issues,
		drawing: {
			kind: "clock",
			clock
		}
	};
}
export { clockModel };

//# sourceMappingURL=chart-polar-clock.js.map