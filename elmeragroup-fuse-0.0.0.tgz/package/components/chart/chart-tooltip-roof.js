"use client";
import { glideShown } from "./chart-spring.js";
import "./layout/tooltip-place.js";
import { boundsOf, box, ellipse, higherRoof, polyline, raisedRoof, roofProfile, widenedRoof } from "./layout/tooltip-roof.js";
// src/components/chart/chart-tooltip-roof.ts
/** The layers that draw series marks: bars, lines, areas, dots and markers. */
const LAYERS = [
	"[data-slot=\"chart-bar-series\"]",
	"[data-slot=\"chart-line-series\"]",
	"[data-slot=\"chart-area-series\"]",
	"[data-slot=\"chart-dots\"]",
	"[data-slot=\"chart-marker\"]"
].join(",");
/**
* The active dots that show. They follow the pointer, so every read takes them afresh, where they
* rest: a dot that glides counts at the end of its glide. An active dot without `data-value` draws
* nothing at the active slot. On its way a dot rides its line, which the roof holds, so it stays
* under the popup as long as it reaches no farther from the line than the popup's gap above the
* roof, and `riderExcess` raises the roof by whatever it reaches beyond.
*/
const ACTIVE_DOTS = "[data-slot=\"chart-active-dot\"][data-value]";
const DRAWINGS = "path, polyline, line, polygon, rect, circle, ellipse";
/**
* Drawings that draw nothing of their own, inside a paint server, a clip or a mask, and the active
* bar's overlay, which redraws a bar the series layer draws too and follows the pointer.
*/
const UNDRAWN = "defs, clipPath, mask, pattern, linearGradient, radialGradient, [data-slot=\"chart-bar-active\"]";
/**
* How far above and below the plot the canvas reaches, in plot pixels, for a stroke or a curve
* that passes the plot's edge. A mark higher than this above the plot reads at this height.
*/
const OVERHANG = 128;
/**
* Create a Root's roof.
*
* @returns The roof.
*/
function createChartRoof() {
	let kept = null;
	let excess = 0;
	let excessReduced = null;
	let keptRiders = -1;
	let watching = null;
	return {
		read: (view) => {
			if (kept === null || keptRiders !== view.riders.revision()) {
				kept = seriesRoof(view);
				excessReduced = null;
				keptRiders = view.riders.revision();
				watching?.takeRecords();
			}
			if (excessReduced !== view.motion.reduced()) {
				excess = riderExcess(view.root);
				excessReduced = view.motion.reduced();
			}
			const roof = higherRoof(kept, roofProfile(drawnMarks(view, ACTIVE_DOTS), ...view.stretch));
			return raisedRoof(roof, excess);
		},
		forget: () => {
			kept = null;
		},
		watch: (root, changed, tweening) => {
			const observer = new MutationObserver((records) => {
				const moving = tweening();
				if (records.some((record) => changesMarks(record, root, moving))) changed();
			});
			observer.observe(root, {
				subtree: true,
				childList: true,
				attributes: true,
				attributeOldValue: true
			});
			for (let above = root.parentElement; above !== null; above = above.parentElement) observer.observe(above, {
				attributes: true,
				attributeFilter: ["style", "class"],
				attributeOldValue: true
			});
			watching = observer;
			return () => {
				observer.disconnect();
				if (watching === observer) watching = null;
			};
		}
	};
}
/**
* The attributes the loop writes as a tween's frames draw: a drawing's geometry and transform, and
* a bar's side of zero. Every other attribute on a mark or its layer comes from a commit, such as
* a new variant, quality or emphasis that a stylesheet strokes apart.
*/
const FRAME_ATTRIBUTES = /* @__PURE__ */ new Set([
	"d",
	"points",
	"x",
	"y",
	"width",
	"height",
	"cx",
	"cy",
	"r",
	"rx",
	"ry",
	"transform",
	"data-negative"
]);
/** Whether a DOM change alters what a series mark draws. */
function changesMarks(record, root, tweening) {
	const target = record.target instanceof Element ? record.target : record.target.parentElement;
	if (target === null) return false;
	if (record.type === "attributes") {
		const name = record.attributeName ?? "";
		if (tweening && FRAME_ATTRIBUTES.has(name)) return false;
		if (name === "style" && sameDrawingStyle(record.oldValue, target.getAttribute("style"), tweening)) return false;
		const styling = name === "style" || name === "class";
		if (target.contains(root) || target.querySelector(LAYERS) !== null) return styling;
		return target.closest(UNDRAWN) === null && target.closest(LAYERS) !== null;
	}
	if ([...record.addedNodes, ...record.removedNodes].some((node) => node instanceof Element && (node.matches(LAYERS) || node.querySelector(LAYERS) !== null))) return true;
	if (tweening) return false;
	return target.closest(UNDRAWN) === null && target.closest(LAYERS) !== null;
}
/**
* Whether two inline styles draw alike: the same declarations once the private `--_` properties
* and `--chart-active-x`, which parts write as they draw and as the pointer moves, are left out,
* and while a tween runs a Marker anchor's `--chart-marker-x` and `--chart-marker-y`, which the
* loop writes each frame.
*/
function sameDrawingStyle(before, after, tweening) {
	const skipped = tweening ? /^(--_|--chart-active-x\s*:|--chart-marker-[xy]\s*:)/u : /^(--_|--chart-active-x\s*:)/u;
	const drawing = (style) => (style ?? "").split(";").map((declaration) => declaration.trim()).filter((declaration) => declaration !== "" && !skipped.test(declaration)).join(";");
	return drawing(before) === drawing(after);
}
/**
* The series marks' profile. During a tween it holds every shape the loop will paint on the way.
* The marks' own writers draw them where they show, at evenly spaced fractions of the route the
* loop takes from there to the route's end, at the route's end and where they rest, and every
* shape drawn counts. The loop writes each frame as a fraction of that same route, so every curve,
* slide and bridge the marks paint lies among the shapes drawn, up to the gap between two
* neighbouring fractions, which the profile adds as a margin. A box or a dot, whose edges move in
* straight lines, counts as one box around where it shows, where its route ends and where it rests,
* which holds every place it passes.
*/
function seriesRoof(view) {
	const tween = routeRoof(view);
	if (tween !== null) return tween;
	const raster = pathRaster(view, LAYERS);
	raster.draw();
	const marks = [...drawnMarks(view, LAYERS), ...riddenMarks(view)];
	return higherRoof(roofProfile(marks, ...view.stretch), raster.read());
}
/**
* The bar tracks active dots ride, each an invisible line through its bars' far ends. A dot riding
* the straight stretch between two bars passes over the empty gap between them, where no bar holds
* the roof up, so the roof holds the track as it holds a drawn line. The dot reaches past the track
* no farther than it reaches past a line, which `riderExcess` covers. The tracks are in the plot
* pixels the dots' layers share with the plot.
*/
function riddenMarks(view) {
	const vertical = view.frame.orientation === "vertical";
	return [...view.root.querySelectorAll("[data-slot=\"chart-active-dot\"]")].flatMap((layer) => (view.riders.track(layer) ?? []).map(({ along, across }) => ({
		pieces: polyline(Array.from(along, (place, index) => vertical ? [place, across[index] ?? 0] : [across[index] ?? 0, place])),
		reach: 0
	})));
}
/**
* The most numbers a tween's read writes in all, its fractions included. A route with more numbers
* draws fewer fractions, each farther apart, so the read stays bounded on large charts. Measured
* in Chromium on 2026-11-02, the read added 8 to 15 ms to a data update of two 30-reading lines,
* and 36 to 65 ms to one of two 20,000-reading lines, with the popup open.
*/
const ROUTE_BUDGET = 12e4;
/**
* The most fractions a route draws, however far its marks travel. A full-height move on a 600 px
* plot then draws fractions under 2.5 px apart.
*/
const MOST_FRACTIONS = 256;
/**
* Every shape a tween paints, drawn through the marks' own writers and then drawn back where they
* show, all in one task, so nothing paints between. Fractions of the route sit at most a plot
* pixel apart along any number, up to `ROUTE_BUDGET`, past which the gap between two fractions
* becomes the margin the profile adds above and beside each column.
*
* @returns The profile, or null without drawing when no mark moves.
*/
function routeRoof(view) {
	const marks = [];
	view.motion.eachLanding((write, target, drawn, axes, end) => {
		marks.push({
			write,
			drawn,
			end,
			target,
			axes
		});
	});
	if (marks.length === 0) return null;
	let travel = 0;
	let numbers = 0;
	for (const { drawn, end, axes } of marks) {
		numbers += end.length;
		end.forEach((to, index) => {
			if (axes[index % axes.length] !== "size") travel = Math.max(travel, Math.abs(to - (drawn[index] ?? to)));
		});
	}
	const fractions = Math.max(1, Math.min(MOST_FRACTIONS, Math.ceil(travel), Math.floor(ROUTE_BUDGET / Math.max(1, numbers))));
	const gap = travel / fractions;
	const selector = `${LAYERS},${ACTIVE_DOTS}`;
	const raster = pathRaster(view, selector);
	const swept = /* @__PURE__ */ new Map();
	const sweep = () => {
		for (const drawing of drawingsOf(view, selector)) {
			if (drawing.localName === "path") continue;
			const mark = markOf(drawing, view);
			if (mark === null) continue;
			const held = swept.get(drawing);
			swept.set(drawing, {
				bounds: boundsOf(mark.pieces, held?.bounds ?? null),
				reach: Math.max(held?.reach ?? 0, mark.reach)
			});
		}
	};
	try {
		sweep();
		raster.draw();
		for (let step = 1; step <= fractions; step += 1) {
			const at = step / fractions;
			view.motion.batch(() => {
				for (const { write, drawn, end } of marks) write(end.map((to, index) => (drawn[index] ?? to) + (to - (drawn[index] ?? to)) * at));
			});
			raster.draw();
		}
		sweep();
		view.motion.batch(() => {
			for (const { write, target } of marks) write(target);
		});
		raster.draw();
		sweep();
		const footprints = [...swept.values()].flatMap(({ bounds, reach }) => bounds === null ? [] : [{
			pieces: box(bounds.left, bounds.top, bounds.right - bounds.left, bounds.bottom - bounds.top),
			reach
		}]);
		const profile = higherRoof(roofProfile(footprints, ...view.stretch), raster.read());
		return raisedRoof(widenedRoof(profile, gap), gap);
	} finally {
		view.motion.batch(() => {
			for (const { write, drawn } of marks) write(drawn);
		});
	}
}
/**
* A raster for the paths the layers a selector names. The browser draws each path's own data
* through its screen transform onto a canvas whose pixels are plot pixels, with its stroke's
* width, caps and joins, and a column's first painted pixel from the top is its roof. A pixel a
* path only grazes counts, so the roof errs high by under a pixel. The paths and their styles are
* found once, and each draw reads only their data and transforms.
*/
function pathRaster(view, selector) {
	const [start, end] = view.stretch;
	const first = Math.floor(start);
	const width = Math.max(1, Math.ceil(end) - first);
	const height = Math.ceil(view.frame.box.height) + 256;
	const paths = drawingsOf(view, selector).filter((drawing) => drawing.localName === "path").map((path) => ({
		path,
		style: getComputedStyle(path)
	}));
	const canvas = paths.length === 0 ? null : document.createElement("canvas");
	const context = canvas === null ? null : canvas.getContext("2d", { willReadFrequently: true });
	if (canvas !== null) {
		canvas.width = width;
		canvas.height = height;
	}
	const { surface, scale } = view;
	const toCanvas = new DOMMatrix().translate(-first, OVERHANG).scale(1 / scale.x, 1 / scale.y).translate(-surface.left, -surface.top);
	return {
		draw: () => {
			if (context === null) return;
			for (const { path, style } of paths) {
				const data = path.getAttribute("d") ?? "";
				const matrix = path.getScreenCTM();
				if (data === "" || matrix === null) continue;
				const outline = new Path2D(data);
				context.setTransform(toCanvas.multiply(matrix));
				if (style.fill !== "none" && style.fill !== "") context.fill(outline);
				if (style.stroke !== "none" && style.stroke !== "") {
					context.lineWidth = Number.parseFloat(style.strokeWidth) || 0;
					context.lineCap = canvasCap(style.strokeLinecap);
					context.lineJoin = canvasJoin(style.strokeLinejoin);
					context.stroke(outline);
				}
			}
		},
		read: () => {
			const tops = new Float64Array(width).fill(Number.POSITIVE_INFINITY);
			if (context === null) return {
				start: first,
				tops
			};
			const pixels = context.getImageData(0, 0, width, height).data;
			for (let column = 0; column < width; column += 1) for (let row = 0; row < height; row += 1) if ((pixels[(row * width + column) * 4 + 3] ?? 0) > 0) {
				tops[column] = row - OVERHANG;
				break;
			}
			return {
				start: first,
				tops
			};
		}
	};
}
/** The drawings the layers a selector names hold, past those that draw nothing of their own. */
function drawingsOf(view, selector) {
	const drawings = [];
	for (const layer of view.root.querySelectorAll(selector)) for (const drawing of layer.querySelectorAll(DRAWINGS)) if (drawing.closest(UNDRAWN) === null) drawings.push(drawing);
	return drawings;
}
/** The boxes and dots the layers a selector names draw now, in plot pixels. */
function drawnMarks(view, selector) {
	const marks = [];
	for (const drawing of drawingsOf(view, selector)) {
		if (drawing.localName === "path") continue;
		const mark = markOf(drawing, view);
		if (mark !== null) marks.push(mark);
	}
	return marks;
}
function canvasCap(cap) {
	return cap === "round" || cap === "square" ? cap : "butt";
}
function canvasJoin(join) {
	return join === "round" || join === "bevel" ? join : "miter";
}
/** One drawing's mark in plot pixels, or null for one the browser does not place. */
function markOf(drawing, view) {
	const matrix = restingMatrix(drawing);
	if (matrix === null) return null;
	const { surface, scale } = view;
	const toPlot = (x, y) => {
		const point = new DOMPoint(x, y).matrixTransform(matrix);
		return [(point.x - surface.left) / scale.x, (point.y - surface.top) / scale.y];
	};
	const perUnit = Math.sqrt(Math.abs(matrix.a * matrix.d - matrix.b * matrix.c)) / Math.sqrt(scale.x * scale.y);
	const style = getComputedStyle(drawing);
	const reach = style.stroke !== "none" && style.stroke !== "" ? (Number.parseFloat(style.strokeWidth) || 0) / 2 * perUnit : 0;
	const pieces = piecesOf(drawing, matrix, toPlot);
	return pieces.length === 0 ? null : {
		pieces,
		reach
	};
}
/**
* How far an active dot reaches from the centre it rides the line on, beyond the gap a popup keeps
* above the roof, in CSS pixels: its radius at the widest a ring animation scales it, as a ping
* ring's does, plus half its stroke. A default, ring or halo dot reaches 5 to 8 px and fits inside
* the 8 px gap, so only a ping ring, at 10 px, raises the roof. The roof reads it once for each
* profile it keeps, and again when the reader's motion preference changes, since reduced motion
* stops the ring's animation and with it the scale this read finds.
*/
function riderExcess(root) {
	let reach = 0;
	for (const dot of root.querySelectorAll("[data-slot=\"chart-active-dot\"] circle")) {
		const style = getComputedStyle(dot);
		const stroke = style.stroke === "none" ? 0 : Number.parseFloat(style.strokeWidth) || 0;
		reach = Math.max(reach, dot.r.baseVal.value * widestScale(dot) + stroke / 2);
	}
	return Math.max(0, reach - 8);
}
/** The largest `scale()` any running animation's keyframes give an element, 1 without one. */
function widestScale(element) {
	let widest = 1;
	for (const animation of element.getAnimations()) {
		const { effect } = animation;
		if (!(effect instanceof KeyframeEffect)) continue;
		for (const frame of effect.getKeyframes()) {
			const scale = /scale\(\s*([\d.]+)/u.exec(String(frame.transform ?? ""));
			if (scale !== null) widest = Math.max(widest, Number(scale[1]));
		}
	}
	return widest;
}
/**
* A drawing's screen matrix where it rests. An active dot's layer glides by a translation in its own
* pixels, which the screen matrix carries, and which the spring's closed form gives. The layer's own
* screen matrix scales that translation to the screen, so a transform inside the layer, such as a
* ping ring's scale, leaves it alone, and the drawing's matrix moves back by it.
*/
function restingMatrix(drawing) {
	const matrix = drawing.getScreenCTM();
	const layer = drawing.closest("[data-slot=\"chart-active-dot\"]");
	const shown = layer === null ? null : glideShown(layer);
	const scale = layer?.getScreenCTM();
	if (matrix === null || shown === null || scale === null || scale === void 0) return matrix;
	const [x, y] = shown;
	return new DOMMatrix().translate(-(scale.a * x + scale.c * y), -(scale.b * x + scale.d * y)).multiply(matrix);
}
/**
* A drawing's pieces from its bounding box: a box or an ellipse while its transform keeps it
* upright, and its four mapped corners otherwise.
*/
function piecesOf(drawing, matrix, toPlot) {
	const { x, y, width, height } = drawing.getBBox();
	if (!(Math.abs(matrix.b) < 1e-9 && Math.abs(matrix.c) < 1e-9)) {
		const corners = [
			toPlot(x, y),
			toPlot(x + width, y),
			toPlot(x + width, y + height),
			toPlot(x, y + height)
		];
		return polyline([...corners, toPlot(x, y)]);
	}
	const [x0, y0] = toPlot(x, y);
	const [x1, y1] = toPlot(x + width, y + height);
	const left = Math.min(x0, x1);
	const top = Math.min(y0, y1);
	const right = Math.max(x0, x1);
	const bottom = Math.max(y0, y1);
	return drawing.localName === "circle" || drawing.localName === "ellipse" ? ellipse((left + right) / 2, (top + bottom) / 2, (right - left) / 2, (bottom - top) / 2) : box(left, top, right - left, bottom - top);
}
export { createChartRoof };

//# sourceMappingURL=chart-tooltip-roof.js.map