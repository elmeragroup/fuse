"use client";
import { CHART_STRINGS } from "./format/chart-strings.js";
import { useChartReadout } from "./chart-readout.js";
import { Table } from "../table/table.js";
import { ChartTableShell, Twin, useTableDisclosure } from "./chart-table-shell.js";
import { Fragment, createContext, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-table-body.tsx
/**
* The table every chart family shares: a "Vis som tabell" button and the chart's data as a table,
* paged in the shell's pagination, with each TableColumn rendered in the header row and in each
* body row. The family's Table part hands it the table model, so a route that renders no Table
* ships no family's rows. TableColumn, the extra column every family's Table takes, lives in
* `chart-table-column.tsx`, so a route with no TableColumn ships no time formatting.
*/
/** The row a TableColumn renders in, or null outside a Table. */
const ChartTableRowContext = createContext(null);
/**
* One body cell: its text with each word in parentheses after it, or words for screen readers
* alone. The space before each word sits outside the word's muted span, because accessible-name
* rules that join inline children drop a space inside it, and a reader would hear "0,42(estimert)".
*/
function BodyCell({ cell }) {
	if (cell.kind === "covered") return null;
	const span = cell.rows > 1 ? { rowSpan: cell.rows } : {};
	if (cell.kind === "silent") return /* @__PURE__ */ jsx(Table.Cell, {
		...span,
		children: /* @__PURE__ */ jsx("span", {
			className: "sr-only",
			children: cell.spoken
		})
	});
	return /* @__PURE__ */ jsxs(Table.Cell, {
		...span,
		children: [/* @__PURE__ */ jsx(Twin, { text: cell.text }), cell.words.map((word) => /* @__PURE__ */ jsxs(Fragment, { children: [" ", /* @__PURE__ */ jsx("span", {
			"data-quality": "",
			children: `(${word})`
		})] }, word))]
	});
}
/**
* The table over a family's model. It lists the model's pages and renders the shown page's rows.
*
* @param props - The Table's props and the family's table model.
* @returns The table, or an empty fragment while the Root draws nothing.
*/
function ChartTableBody({ table, caption, xHeader, showLabel, hideLabel, className, style, children }) {
	const readout = useChartReadout("Chart.Table");
	const strings = CHART_STRINGS[readout.locale];
	const disclosure = useTableDisclosure();
	const [pageKey, setPageKey] = useState(null);
	const pages = table.pages();
	let index = 0;
	if (pageKey !== null) {
		let distance = Number.POSITIVE_INFINITY;
		pages.forEach((page, position) => {
			const gap = Math.abs(page.key - pageKey);
			if (gap < distance) {
				distance = gap;
				index = position;
			}
		});
	}
	const page = pages[index] ?? {
		key: 0,
		slots: [],
		label: "",
		spoken: ""
	};
	if (readout.empty) return /* @__PURE__ */ jsx(Fragment$1, {});
	const go = (next) => {
		const target = pages[next];
		if (target === void 0 || next === index) return;
		setPageKey(target.key);
		readout.store.announce(strings.pageStatus(String(next + 1), String(pages.length), target.spoken));
	};
	return /* @__PURE__ */ jsx(ChartTableShell, {
		disclosure,
		tableId: `${readout.id}-rows`,
		showLabel: showLabel ?? strings.showTable,
		hideLabel: hideLabel ?? strings.hideTable,
		className,
		style,
		caption: caption ?? table.caption(),
		head: /* @__PURE__ */ jsxs(Fragment$1, { children: [
			/* @__PURE__ */ jsx(Table.Head, {
				scope: "col",
				children: xHeader ?? table.xHeader()
			}),
			table.heads().map((head, column) => /* @__PURE__ */ jsx(Table.Head, {
				scope: "col",
				children: /* @__PURE__ */ jsx(Twin, { text: head })
			}, column)),
			/* @__PURE__ */ jsx(ChartTableRowContext, {
				value: {
					kind: "header",
					table
				},
				children
			})
		] }),
		pages: {
			index,
			count: pages.length,
			status: strings.pageStatus(String(index + 1), String(pages.length), page.label),
			go
		},
		children: table.rows(page).map((row) => /* @__PURE__ */ jsxs(Table.Row, { children: [
			/* @__PURE__ */ jsx(Table.Head, {
				scope: "row",
				children: /* @__PURE__ */ jsx(Twin, { text: row.head })
			}),
			row.cells.map((cell) => /* @__PURE__ */ jsx(BodyCell, { cell }, cell.key)),
			/* @__PURE__ */ jsx(ChartTableRowContext, {
				value: {
					kind: "row",
					slot: row.slot,
					table
				},
				children
			})
		] }, row.key))
	});
}
Object.assign(ChartTableBody, { displayName: "Chart.TableBody" });
export { ChartTableBody, ChartTableRowContext };

//# sourceMappingURL=chart-table-body.js.map