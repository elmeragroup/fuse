"use client";
import { hairline, ruleAcross, slotBand, valueAt } from "./layout/plot-frame.js";
import { useChartRoot, usePlotLayout } from "./chart-context.js";
import { useChartFrame } from "./chart-plot.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-grid.tsx
/**
* Lines at the value ticks, behind the marks. The line at 0 always draws solid, so negative values
* hang below a visible zero line. Lines across the value axis sit between the slots. Every line
* is a hairline, 1 px rounded down to whole device pixels, on the device pixel grid.
*
* @beta
*/
function ChartGrid({ orientation, variant = "solid", className, style }) {
	const { orientation: chartOrientation } = useChartRoot("Chart.Grid");
	const layout = usePlotLayout("Chart.Grid");
	const { y } = layout;
	const drawn = useChartFrame("Chart.Grid", layout);
	const valueLines = chartOrientation === "vertical" ? "horizontal" : "vertical";
	const lines = orientation ?? valueLines;
	const showValues = lines === "both" || lines === valueLines;
	const showSlots = lines === "both" || lines !== valueLines;
	const frame = drawn?.frame;
	const across = (at, direction) => frame === void 0 ? {} : ruleAcross(frame.box, direction, at);
	const slotDirection = valueLines === "horizontal" ? "vertical" : "horizontal";
	return /* @__PURE__ */ jsx("svg", {
		"data-slot": "chart-grid",
		"data-variant": variant,
		"data-direction": lines,
		"aria-hidden": "true",
		className,
		style: frame === void 0 ? style : {
			"--_rule-width": `${String(hairline(frame.box))}px`,
			...style
		},
		children: frame === void 0 ? null : /* @__PURE__ */ jsxs(Fragment, { children: [showValues ? y.ticks.map((tick) => /* @__PURE__ */ jsx("line", {
			"data-slot": "chart-grid-line",
			"data-axis": "value",
			"data-zero": tick === 0 ? "" : void 0,
			...across(valueAt(frame, tick), valueLines)
		}, `value-${String(tick)}`)) : null, showSlots ? Array.from({ length: Math.max(0, frame.count - 1) }, (_, index) => /* @__PURE__ */ jsx("line", {
			"data-slot": "chart-grid-line",
			"data-axis": "slot",
			...across(slotBand(frame, index + 1)[0], slotDirection)
		}, `slot-${String(index)}`)) : null] })
	});
}
Object.assign(ChartGrid, { displayName: "Chart.Grid" });
export { ChartGrid };

//# sourceMappingURL=chart-grid.js.map