"use client";
import { ChartCrosshairContext } from "./chart-scope-contexts.js";
import { useAxisFormat, useAxisTicks } from "./chart-axis-format.js";
import { alongLength, centreOf } from "./layout/plot-frame.js";
import { useChartRoot, usePlotLayout } from "./chart-context.js";
import { clientScale, writeAttribute, writeStyle } from "./chart-dom.js";
import { useChartFollower } from "./chart-followers.js";
import { CHART_SPRINGS } from "./layout/motion.js";
import { useChartFrame } from "./chart-plot.js";
import { sameShallow, useSteady } from "./chart-steady.js";
import { slotTickLabel } from "./chart-axis.js";
import { springTiming } from "./chart-spring.js";
import { use, useLayoutEffect, useMemo, useRef } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-slot-label.tsx
/** Above this many labels the pill prints one label, written at once, as a compact ticker. */
const ROLLING_LABELS = 60;
/** A run of letters or digits, or a run of anything else, so `30. sep.` rolls `30` and `sep` apart. */
const PART = /[\p{L}\p{N}]+|[^\p{L}\p{N}]+/gu;
function rollingOf(labels) {
	const split = labels.map((label) => label.match(PART) ?? []);
	const count = Math.max(0, ...split.map((parts) => parts.length));
	const stacks = Array.from({ length: count }, () => []);
	return {
		stacks,
		at: split.map((parts) => stacks.map((stack, part) => {
			const value = parts[part] ?? "";
			if (stack.at(-1) !== value) stack.push(value);
			return stack.length - 1;
		}))
	};
}
/**
* The active slot's label as a pill on the x axis. Write it inside a `Chart.Crosshair`. It rides
* along the axis to the active slot and prints the slot in the axis's format, and the tick labels
* under it fade out until it moves on. Each part of the label, such as a day or a month, rolls to
* its new value on a stack of its values, so a part that keeps its value stays still, and the pill
* glides and resizes on a spring. Above 60 labels it prints one label, written at once. Root moves
* it by writing styles, so a pointer move renders nothing in React. It is plot output, hidden from
* screen readers, which hear the slot from the focused option. The server renders none of it, and
* neither does a horizontal chart, whose axis prints every category.
*
* @beta
*/
function ChartSlotLabel({ format, className, style }) {
	const context = useChartRoot("Chart.SlotLabel");
	const layout = usePlotLayout("Chart.SlotLabel");
	const drawn = useChartFrame("Chart.SlotLabel", layout);
	const inside = use(ChartCrosshairContext);
	const axisFormat = useAxisFormat(context.axis);
	useAxisTicks(context.axis);
	const steadyFormat = useSteady(format, sameShallow) ?? axisFormat;
	const { locale, xScale, orientation } = context;
	const { domain, window } = context.model;
	const first = window?.first;
	const last = window?.last;
	const shows = inside && drawn !== null && orientation === "vertical";
	const compact = first !== void 0 && last !== void 0 && last - first + 1 > ROLLING_LABELS;
	const labels = useMemo(() => !shows || compact || first === void 0 || last === void 0 ? [] : Array.from({ length: last - first + 1 }, (_, index) => slotTickLabel({
		domain,
		locale
	}, first + index, steadyFormat)), [
		shows,
		compact,
		domain,
		first,
		last,
		locale,
		steadyFormat
	]);
	const rolling = useMemo(() => compact ? null : rollingOf(labels), [compact, labels]);
	const labelInputs = useMemo(() => ({
		domain,
		locale,
		format: steadyFormat
	}), [
		domain,
		locale,
		steadyFormat
	]);
	const lastLabel = useRef(null);
	const root = useRef(null);
	const measured = useRef(null);
	const compactWidth = useRef(0);
	const placedAt = useRef(null);
	const retry = useRef(() => void 0);
	const deferred = useRef(() => void 0);
	const retrying = useRef(false);
	const place = (node, known, frame, position, width) => {
		const half = width / 2 + known.padding;
		const length = alongLength(frame);
		const centre = Math.min(Math.max(centreOf(frame, position, xScale), half), Math.max(half, length - half));
		const rider = node.firstElementChild;
		if (rider instanceof HTMLElement) writeStyle(rider, "translate", `${String(centre)}px 0`);
		for (const { node: tick, box } of known.ticks) {
			const covered = box.left < centre + half && centre - half < box.right && box.top < known.bottom && known.top < box.bottom;
			writeAttribute(tick, "data-covered", covered ? "" : null);
		}
	};
	const repaint = useChartFollower("Chart.SlotLabel", (active, cause) => {
		const node = root.current;
		const known = measured.current;
		if (node !== null && known === null && active !== null && shows) retry.current();
		if (node === null || known === null || drawn === null || window === null || active === null) {
			placedAt.current = null;
			if (node !== null) writeAttribute(node, "data-shown", null);
			for (const { node: tick } of known?.ticks ?? []) writeAttribute(tick, "data-covered", null);
			return;
		}
		const position = active.slot - window.first;
		writeAttribute(node, "data-snap", placedAt.current !== null && cause === "step" ? null : "");
		writeAttribute(node, "data-shown", "");
		placedAt.current = position;
		if (compact) {
			const item = node.querySelector("[data-part=\"stack\"] > span");
			const cached = lastLabel.current;
			const label = cached?.inputs === labelInputs && cached.slot === active.slot ? cached.text : slotTickLabel(labelInputs, active.slot, labelInputs.format);
			lastLabel.current = {
				inputs: labelInputs,
				slot: active.slot,
				text: label
			};
			if (item !== null && item.textContent !== label) item.textContent = label;
			place(node, known, drawn.frame, position, compactWidth.current);
			return;
		}
		place(node, known, drawn.frame, position, writeParts(node, rolling, known, position));
	});
	useLayoutEffect(() => {
		deferred.current = () => {
			const node = root.current;
			if (node === null || !node.isConnected) return;
			measured.current = measureLabel(node, rolling);
			if (measured.current !== null) repaint();
		};
		retry.current = () => {
			if (retrying.current) return;
			retrying.current = true;
			requestAnimationFrame(() => {
				setTimeout(() => {
					retrying.current = false;
					deferred.current();
				}, 0);
			});
		};
	});
	useLayoutEffect(() => {
		const node = root.current;
		if (!shows || node === null) return;
		const remeasure = () => {
			measured.current = measureLabel(node, rolling);
			repaint();
		};
		measured.current = measureLabel(node, rolling);
		const fonts = node.ownerDocument.fonts;
		fonts.addEventListener("loadingdone", remeasure);
		let confirmed = false;
		const resized = new ResizeObserver(() => {
			if (confirmed) remeasure();
			confirmed = true;
		});
		for (const item of node.querySelectorAll("[data-part=\"stack\"] > span")) resized.observe(item);
		for (const { node: tick } of measured.current?.ticks ?? []) resized.observe(tick);
		return () => {
			resized.disconnect();
			fonts.removeEventListener("loadingdone", remeasure);
			for (const { node: tick } of measured.current?.ticks ?? []) writeAttribute(tick, "data-covered", null);
			measured.current = null;
		};
	});
	useLayoutEffect(() => {
		const pill = compact && shows ? root.current?.querySelector("[data-part=\"part\"]") : null;
		if (pill === null || pill === void 0) return;
		const observer = new ResizeObserver(([entry]) => {
			const width = entry?.contentBoxSize[0]?.inlineSize;
			if (width === void 0) return;
			compactWidth.current = width;
			const node = root.current;
			const known = measured.current;
			const position = placedAt.current;
			if (node !== null && known !== null && drawn !== null && position !== null) place(node, known, drawn.frame, position, width);
		});
		observer.observe(pill);
		return () => observer.disconnect();
	});
	if (!shows) return /* @__PURE__ */ jsx(Fragment$1, {});
	const { duration, easing } = springTiming(CHART_SPRINGS.ticker);
	const stacks = rolling?.stacks ?? [[""]];
	return /* @__PURE__ */ jsx("div", {
		ref: root,
		"data-slot": "chart-slot-label",
		"data-compact": compact ? "" : void 0,
		"aria-hidden": "true",
		className,
		style: {
			"--_spring-duration": `${String(duration)}ms`,
			"--_spring-easing": easing,
			...style
		},
		children: /* @__PURE__ */ jsxs("span", {
			"data-part": "rider",
			children: [compact ? null : /* @__PURE__ */ jsx("span", { "data-part": "pill" }), stacks.map((stack, part) => /* @__PURE__ */ jsx("span", {
				"data-part": "part",
				children: /* @__PURE__ */ jsx("span", {
					"data-part": "stack",
					children: stack.map((value, place) => /* @__PURE__ */ jsx("span", { children: value }, place))
				})
			}, part))]
		})
	});
}
/**
* Write each part's place and its stack's offset for a label, and the pill's width, and return the
* label's width.
*/
function writeParts(node, rolling, known, position) {
	const at = rolling?.at[position] ?? [];
	const widths = at.map((place, part) => known.widths[part]?.[place] ?? 0);
	const width = widths.reduce((sum, part) => sum + part, 0);
	let offset = -width / 2;
	node.querySelectorAll("[data-part=\"part\"]").forEach((part, index) => {
		writeStyle(part, "translate", `${String(offset)}px 0`);
		offset += widths[index] ?? 0;
		const stack = part.firstElementChild;
		const count = rolling?.stacks[index]?.length ?? 1;
		if (stack instanceof HTMLElement) writeStyle(stack, "translate", `0 ${String(-100 * (at[index] ?? 0) / count)}%`);
	});
	const pill = node.querySelector("[data-part=\"pill\"]");
	if (pill !== null) writeStyle(pill, "clip-path", `inset(0 ${String((known.full - width) / 2)}px round 9999px)`);
	return width;
}
/**
* Read the widths, the pill's padding and box and the tick boxes once, for every paint until the
* next layout, all in the layout pixels of the label's own box, whose left edge is the plot's.
*/
function measureLabel(node, rolling) {
	const origin = node.getBoundingClientRect();
	const pill = node.querySelector("[data-part=\"pill\"]") ?? node.querySelector("[data-part=\"part\"]");
	const scale = {
		x: clientScale(node).x,
		y: pill === null ? 1 : clientScale(pill).y
	};
	if (!(scale.x > 0 && Number.isFinite(scale.x) && scale.y > 0 && Number.isFinite(scale.y))) return null;
	const widths = [...node.querySelectorAll("[data-part=\"part\"]")].map((part) => [...part.querySelectorAll("[data-part=\"stack\"] > span")].map((item) => item.getBoundingClientRect().width / scale.x));
	const full = Math.max(0, ...(rolling?.at ?? []).map((places) => places.reduce((sum, place, part) => sum + (widths[part]?.[place] ?? 0), 0)));
	writeStyle(node, "--_full", `${String(full)}px`);
	const box = pill?.getBoundingClientRect() ?? origin;
	const padding = pill === null ? 0 : Number.parseFloat(getComputedStyle(pill).paddingLeft) || 0;
	const local = (at) => new DOMRect((at.left - origin.left) / scale.x, (at.top - origin.top) / scale.y, at.width / scale.x, at.height / scale.y);
	const ticks = [...node.closest("[data-slot=\"chart-frame\"]")?.querySelectorAll("[data-slot=\"chart-x-tick\"]") ?? []].flatMap((tick) => {
		const at = tick.getBoundingClientRect();
		return at.width === 0 ? [] : [{
			node: tick,
			box: local(at)
		}];
	});
	const pillBox = local(box);
	return {
		widths,
		full,
		padding,
		top: pillBox.top,
		bottom: pillBox.bottom,
		ticks
	};
}
Object.assign(ChartSlotLabel, { displayName: "Chart.SlotLabel" });
export { ChartSlotLabel };

//# sourceMappingURL=chart-slot-label.js.map