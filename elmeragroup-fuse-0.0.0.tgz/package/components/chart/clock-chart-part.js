"use client";
import { ChartCompositionError } from "./layout/errors.js";
import { useChartReadout } from "./chart-readout.js";
import { writeAttribute } from "./chart-dom.js";
import { clockDrawingIn, usePolarContext } from "./chart-polar-context.js";
import { seriesPaintOf } from "./chart-paint.js";
import { keywordSlots, listedSlots } from "./layout/datum.js";
import { ownerSlot, revealPath, slotAt } from "./layout/clock-path.js";
import { useLayoutEffect, useRef } from "react";
// src/components/chart/clock-chart-part.ts
/**
* What every clock series part shares: the series a part names, its placement on the Root's loop
* through the classifier, the slots a datum selects, the reveal and path writers, the value glow's
* retuning, and the curve each Line registers for an ActiveDot.
*/
/** The dial's nominal radius in CSS pixels, half of the 12.5rem cell, which a value glow's blur reads. */
const NOMINAL_RADIUS = 100;
/** The glow region of a dial: its whole box past the rim, in the dial's units. */
const DIAL_REGION = {
	x: -1.5,
	y: -1.5,
	width: 3,
	height: 3,
	unit: 100
};
/**
* Throw `baseline-required` for a part that encodes its value as the length from 0, as a Column's
* wedge and an Area's band do, under a Root whose `yBaseline="none"` domain cuts that length off at
* the hole, as the cartesian Bar and Area rule says.
*
* @param clock - The dial.
* @param part - The part's display name.
* @param mark - What the part draws from 0, for the message.
* @throws {ChartCompositionError} `baseline-required` under `yBaseline="none"`.
*/
function assertClockBaseline(clock, part, mark) {
	if (clock.baseline !== "none") return;
	throw new ChartCompositionError(part, "baseline-required", `draws in a dial with yBaseline="none", but ${mark} encodes its value as the length from 0. Keep the zero baseline, or draw a ClockChart.Line.`);
}
/**
* The slots a datum selects on a clock: a keyword over a series' drawn values, or the slots holding
* explicit instants, each resolved to the slot that owns its reading.
*
* @param clock - The clock's drawing.
* @param part - The selecting part's display name, which an x of the wrong type names.
* @param series - The series.
* @param datum - A keyword or explicit x values.
* @returns The selected slots, ascending.
* @throws {ChartCompositionError} `x-type-mismatch` for an x string, since a dial reads instants.
*/
function clockDatumSlots(clock, part, series, datum) {
	const window = clock.text.model.window;
	if (window === null) return [];
	const owned = (picked) => [...new Set(picked.map((slot) => ownerSlot(series.slots.states, slot)))].toSorted((a, b) => a - b);
	if (datum === "first" || datum === "last" || datum === "min" || datum === "max" || datum === "now") return owned(keywordSlots(datum, {
		values: series.values,
		window,
		nowSlot: clock.now?.slot ?? -1
	}));
	const xs = Array.isArray(datum.x) ? datum.x : [datum.x];
	return owned(listedSlots(xs.map((x) => {
		if (typeof x === "string") throw new ChartCompositionError(part, "x-type-mismatch", "received a string x on a clock dial. Pass a Date or epoch milliseconds, because a date-only string parses as UTC midnight and lands on the wrong day.");
		return clock.slotOf(x);
	}), window));
}
function useClockSeries(part, dataKey) {
	const polar = usePolarContext(part, ["clock"]);
	useChartReadout(part).assertKey(part, dataKey);
	const clock = clockDrawingIn(polar.model, part);
	return {
		polar,
		clock,
		series: clock.series.find(({ key }) => key === dataKey)
	};
}
/**
* The numbers a series' old slots draw in, paired with the new slots by their wall clock offsets
* from the cycle's start, so a change of slot count tweens each slot from where it stood and the
* dial turns. A slot with no old twin, as the repeated hour of a 25-hour day, opens from zero width
* at the end of the slot before it, at that slot's base and tip.
*/
function pairedFrom(previous, pairs) {
	const at = new Map(previous.pairs.map((pair, slot) => [pair, slot]));
	const from = [previous.values[0] ?? 1];
	const [, , firstBase, firstTip] = slotAt(previous.values, 0);
	let before = [
		0,
		firstBase,
		firstTip
	];
	pairs.forEach((pair) => {
		const old = at.get(pair);
		if (old !== void 0) {
			const numbers = slotAt(previous.values, old);
			from.push(...numbers);
			before = [
				numbers[1],
				numbers[2],
				numbers[3]
			];
			return;
		}
		const [end, base, tip] = before;
		from.push(end, end, base, tip);
	});
	return from;
}
/**
* Place a series mark for a commit through the classifier: the entrance, an update, or a turn of
* the dial when the slot count changes, along the route that pairs the old slots with the new. A
* turn starts from what the mark draws, mid-tween too, so its first frame never jumps. It places
* only when the dial, the series, the writer's look or the commit changes, so a render that changes
* none of them, such as the parent's unrelated state, redraws nothing.
*
* @param clock - The dial.
* @param series - The series the mark draws.
* @param look - What the mark's writer reads beside its numbers.
* @param mark - The mark's commit classifier, its placement and the numbers it drew last.
*/
function useClockPlacement(clock, series, look, mark) {
	const { commit, place, drawn } = mark;
	const last = useRef(null);
	useLayoutEffect(() => {
		if (series === void 0) return;
		const previous = last.current;
		last.current = clock.pairs;
		const via = previous !== null && previous.length !== clock.pairs.length ? {
			from: pairedFrom({
				pairs: previous,
				values: drawn() ?? series.rest
			}, clock.pairs),
			to: series.rest
		} : void 0;
		const from = series.rest.slice();
		from[0] = 0;
		place(series.rest, commit(series.index, from, via));
	}, [
		clock,
		series,
		look,
		commit,
		place,
		drawn
	]);
}
/** Write the entrance's open wedge onto a mark's clip path, or none once the dial is whole. */
function writeReveal(group, reveal) {
	const clip = group.ownerSVGElement?.querySelector("[data-part=\"reveal\"]");
	if (clip !== null && clip !== void 0) writeAttribute(clip, "d", revealPath(reveal));
	writeAttribute(group, "clip-path", reveal >= 360 ? null : group.getAttribute("data-clip") ?? null);
}
/** Write each named path of a group from a map of paths by part. */
function writeParts(group, paths) {
	for (const path of group.querySelectorAll("path[data-part]")) {
		const part = path.getAttribute("data-part");
		if (part === null || part === "reveal") continue;
		writeAttribute(path, "d", paths.get(part) ?? "");
	}
}
/** The series paint of a drawing's series, its config colour over its model. */
function paintOf(clock, series) {
	const model = clock.text.model.series.find(({ key }) => key === series.key);
	return seriesPaintOf(series.key, clock.text.config[series.key]?.color ?? "chart-1", model);
}
/** The group a wedge or a dot paints in: its step, and past or now under `data-fade="past"`. */
function groupOf(series, clock, slot) {
	const past = clock.now !== null && slot < clock.now.slot ? "-past" : "";
	return `step-${String(series.stepAt[slot] ?? 0)}${past}`;
}
/**
* Tune a value glow's blur to the dial as it draws: the halo's CSS pixels over the dial's pixels per
* unit, and the filter's region past the dial by three of them.
*/
function retuneGlow(svg, unit, halo) {
	if (!(unit > 0)) return;
	const deviation = halo.deviation / unit;
	const margin = 3 * deviation;
	for (const filter of svg.querySelectorAll("filter")) {
		writeAttribute(filter, "x", -1.5 - margin);
		writeAttribute(filter, "y", -1.5 - margin);
		writeAttribute(filter, "width", 3 + 2 * margin);
		writeAttribute(filter, "height", 3 + 2 * margin);
		const blur = filter.querySelector("feGaussianBlur");
		if (blur !== null) writeAttribute(blur, "stdDeviation", deviation);
	}
}
/** Each loop's drawn curves by series and by part, which an ActiveDot rides between slots. */
const curves = /* @__PURE__ */ new WeakMap();
/**
* Note the curve a Line or an Area draws its series in, for as long as it is mounted.
*
* @param motion - The Root's loop.
* @param key - The series.
* @param curve - The curve it draws.
* @param part - Which part draws it.
*/
function useSeriesCurve(motion, key, curve, part) {
	useLayoutEffect(() => {
		const byKey = curves.get(motion) ?? /* @__PURE__ */ new Map();
		curves.set(motion, byKey);
		const byPart = byKey.get(key) ?? /* @__PURE__ */ new Map();
		byKey.set(key, byPart);
		byPart.set(part, curve);
		return () => {
			if (byPart.get(part) === curve) byPart.delete(part);
		};
	}, [
		motion,
		key,
		curve,
		part
	]);
}
/**
* The curve a series' ActiveDot rides: its Line's, else its Area's top edge, or null for a series
* drawn only as Columns or Dots.
*
* @param motion - The Root's loop.
* @param key - The series.
* @returns The curve, or null.
*/
function seriesCurve(motion, key) {
	const byPart = curves.get(motion)?.get(key);
	return byPart?.get("line") ?? byPart?.get("area") ?? null;
}
export { DIAL_REGION, NOMINAL_RADIUS, assertClockBaseline, clockDatumSlots, groupOf, paintOf, retuneGlow, seriesCurve, useClockPlacement, useClockSeries, useSeriesCurve, writeParts, writeReveal };

//# sourceMappingURL=clock-chart-part.js.map