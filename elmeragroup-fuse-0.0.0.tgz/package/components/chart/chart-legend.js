"use client";
import { ChartLegendSideContext, ChartRowContext } from "./chart-scope-contexts.js";
import { useActiveIndex } from "./chart-active-point.js";
import { ChartSelectionContext } from "./chart-readout-port.js";
import { shareDigits, shareText, useChartReadout, useReadoutKey } from "./chart-readout.js";
import { ChartSeriesLabel, ChartSwatch } from "./chart-series.js";
import { ToggleGroupItem, ToggleGroupRoot } from "../toggle-group/toggle-group.js";
import { use, useEffect } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
// src/components/chart/chart-legend.tsx
/**
* A static list of the series, "bottom" by default, as Figma's `Chart` places it. Without children,
* one LegendItem per config key, or per kept category and then one Other item in a folded pie. A
* series coloured by a threshold has two entries, its `above` side first, each with the side's
* label and swatch. The list is visible text, so screen readers read it, and its swatches are
* decoration.
*
* @beta
*/
function ChartLegend({ side = "bottom", render, className, children, ...props }) {
	useChartReadout("Chart.Legend");
	return useRender({
		defaultTagName: "ul",
		render,
		props: {
			"data-slot": "chart-legend",
			"data-side": side,
			...mergeProps({
				className,
				children: children ?? /* @__PURE__ */ jsx(ChartLegendItem, {})
			}, props)
		}
	});
}
/**
* The legend entries of one series: one per side of a threshold colour, the upper side first as
* the value axis reads, or one entry with no side for every other colour.
*/
function entrySides(readout, key) {
	return readout.item(key)?.sides ?? [null];
}
/** One legend entry's own element. */
function LegendEntry({ itemKey, side, render, className, children, props }) {
	const readout = useChartReadout("Chart.LegendItem");
	const selectedKey = use(ChartSelectionContext);
	const seriesIndex = readout.item(itemKey)?.index;
	const element = useRender({
		defaultTagName: "li",
		render,
		props: {
			"data-slot": "chart-legend-item",
			"data-series": seriesIndex,
			"data-dimmed": selectedKey !== null && selectedKey !== itemKey ? "" : void 0,
			...mergeProps({
				className,
				children: children ?? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(ChartSwatch, {}), /* @__PURE__ */ jsx(ChartSeriesLabel, {})] })
			}, props)
		}
	});
	return /* @__PURE__ */ jsx(ChartRowContext, {
		value: itemKey,
		children: /* @__PURE__ */ jsx(ChartLegendSideContext, {
			value: side === null ? null : {
				key: itemKey,
				side
			},
			children: element
		})
	});
}
/**
* One legend entry. With a `dataKey`, that series' entries: one item, or one per side of a threshold
* colour, above first. Without one, a template rendered once per legend entry, as TooltipItems is.
* Inside a threshold side's item, a Swatch or a SeriesLabel of its series shows the side's paint
* and label, while a LegendValue and a LegendShare print the whole series' value and share.
*
* @beta
*/
function ChartLegendItem({ dataKey, render, className, children, ...props }) {
	const readout = useChartReadout("Chart.LegendItem");
	if (dataKey !== void 0) readout.assertKey("Chart.LegendItem", dataKey);
	const keys = dataKey === void 0 ? readout.legendKeys : [dataKey];
	return /* @__PURE__ */ jsx(Fragment$1, { children: keys.flatMap((key) => entrySides(readout, key).map((side, index) => /* @__PURE__ */ jsx(LegendEntry, {
		itemKey: key,
		side,
		render,
		className,
		props,
		children
	}, `${key}\u0000${String(index)}`))) });
}
/**
* The series' value at the active slot, or the `fallback` value when nothing is active, "last" by
* default. In pie and radial charts it is the category's value. It renders once per change of the
* active slot, never on a pointer move inside one slot.
*
* @beta
*/
function ChartLegendValue({ dataKey, fallback = "last", format, render, className, ...props }) {
	const readout = useChartReadout("Chart.LegendValue");
	const active = useActiveIndex(readout, true);
	const key = useReadoutKey("Chart.LegendValue", readout, dataKey, null);
	const at = key === null ? null : readout.legendAt(key, active, fallback);
	const text = key === null || at === null ? null : readout.valueText(key, at, format);
	return useRender({
		defaultTagName: "span",
		render,
		props: {
			"data-slot": "chart-legend-value",
			...mergeProps({
				className,
				children: text
			}, props)
		}
	});
}
/**
* The series total's share of every series' total over the effective window, or the slice's share
* in a pie. The legend's shares round together, so they sum to 100 %.
*
* @beta
*/
function ChartLegendShare({ dataKey, format, render, className, ...props }) {
	const readout = useChartReadout("Chart.LegendShare");
	const key = useReadoutKey("Chart.LegendShare", readout, dataKey, null);
	const text = key === null ? null : shareText(readout.locale, readout.legendShare(key, shareDigits(format)), format);
	return useRender({
		defaultTagName: "span",
		render,
		props: {
			"data-slot": "chart-legend-share",
			...mergeProps({
				className,
				children: text
			}, props)
		}
	});
}
/**
* A Fuse ToggleGroup that edits Root's `selectedKey`. Root owns the value and the change callback,
* so the group takes no `value`, `multiple` or `disabled` of its own. Each toggle selects a series,
* so a series coloured by a threshold keeps one toggle, its swatch split between the two sides and
* its label the series' own. One toggle is pressed at a time, and pressing the pressed toggle clears
* the selection. While the group is mounted, Enter on the plot's option and a plot click select a
* series too. Each change announces the selection through Root's status region.
*
* @beta
*/
function ChartLegendToggleGroup({ "aria-label": ariaLabel, side = "bottom", className, style, children }) {
	const readout = useChartReadout("Chart.LegendToggleGroup");
	const { registerToggleGroup, select } = readout;
	const selectedKey = use(ChartSelectionContext);
	useEffect(() => registerToggleGroup(), [registerToggleGroup]);
	return /* @__PURE__ */ jsx(ToggleGroupRoot, {
		"data-slot": "chart-legend-toggle-group",
		"data-side": side,
		"aria-label": ariaLabel ?? readout.toggleGroupName,
		size: "xs",
		value: selectedKey === null ? [] : [selectedKey],
		onValueChange: (value, details) => {
			select(value.at(-1) ?? null, "legend", details.event);
		},
		className,
		style,
		children: children ?? readout.legendKeys.filter((key) => readout.item(key)?.selectable === true).map((key) => /* @__PURE__ */ jsx(ChartLegendToggle, { dataKey: key }, key))
	});
}
/**
* One series toggle, named by the visible text of the series label, so a speech-input user can say
* what they see. Hovering or focusing it highlights its series through Root's attributes, which
* renders nothing in React.
*
* @beta
*/
function ChartLegendToggle({ dataKey, className, style, children }) {
	const readout = useChartReadout("Chart.LegendToggle");
	readout.assertKey("Chart.LegendToggle", dataKey);
	const item = readout.item(dataKey);
	return /* @__PURE__ */ jsx(ToggleGroupItem, {
		value: dataKey,
		size: "xs",
		"data-slot": "chart-legend-toggle",
		"data-series": item?.index,
		className,
		style,
		onPointerEnter: () => readout.highlight(dataKey),
		onPointerLeave: () => readout.highlight(null),
		onFocus: () => readout.highlight(dataKey),
		onBlur: () => readout.highlight(null),
		children: /* @__PURE__ */ jsx(ChartRowContext, {
			value: dataKey,
			children: children ?? /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(ChartSwatch, {}), /* @__PURE__ */ jsx("span", { children: item?.label.text ?? dataKey })] })
		})
	});
}
Object.assign(ChartLegend, { displayName: "Chart.Legend" });
Object.assign(ChartLegendItem, { displayName: "Chart.LegendItem" });
Object.assign(ChartLegendValue, { displayName: "Chart.LegendValue" });
Object.assign(ChartLegendShare, { displayName: "Chart.LegendShare" });
Object.assign(ChartLegendToggleGroup, { displayName: "Chart.LegendToggleGroup" });
Object.assign(ChartLegendToggle, { displayName: "Chart.LegendToggle" });
export { ChartLegend, ChartLegendItem, ChartLegendShare, ChartLegendToggle, ChartLegendToggleGroup, ChartLegendValue };

//# sourceMappingURL=chart-legend.js.map