"use client";
import { ChartLayoutContext, ChartRootContext } from "./chart-scope-contexts.js";
import { ChartCompositionError, assertKnownKey } from "./layout/errors.js";
import { use, useLayoutEffect } from "react";
// src/components/chart/chart-context.ts
/**
* The contexts a cartesian Root provides. The root context changes with data, config and the
* effective window, never with the pointer, so marks that read it render only on a data change.
* The layout context is the seam Panels plug into. Root provides the default layout, and a Panel
* provides its own, so a mark reads the nearest layout without knowing which: its value domain,
* the frame its motion maps under on a resize, and the registry its reference labels stack in.
*/
/**
* Decide, for a Panel as it commits, whether a data update moves its value domain. A moved
* domain marks its keys as gliding, and a moved or still gliding domain under which the update
* mounts a bar relays the plot, as `relaysPlot` rules for Root's default layout.
*
* @param update - The update the Panel renders first.
* @param keys - The Panel's series.
* @param domain - The Panel's value domain under the update.
*/
function reportLayoutDomain(update, keys, domain) {
	if (update.kind !== "data") return;
	const moved = keys.some((key) => {
		const from = update.from.get(key);
		return from !== void 0 && (from[0] !== domain[0] || from[1] !== domain[1]);
	});
	if (moved) for (const key of keys) update.layouts.moved.add(key);
	if ((moved || keys.some((key) => update.gliding.has(key))) && keys.some((key) => update.mounted.has(key))) update.layouts.relays = true;
}
/**
* Read the enclosing cartesian Root.
*
* @param part - The calling part's display name, which the error names.
* @returns The Root's context.
* @throws {ChartCompositionError} `part-outside-root` when no `Chart.Root` encloses the part.
*/
function useChartRoot(part) {
	const value = use(ChartRootContext);
	if (value === null) throw new ChartCompositionError(part, "part-outside-root", "must be used within Chart.Root. Wrap the chart's parts in Chart.Root, or in BarChart.Root, AreaChart.Root or LineChart.Root.");
	return value;
}
/**
* Read the nearest layout, a Panel's or Root's default one.
*
* @param part - The calling part's display name.
* @returns The layout.
* @throws {ChartCompositionError} `part-outside-root` when no `Chart.Root` encloses the part.
*/
function useChartLayout(part) {
	useChartRoot(part);
	const layout = use(ChartLayoutContext);
	if (layout === null) throw new Error(`${part} found Chart.Root but no layout, which Root always provides.`);
	return layout;
}
/**
* The error of a plot part directly under a Root with Panels.
*
* @param part - The part's display name.
* @returns The `part-outside-panel` error.
*/
function partOutsidePanel(part) {
	return new ChartCompositionError(part, "part-outside-panel", "sits directly under a Chart.Root that has Panels, so it has no y domain. Move it into the Chart.Panel whose series it draws.");
}
/**
* Read the layout a plot part draws in. A part in the default layout registers with Root, whose
* check of the current tree throws `part-outside-panel` when Panels have registered beside it.
*
* @param part - The calling part's display name.
* @returns The layout.
* @throws {ChartCompositionError} `mixed-sentiment-categorical` when the default layout mixes
*   colour families.
*/
function usePlotLayout(part) {
	const { registerRootPart, colourRule } = useChartRoot(part);
	const layout = useChartLayout(part);
	const inRoot = layout.kind === "root";
	useLayoutEffect(() => inRoot ? registerRootPart(part) : void 0, [
		inRoot,
		part,
		registerRootPart
	]);
	if (inRoot && colourRule !== null) throw colourRule;
	return layout;
}
/**
* Open a part that draws one series in the nearest layout: read Root, check the key against its
* config, read the layout and check the key against it.
*
* @param part - The calling part's display name.
* @param dataKey - The config key the part draws.
* @returns Root's context and the part's layout.
* @throws {ChartCompositionError} `part-outside-root`, `unknown-key`, `series-not-in-panel`, or the
*   default layout's colour rule.
*/
function useSeriesPart(part, dataKey) {
	const context = useChartRoot(part);
	assertKnownKey(part, context.config, dataKey);
	const layout = usePlotLayout(part);
	assertLayoutKey(part, layout, dataKey);
	return {
		context,
		layout
	};
}
/**
* Check that a mark inside a Panel draws one of the Panel's series.
*
* @param part - The calling part's display name.
* @param layout - The mark's layout.
* @param key - The config key the mark draws.
* @throws {ChartCompositionError} `series-not-in-panel`, listing the Panel's series.
*/
function assertLayoutKey(part, layout, key) {
	if (layout.kind === "root" || layout.keys.includes(key)) return;
	const keys = layout.keys.map((name) => JSON.stringify(name)).join(", ");
	throw new ChartCompositionError(part, "series-not-in-panel", `draws ${JSON.stringify(key)}, which its Chart.Panel's series does not list. Add it to the Panel's series, or move the part to the Panel that lists it: ${keys}.`);
}
export { assertKnownKey, assertLayoutKey, partOutsidePanel, reportLayoutDomain, useChartLayout, useChartRoot, usePlotLayout, useSeriesPart };

//# sourceMappingURL=chart-context.js.map