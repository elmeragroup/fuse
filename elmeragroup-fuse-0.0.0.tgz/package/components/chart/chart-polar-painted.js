"use client";
// src/components/chart/chart-polar-painted.ts
const painted = /* @__PURE__ */ new WeakMap();
/**
* Share a frame's painted angles on its loop.
*
* @param motion - The Root's loop.
* @param angles - The painted angles by key.
*/
function sharePainted(motion, angles) {
	painted.set(motion, angles);
}
/**
* The painted angles a frame shares on a loop.
*
* @param motion - The Root's loop.
* @returns The angles by key, or undefined where no frame paints.
*/
function paintedOf(motion) {
	return painted.get(motion);
}
export { paintedOf, sharePainted };

//# sourceMappingURL=chart-polar-painted.js.map