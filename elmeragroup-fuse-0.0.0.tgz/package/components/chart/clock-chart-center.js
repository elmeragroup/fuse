"use client";
import { numberAndUnit } from "./format/formatted-text.js";
import { formatValue } from "./format/value-format.js";
import { ChartHeadlineContext } from "./chart-scope-contexts.js";
import { useActiveIndex } from "./chart-active-point.js";
import { assertKnownKey } from "./layout/errors.js";
import { clockDrawingIn, usePolarContext } from "./chart-polar-context.js";
import { slotLabel } from "./chart-text.js";
import { fallbackSlot, readingAt } from "./chart-series-readout.js";
import { useCentreFit } from "./chart-centre-fit.js";
import { use } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/clock-chart-center.tsx
/**
* The text in the clock's hole and its value readouts. The Center lays its children in the square
* inscribed in the hole, and by default prints the first series' active value, or the value at
* `now` with nothing active, over the slot's label. ActiveValue prints one series' value at the
* active slot, or at its `fallback` slot, and inside a Headline it is exposed text. They read the
* series model, never plot geometry.
*/
/**
* A value as its number and its unit, in the order the formatter wrote them and joined by a
* breakable space, so a value too wide for the hole wraps between them instead of overflowing.
*/
function ValueParts({ text }) {
	const parts = numberAndUnit(text);
	const number = /* @__PURE__ */ jsx("span", {
		"data-part": "number",
		children: parts.number
	});
	if (parts.unit === null) return number;
	const unit = /* @__PURE__ */ jsx("span", {
		"data-part": "unit",
		children: parts.unit
	});
	return parts.side === "before" ? /* @__PURE__ */ jsxs(Fragment$1, { children: [
		unit,
		" ",
		number
	] }) : /* @__PURE__ */ jsxs(Fragment$1, { children: [
		number,
		" ",
		unit
	] });
}
/** The slot a value part prints: the active slot, or the fallback's. */
function useShownSlot(clock, dataKey, fallback) {
	const { kernel } = usePolarContext("ClockChart.ActiveValue", ["clock"]);
	return useActiveIndex({
		store: kernel.store,
		window: clock.text.model.window
	}, true) ?? fallbackSlot(clock.text, dataKey, fallback);
}
/**
* One series' value at the active slot, or at the `fallback` slot with nothing active, "now" by
* default. Inside a Headline it is exposed text with a visually hidden spoken twin wherever the
* spoken form differs, and anywhere else it is plot output that readers skip.
*
* @beta
*/
function ClockChartActiveValue({ dataKey, fallback = "now", format, className, style }) {
	const { model } = usePolarContext("ClockChart.ActiveValue", ["clock"]);
	const clock = clockDrawingIn(model, "ClockChart.ActiveValue");
	assertKnownKey("ClockChart.ActiveValue", clock.text.config, dataKey);
	const exposed = use(ChartHeadlineContext);
	const slot = useShownSlot(clock, dataKey, fallback);
	const reading = slot === null ? void 0 : readingAt(clock.text, dataKey, slot);
	const label = reading?.kind === "reading" ? formatValue(clock.text.locale, reading.value, format ?? clock.text.config[dataKey]?.format ?? {}, "full") : null;
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "clock-chart-active-value",
		"aria-hidden": exposed ? void 0 : "true",
		className,
		style,
		children: label === null ? null : !exposed ? /* @__PURE__ */ jsx(ValueParts, { text: label.text }) : label.text === label.spoken ? label.text : /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("span", {
			"aria-hidden": "true",
			children: label.text
		}), /* @__PURE__ */ jsx("span", {
			"data-spoken": "",
			children: label.spoken
		})] })
	});
}
/** The Center's default content: the first series' value over the shown slot's label. */
function DefaultCentre({ clock }) {
	const key = clock.series[0]?.key;
	const slot = useShownSlot(clock, key ?? "", "now");
	if (key === void 0) return null;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx(ClockChartActiveValue, { dataKey: key }), /* @__PURE__ */ jsx("span", {
		"data-slot": "clock-chart-center-label",
		children: slot === null ? null : slotLabel(clock.text, slot).text
	})] });
}
/**
* The text in the dial's hole: its children sit in the square inscribed in the hole. The first
* series' value at the active slot, or at `now`, over the slot's label is the default. Its text never
* shrinks below 12 px: when the lines overflow the square it drops every line but the value, and
* then the value.
*
* @beta
*/
function ClockChartCenter({ children, className, style }) {
	const { model, box } = usePolarContext("ClockChart.Center", ["clock"]);
	const clock = clockDrawingIn(model, "ClockChart.Center");
	const fitted = useCentreFit();
	const half = Math.SQRT2 * clock.inner / 2;
	const width = box.right - box.left;
	const height = box.bottom - box.top;
	const percent = (value, of) => `${(value / of * 100).toFixed(3)}%`;
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "clock-chart-center",
		"data-polar-layer": "",
		"aria-hidden": "true",
		className,
		style,
		children: /* @__PURE__ */ jsx("div", {
			ref: fitted,
			"data-part": "hole",
			style: {
				"--_left": percent(-half - box.left, width),
				"--_top": percent(-half - box.top, height),
				"--_width": percent(2 * half, width),
				"--_height": percent(2 * half, height)
			},
			children: children ?? /* @__PURE__ */ jsx(DefaultCentre, { clock })
		})
	});
}
Object.assign(ClockChartActiveValue, { displayName: "ClockChart.ActiveValue" });
Object.assign(ClockChartCenter, { displayName: "ClockChart.Center" });
export { ClockChartActiveValue, ClockChartCenter };

//# sourceMappingURL=clock-chart-center.js.map