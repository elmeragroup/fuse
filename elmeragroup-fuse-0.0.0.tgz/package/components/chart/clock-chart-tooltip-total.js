"use client";
import { useActiveIndex } from "./chart-active-point.js";
import { clockDrawingIn, usePolarContext } from "./chart-polar-context.js";
import { TooltipTotalRow } from "./chart-tooltip-total-row.js";
import { jsx } from "react/jsx-runtime";
// src/components/chart/clock-chart-tooltip-total.tsx
/**
* A tooltip row with one stack's net total at the active slot, followed by the incomplete word when
* a part is missing. A `stack` that names no stack of two or more series throws `unknown-key`.
*
* @beta
*/
function ClockChartTooltipTotal(props) {
	const { model, kernel } = usePolarContext("ClockChart.TooltipTotal", ["clock"]);
	const clock = clockDrawingIn(model, "ClockChart.TooltipTotal");
	const slot = useActiveIndex({
		store: kernel.store,
		window: clock.text.model.window
	});
	return /* @__PURE__ */ jsx(TooltipTotalRow, {
		part: "ClockChart.TooltipTotal",
		context: clock.text,
		at: slot,
		...props
	});
}
Object.assign(ClockChartTooltipTotal, { displayName: "ClockChart.TooltipTotal" });
export { ClockChartTooltipTotal };

//# sourceMappingURL=clock-chart-tooltip-total.js.map