"use client";
import { formatValue } from "./format/value-format.js";
import { ChartDatumContext } from "./chart-scope-contexts.js";
import { introFor, useKeptIntro, usePhase } from "./chart-store.js";
import { useActiveIndex } from "./chart-active-point.js";
import { ownSlot } from "./layout/coarse-slots.js";
import { sameItems } from "./layout/same-items.js";
import { alongLength } from "./layout/plot-frame.js";
import { barCellAt, barCells } from "./layout/bar-geometry.js";
import { seriesPathOf } from "./layout/series-path.js";
import { useChartRoot, useSeriesPart } from "./chart-context.js";
import { partsCache, writeAttribute, writeStyle } from "./chart-dom.js";
import { useChartFollower } from "./chart-followers.js";
import { readingPaint, seriesPaintOf } from "./chart-paint.js";
import { pathAnchor, routeRestIndex } from "./chart-paths.js";
import { useChartFrame } from "./chart-plot.js";
import { seriesOf } from "./layout/series-of.js";
import { readingAt } from "./chart-series-readout.js";
import { useSteady } from "./chart-steady.js";
import { barAnchor } from "./chart-bar-draw.js";
import { datumSlots } from "./chart-datum.js";
import { attachJoin, barTip, followedKind, noteShownText, pointAxes, pointCentre, restingPoint, useAttachedMark } from "./chart-attached.js";
import { parseTrack, rideCourse, rideKeyframes, runBetween, trackOf } from "./layout/ride.js";
import { glideShown, rideFrom, snapGlide, stepSpring } from "./chart-spring.js";
import { memo, use, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-dots.tsx
/** The radius of each dot look, in CSS pixels, so a dot reads 8 px across or more. */
const DOT_RADIUS = {
	default: 4,
	ring: 4,
	halo: 5,
	ping: 4
};
/**
* Write each dot's centre from the loop's numbers, a place and a value per point, in order. A point
* may draw more than one circle, as a ping ring and its dot do, which share its numbers.
*/
function writeCentres(dots, look, values, perPoint = 1) {
	const { frame, xScale } = look;
	let index = 0;
	for (const dot of dots) {
		const point = Math.floor(index / perPoint);
		const { cx, cy } = pointCentre(frame, xScale, values[point * 2] ?? 0, values[point * 2 + 1] ?? 0);
		writeAttribute(dot, "cx", cx);
		writeAttribute(dot, "cy", cy);
		index += 1;
	}
}
/** Draw a series' dots from the loop's numbers. */
function drawDots(group, look, values) {
	const { frame, xScale } = look;
	if (frame !== null) writeCentres(group.children, {
		frame,
		xScale
	}, values);
}
/**
* One dot, which keeps the `data-intro` value and the centre its first render chose, so an added
* dot fades in and React writes its centre once. The loop draws the centre after that, so the dot
* renders again only for the props it reads after its first render.
*/
const Dot = memo(function Dot({ intro, series, radius, paint, cx, cy }) {
	const [first] = useState({
		intro,
		cx,
		cy
	});
	return /* @__PURE__ */ jsx("circle", {
		"data-slot": "chart-dot",
		"data-series": series,
		"data-intro": first.intro,
		r: radius,
		cx: first.cx,
		cy: first.cy,
		style: paint === void 0 ? void 0 : { "--chart-series-paint": paint }
	});
}, sameDot);
/** Whether a dot's later props change what it renders: its series, its radius and its paint. */
function sameDot(a, b) {
	return a.series === b.series && a.radius === b.radius && a.paint === b.paint;
}
/**
* What an attached part writes on `data-intro` for the dots that mount now, which draw as they
* mount: nothing while Root's entrance waits, so they join it, and their update's intro after it
* started.
*/
function useMountIntro(context) {
	return introFor(usePhase(context.store), context.update.kind, context.entrance);
}
/** The inline paint each kept dot wore, in order, for a series painted by its values. */
const keptPaints = /* @__PURE__ */ new WeakMap();
/** The paint a dot names inline, or "" for one that takes its layer's. */
function inlinePaint(dot) {
	return dot instanceof SVGElement ? dot.style.getPropertyValue("--chart-series-paint") : "";
}
/**
* How Dots keep their last drawing: the group and one dot of it as a template, so a commit copies
* two elements and not every dot. Where a scale or a threshold paints the dots by value, it keeps
* each dot's own paint too, a string per dot, and only there does a commit read every dot. A
* crossfade then builds the old dots from the template, one per point the loop drew last, each in
* the paint its dot wore.
*/
const DOTS_COPY = {
	keep: (live) => {
		const kept = live.cloneNode(false);
		const template = live.firstElementChild?.cloneNode(false);
		if (!(kept instanceof Element)) return live;
		if (template instanceof Element) {
			template.removeAttribute("data-intro");
			template.removeAttribute("style");
			kept.append(template);
		}
		if (live.firstElementChild === null || inlinePaint(live.firstElementChild) === "") return kept;
		keptPaints.set(kept, [...live.children].map(inlinePaint));
		return kept;
	},
	outgoing: (kept, before) => {
		const template = kept.firstElementChild;
		const copy = kept.cloneNode(false);
		if (template === null || !(copy instanceof Element)) return null;
		const paints = keptPaints.get(kept);
		for (let point = 0; point < before.length / 2; point += 1) {
			const dot = template.cloneNode(false);
			const paint = paints?.[point] ?? "";
			if (paint !== "" && dot instanceof SVGElement) dot.style.setProperty("--chart-series-paint", paint);
			copy.append(dot);
		}
		return copy;
	}
};
/**
* A dot on every reading of one series, on its Line's or Area's vertices. The dots move with the
* series' path on a data update, and a dot that an update adds fades in.
*
* @beta
*/
function ChartDots({ dataKey, variant = "default", className, style }) {
	const { context, layout } = useSeriesPart("Chart.Dots", dataKey);
	const { model, update, xScale } = context;
	const { window } = model;
	const series = seriesOf(model, dataKey);
	const paint = pointPaint(context, dataKey, series);
	const drawn = useChartFrame("Chart.Dots", layout);
	const frame = drawn?.frame ?? null;
	const dots = useMemo(() => {
		if (series === void 0 || frame === null) return [];
		const path = seriesPathOf(model, series, update.keys, alongLength(frame));
		const place = {
			window,
			xScale
		};
		return path.vertices.flatMap((vertex, index) => {
			const point = vertex.state === "reading" ? restingPoint(place, frame, series, vertex.slot) : null;
			return point === null ? [] : [{
				key: path.keys[index] ?? String(vertex.slot),
				slot: vertex.slot,
				point,
				paint: readingPaint(paint, series.readings[vertex.slot])
			}];
		});
	}, [
		model,
		update.keys,
		series,
		frame,
		window,
		xScale,
		paint
	]);
	const rest = useMemo(() => dots.flatMap(({ point }) => [...point]), [dots]);
	const slots = useMemo(() => dots.map(({ slot }) => slot), [dots]);
	const look = useMemo(() => ({
		frame,
		xScale: context.xScale
	}), [frame, context.xScale]);
	const { ref: markRef, outgoingRef, attach } = useAttachedMark(context, drawn, drawDots, look, pointAxes(context.orientation), {
		point: true,
		copy: DOTS_COPY
	});
	useChartFollower("Chart.Dots", (_active, cause) => {
		if (cause === "step" || series === void 0 || frame === null) return;
		attach(cause, attachJoin(context, series, slots, rest, "line"), rest);
	});
	const intro = useMountIntro(context);
	const layerIntro = useKeptIntro(intro, frame !== null);
	const radius = DOT_RADIUS[variant];
	return /* @__PURE__ */ jsx("svg", {
		"data-slot": "chart-dots",
		"data-variant": variant,
		"data-series": series?.seriesIndex,
		"data-intro": layerIntro,
		"aria-hidden": "true",
		className,
		style: {
			"--chart-series-paint": paint.base,
			"--chart-series": series?.seriesIndex,
			...style
		},
		children: frame === null ? null : /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("g", {
			ref: markRef,
			children: dots.map(({ key, point, paint: own }) => {
				const { cx, cy } = pointCentre(frame, context.xScale, point[0], point[1]);
				return /* @__PURE__ */ jsx(Dot, {
					intro,
					series: series?.seriesIndex ?? 0,
					radius,
					paint: own,
					cx,
					cy
				}, key);
			})
		}), /* @__PURE__ */ jsx("g", {
			ref: outgoingRef,
			"data-part": "outgoing"
		})] })
	});
}
/**
* The paint of a series' point marks. Its base paints the layer: a role, a role list's first role,
* a scale's middle step or a threshold's lower side. A mark on a reading of a scale or a threshold
* paints the step of its value over it.
*/
function pointPaint(context, dataKey, series) {
	return seriesPaintOf(dataKey, context.config[dataKey]?.color ?? "chart-1", series);
}
/** The active dot's circles, its ping ring first if any, found once per commit of its mark. */
const activeDots = partsCache((svg) => [...svg.querySelectorAll(":scope > [data-slot=chart-dot]")]);
/**
* How an active dot keeps its last drawing: a deep copy at each commit, whose circles take the live
* circles' paint at each step, so a crossfade fades out the paint of the reading the dot last
* showed, not the one it showed at the last commit.
*/
const ACTIVE_DOT_COPY = { sync: (kept, live) => {
	const copies = activeDots(kept);
	activeDots(live).forEach((dot, index) => {
		const copy = copies[index];
		const paint = inlinePaint(dot);
		if (copy instanceof SVGElement) writeStyle(copy, "--chart-series-paint", paint === "" ? null : paint);
	});
} };
/** Draw the active dot at the loop's numbers, its place and its value, with its ping ring if any. */
function drawActiveDot(svg, look, values) {
	const { frame, xScale } = look;
	if (frame === null) return;
	const dots = activeDots(svg);
	writeCentres(dots, {
		frame,
		xScale
	}, values, dots.length);
}
/**
* Where an active dot on a Bar series rests at a slot, as attaching places it: the middle of its
* bar's far end, the tip of a positive bar or a stack's segment and the low end of a negative one,
* as the bar rests in the loop. In the path form, the columns' resting place and value at the
* slot, in the series' own sub-band, or the series' resting point where the columns draw no entry
* of their own for it.
*/
function barEnd(context, series, frame, slot, kind) {
	const cell = barCellAt(context.model, series, slot);
	if (cell === null) return null;
	const resting = (kind === "bars" ? barTipAt(context, series, cell.slot) : columnAt(context, series, cell.slot)) ?? restingPoint({
		window: context.model.window,
		xScale: context.xScale
	}, frame, series, slot);
	return resting === null ? null : pointCentre(frame, context.xScale, resting[0], resting[1]);
}
/** A bar's middle along the slot axis and its tip, where it rests in the loop, or null. */
function barTipAt(context, series, slot) {
	const rest = context.motion.restAt(barAnchor(series.seriesIndex, slot));
	return rest === null ? null : barTip(rest);
}
/** The path form's columns' resting place and value at a slot, or null where they rest on none. */
function columnAt(context, series, slot) {
	const route = context.paths.get(series.seriesIndex, "columns");
	const values = context.motion.restAt(pathAnchor(series.seriesIndex, "columns"));
	if (route === void 0 || values === null) return null;
	const index = routeRestIndex(route, context.update.keys[slot] ?? String(slot));
	return index === void 0 ? null : [values[index * route.stride] ?? 0, values[index * route.stride + 1] ?? 0];
}
/**
* The straight track through a Bar series' far ends, one run per stretch of bars without a
* missing reading between them.
*/
function barTrack(context, series, frame, kind) {
	const runs = [];
	let next = null;
	for (const cell of barCells(context.model, series)) {
		const end = barEnd(context, series, frame, cell.slot, kind);
		if (end === null) continue;
		if (cell.slot !== next || runs.length === 0) runs.push([]);
		runs.at(-1)?.push([end.cx, end.cy]);
		next = ownSlot(series, cell.slot)[1] + 1;
	}
	return trackOf(runs, context.orientation);
}
/**
* The track an active dot rides: its series' drawn line, parsed once for each path data its writer
* draws, or the straight track through its bars' far ends, built once for each model and frame.
* It is null for a series with neither.
*/
function trackFor(context, series, frame, kept) {
	const known = kept.current;
	const kind = followedKind(context, series, "line");
	if (kind === "line" || kind === "area") {
		const data = context.paths.line(series.seriesIndex, kind) ?? "";
		if (data === "") return null;
		if (known?.kind === "line" && known.data === data) return known.track;
		const made = {
			kind: "line",
			data,
			track: parseTrack(data, context.orientation)
		};
		kept.current = made;
		return made.track;
	}
	return keptBarTrack(context, series, frame, kind, kept);
}
/**
* The straight track through a Bar series' far ends that an active dot rides, built again whenever
* the series, the frame or a bar's resting place changes, or null for a series a Line or an Area
* draws, or no Bar. `kind` is what the dot follows, as `followedKind` names it.
*/
function keptBarTrack(context, series, frame, kind, kept) {
	if (kind !== "columns" && kind !== "bars") return null;
	const known = kept.current;
	const revision = context.motion.restRevision();
	if (known?.kind === "bars" && known.series === series.key && known.revision === revision && known.frame === frame) return known.track;
	const made = {
		kind: "bars",
		series: series.key,
		revision,
		frame,
		track: barTrack(context, series, frame, kind)
	};
	kept.current = made;
	return made.track;
}
/**
* How an active dot rides its track from where it shows, a running glide's offset included, to
* where it rests: the offset along the slot axis it starts from, and its keyframes over the course
* `rideCourse` reads off the track. It is null, and the dot moves at once, where no run of the
* track spans the whole step: over a gap or past a lone reading.
*/
function rideOf(layer, track, from, to, orientation) {
	const vertical = orientation === "vertical";
	const along = (centre) => vertical ? centre.cx : centre.cy;
	const across = (centre) => vertical ? centre.cy : centre.cx;
	const shown = glideShown(layer) ?? [0, 0];
	const start = {
		along: along(from) + (vertical ? shown[0] : shown[1]),
		across: across(from) + (vertical ? shown[1] : shown[0])
	};
	const rest = {
		along: along(to),
		across: across(to)
	};
	const run = runBetween(track, start, rest);
	if (run === null) return null;
	const course = rideCourse(run, start, rest);
	const offset = start.along - rest.along;
	return {
		along: offset,
		axis: vertical ? "x" : "y",
		keyframes: (peak) => rideKeyframes(offset, course, peak)
	};
}
/**
* The dot on one series at the active slot. Write one per series that needs one. A pointer, key or
* touch step glides it to the next reading along its series' drawn line, in step with the crosshair
* on a spring that quickens with the pointer, unless the reader prefers reduced motion. It rides its
* Line's or Area's drawn line, or on a Bar series a straight track through the bars' far ends: a
* bar's top, a stack segment's outer edge, a negative bar's low end. It moves at once across a gap
* or a missing reading. It shows and hides at once, and during a data update it rides what it sits
* on.
*
* @beta
*/
function ChartActiveDot({ dataKey, variant = "default", className, style }) {
	const { context, layout } = useSeriesPart("Chart.ActiveDot", dataKey);
	const series = seriesOf(context.model, dataKey);
	const paint = pointPaint(context, dataKey, series);
	const drawn = useChartFrame("Chart.ActiveDot", layout);
	const frame = drawn?.frame ?? null;
	const look = useMemo(() => ({
		frame,
		xScale: context.xScale
	}), [frame, context.xScale]);
	const { ref: markRef, node: markNode, outgoingRef, attach, drawn: drawnPoint } = useAttachedMark(context, drawn, drawActiveDot, look, pointAxes(context.orientation), {
		point: true,
		copy: ACTIVE_DOT_COPY
	});
	const shownBefore = useRef(false);
	const track = useRef(null);
	useChartFollower("Chart.ActiveDot", (active, cause) => {
		const point = active === null || series === void 0 || frame === null ? null : restingPoint({
			window: context.model.window,
			xScale: context.xScale
		}, frame, series, active.slot);
		const svg = markNode();
		const before = drawnPoint();
		const from = shownBefore.current && before !== null && frame !== null ? pointCentre(frame, context.xScale, before[0] ?? 0, before[1] ?? 0) : null;
		if (svg !== null) {
			writeAttribute(svg, "data-value", point === null ? null : "");
			const own = active === null || series === void 0 ? void 0 : readingPaint(paint, series.readings[active.slot]);
			for (const dot of activeDots(svg)) if (dot instanceof SVGElement) writeStyle(dot, "--chart-series-paint", own ?? null);
		}
		attach(cause, active === null || series === void 0 || point === null ? void 0 : attachJoin(context, series, [active.slot], [...point], "line"), svg === null ? null : point);
		shownBefore.current = point !== null;
		if (svg === null) return;
		const placed = point === null ? null : drawnPoint();
		const to = placed === null || frame === null ? null : pointCentre(frame, context.xScale, placed[0] ?? 0, placed[1] ?? 0);
		const { motion, orientation, store } = context;
		const riding = cause === "step" && series !== void 0 && frame !== null && !motion.snaps() && !motion.running() && from !== null && to !== null ? trackFor(context, series, frame, track) : null;
		const ride = riding === null || from === null || to === null ? null : rideOf(svg, riding, from, to, orientation);
		if (ride === null) snapGlide(svg);
		else rideFrom(svg, stepSpring(store), ride);
	});
	const barRide = useRef(() => null);
	useLayoutEffect(() => {
		barRide.current = () => series === void 0 || frame === null ? null : keptBarTrack(context, series, frame, followedKind(context, series, "line"), track);
	});
	const { riders } = context;
	useLayoutEffect(() => {
		const svg = markNode();
		if (svg === null) return void 0;
		return riders.register(svg, () => barRide.current());
	}, [
		markNode,
		dataKey,
		variant,
		riders
	]);
	useLayoutEffect(() => {
		const svg = markNode();
		return () => {
			if (svg !== null) snapGlide(svg);
		};
	}, [markNode]);
	const radius = DOT_RADIUS[variant];
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("svg", {
		ref: markRef,
		"data-slot": "chart-active-dot",
		"data-variant": variant,
		"data-series": series?.seriesIndex,
		"data-follow": "",
		"aria-hidden": "true",
		className,
		style: {
			"--chart-series-paint": paint.base,
			"--chart-series": series?.seriesIndex,
			...style
		},
		children: frame === null ? null : /* @__PURE__ */ jsxs(Fragment$1, { children: [variant === "ping" ? /* @__PURE__ */ jsx("circle", {
			"data-slot": "chart-dot",
			"data-part": "ping",
			r: radius
		}) : null, /* @__PURE__ */ jsx("circle", {
			"data-slot": "chart-dot",
			"data-series": series?.seriesIndex,
			r: radius
		})] })
	}), /* @__PURE__ */ jsx("div", {
		ref: outgoingRef,
		"data-part": "outgoing"
	})] });
}
/** The slots a Marker's `at` selects, comparing the series' readings, where the series has one. */
function markerSlots(context, series, at) {
	if (series === void 0) return [];
	const values = series.readings.map((reading) => reading.kind === "reading" ? reading.value : null);
	return datumSlots(context, "Chart.Marker", series, at, values).filter((slot) => series.readings[slot]?.kind === "reading");
}
/** A Marker's dots and its pills' anchors, found once per commit of its mark. */
const markerParts = partsCache((box) => ({
	dots: [...box.querySelector(":scope > svg")?.children ?? []].filter((child) => child.getAttribute("data-slot") === "chart-dot"),
	anchors: [...box.querySelectorAll(":scope > [data-part=anchor]")]
}));
/** Draw a Marker's dots and its pills' anchors from the loop's numbers, a place and a value per slot. */
function drawMarker(box, look, values) {
	const { frame, xScale } = look;
	if (frame === null) return;
	const { dots, anchors } = markerParts(box);
	writeCentres(dots, {
		frame,
		xScale
	}, values, dots.length / Math.max(1, values.length / 2));
	anchors.forEach((anchor, index) => {
		const { cx, cy } = pointCentre(frame, xScale, values[index * 2] ?? 0, values[index * 2 + 1] ?? 0);
		writeStyle(anchor, "--chart-marker-x", `${String(cx)}px`);
		writeStyle(anchor, "--chart-marker-y", `${String(cy)}px`);
	});
}
/**
* A resting dot on one series at the slots `at` selects, such as the current slot, the latest
* reading or the minimum, as the Figma price chart's Now indicator draws. A `ValueLabel` child adds
* the value as a pill above each dot, or beside it for `at="min"`, so it never covers the line
* that rises on both sides of the lowest reading. It sits on a Line's or an Area's vertex, or at a Bar's tip,
* and moves with what it sits on during a data update. It is plot output that readers skip, and
* the option and description carry its meaning.
*
* @beta
*/
function ChartMarker({ dataKey, at, variant = "default", className, style, children }) {
	const { context, layout } = useSeriesPart("Chart.Marker", dataKey);
	const series = seriesOf(context.model, dataKey);
	const paint = pointPaint(context, dataKey, series);
	const drawn = useChartFrame("Chart.Marker", layout);
	const frame = drawn?.frame ?? null;
	const slots = useSteady(markerSlots(context, series, at), sameItems);
	const marked = useMemo(() => series === void 0 || frame === null ? [] : slots.flatMap((slot) => {
		const point = restingPoint({
			window: context.model.window,
			xScale: context.xScale
		}, frame, series, slot);
		return point === null ? [] : [{
			slot,
			point,
			paint: readingPaint(paint, series.readings[slot])
		}];
	}), [
		context.model,
		context.xScale,
		series,
		frame,
		slots,
		paint
	]);
	const look = useMemo(() => ({
		frame,
		xScale: context.xScale
	}), [frame, context.xScale]);
	const { ref: markRef, outgoingRef, attach } = useAttachedMark(context, drawn, drawMarker, look, pointAxes(context.orientation), { point: true });
	useChartFollower("Chart.Marker", (_active, cause) => {
		if (cause === "step" || series === void 0 || frame === null) return;
		const rest = marked.flatMap(({ point }) => [...point]);
		attach(cause, attachJoin(context, series, marked.map(({ slot }) => slot), rest, "line"), rest);
	});
	const intro = useMountIntro(context);
	const radius = DOT_RADIUS[variant];
	const seriesIndex = series?.seriesIndex ?? 0;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("div", {
		ref: markRef,
		"data-slot": "chart-marker",
		"data-variant": variant,
		"data-series": series?.seriesIndex,
		"aria-hidden": "true",
		className,
		style: {
			"--chart-series-paint": paint.base,
			"--chart-series": series?.seriesIndex,
			...style
		},
		children: frame === null ? null : /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("svg", {
			"aria-hidden": "true",
			children: marked.flatMap(({ slot, point, paint: own }) => {
				const { cx, cy } = pointCentre(frame, context.xScale, point[0], point[1]);
				const dot = /* @__PURE__ */ jsx(Dot, {
					intro,
					series: seriesIndex,
					radius,
					paint: own,
					cx,
					cy
				}, `${String(slot)}-dot`);
				return variant === "ping" ? [/* @__PURE__ */ jsx("circle", {
					"data-slot": "chart-dot",
					"data-part": "ping",
					r: radius,
					cx,
					cy,
					style: own === void 0 ? void 0 : { "--chart-series-paint": own }
				}, `${String(slot)}-ping`), dot] : [dot];
			})
		}), marked.map(({ slot, point }) => {
			const { cx, cy } = pointCentre(frame, context.xScale, point[0], point[1]);
			return /* @__PURE__ */ jsx("span", {
				"data-part": "anchor",
				"data-side": at === "min" ? "beside" : void 0,
				style: {
					"--chart-marker-x": `${String(cx)}px`,
					"--chart-marker-y": `${String(cy)}px`
				},
				children: /* @__PURE__ */ jsx(ChartDatumContext, {
					value: {
						key: dataKey,
						slot
					},
					children
				})
			}, slot);
		})] })
	}), /* @__PURE__ */ jsx("div", {
		ref: outgoingRef,
		"data-part": "outgoing"
	})] });
}
/**
* The value of the enclosing Marker's or ActiveValueLine's datum, as a pill. It is plot output that
* readers skip, because the option carries the value.
*
* @beta
*/
function ChartValueLabel({ format, className, style }) {
	const context = useChartRoot("Chart.ValueLabel");
	const datum = use(ChartDatumContext);
	const active = useActiveIndex({
		store: context.store,
		window: context.model.window
	}, datum?.slot === null);
	const slot = datum?.slot ?? active;
	const reading = datum === null || slot === null ? void 0 : readingAt(context, datum.key, slot);
	const text = datum !== null && reading?.kind === "reading" ? formatValue(context.locale, reading.value, format ?? context.config[datum.key]?.format ?? {}, "tick").text : null;
	const ref = useRef(null);
	useLayoutEffect(() => {
		noteShownText(ref.current, text ?? "", context.update);
	});
	return /* @__PURE__ */ jsx("span", {
		ref,
		"data-slot": "chart-value-label",
		"aria-hidden": "true",
		className,
		style,
		children: text
	});
}
Object.assign(ChartDots, { displayName: "Chart.Dots" });
Object.assign(ChartActiveDot, { displayName: "Chart.ActiveDot" });
Object.assign(ChartMarker, { displayName: "Chart.Marker" });
Object.assign(ChartValueLabel, { displayName: "Chart.ValueLabel" });
export { ChartActiveDot, ChartDots, ChartMarker, ChartValueLabel };

//# sourceMappingURL=chart-dots.js.map