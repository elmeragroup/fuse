"use client";
import { sameItems } from "./layout/same-items.js";
import { settleFloors, zeroSide } from "./layout/floor-settle.js";
import { useId, useLayoutEffect, useMemo } from "react";
// src/components/chart/chart-stack-floors.ts
/**
* The stack floors of one motion loop: the bookkeeping around `settleFloors`, which holds the
* floor's whole policy. Each segment of a stack draws in a mark of its own, a bar or a series' path,
* so no one writer sees a whole stack. Every stacked mark hands the registry the spans it draws in a
* frame and leaves its painting to it. While the loop writes a batch of marks, such as one frame's
* moving marks, the registry only records, and once the batch ends it settles each changed stack
* once, in its marks' frame, paints each mark that recorded or whose floors changed once, and then
* redraws whatever reads the stack's floors, such as the active overlay. A mark that draws or
* leaves outside a batch, as every mark a commit places or unmounts does, only records too, and its
* stack settles once for the commit: in Root's first layout effect when Root renders in it, after
* every mark's, and otherwise in the next microtask, before the browser paints, as when the draw
* gate opens or a Bar mounts or changes on its own. Root's unmount discards that work, so nothing
* settles or paints into a chart that is gone.
*/
/** One loop's registry, created with the first stacked mark that draws in it. */
const registries = /* @__PURE__ */ new WeakMap();
/**
* The stack floors of a motion loop, shared by every stacked mark it draws.
*
* @param motion - The loop.
* @returns Its registry.
*/
function stackFloorsOf(motion) {
	const known = registries.get(motion);
	if (known !== void 0) return known;
	const created = createStackFloors(motion);
	registries.set(motion, created);
	return created;
}
/**
* Settle what a loop's marks drew or left outside a batch, if it has stack floors, as Root does in
* each commit.
*
* @param motion - The loop.
*/
function flushStackFloors(motion) {
	registries.get(motion)?.flush();
}
/**
* Throw away the pending work of a loop's stack floors, if it has any, as Root does when it unmounts.
*
* @param motion - The loop.
*/
function discardStackFloors(motion) {
	registries.get(motion)?.discard();
}
/**
* A stacked mark's seat among the stack floors for as long as it is mounted, or null for a loose
* series' mark. A mark that unmounts, or moves to another seat, leaves its stack, whose floors may
* pass to another segment.
*
* @param motion - Root's loop.
* @param stack - The series' stack, or undefined for a loose series.
* @param series - The series' config key, which names the mark's spans.
* @returns The seat, or null.
*/
function useStackSeat(motion, stack, series) {
	const mark = useId();
	const seat = useMemo(() => stack === void 0 ? null : {
		floors: stackFloorsOf(motion),
		mark,
		stack,
		series
	}, [
		motion,
		mark,
		stack,
		series
	]);
	useLayoutEffect(() => {
		if (seat === null) return void 0;
		return () => seat.floors.forget(seat.mark);
	}, [seat]);
	return seat;
}
function createStackFloors(motion) {
	const marks = /* @__PURE__ */ new Map();
	/** Each stack's marks. */
	const stacks = /* @__PURE__ */ new Map();
	/** Each mark's spans' places, 1 where the span keeps its floor. */
	const places = /* @__PURE__ */ new Map();
	/** Each stack's series' covers, built on demand once a settle. */
	const covers = /* @__PURE__ */ new Map();
	const paints = /* @__PURE__ */ new Map();
	const watchers = /* @__PURE__ */ new Map();
	const dirty = /* @__PURE__ */ new Set();
	const pending = /* @__PURE__ */ new Set();
	let depth = 0;
	/** Whether a microtask that settles the marks written outside a batch is queued. */
	let queued = false;
	/** Whether Root threw the pending work away, so no mark that leaves after it settles anything. */
	let discarded = false;
	/** Settle a stack's spans in its marks' frame, and note the marks whose places change. */
	const settleStack = (stack) => {
		const records = [...stacks.get(stack) ?? []].flatMap((name) => {
			const recorded = marks.get(name);
			return recorded === void 0 ? [] : [{
				name,
				...recorded
			}];
		});
		const frame = records[0]?.frame;
		const keeps = frame === void 0 ? /* @__PURE__ */ new Uint8Array(0) : settleFloors(records.flatMap(({ spans }) => spans), frame);
		let changed = false;
		let offset = 0;
		for (const { name, spans } of records) {
			const next = keeps.slice(offset, offset + spans.length);
			offset += spans.length;
			const last = places.get(name);
			places.set(name, next);
			if (sameItems(last, next)) continue;
			pending.add(name);
			changed = true;
		}
		covers.delete(stack);
		return changed;
	};
	/** Settle every changed stack, paint every mark that needs it once, then redraw the readers. */
	const settle = () => {
		const moved = [];
		for (const stack of dirty) if (settleStack(stack)) moved.push(stack);
		dirty.clear();
		const painting = [...pending];
		pending.clear();
		for (const name of painting) {
			const kept = places.get(name);
			if (kept !== void 0) paints.get(name)?.(kept);
		}
		for (const stack of moved) for (const redraw of watchers.get(stack) ?? []) redraw();
	};
	/** Settle in the next microtask, unless a batch ends first and settles for it. */
	const settleSoon = () => {
		if (queued) return;
		queued = true;
		queueMicrotask(() => {
			queued = false;
			if (depth === 0 && !discarded) settle();
		});
	};
	/** A series' cover in a stack, built once a settle from its marks' spans and places. */
	const coverOf = (stack, series) => {
		const known = covers.get(stack)?.get(series);
		if (known !== void 0) return known;
		const owned = [];
		for (const name of stacks.get(stack) ?? []) {
			const recorded = marks.get(name);
			const kept = places.get(name);
			if (recorded === void 0 || kept === void 0) continue;
			recorded.spans.forEach((span, index) => {
				const side = zeroSide(recorded.frame, span.segment.base, span.segment.tip);
				if (span.series !== series || side === null || span.to <= span.from) return;
				owned.push({
					from: span.from,
					to: span.to,
					side,
					keep: kept[index] ?? 0
				});
			});
		}
		if (owned.length === 0) return void 0;
		const low = Math.min(...owned.map(({ from }) => from));
		const high = Math.max(...owned.map(({ to }) => to));
		const above = new Int8Array(high - low).fill(-1);
		const below = new Int8Array(high - low).fill(-1);
		for (const { from, to, side, keep } of owned) {
			const cells = side === "above" ? above : below;
			for (let at = from; at < to; at += 1) if ((cells[at - low] ?? -1) !== 0) cells[at - low] = keep;
		}
		const built = {
			from: low,
			above,
			below
		};
		const byStack = covers.get(stack) ?? /* @__PURE__ */ new Map();
		covers.set(stack, byStack);
		byStack.set(series, built);
		return built;
	};
	/**
	* Note a stack whose spans changed, which settles again. A reader before then builds its cover
	* from the spans as they are, so it lags only where the settle changes a place, and the settle
	* redraws it there.
	*/
	const touch = (stack) => {
		dirty.add(stack);
		covers.delete(stack);
	};
	/** Drop a mark from its stack, which settles again. */
	const leave = (name) => {
		const stack = marks.get(name)?.stack;
		if (stack === void 0) return;
		const members = stacks.get(stack);
		members?.delete(name);
		if (members?.size === 0) stacks.delete(stack);
		touch(stack);
	};
	motion.batches({
		begin: () => {
			depth += 1;
		},
		end: () => {
			if (depth === 0) return;
			depth -= 1;
			if (depth === 0) settle();
		}
	});
	return {
		draw: (name, stack, spans, frame, paint) => {
			if (marks.get(name)?.stack !== stack) leave(name);
			marks.set(name, {
				stack,
				spans,
				frame
			});
			const members = stacks.get(stack) ?? /* @__PURE__ */ new Set();
			stacks.set(stack, members);
			members.add(name);
			touch(stack);
			paints.set(name, paint);
			pending.add(name);
			discarded = false;
			if (depth === 0) settleSoon();
		},
		placeOver: (stack, reader, frame) => {
			const side = zeroSide(frame, reader.segment.base, reader.segment.tip);
			const cover = side === null ? void 0 : coverOf(stack, reader.series);
			if (side === null || cover === void 0) return void 0;
			const cells = side === "above" ? cover.above : cover.below;
			let place;
			for (let at = reader.from; at < reader.to; at += 1) {
				const cell = cells[at - cover.from] ?? -1;
				if (cell === 0) return "inner";
				if (cell === 1) place = "outer";
			}
			return place;
		},
		watch: (stack, redraw) => {
			const set = watchers.get(stack) ?? /* @__PURE__ */ new Set();
			watchers.set(stack, set);
			set.add(redraw);
			return () => {
				set.delete(redraw);
				if (set.size === 0) watchers.delete(stack);
			};
		},
		forget: (name) => {
			leave(name);
			marks.delete(name);
			places.delete(name);
			paints.delete(name);
			pending.delete(name);
			if (discarded) dirty.clear();
			else if (depth === 0) settleSoon();
		},
		flush: () => {
			if (depth === 0 && !discarded && dirty.size > 0) settle();
		},
		discard: () => {
			discarded = true;
			dirty.clear();
			pending.clear();
			covers.clear();
		}
	};
}
export { discardStackFloors, flushStackFloors, stackFloorsOf, useStackSeat };

//# sourceMappingURL=chart-stack-floors.js.map