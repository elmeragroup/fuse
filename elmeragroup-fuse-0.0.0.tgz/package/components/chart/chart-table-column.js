"use client";
import { isThemeDevelopment } from "../../theme/validate-theme.js";
import { CHART_STRINGS } from "./format/chart-strings.js";
import { PRESET_INTERVAL, formatSlot } from "./format/time-format.js";
import { formatValue } from "./format/value-format.js";
import { ChartDataError, DATA_MESSAGES } from "./layout/errors.js";
import { useChartReadout } from "./chart-readout.js";
import { numberOf, stringOf } from "./layout/scalar.js";
import { Table } from "../table/table.js";
import { Twin } from "./chart-table-shell.js";
import { ChartTableRowContext } from "./chart-table-body.js";
import { use } from "react";
import { Fragment as Fragment$1, jsx } from "react/jsx-runtime";
// src/components/chart/chart-table-column.tsx
/**
* The extra column every family's Table takes, for a row column the chart does not plot. Its own
* module, because its `Date` cells print through the time formats, which a Table with no
* TableColumn never needs.
*/
/** The Intl date-time option names, which tell an `XFormat` object from Intl number options. */
const DATE_FIELDS = /* @__PURE__ */ new Set([
	"dateStyle",
	"timeStyle",
	"weekday",
	"era",
	"year",
	"month",
	"day",
	"dayPeriod",
	"hour",
	"minute",
	"second",
	"fractionalSecondDigits",
	"hour12",
	"hourCycle"
]);
/** Whether a format names a time preset. Every ValueFormat is an object, so a string is a preset. */
function isPreset(format) {
	return typeof format === "string";
}
/** Whether a TableColumn format is an `XFormat`, a time preset or Intl date-time options. */
function isTimeFormat(format) {
	return isPreset(format) || Object.keys(format).some((field) => DATE_FIELDS.has(field));
}
/** The development throw or production warning of `table-column-format`, once per Root and column. */
function formatMismatch(readout, dataKey) {
	const message = DATA_MESSAGES["table-column-format"];
	if (isThemeDevelopment()) throw new ChartDataError("Chart.TableColumn", "table-column-format", message);
	readout.warnOnce("table-column-format", dataKey, `Chart.TableColumn ${message}`);
}
/** A TableColumn cell's text. */
function columnCell(readout, timeZone, dataKey, cell, format) {
	const time = format !== void 0 && isTimeFormat(format);
	if (cell instanceof Date) {
		if (format !== void 0 && !time) formatMismatch(readout, dataKey);
		const preset = format !== void 0 && time ? format : "date";
		const interval = isPreset(preset) ? PRESET_INTERVAL[preset] : "second";
		return formatSlot(readout.locale, timeZone, cell.getTime(), interval, preset, "full");
	}
	const number = numberOf(cell);
	if (number !== void 0 && Number.isFinite(number)) {
		if (time) formatMismatch(readout, dataKey);
		const value = format !== void 0 && !time ? format : {};
		return formatValue(readout.locale, number, value, "full");
	}
	const text = stringOf(cell);
	if (text !== void 0) return {
		text,
		spoken: text
	};
	return {
		text: "–",
		spoken: CHART_STRINGS[readout.locale].missing
	};
}
/**
* A table column for a row column that the chart does not plot, such as a change percentage or the
* hour of a day's peak. Number cells print through a `ValueFormat`, `Date` cells through an
* `XFormat` in Root's zone, strings verbatim, and every other cell as `–`. A format that does not
* fit its cells throws `table-column-format` in development, and a column no row holds warns
* `absent-column` there.
*
* @beta
*/
function ChartTableColumn({ dataKey, header, format, className, style }) {
	const readout = useChartReadout("Chart.TableColumn");
	const row = use(ChartTableRowContext);
	if (row?.kind === "header") {
		if (isThemeDevelopment() && !row.table.hasColumn(dataKey)) readout.warnOnce("absent-column", dataKey, `Chart.TableColumn lists ${JSON.stringify(dataKey)}, a column no row holds, so every cell prints –. Check the dataKey against the rows.`);
		return /* @__PURE__ */ jsx(Table.Head, {
			scope: "col",
			className,
			style,
			children: /* @__PURE__ */ jsx("span", {
				"data-slot": "chart-table-column",
				children: header
			})
		});
	}
	if (row === null) return /* @__PURE__ */ jsx(Fragment$1, {});
	const cell = row.table.cell(row.slot, dataKey);
	return /* @__PURE__ */ jsx(Table.Cell, {
		className,
		style,
		children: /* @__PURE__ */ jsx("span", {
			"data-slot": "chart-table-column",
			children: /* @__PURE__ */ jsx(Twin, { text: columnCell(readout, row.table.timeZone, dataKey, cell, format) })
		})
	});
}
Object.assign(ChartTableColumn, { displayName: "Chart.TableColumn" });
export { ChartTableColumn };

//# sourceMappingURL=chart-table-column.js.map