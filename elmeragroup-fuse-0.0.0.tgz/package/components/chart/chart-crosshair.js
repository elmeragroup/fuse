"use client";
import { ChartCrosshairContext } from "./chart-scope-contexts.js";
import { coarsestOf, ownSlot } from "./layout/coarse-slots.js";
import { optionBand, slotLine, wholeWidth } from "./layout/plot-frame.js";
import { useChartRoot, usePlotLayout } from "./chart-context.js";
import { writeAttribute } from "./chart-dom.js";
import { useChartFollower } from "./chart-followers.js";
import { usePlotRead } from "./chart-plot-measure.js";
import { useChartFrame } from "./chart-plot.js";
import { sameShallow, useSteady } from "./chart-steady.js";
import { glideFrom, snapGlide, stepSpring } from "./chart-spring.js";
import { useLayoutEffect, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-crosshair.tsx
/**
* The marker of the active slot, a band for `xScale="band"` and a line for `"point"` by default.
* Write one in each Panel that needs one. Root moves it with the pointer by writing its geometry,
* so a pointer move renders nothing in React. The band covers the same pixel columns as the
* focused option and the tooltip's anchor. The line glides from slot to slot on a spring that
* quickens with the pointer, so it keeps up with a fast sweep and eases after a slow one, unless the
* reader prefers reduced motion, and fades at both ends by default. Active dots glide with it.
*
* @beta
*/
function ChartCrosshair({ variant, fade = "both", className, style, children }) {
	const { xScale, model, motion, store, orientation } = useChartRoot("Chart.Crosshair");
	const layout = usePlotLayout("Chart.Crosshair");
	const { keys } = layout;
	const drawn = useChartFrame("Chart.Crosshair", layout);
	const coarsest = coarsestOf(model.series.filter(({ key }) => keys.includes(key)));
	const look = variant ?? (xScale === "band" ? "band" : "line");
	const layer = useRef(null);
	const mark = useRef(null);
	const [token, setToken] = useState(1);
	const steadyStyle = useSteady(style, sameShallow);
	usePlotRead(() => {
		const svg = layer.current;
		if (svg === null) return false;
		const read = Number.parseFloat(getComputedStyle(svg).getPropertyValue("--chart-crosshair-width"));
		setToken(Number.isFinite(read) ? read : 1);
		return true;
	}, [className, steadyStyle]);
	const shown = useRef(null);
	useChartFollower("Chart.Crosshair", (active, cause) => {
		const node = mark.current;
		const window = model.window;
		if (node === null || drawn === null || active === null || window === null) {
			shown.current = null;
			if (layer.current !== null) snapGlide(layer.current);
			return;
		}
		const { frame } = drawn;
		const { box } = frame;
		const vertical = frame.orientation === "vertical";
		const position = active.slot - window.first;
		const [first, last] = coarsest === void 0 ? [active.slot, active.slot] : ownSlot(coarsest, active.slot);
		const [start, end] = look === "band" ? [optionBand(frame, Math.max(first, window.first) - window.first, xScale)[0], optionBand(frame, Math.min(last, window.last) - window.first, xScale)[1]] : slotLine(frame, position, xScale, wholeWidth(box, token));
		writeAttribute(node, vertical ? "x" : "y", start);
		writeAttribute(node, vertical ? "width" : "height", end - start);
		writeAttribute(node, vertical ? "y" : "x", 0);
		writeAttribute(node, vertical ? "height" : "width", vertical ? box.height : box.width);
		const from = shown.current;
		shown.current = start;
		const svg = layer.current;
		if (svg === null) return;
		if (look !== "line" || cause !== "step" || from === null || motion.snaps()) {
			snapGlide(svg);
			return;
		}
		glideFrom(svg, vertical ? [from - start, 0] : [0, from - start], stepSpring(store));
	});
	useLayoutEffect(() => {
		const svg = layer.current;
		return () => {
			if (svg !== null) snapGlide(svg);
		};
	}, []);
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("svg", {
		ref: layer,
		"data-slot": "chart-crosshair",
		"data-orientation": orientation,
		"data-variant": look,
		"data-fade": look === "line" ? fade : void 0,
		"aria-hidden": "true",
		className,
		style,
		children: drawn === null ? null : /* @__PURE__ */ jsx("rect", {
			ref: mark,
			"data-slot": "chart-crosshair-mark"
		})
	}), children === void 0 ? null : /* @__PURE__ */ jsx(ChartCrosshairContext, {
		value: true,
		children
	})] });
}
Object.assign(ChartCrosshair, { displayName: "Chart.Crosshair" });
export { ChartCrosshair };

//# sourceMappingURL=chart-crosshair.js.map