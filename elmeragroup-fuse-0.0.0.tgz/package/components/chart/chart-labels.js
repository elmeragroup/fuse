"use client";
import { writeAttribute, writeStyle } from "./chart-dom.js";
import { placeLabels } from "./layout/reference-labels.js";
// src/components/chart/chart-labels.ts
/**
* Root's reference labels on a vertical chart. Each value label registers its node and its own
* size, and its reference's writer hands over the guide it draws in every frame. Each slot label
* registers too, and its writer reports whether its guide shows in the plot now, which reserves the
* row of slot labels above the plot. Every handover and every change of a label's size, of the row
* or of the plot places all the value labels again through `placeLabels`, from what every guide
* draws now, so collision membership, stacking order, the row and offsets all follow the drawn
* guides and none of them reads a target.
*/
/** Whether two label sizes match. */
function sameSize(a, b) {
	return a.height === b.height && a.inset === b.inset;
}
/** Take a label out of the stack. */
function unstack(node) {
	writeAttribute(node, "data-stack", null);
	writeStyle(node, "--chart-label-bottom", null);
}
/**
* Create a Root's label registry.
*
* @returns The registry.
*/
function createChartLabels() {
	const entries = /* @__PURE__ */ new Map();
	let mounted = 0;
	let bounds = {
		end: 0,
		pixel: 1
	};
	const slots = /* @__PURE__ */ new Map();
	const place = () => {
		const plot = {
			start: [...slots.values()].some(Boolean) ? 0 : Number.NEGATIVE_INFINITY,
			...bounds
		};
		const drawn = [...entries.values()].filter((entry) => entry.span !== null);
		for (const entry of entries.values()) if (entry.span === null) unstack(entry.node);
		const guides = drawn.map(({ kind, order, span, size }) => ({
			kind,
			order,
			span,
			...size
		}));
		placeLabels(guides, plot).forEach((bottom, index) => {
			const node = drawn[index]?.node;
			if (node === void 0) return;
			writeStyle(node, "--chart-label-bottom", `${String(bottom)}px`);
			writeAttribute(node, "data-stack", "");
		});
	};
	return {
		add(key, node, kind, size) {
			const entry = {
				node,
				kind,
				order: mounted,
				size,
				span: null
			};
			mounted += 1;
			entries.set(key, entry);
			return () => {
				if (entries.get(key) !== entry) return;
				entries.delete(key);
				unstack(node);
				place();
			};
		},
		resize(key, size) {
			const entry = entries.get(key);
			if (entry === void 0 || sameSize(entry.size, size)) return;
			entry.size = size;
			place();
		},
		measure(next) {
			if (next.end === bounds.end && next.pixel === bounds.pixel) return;
			bounds = next;
			place();
		},
		move(key, span) {
			const entry = entries.get(key);
			if (entry === void 0 || span === null && entry.span === null) return;
			entry.span = span;
			place();
		},
		addSlot(key) {
			slots.set(key, false);
			return () => {
				const shown = slots.get(key) === true;
				slots.delete(key);
				if (shown) place();
			};
		},
		showSlot(key, shown) {
			if (!slots.has(key) || slots.get(key) === shown) return;
			slots.set(key, shown);
			place();
		}
	};
}
export { createChartLabels };

//# sourceMappingURL=chart-labels.js.map