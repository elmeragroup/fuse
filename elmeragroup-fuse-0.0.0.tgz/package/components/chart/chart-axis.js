"use client";
import { formatSlot, isClockPreset } from "./format/time-format.js";
import { formatValue } from "./format/value-format.js";
import { slotCount } from "./layout/x-domain.js";
import { runMargins } from "./layout/plot-frame.js";
import { useChartRoot, usePlotLayout } from "./chart-context.js";
import { useRootFrame } from "./chart-plot.js";
import { sameShallow, useSteady } from "./chart-steady.js";
import { labelWidth } from "./layout/label-width.js";
import { slotCentre, valueTop } from "./layout/plot-geometry.js";
import { fitsEveryBucket, thinTicks } from "./layout/tick-fit.js";
import { tickStrides } from "./layout/x-ticks.js";
import { useLayoutEffect, useMemo } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-axis.tsx
/** Each interval's default tick preset. */
const TICK_PRESETS = {
	second: "time-seconds",
	minute: "time",
	"quarter-hour": "hour",
	hour: "hour",
	day: "day",
	week: "week",
	month: "month",
	year: "year"
};
/**
* The preset of one tick. A tick of a coarser unit than the domain's is a day or longer, so a clock
* preset gives way to the unit's own default there.
*/
function tickFormat(format, unit, coarser) {
	if (format === void 0 || coarser && isClockPreset(format)) return TICK_PRESETS[unit];
	return format;
}
/**
* A slot's x axis label in the axis's format: the category itself, or the slot's start in the
* interval's tick preset or `format`.
*
* @param input - The domain and the locale.
* @param slot - A slot index.
* @param format - The axis's `format`, or undefined for the interval's tick preset.
* @returns The label's visual text.
*/
function slotTickLabel(input, slot, format) {
	const { domain, locale } = input;
	if (domain.kind === "category") return domain.names[slot] ?? "";
	const preset = tickFormat(format, domain.interval, false);
	return formatSlot(locale, domain.timeZone, domain.starts[slot] ?? 0, domain.interval, preset, "tick").text;
}
/** The x axis's ticks over the window, each with its text, place and visibility. */
function xTicks(input, format) {
	const { domain, window, locale, xScale, orientation } = input;
	if (window === null) return [];
	const inWindow = (slot) => slot >= window.first && slot <= window.last;
	const whole = window.first === 0 && window.last === slotCount(domain) - 1;
	const strides = tickStrides(domain);
	const all = whole ? strides : strides.map((entry) => ({
		...entry,
		slots: entry.slots.filter(inWindow)
	}));
	const isOwn = ({ unit }) => unit === "row" || domain.kind === "time" && unit === domain.interval;
	const own = all.filter(isOwn);
	const unitOf = /* @__PURE__ */ new Map();
	for (const entry of all) {
		if (entry.unit === "row" || isOwn(entry)) continue;
		for (const slot of entry.slots) unitOf.set(slot, entry.unit);
	}
	const text = (slot, coarse) => {
		if (domain.kind === "category" || !coarse) return slotTickLabel(input, slot, format);
		const unit = unitOf.get(slot) ?? domain.interval;
		const preset = tickFormat(format, unit, unit !== domain.interval);
		return formatSlot(locale, domain.timeZone, domain.starts[slot] ?? 0, unit, preset, "tick").text;
	};
	const position = (slot) => slotCentre(window, slot, xScale);
	const measure = (coarse) => {
		const labels = /* @__PURE__ */ new Map();
		const label = (slot) => {
			const known = labels.get(slot);
			if (known !== void 0) return known;
			const made = text(slot, coarse);
			labels.set(slot, made);
			return made;
		};
		const widths = /* @__PURE__ */ new Map();
		const width = (slot) => {
			const known = widths.get(slot);
			if (known !== void 0) return known;
			const made = labelWidth(label(slot));
			widths.set(slot, made);
			return made;
		};
		return {
			label,
			geometry: {
				position,
				width
			}
		};
	};
	if (orientation === "horizontal") {
		const { label } = measure(false);
		return (own[0]?.slots ?? []).map((slot) => ({
			slot,
			text: label(slot),
			at: position(slot),
			visibility: "always"
		}));
	}
	const fine = measure(false);
	const coarse = !fitsEveryBucket(own, fine.geometry) && all.length > own.length;
	const { label, geometry } = coarse ? measure(true) : fine;
	return thinTicks(coarse ? all : own, geometry).map(({ slot, visibility }) => ({
		slot,
		text: label(slot),
		at: position(slot),
		visibility
	}));
}
/**
* The visibility of each value label on an inline value axis, which horizontal bars draw along the
* bottom. The labels thin by the x axis's width buckets and fit rule. Each stride counts from the
* lowest tick, zero on a domain from zero, so the shown values keep one step, such as 0, 150 and
* 300. The lowest always shows, and each fit check counts the end labels CSS clamps inward.
*/
function inlineValueTicks(labels, domain) {
	const count = labels.length;
	const strides = Array.from({ length: Math.max(count - 1, 1) }, (_, index) => ({ slots: labels.flatMap((_label, slot) => slot % (index + 1) === 0 ? [slot] : []) }));
	const shown = thinTicks(strides, {
		position: (slot) => 1 - valueTop(domain, labels[slot]?.value ?? 0) / 100,
		width: (slot) => labelWidth(labels[slot]?.text ?? "")
	});
	return labels.map((_, slot) => shown.find((tick) => tick.slot === slot)?.visibility ?? "none");
}
/**
* The `xKey` axis in both orientations. It draws at the bottom, or at the left edge under
* `orientation="horizontal"`. Labels never rotate. When long labels do not fit, the axis shows
* fewer: each width bucket shows the smallest stride whose labels fit, and a wider axis never shows
* fewer labels than a narrower one. The axis is plot output, so it is hidden from screen readers.
*
* @beta
*/
function ChartXAxis({ format, label, tick = "none", className, style }) {
	const context = useChartRoot("Chart.XAxis");
	usePlotLayout("Chart.XAxis");
	const steadyFormat = useSteady(format, sameShallow);
	const { axis } = context;
	useLayoutEffect(() => {
		axis.setFormat(steadyFormat);
		return () => axis.setFormat(void 0);
	}, [axis, steadyFormat]);
	const { locale, xScale, orientation } = context;
	const { domain, window } = context.model;
	const first = window?.first;
	const last = window?.last;
	const ticks = useMemo(() => xTicks({
		domain,
		window: first === void 0 || last === void 0 ? null : {
			first,
			last
		},
		locale,
		xScale,
		orientation
	}, steadyFormat), [
		domain,
		first,
		last,
		locale,
		xScale,
		orientation,
		steadyFormat
	]);
	useLayoutEffect(() => {
		axis.touchTicks();
		return () => axis.touchTicks();
	}, [axis, ticks]);
	const keyOf = (slot, index) => index === 0 ? "first" : `slot:${context.update.keys[slot] ?? String(slot)}`;
	const drawn = useRootFrame("Chart.XAxis");
	const margins = runMargins(drawn?.frame ?? null);
	const placed = {
		...style,
		"--_run-before": margins.before,
		"--_run-after": margins.after
	};
	return /* @__PURE__ */ jsxs("div", {
		"data-slot": "chart-x-axis",
		"data-orientation": orientation,
		"data-tick": tick,
		"aria-hidden": "true",
		className,
		style: placed,
		children: [
			context.orientation === "horizontal" ? /* @__PURE__ */ jsx("span", {
				"data-slot": "chart-axis-sizer",
				children: ticks.map(({ slot, text }, index) => /* @__PURE__ */ jsx("span", { children: text }, keyOf(slot, index)))
			}) : null,
			ticks.map(({ slot, text, at, visibility }, index) => /* @__PURE__ */ jsx("span", {
				"data-slot": "chart-x-tick",
				"data-min": visibility === "always" ? void 0 : String(visibility),
				style: { "--chart-at": at },
				children: text
			}, keyOf(slot, index))),
			label === void 0 ? null : /* @__PURE__ */ jsx("span", {
				"data-slot": "chart-axis-label",
				children: label
			})
		]
	});
}
/**
* The value axis in both orientations, with d3 nice ticks. Under `stackOffset="expand"` it prints
* shares by default. A hidden sizer holds every label, so the axis column takes the widest label's
* width on the server and in every engine alike.
*
* @beta
*/
function ChartYAxis({ format, label, side = "start", className, style }) {
	const context = useChartRoot("Chart.YAxis");
	const { y, keys } = usePlotLayout("Chart.YAxis");
	const first = keys[0];
	const fallback = context.stackOffset === "expand" ? { style: "percent" } : (first === void 0 ? void 0 : context.config[first]?.format) ?? {};
	const labels = y.ticks.map((value) => ({
		value,
		text: formatValue(context.locale, value, format ?? fallback, "tick").text
	}));
	const inline = context.orientation === "horizontal" ? inlineValueTicks(labels, y.domain) : void 0;
	return /* @__PURE__ */ jsxs("div", {
		"data-slot": "chart-y-axis",
		"data-orientation": context.orientation,
		"data-side": side,
		"aria-hidden": "true",
		className,
		style,
		children: [
			/* @__PURE__ */ jsx("span", {
				"data-slot": "chart-axis-sizer",
				children: labels.map(({ value, text }) => /* @__PURE__ */ jsx("span", { children: text }, value))
			}),
			labels.map(({ value, text }, index) => {
				const at = valueTop(y.domain, value);
				const edge = at === 0 ? "end" : at === 100 ? "start" : void 0;
				const shown = inline?.[index];
				if (shown === "none") return null;
				return /* @__PURE__ */ jsx("span", {
					"data-slot": "chart-y-tick",
					"data-edge": edge,
					"data-min": shown === void 0 || shown === "always" ? void 0 : String(shown),
					style: { "--chart-at": `${String(at)}%` },
					children: text
				}, value);
			}),
			label === void 0 ? null : /* @__PURE__ */ jsx("span", {
				"data-slot": "chart-axis-label",
				children: label
			})
		]
	});
}
Object.assign(ChartXAxis, { displayName: "Chart.XAxis" });
Object.assign(ChartYAxis, { displayName: "Chart.YAxis" });
export { ChartXAxis, ChartYAxis, slotTickLabel };

//# sourceMappingURL=chart-axis.js.map