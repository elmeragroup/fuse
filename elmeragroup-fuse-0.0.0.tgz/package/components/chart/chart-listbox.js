"use client";
import { withinFocusRingClass } from "../../styles/utils.js";
import { CHART_STRINGS } from "./format/chart-strings.js";
import { useLayoutEffect, useRef, useState } from "react";
import { jsx } from "react/jsx-runtime";
// src/components/chart/chart-listbox.tsx
/**
* The listbox every chart family's plot surface is: the plot's single tab stop, a `listbox` over the
* plot that holds exactly one `option`, the active datum's, and that option holds DOM focus. Each
* step renders the next option beside the current one, focuses it in a layout effect and removes
* the old one in the next commit, so focus never passes through `body`. Each family's surface keeps
* its own listbox element where its Root mounts it, with its own keys, pick and option names, and
* reads the handoff, the naming and the status region from here.
*
* The fallback pattern of CONTRACT section 9.1 changes only the families' surfaces and this module.
* There the listbox takes `tabIndex={0}` and DOM focus, the single option loses its tab index, and
* the listbox sets `aria-activedescendant` to the option's id. Names, positions, descriptions, keys
* and the status region stay as they are, so a switch ships as a patch with no public change.
*/
/**
* The option handoff of a surface: an id counter under the Root's prefix, the current option and
* the one a step leaves, and a layout effect that focuses a new option once it commits.
*
* @template T - The family's option state, such as a slot's x and the series focus.
* @param id - The Root's id prefix.
* @param listbox - The listbox element, which the focus moves inside.
* @param initial - The first option's state.
* @returns The handoff.
*/
function useOptionHandoff(id, listbox, initial) {
	const counter = useRef(0);
	const nextId = () => {
		counter.current += 1;
		return `${id}-option-${String(counter.current)}`;
	};
	const [options, setOptions] = useState(() => [{
		...initial(),
		id: `${id}-option-0`,
		entry: true
	}]);
	const focusTarget = useRef(null);
	useLayoutEffect(() => {
		const target = focusTarget.current;
		if (target === null) return;
		focusTarget.current = null;
		listbox.current?.querySelector(`[id="${CSS.escape(target)}"]`)?.focus({ preventScroll: true });
	});
	const current = options.at(-1);
	return {
		options,
		current,
		step: (state) => {
			const next = {
				...state,
				id: nextId(),
				entry: false
			};
			focusTarget.current = next.id;
			setOptions((list) => [...list.slice(-1), next]);
		},
		revise: (state) => {
			if (current === void 0) return;
			setOptions([...options.slice(0, -1), {
				...state,
				id: current.id,
				entry: current.entry
			}]);
		},
		within: (event) => event.relatedTarget instanceof Node && event.currentTarget.contains(event.relatedTarget),
		kept: (event) => event.target === event.currentTarget.ownerDocument.activeElement,
		prune: () => {
			if (options.length > 1) setOptions((list) => list.slice(-1));
		},
		reset: (state) => {
			setOptions([{
				...state,
				id: nextId(),
				entry: true
			}]);
		}
	};
}
/**
* End a surface's press when its element goes away. An empty model takes the surface's element
* away, mid-press too, so no later press inherits the gesture: the element's cleanup ends it.
*
* @template G - The surface's record of a press in progress.
* @param shown - Whether the surface's element renders.
* @param lift - The surface's lift record.
* @param gesture - The surface's press in progress.
* @param idle - The record of no press.
*/
function useGestureEnd(shown, lift, gesture, idle) {
	useLayoutEffect(() => shown ? () => {
		gesture.current = idle;
		lift.press();
	} : void 0, [
		shown,
		lift,
		gesture,
		idle
	]);
}
/**
* The listbox element's own attributes beside its `role`: its id, slot, pin state, orientation,
* name and focus ring. With `aria-labelledby` on Root, the listbox reads the chart's name followed by its own
* hidden name, which `SurfaceName` renders.
*
* @param naming - What names the surface.
* @param pinned - Whether a tooltip is pinned.
* @param orientation - The axis the options step along.
* @returns The attributes to spread on the listbox element.
*/
function listboxProps(naming, pinned, orientation) {
	const { id, name, labelledBy, locale } = naming;
	return {
		id: `${id}-surface`,
		"data-slot": "chart-surface",
		"data-pinned": pinned ? "" : void 0,
		"aria-orientation": orientation,
		...labelledBy === void 0 ? { "aria-label": CHART_STRINGS[locale].surfaceName(name ?? "") } : { "aria-labelledby": `${labelledBy} ${id}-surface-name` },
		className: withinFocusRingClass
	};
}
/**
* The surface's own name, hidden, which the listbox's `aria-labelledby` reads after the chart's
* name. It renders only under `aria-labelledby`.
*
* @param props - What names the surface.
* @returns The hidden name, or null.
*/
function SurfaceName({ id, labelledBy, locale }) {
	if (labelledBy === void 0) return null;
	return /* @__PURE__ */ jsx("span", {
		id: `${id}-surface-name`,
		hidden: true,
		children: CHART_STRINGS[locale].surfaceName("").replace(/^,\s*/u, "")
	});
}
/**
* A Root's status region. It is mounted empty on the server and never unmounts. A repeated message
* gets an alternating trailing U+00A0, so the region announces it again.
*
* @param props - The latest message and how many messages came before it.
* @returns The region.
*/
function StatusRegion({ text, count }) {
	return /* @__PURE__ */ jsx("div", {
		role: "status",
		"data-slot": "chart-status",
		children: text === "" ? "" : `${text}${count % 2 === 0 ? "\xA0" : ""}`
	});
}
Object.assign(SurfaceName, { displayName: "Chart.SurfaceName" });
Object.assign(StatusRegion, { displayName: "Chart.StatusRegion" });
export { StatusRegion, SurfaceName, listboxProps, useGestureEnd, useOptionHandoff };

//# sourceMappingURL=chart-listbox.js.map