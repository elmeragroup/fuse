"use client";
import { isThemeDevelopment } from "../../theme/validate-theme.js";
import { CHART_STRINGS } from "./format/chart-strings.js";
import { formatValue } from "./format/value-format.js";
import { ChartCompositionError } from "./layout/errors.js";
import { stringOf } from "./layout/scalar.js";
import { slotOf } from "./layout/x-domain.js";
import { hairline, ruleAcross, slotAxisAt, slotLine, slotLineAt, slotShare, snapAcross, snapAcrossSpan, snapAlong, snapSpan, snapY, valueShare, wholeWidth } from "./layout/plot-frame.js";
import { barForm } from "./layout/bar-geometry.js";
import { useChartRoot, usePlotLayout } from "./chart-context.js";
import { partsCache, writeAttribute, writeAttributes, writeStyle } from "./chart-dom.js";
import { usePlotRead } from "./chart-plot-measure.js";
import { useChartFrame } from "./chart-plot.js";
import { slotLabel } from "./chart-text.js";
import { sameShallow, useSteady } from "./chart-steady.js";
import { slotCentre, valueTop } from "./layout/plot-geometry.js";
import { placementOf, useCommitMotion, useFirstDraw, useMotionMark } from "./chart-motion-mark.js";
import { referenceSentence } from "./chart-reference-text.js";
import { useId, useLayoutEffect, useMemo, useRef } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-reference.tsx
/**
* The slot a child x prop names. A string on a time axis, or a `Date` or number on a category axis,
* throws `x-type-mismatch` in every build.
*/
function childSlot(context, part, x) {
	const { domain } = context.model;
	const isString = stringOf(x) !== void 0;
	if (domain.kind === "time" === isString) throw new ChartCompositionError(part, "x-type-mismatch", domain.kind === "time" ? "received an x string on a time axis. Pass a Date or epoch milliseconds, because a date-only string parses as UTC midnight and lands on the wrong day." : "received a Date or a number on a category axis. Pass the category string.");
	return slotOf(domain, x);
}
/** The value of a value-axis reference in the layout's first series' format. */
function valueText(context, keys, value, format) {
	const first = keys[0];
	return formatValue(context.locale, value, format ?? (first === void 0 ? {} : context.config[first]?.format) ?? {}, "full");
}
/** Warn once per Root in development when a reference sits outside the value domain. */
function warnOutside(context, part, values, domain) {
	if (!isThemeDevelopment()) return;
	if (values.every((value) => value >= domain[0] && value <= domain[1])) return;
	context.warnOnce("reference-outside-domain", `${part} ${values.join(" ")}`, `${part} sits outside the value domain, so it renders clipped. Pass its value to yInclude on Chart.Root or the Panel, because Root never reads its children.`);
}
/** A label's own size, from its text: one line high, its cut-area inset 0.25rem below that. */
function labelSize(node) {
	const style = getComputedStyle(node);
	const height = Number.parseFloat(style.lineHeight) || Number.parseFloat(style.fontSize) * 1.2 || 0;
	return {
		height,
		inset: .25 * (Number.parseFloat(getComputedStyle(document.documentElement).fontSize) || 16) + height
	};
}
/**
* Place a reference's label on a vertical chart through its layout's label registry, one per
* Panel, so labels stack against their own Panel's plot and a slot label reserves a row there
* alone. It places them from what the
* reference draws. A value reference's label registers with its own size, and every frame its
* writer hands over the guide it draws, so the registry places every value label from the drawn
* guides alone. A slot reference's label registers in the row of slot labels above the plot, and
* every frame its writer reports whether its guide shows, which reserves the row. The reference
* places its guide on every commit, so a label that registers or changes size draws from the
* guide's current position at once. Before the first frame, as on the server, a value label sits
* on its own edge. A horizontal chart stacks nothing.
*/
function useStackedLabel(context, labels, drawn, labelled, kind, axis, inputs) {
	const key = useId();
	const ref = useRef(null);
	const placed = labelled && context.orientation === "vertical";
	const stacks = placed && axis === "value";
	const row = placed && axis === "slot";
	useLayoutEffect(() => {
		const node = ref.current;
		if (!stacks || node === null) return;
		return labels.add(key, node, kind, labelSize(node));
	}, [
		labels,
		key,
		stacks,
		kind
	]);
	useLayoutEffect(() => {
		if (row) return labels.addSlot(key);
	}, [
		labels,
		key,
		row
	]);
	usePlotRead(() => {
		const node = ref.current;
		if (node === null) return false;
		if (stacks) labels.resize(key, labelSize(node));
		return true;
	}, inputs);
	useLayoutEffect(() => {
		if (!stacks || drawn === null) return;
		const { box } = drawn.frame;
		labels.measure({
			end: snapY(box, box.height),
			pixel: 1 / box.dpr
		});
	});
	return useMemo(() => ({
		ref,
		move: (span) => {
			if (stacks) labels.move(key, span);
		},
		show: (shown) => {
			if (row) labels.showSlot(key, shown);
		}
	}), [
		labels,
		key,
		stacks,
		row
	]);
}
/** A range in visual form with a bare en dash, writing a shared unit once, such as `5–10 kWh`. */
function rangeText(from, to, join) {
	const fromParts = from.text.split("\xA0");
	const toParts = to.text.split("\xA0");
	return {
		text: `${fromParts.length > 1 && fromParts.at(-1) === toParts.at(-1) ? fromParts.slice(0, -1).join("\xA0") : from.text}\u2013${to.text}`,
		spoken: join(from.spoken, to.spoken)
	};
}
/**
* Whether a reference on an axis runs across the plot at an x, as a slot reference on a vertical
* chart and a value reference on a horizontal one do, rather than at a y.
*/
function atX(frame, axis) {
	return frame.orientation === "vertical" === (axis === "slot");
}
/**
* The pixel coordinate of a share of the plot. A value share runs from the domain maximum, the
* top or the right edge, and a slot share from the first slot, the left or the top edge, across
* the run the slot bands take, so a slot reference keeps to its slot's band.
*/
function plotCoordinate(frame, axis, at) {
	if (axis === "slot") return slotAxisAt(frame, at / 100);
	const length = plotLength(frame, axis);
	const share = at / 100 * length;
	return frame.orientation === "horizontal" ? length - share : share;
}
/**
* Snap a reference's tweened coordinate where it draws, as a bar's edge or a slot's centre snaps,
* so a guide at a bar's value meets the bar's edge. The loop tweens the unsnapped coordinate, so
* whether a guide lies inside the plot never rests on a snap.
*/
function drawnPixel(frame, axis, at) {
	return axis === "value" ? snapAcross(frame, at) : snapAlong(frame, at);
}
/** The plot's length along the axis a reference's coordinate runs on, unsnapped. */
function plotLength(frame, axis) {
	return atX(frame, axis) ? frame.box.width : frame.box.height;
}
/**
* Where a reference's coordinate may lie and still show: the plot along the value axis, and along
* the slot axis the run the slot bands take, so a slot outside the window stays out of the plot's
* leftover pixels at either end.
*/
function axisBounds(frame, axis) {
	return axis === "slot" ? [slotAxisAt(frame, 0), slotAxisAt(frame, 1)] : [0, plotLength(frame, axis)];
}
/** The share of the plot a drawn coordinate stands for. */
function referenceShare(frame, axis, at) {
	return axis === "value" ? valueShare(frame, at) : slotShare(frame, at);
}
/**
* Move a reference with the bars. Its two numbers tween through Root's animation loop in the same
* pixel space and on the same clock as the bars, so a resize during an update keeps a guide on its
* bar. Its writer, at module scope, redraws the line or band, its label and its CSS shares from the
* drawn numbers.
*
* @param axis - The axis the reference's coordinates run on. Its numbers mean pixels along that
*   axis, so a change of axis is a change of coordinate space, which snaps.
* @param target - The reference's two numbers in a frame: a line's coordinate and width, or an
*   area's two edges, each unsnapped.
* @param look - The writer's look, whose kind says whether the second number, a line's width, is a
*   size, or an area's far edge, which runs on the same axis as its near one.
* @returns The ref of the reference's wrapper.
*/
function useReferenceMark(context, drawn, axis, target, look) {
	const direction = context.orientation === "vertical" === (axis === "slot") ? "x" : "y";
	const axes = [direction, look.kind === "line" ? "size" : direction];
	const { ref, place } = useMotionMark(context.motion, drawReference, look, axes);
	const commit = useCommitMotion(context.update, drawn?.plot ?? null, `${context.orientation} ${axis}`, drawn?.frame ?? null);
	useLayoutEffect(() => {
		if (drawn === null) return;
		const asked = commit();
		const glides = barForm(context.model, context.orientation) === "bars" && Object.keys(context.config).some((key) => context.drawsBar(key));
		const crossfades = asked.kind === "move" && context.update.window.mode === "crossfade" && !glides;
		place(target(drawn.frame), crossfades ? { kind: "snap" } : placementOf(asked));
	});
	return ref;
}
/**
* A rule at a drawn coordinate, across the plot's whole length: a hairline on the value axis, and as
* wide as the slot's line on the slot axis, its near edge at the coordinate.
*/
function lineAttributes(frame, axis, at, width) {
	if (axis === "value") return ruleAcross(frame.box, atX(frame, axis) ? "vertical" : "horizontal", at);
	const centre = snapAlong(frame, at) + width / 2;
	return frame.orientation === "vertical" ? {
		x1: centre,
		y1: 0,
		x2: centre,
		y2: frame.box.height
	} : {
		x1: 0,
		y1: centre,
		x2: frame.box.width,
		y2: centre
	};
}
/**
* A line's drawn state at a tweened, unsnapped coordinate: a value, or a slot's centre, which lies
* outside the plot for a slot outside the window. A slot line inside the plot draws inside its
* slot's band, as `slotLineAt` draws it, and its span starts where the rule does.
*/
function lineDrawn(frame, axis, at, width, xScale) {
	const [low, high] = axisBounds(frame, axis);
	const outside = at < low || at > high;
	const start = axis === "slot" && !outside ? slotLineAt(frame, at, xScale, width)[0] : drawnPixel(frame, axis, at);
	const span = [start, start];
	return {
		outside,
		clipped: false,
		span,
		guide: outside ? null : span
	};
}
/** A reference's rule or band, found once per commit of its mark. */
const referencePart = partsCache((node) => node.querySelector("[data-slot=\"chart-reference-rule\"], [data-slot=\"chart-reference-band\"]"));
/** Draw a line from the loop's numbers, its coordinate and its width. */
function drawLine(node, look, values) {
	const { frame, axis, xScale, label } = look;
	if (frame === null) return;
	const [pixel = 0, tweened = 1] = values;
	const width = wholeWidth(frame.box, tweened);
	const state = lineDrawn(frame, axis, pixel, width, xScale);
	const share = referenceShare(frame, axis, state.span[0]);
	writeStyle(node, "--chart-at", `${String(share)}%`);
	writeStyle(node, "--chart-x", String(share / 100));
	toggle(node, "data-outside", state.outside);
	label.move(state.guide);
	label.show(!state.outside);
	writeStyle(node, "--_rule-width", `${String(width)}px`);
	writeAttributes(referencePart(node), lineAttributes(frame, axis, state.span[0], width));
}
/** Draw a reference from the loop's numbers, as its kind draws it. */
function drawReference(node, look, values) {
	if (look.kind === "line") drawLine(node, look, values);
	else drawArea(node, look, values);
}
/** Draw a band from the loop's numbers, its two edges. */
function drawArea(node, look, values) {
	const { frame, axis, label } = look;
	if (frame === null) return;
	const [start = 0, end = 0] = values;
	const state = bandDrawn(frame, axis, start, end);
	const [low, high] = state.span;
	const clamp = (share) => Math.min(Math.max(share, 0), 100);
	const [fromEdge, toEdge] = start <= end ? [low, high] : [high, low];
	const shownStart = axis === "slot" ? slotShare(frame, low) : clamp(referenceShare(frame, axis, fromEdge));
	const shownEnd = axis === "slot" ? slotShare(frame, high) : clamp(referenceShare(frame, axis, toEdge));
	writeStyle(node, "--chart-from", `${String(shownStart)}%`);
	writeStyle(node, "--chart-to", `${String(shownEnd)}%`);
	writeStyle(node, "--chart-x", String(shownStart / 100));
	toggle(node, "data-outside", state.outside);
	toggle(node, "data-clipped", state.clipped);
	label.move(state.guide);
	label.show(!state.outside);
	writeAttributes(referencePart(node), bandAttributes(frame, axis, state.span));
}
/** A band's drawn state between two tweened coordinates. */
function bandDrawn(frame, axis, start, end) {
	const [first, last] = axisBounds(frame, axis);
	const low = Math.max(Math.min(start, end), 0);
	const high = Math.min(Math.max(start, end), plotLength(frame, axis));
	const outside = Math.max(low, first) >= Math.min(high, last);
	const clipped = axis === "value" && referenceShare(frame, axis, start) < 0;
	if (outside) {
		const at = drawnPixel(frame, axis, low);
		return {
			outside,
			clipped,
			span: [at, at],
			guide: null
		};
	}
	return {
		outside,
		clipped,
		span: axis === "slot" ? snapSpan(frame, low, high) : snapAcrossSpan(frame, low, high),
		guide: [drawnPixel(frame, axis, Math.min(start, end)), drawnPixel(frame, axis, Math.max(start, end))]
	};
}
/** The rectangle of a band's drawn span, across the plot's whole length. */
function bandAttributes(frame, axis, [start, stop]) {
	const { box } = frame;
	return atX(frame, axis) ? {
		x: start,
		width: stop - start,
		y: 0,
		height: box.height
	} : {
		x: 0,
		width: box.width,
		y: start,
		height: stop - start
	};
}
/** Set or remove a boolean data attribute. */
function toggle(node, name, on) {
	writeAttribute(node, name, on ? "" : null);
}
/**
* A line at one value or one x, such as a price cap. Readers hear it as a visually hidden sentence
* that always carries the value, in the reference's own place after the plot. Pass the value to
* Root's `yInclude` when it may sit outside the data, because Root never reads its children, and a
* development build warns with `reference-outside-domain` when it does.
*
* @beta
*/
function ChartReferenceLine({ style, ...props }) {
	const { label, variant = "solid", tone = "default", className } = props;
	const context = useChartRoot("Chart.ReferenceLine");
	const layout = usePlotLayout("Chart.ReferenceLine");
	const strings = CHART_STRINGS[context.locale];
	let at;
	let value;
	let axis;
	let position = null;
	if (props.y === void 0) {
		const window = context.model.window;
		const slot = childSlot(context, "Chart.ReferenceLine", props.x);
		at = window === null || slot === -1 ? -1 : slotCentre(window, slot, context.xScale) * 100;
		position = window === null || slot === -1 ? null : slot - window.first;
		value = slot === -1 ? {
			text: "",
			spoken: ""
		} : slotLabel(context, slot, props.format);
		axis = "slot";
	} else {
		warnOutside(context, "Chart.ReferenceLine", [props.y], layout.y.domain);
		at = valueTop(layout.y.domain, props.y);
		value = valueText(context, layout.keys, props.y, props.format);
		axis = "value";
	}
	const text = referenceSentence(label, value, strings.referenceLine);
	const outside = at < 0 || at > 100;
	const drawn = useChartFrame("Chart.ReferenceLine", layout);
	const steadyStyle = useSteady(style, sameShallow);
	const stacked = useStackedLabel(context, layout.labels, drawn, label !== void 0 && label !== "", "line", axis, [className, steadyStyle]);
	const { ref: labelRef } = stacked;
	const frame = drawn?.frame ?? null;
	const look = useMemo(() => ({
		kind: "line",
		frame,
		axis,
		xScale: context.xScale,
		label: stacked
	}), [
		frame,
		axis,
		context.xScale,
		stacked
	]);
	const ruleWidth = (measured) => {
		if (position === null) return hairline(measured.box);
		const [start, end] = slotLine(measured, position, context.xScale);
		return end - start;
	};
	const target = (measured) => [plotCoordinate(measured, axis, at), ruleWidth(measured)];
	const wrapper = useReferenceMark(context, drawn, axis, target, look);
	const rule = (measured) => {
		const [coordinate, wide] = target(measured);
		const width = wholeWidth(measured.box, wide);
		return lineAttributes(measured, axis, lineDrawn(measured, axis, coordinate, width, context.xScale).span[0], width);
	};
	const ruleAttributes = useFirstDraw(() => frame === null ? null : rule(frame));
	return /* @__PURE__ */ jsxs("div", {
		ref: wrapper,
		"data-slot": "chart-reference-line",
		"data-orientation": context.orientation,
		"data-axis": axis,
		"data-outside": outside ? "" : void 0,
		"data-variant": variant,
		"data-tone": tone,
		className,
		style: {
			"--chart-at": `${String(at)}%`,
			"--chart-x": at / 100,
			...style
		},
		children: [
			/* @__PURE__ */ jsx("svg", {
				"aria-hidden": "true",
				children: ruleAttributes === null ? null : /* @__PURE__ */ jsx("line", {
					"data-slot": "chart-reference-rule",
					...ruleAttributes
				})
			}),
			/* @__PURE__ */ jsx("span", {
				ref: labelRef,
				"data-slot": "chart-reference-label",
				"aria-hidden": "true",
				children: label === void 0 ? null : text.text
			}),
			/* @__PURE__ */ jsx("span", {
				"data-slot": "chart-reference-text",
				children: text.spoken
			})
		]
	});
}
/**
* A band between two values or two x values, such as a tariff step. Readers hear it as a visually
* hidden sentence with the range. Both ends are inclusive.
*
* @beta
*/
function ChartReferenceArea({ style, ...props }) {
	const { label, tone = "default", className } = props;
	const context = useChartRoot("Chart.ReferenceArea");
	const layout = usePlotLayout("Chart.ReferenceArea");
	const strings = CHART_STRINGS[context.locale];
	let from;
	let to;
	let value;
	let axis;
	if (props.y1 === void 0) {
		const window = context.model.window;
		const a = childSlot(context, "Chart.ReferenceArea", props.x1);
		const b = childSlot(context, "Chart.ReferenceArea", props.x2);
		const count = window === null ? 1 : window.last - window.first + 1;
		const first = Math.min(a, b) - (window?.first ?? 0);
		const last = Math.max(a, b) - (window?.first ?? 0);
		from = first / count * 100;
		to = (last + 1) / count * 100;
		value = a === -1 || b === -1 ? {
			text: "",
			spoken: ""
		} : rangeText(slotLabel(context, Math.min(a, b), props.format), slotLabel(context, Math.max(a, b), props.format), strings.valueRange);
		axis = "slot";
	} else {
		const low = Math.min(props.y1, props.y2);
		const high = Math.max(props.y1, props.y2);
		warnOutside(context, "Chart.ReferenceArea", [low, high], layout.y.domain);
		from = valueTop(layout.y.domain, high);
		to = valueTop(layout.y.domain, low);
		value = rangeText(valueText(context, layout.keys, low, props.format), valueText(context, layout.keys, high, props.format), strings.valueRange);
		axis = "value";
	}
	const text = referenceSentence(label, value, strings.referenceArea);
	const shownFrom = Math.min(Math.max(from, 0), 100);
	const shownTo = Math.min(Math.max(to, 0), 100);
	const outside = shownFrom >= shownTo;
	const clipped = axis === "value" && from < 0;
	const drawn = useChartFrame("Chart.ReferenceArea", layout);
	const steadyStyle = useSteady(style, sameShallow);
	const stacked = useStackedLabel(context, layout.labels, drawn, label !== void 0 && label !== "", "area", axis, [className, steadyStyle]);
	const { ref: labelRef } = stacked;
	const frame = drawn?.frame ?? null;
	const look = useMemo(() => ({
		kind: "area",
		frame,
		axis,
		xScale: context.xScale,
		label: stacked
	}), [
		frame,
		axis,
		context.xScale,
		stacked
	]);
	const target = (measured) => [plotCoordinate(measured, axis, from), plotCoordinate(measured, axis, to)];
	const wrapper = useReferenceMark(context, drawn, axis, target, look);
	const band = useFirstDraw(() => frame === null ? null : bandAttributes(frame, axis, bandDrawn(frame, axis, ...target(frame)).span));
	return /* @__PURE__ */ jsxs("div", {
		ref: wrapper,
		"data-slot": "chart-reference-area",
		"data-orientation": context.orientation,
		"data-axis": axis,
		"data-outside": outside ? "" : void 0,
		"data-clipped": clipped ? "" : void 0,
		"data-tone": tone,
		className,
		style: {
			"--chart-from": `${String(shownFrom)}%`,
			"--chart-to": `${String(shownTo)}%`,
			"--chart-x": shownFrom / 100,
			...style
		},
		children: [
			/* @__PURE__ */ jsx("svg", {
				"aria-hidden": "true",
				children: band === null ? null : /* @__PURE__ */ jsx("rect", {
					"data-slot": "chart-reference-band",
					...band
				})
			}),
			/* @__PURE__ */ jsx("span", {
				ref: labelRef,
				"data-slot": "chart-reference-label",
				"aria-hidden": "true",
				children: label === void 0 ? null : text.text
			}),
			/* @__PURE__ */ jsx("span", {
				"data-slot": "chart-reference-text",
				children: text.spoken
			})
		]
	});
}
Object.assign(ChartReferenceLine, { displayName: "Chart.ReferenceLine" });
Object.assign(ChartReferenceArea, { displayName: "Chart.ReferenceArea" });
export { ChartReferenceArea, ChartReferenceLine, childSlot };

//# sourceMappingURL=chart-reference.js.map