import { ChartCompositionError } from "./layout/errors.js";
import { binEdges, colorBins } from "./layout/color-bins.js";
import { isRoleList, isThresholdColor, seriesPaint } from "./layout/color-key.js";
// src/components/chart/chart-paint.ts
/** The scale a colour names, or undefined for every other colour. */
function scaleOf(color) {
	return color === "chart-seq" || color === "chart-diverging" ? color : void 0;
}
/** The roles a colour paints with: a role, a list's roles, a threshold's two sides, or none for a scale. */
function rolesOf(color) {
	if (isRoleList(color)) return color;
	if (isThresholdColor(color)) return [color.below.color, color.above.color];
	return [color];
}
/**
* The series whose threshold is not a finite number, in config order. Development throws
* `non-finite-threshold` for the first, and production warns once for each and paints it in its
* `below` role.
*
* @param config - The Root's config.
* @returns The series keys, empty when every threshold is finite.
*/
function nonFiniteThresholds(config) {
	return Object.keys(config).filter((key) => {
		const color = config[key]?.color;
		return color !== void 0 && isThresholdColor(color) && !Number.isFinite(color.threshold);
	});
}
/**
* The error of one layout that mixes a sentiment role with a categorical role, which D4 forbids,
* because a reader would take the categorical hue for a judgement. Each layout checks its own
* keys: a Panel its `series`, and Root's default layout every config key when it draws.
*
* @param part - The layout's owner, `Chart.Root` or `Chart.Panel`.
* @param config - The Root's config.
* @param keys - The config keys the layout covers.
* @returns The error, or null for a layout of one colour family.
*/
function colourFamilyError(part, config, keys) {
	const roles = keys.flatMap((key) => {
		const color = config[key]?.color;
		return color === void 0 ? [] : rolesOf(color);
	});
	const sentiment = roles.some((role) => role.startsWith("chart-sentiment-"));
	const categorical = roles.some((role) => /^chart-\d$/u.test(role));
	return sentiment && categorical ? new ChartCompositionError(part, "mixed-sentiment-categorical", "mixes a sentiment role with a categorical role in one layout. Colour every series of the layout by sentiment, or every series by category.") : null;
}
/**
* The error of a Line or Area coloured by a scale or a threshold whose values draw stacked. Both
* split the series' own values along the value axis, and a stacked or expanded path draws at other
* values, so no single gradient can paint it by value. Bars take either on a stack, because each
* bar paints its own value.
*
* @param part - `Chart.Line` or `Chart.Area`.
* @param color - The series colour.
* @param stacked - Whether the series is in a stack of two or more keys.
* @param stackOffset - Root's stack offset, which under "expand" redraws even a lone series.
* @returns The error, or null for a path that draws its own values.
*/
function stackedScaleError(part, color, stacked, stackOffset) {
	const scale = scaleOf(color);
	if (scale === void 0 && !isThresholdColor(color)) return null;
	if (!stacked && stackOffset !== "expand") return null;
	const named = scale === void 0 ? "a threshold colour" : `color "${scale}"`;
	return new ChartCompositionError(part, "scale-colour-on-stack", `paints ${named} on ${stacked ? "a stacked series" : "stackOffset=\"expand\""}, where the path draws at stacked values ${scale === void 0 ? "the threshold doesn't follow" : "the scale's bins don't follow"}. Give the series a role, or draw it with Chart.Bar.`);
}
const SCALE_STEPS = [
	1,
	2,
	3,
	4,
	5,
	6,
	7
];
const paints = /* @__PURE__ */ new WeakMap();
/**
* A threshold's two steps. A value above the threshold takes step 2, and a value at it or below
* takes step 1, so a reading that equals the average reads as not above it. A threshold that is
* not a finite number puts every value in step 1, production's `non-finite-threshold` fallback.
*/
function thresholdBins(threshold) {
	if (!Number.isFinite(threshold)) return () => 1;
	return (value) => value > threshold ? 2 : 1;
}
function buildPaint(key, color, series) {
	if (isRoleList(color)) {
		const stops = color.map((role) => seriesPaint(key, role));
		return {
			key,
			color,
			base: seriesPaint(key, color[0]),
			bins: void 0,
			edges: [],
			stops,
			ramp: void 0
		};
	}
	if (isThresholdColor(color)) {
		const { threshold, below, above } = color;
		const ramp = [seriesPaint(key, below.color), seriesPaint(key, above.color)];
		return {
			key,
			color,
			base: ramp[0],
			bins: thresholdBins(threshold),
			edges: Number.isFinite(threshold) ? [threshold] : [],
			stops: void 0,
			ramp
		};
	}
	const scale = scaleOf(color);
	if (scale === void 0) return {
		key,
		color,
		base: seriesPaint(key, color),
		bins: void 0,
		edges: [],
		stops: void 0,
		ramp: void 0
	};
	const values = series === void 0 ? [] : series.readings.flatMap((reading) => reading.kind === "reading" ? [reading.value] : []);
	return {
		key,
		color,
		base: seriesPaint(key, `${scale}-4`),
		bins: series === void 0 ? void 0 : colorBins(scale, values),
		edges: binEdges(scale, values),
		stops: void 0,
		ramp: SCALE_STEPS.map((step) => seriesPaint(key, `${scale}-${String(step)}`))
	};
}
/** What tells two colours' paints apart: a threshold's number and roles, never its labels. */
function paintId(color) {
	if (isRoleList(color)) return color.join(",");
	if (isThresholdColor(color)) return `threshold:${String(color.threshold)}:${color.below.color}:${color.above.color}`;
	return color;
}
/**
* A series' paint, every stop with the consumer's `--chart-color-<key>` first. It is built once per
* series model, key and colour, so a pointer step that reads it only looks up the active value.
*
* @param key - The series key.
* @param color - The series colour.
* @param series - The series, whose readings a scale bins.
* @returns The paint.
*/
function seriesPaintOf(key, color, series) {
	if (series === void 0) return buildPaint(key, color, series);
	const id = `${key}\u0000${paintId(color)}`;
	const known = paints.get(series) ?? /* @__PURE__ */ new Map();
	paints.set(series, known);
	const paint = known.get(id) ?? buildPaint(key, color, series);
	known.set(id, paint);
	return paint;
}
/**
* One value's paint: its scale step, or its threshold side. Undefined when the series paint covers
* it, which is every value of a role or a role list.
*
* @param paint - The series paint.
* @param value - The value.
* @returns A CSS colour with the consumer override first.
*/
function valuePaint(paint, value) {
	return paint.bins === void 0 ? void 0 : paint.ramp?.[paint.bins(value) - 1];
}
/**
* One reading's paint: its value's step under a scale or a threshold. Undefined for a slot with no
* reading and for every reading of a role or a role list, which take the series paint.
*
* @param paint - The series paint.
* @param reading - The slot's reading, if any.
* @returns A CSS colour with the consumer override first.
*/
function readingPaint(paint, reading) {
	return reading?.kind === "reading" ? valuePaint(paint, reading.value) : void 0;
}
/**
* The CSS paint of a swatch, the marks' own stops: a role paints itself, a role list its roles as a
* gradient, a scale its 7-step ramp and a threshold its two sides split in half, lower side first.
* A step the active value picks paints alone.
*
* @param paint - The series' paint.
* @param step - The step the active reading picks, or undefined.
* @returns The CSS paint.
*/
function swatchPaint(paint, step) {
	if (step !== void 0) return step;
	const { stops, ramp } = paint;
	if (stops !== void 0) return `linear-gradient(to right, ${stops.join(", ")})`;
	if (ramp === void 0) return paint.base;
	if (!isThresholdColor(paint.color)) return `linear-gradient(to right, ${ramp.join(", ")})`;
	const [below = paint.base, above = paint.base] = ramp;
	return `linear-gradient(to right, ${below} 50%, ${above} 50%)`;
}
export { colourFamilyError, nonFiniteThresholds, readingPaint, seriesPaintOf, stackedScaleError, swatchPaint, valuePaint };

//# sourceMappingURL=chart-paint.js.map