"use client";
import { jsx } from "react/jsx-runtime";
// src/components/chart/clock-chart-placed-label.tsx
/**
* A label placed past the rim, its place written as the stylesheet's custom properties. It is
* drawing, hidden from readers, so a part that speaks says so in text of its own.
*/
function PlacedLabel({ place, dataSlot, min, hidden, children }) {
	return /* @__PURE__ */ jsx("span", {
		"data-slot": dataSlot,
		"aria-hidden": "true",
		"data-part": dataSlot === void 0 ? "label" : void 0,
		"data-min": min,
		"data-hidden": hidden === true ? "" : void 0,
		style: {
			"--_x": place.x,
			"--_y": place.y,
			"--_align-x": place.alignX,
			"--_align-y": place.alignY
		},
		children
	});
}
Object.assign(PlacedLabel, { displayName: "ClockChart.PlacedLabel" });
export { PlacedLabel };

//# sourceMappingURL=clock-chart-placed-label.js.map