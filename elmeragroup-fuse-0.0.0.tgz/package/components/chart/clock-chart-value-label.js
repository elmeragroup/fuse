"use client";
import { useLocale } from "../../intl/locale-context.js";
import { formatValue } from "./format/value-format.js";
import { ChartCompositionError } from "./layout/errors.js";
import { writeAttribute } from "./chart-dom.js";
import { ClockMarkerContext } from "./chart-marker-context.js";
import { clockDrawingIn, usePolarContext } from "./chart-polar-context.js";
import { slotVertex } from "./layout/clock-path.js";
import { angleLabel } from "./layout/polar-labels.js";
import { use } from "react";
import { jsx } from "react/jsx-runtime";
// src/components/chart/clock-chart-value-label.tsx
/**
* The clock's ValueLabel: the value of each slot its Marker marks, as a pill past the dot.
*/
/**
* The value of each slot its Marker marks, as a pill past the dot at rest, reading away from the
* centre. The pills hide while their Marker's dots enter or tween to new data, and show once the
* dots rest. Outside a Marker it throws `part-outside-root`.
*
* @beta
*/
function ClockChartValueLabel({ format, className, style }) {
	const marker = use(ClockMarkerContext);
	const polar = usePolarContext("ClockChart.ValueLabel", ["clock"]);
	const { locale } = useLocale();
	if (marker === null) throw new ChartCompositionError("ClockChart.ValueLabel", "part-outside-root", "must be used within ClockChart.Marker. Put it inside the Marker whose values it prints.");
	const clock = clockDrawingIn(polar.model, "ClockChart.ValueLabel");
	const { box } = polar;
	const { series, slots, labels } = marker;
	const valueFormat = format ?? clock.text.config[series.key]?.format ?? {};
	return /* @__PURE__ */ jsx("div", {
		ref: (node) => {
			if (node === null) return void 0;
			labels.nodes.add(node);
			writeAttribute(node, "data-moving", labels.moving ? "" : null);
			return () => {
				labels.nodes.delete(node);
				node.removeAttribute("data-moving");
			};
		},
		"data-slot": "clock-chart-value-labels",
		"data-polar-layer": "",
		"aria-hidden": "true",
		className,
		style,
		children: slots.flatMap((slot) => {
			const value = series.values[slot];
			if (value === null || value === void 0) return [];
			const vertex = slotVertex(series.rest, slot);
			const { point, alignX, alignY } = angleLabel(vertex.angle, vertex.radius + .08);
			const left = (point.x - box.left) / (box.right - box.left) * 100;
			const top = (point.y - box.top) / (box.bottom - box.top) * 100;
			return [/* @__PURE__ */ jsx("span", {
				"data-slot": "clock-chart-value-label",
				style: {
					"--_x": `${left.toFixed(3)}%`,
					"--_y": `${top.toFixed(3)}%`,
					"--_align-x": `${String(-alignX * 100)}%`,
					"--_align-y": `${String(-alignY * 100)}%`
				},
				children: formatValue(locale, value, valueFormat, "full").text
			}, slot)];
		})
	});
}
Object.assign(ClockChartValueLabel, { displayName: "ClockChart.ValueLabel" });
export { ClockChartValueLabel };

//# sourceMappingURL=clock-chart-value-label.js.map