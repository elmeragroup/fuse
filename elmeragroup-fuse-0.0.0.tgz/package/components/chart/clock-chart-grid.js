"use client";
import { clockDrawingIn, usePolarContext } from "./chart-polar-context.js";
import { viewBoxOf } from "./layout/polar-angle.js";
import { ringPath } from "./layout/clock-path.js";
import { spokePath } from "./clock-chart-dial.js";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/clock-chart-grid.tsx
/**
* The rings at the value ticks, the spokes at the cycle's labels, and a solid zero ring when the
* domain spans 0. Every stroke keeps 1 px at any dial size.
*
* @beta
*/
function ClockChartGrid({ variant = "solid", className, style }) {
	const { model, box } = usePolarContext("ClockChart.Grid", ["clock"]);
	const clock = clockDrawingIn(model, "ClockChart.Grid");
	const rings = clock.ticks.flatMap((tick) => {
		const radius = clock.radius(tick);
		return radius > clock.inner + 1e-9 && radius <= 1 + 1e-9 ? [{
			tick,
			radius
		}] : [];
	});
	return /* @__PURE__ */ jsxs("svg", {
		"data-slot": "clock-chart-grid",
		"data-variant": variant,
		"data-polar-layer": "",
		"aria-hidden": "true",
		focusable: "false",
		viewBox: viewBoxOf(box),
		className,
		style,
		children: [
			/* @__PURE__ */ jsx("path", {
				"data-slot": "clock-chart-grid-ring",
				"data-part": "hole",
				d: ringPath(clock.inner)
			}),
			rings.map(({ tick, radius }) => /* @__PURE__ */ jsx("path", {
				"data-slot": "clock-chart-grid-ring",
				"data-zero": clock.zero !== null && tick === 0 ? "" : void 0,
				d: ringPath(radius)
			}, tick)),
			clock.labels.map((label) => /* @__PURE__ */ jsx("path", {
				"data-slot": "clock-chart-spoke",
				d: spokePath(label.angle, clock.inner, 1)
			}, label.start))
		]
	});
}
Object.assign(ClockChartGrid, { displayName: "ClockChart.Grid" });
export { ClockChartGrid };

//# sourceMappingURL=clock-chart-grid.js.map