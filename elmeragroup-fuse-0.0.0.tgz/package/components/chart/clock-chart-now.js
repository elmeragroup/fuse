"use client";
import { pathNumber } from "./layout/rounding.js";
import { clockDrawingIn, usePolarContext } from "./chart-polar-context.js";
import { labelWidth } from "./layout/label-width.js";
import { useLabelWidths } from "./chart-label-widths.js";
import { polarPoint, viewBoxOf } from "./layout/polar-angle.js";
import { rayPlace, spokePath } from "./clock-chart-dial.js";
import { PlacedLabel } from "./clock-chart-placed-label.js";
import { fitHandLabel } from "./layout/ring-labels.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/clock-chart-now.tsx
/**
* A hand at Root's `now`, to the minute, with a ping at its tip and an optional label on the hand
* just inside the rim. The label shows only at the widths from which it keeps clear of the hole and
* its centre text, and otherwise the hand and its dot mark Now alone, as the centre names the slot.
* It draws nothing when `now` lies outside the cycle.
*
* @beta
*/
function ClockChartNow({ label, tone = "default", className, style }) {
	const { model, box } = usePolarContext("ClockChart.Now", ["clock"]);
	const measured = useLabelWidths("box");
	const clock = clockDrawingIn(model, "ClockChart.Now");
	const now = clock.now;
	const tip = now === null ? null : polarPoint(now.angle, 1);
	const fit = now === null || label === void 0 ? "none" : fitHandLabel({
		angle: now.angle,
		width: labelWidth(label) + 8
	}, clock.inner);
	const shown = fit === "none" ? void 0 : fit;
	return /* @__PURE__ */ jsx("div", {
		ref: measured,
		"data-slot": "clock-chart-now",
		"data-tone": tone,
		"data-polar-layer": "",
		"aria-hidden": "true",
		className,
		style,
		children: now === null || tip === null ? null : /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsxs("svg", {
			viewBox: viewBoxOf(box),
			focusable: "false",
			children: [
				/* @__PURE__ */ jsx("path", {
					"data-slot": "clock-chart-now-path",
					"data-part": "hand",
					d: spokePath(now.angle, clock.inner, 1)
				}),
				/* @__PURE__ */ jsx("path", {
					"data-slot": "clock-chart-now-path",
					"data-part": "ping",
					d: `M${pathNumber(tip.x)},${pathNumber(tip.y)}h0`
				}),
				/* @__PURE__ */ jsx("path", {
					"data-slot": "clock-chart-now-path",
					"data-part": "dot",
					d: `M${pathNumber(tip.x)},${pathNumber(tip.y)}h0`
				})
			]
		}), label === void 0 ? null : /* @__PURE__ */ jsx(PlacedLabel, {
			place: rayPlace(box, now.angle, labelWidth(label), "inside"),
			min: shown,
			hidden: shown === void 0,
			children: label
		})] })
	});
}
Object.assign(ClockChartNow, { displayName: "ClockChart.Now" });
export { ClockChartNow };

//# sourceMappingURL=clock-chart-now.js.map