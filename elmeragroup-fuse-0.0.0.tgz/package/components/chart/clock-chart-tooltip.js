"use client";
import { clockDrawingIn, usePolarContext } from "./chart-polar-context.js";
import { ClockChartTooltipTotal } from "./clock-chart-tooltip-total.js";
import { DefaultPolarTooltip, PolarTooltip } from "./polar-chart-tooltip.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/clock-chart-tooltip.tsx
/** The default content: the slot's label and rows, then one total per stack of two or more series. */
function DefaultClockTooltip() {
	const { model } = usePolarContext("ClockChart.Tooltip", ["clock"]);
	const clock = clockDrawingIn(model, "ClockChart.Tooltip");
	return /* @__PURE__ */ jsxs(Fragment, { children: [/* @__PURE__ */ jsx(DefaultPolarTooltip, {}), clock.text.model.stacks.map(({ id }) => /* @__PURE__ */ jsx(ClockChartTooltipTotal, { stack: id }, id))] });
}
/**
* The popup over the active slot, with one row per series and, by default, one total per stack of
* two or more series. It rests in a side lane beside the dial at the height where the hand meets
* the rim, moving with the hand, and a step that leaps across the dial fades it in where the step
* lands, as a change of lane does. A side lane takes it only when the lane's room holds its
* content; otherwise it rests below the dial and its labels, or above the chart where below would
* leave the viewport. Like `Chart.Tooltip`'s, it may reach past the chart's box, below or above it,
* and stays inside the viewport, but it never covers its dial, its labels or its title. Escape
* closes it and keeps the reader's place. `anchor` does nothing here, since the lane decides where
* the popup rests.
*
* @beta
*/
function ClockChartTooltip({ children, ...props }) {
	return /* @__PURE__ */ jsx(PolarTooltip, {
		...props,
		children: children ?? /* @__PURE__ */ jsx(DefaultClockTooltip, {})
	});
}
Object.assign(ClockChartTooltip, { displayName: "ClockChart.Tooltip" });
export { ClockChartTooltip };

//# sourceMappingURL=clock-chart-tooltip.js.map