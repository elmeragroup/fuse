"use client";
import { ownBounds, ownSlot, ownSpan } from "./layout/coarse-slots.js";
import { slotTime } from "./layout/readings.js";
import { barSpan, snapAcross, snapBarSpan, snapX, tickWidth, valueAt } from "./layout/plot-frame.js";
import { barCells, barGeometry, geometryRect, introStep } from "./layout/bar-geometry.js";
import "./layout/motion.js";
import { valuePaint } from "./chart-paint.js";
import { fillId, fillKind } from "./chart-bar-fills.js";
import { placementOf } from "./chart-motion-mark.js";
// src/components/chart/chart-bar-draw.ts
/**
* Where one Bar's marks land and what they paint, as plain data: the bars of the element form, the
* paths of the path form, each bar's parts for its look, its paint server and the way it enters.
* The series modules render this data, and the animation loop redraws a bar's parts from each
* frame's rectangle.
*/
/**
* How a bar reaches its rectangle in a commit. Every commit that draws the bar in Root's waiting
* entrance places it at its base again, under the latest data, to grow from there once the
* entrance plays. Any other commit moves, snaps or settles the bar as the commit asks.
*
* @param bar - The bar.
* @param commit - What the commit asks of the bar.
* @returns The loop's placement.
*/
function barPlacement(bar, commit) {
	return bar.step === void 0 ? placementOf(commit) : {
		kind: "enter",
		from: bar.geometry.map((value, index) => index === 3 ? bar.geometry[2] : value),
		delay: bar.step * 16
	};
}
/**
* The anchor a bar places itself under, which a follower at the same series and slot joins.
*
* @param seriesIndex - The series' ordinal.
* @param slot - The bar's slot.
* @returns The anchor.
*/
function barAnchor(seriesIndex, slot) {
	return `${String(seriesIndex)} ${String(slot)}`;
}
/**
* What each of a bar's geometry numbers measures, for the loop: its span along the slot axis, its
* base and tip across the value axis, and its seam and top weight, sizes the box leaves alone.
*
* @param orientation - The frame's orientation.
* @returns The axes, in `BarGeometry`'s order.
*/
function barAxes(orientation) {
	const [along, across] = orientation === "vertical" ? ["x", "y"] : ["y", "x"];
	return [
		along,
		along,
		across,
		across,
		"size",
		"size"
	];
}
/** A bar's geometry and the rectangle it stands for at rest. */
function restingBar(frame, cell, metrics, sub) {
	const geometry = barGeometry(frame, cell, metrics, sub, "cut");
	return {
		geometry,
		rect: geometryRect(frame, geometry, cell.place)
	};
}
/** One fill on both sides of the base. */
function sameFill(fill) {
	return {
		positive: fill,
		negative: fill
	};
}
/** A greyed paint, a quarter of the way to the muted text role, for the bars emphasis leaves out. */
function greyed(paint) {
	return `color-mix(in oklab, ${paint} 75%, var(--muted-foreground))`;
}
/** The paint servers a series' bars reference, collected while the bars are laid out. */
var FillNeeds = class {
	prefix;
	needs = /* @__PURE__ */ new Map();
	constructor(prefix) {
		this.prefix = prefix;
	}
	/** The `url(#…)` of a kind's server for a paint, adding the server on first use. */
	use(kind, paint) {
		const paints = this.needs.get(kind) ?? /* @__PURE__ */ new Set();
		paints.add(paint);
		this.needs.set(kind, paints);
		return `url(#${fillId(this.prefix, kind, paint)})`;
	}
};
/**
* A role list's gradient for a bar of the default look, from its tip to its base. Both the element
* form and the path form define the two gradients, so the active overlay finds them in either.
*
* @param prefix - The series' id prefix.
* @param variant - The series' look.
* @param paint - The series' paint.
* @param negative - Whether the bar hangs below zero.
* @returns The `url(#…)`, or undefined when the series paints no role list.
*/
function listFill(prefix, variant, paint, negative) {
	if (paint.stops === void 0 || variant !== "default") return void 0;
	return `url(#${prefix}-list-${negative ? "negative" : "positive"})`;
}
/**
* The fills of the active overlay on either side of its base: hatched when the reading is
* projected, as the element form's servers draw it, and through the role list's gradient on the
* default look, whose direction the drawn overlay picks.
*
* @param prefix - The series' id prefix.
* @param form - The series' form, since only the element form defines the projected servers.
* @param variant - The series' look.
* @param paint - The series' paint.
* @param bar - The active reading's own paint, and whether it is projected.
* @returns The fills, each a `url(#…)`, or undefined for a plain fill.
*/
function overlayFills(prefix, form, variant, paint, bar) {
	if (bar.projected && form === "bars") return sameFill(`url(#${fillId(prefix, "projected", bar.own ?? paint.base)})`);
	return {
		positive: listFill(prefix, variant, paint, false),
		negative: listFill(prefix, variant, paint, true)
	};
}
/**
* The plot geometry the plot-anchored paint servers read.
*
* @param frame - The frame the series draws in.
* @returns The plot's size and orientation.
*/
function fillPlot(frame) {
	return {
		orientation: frame.orientation,
		width: frame.box.width,
		height: frame.box.height
	};
}
/**
* The centre of the missing tick on the zero line. The tick is `tickWidth` wide, whole device
* pixels, and the zero line's snapped pixel edge, where the bars' bases draw, lies inside it, half
* its pixels from its near edge, rounded down: on its centre wherever its pixels are even.
*
* @param frame - The frame the series draws in.
* @param zero - Where the zero line lies along the value axis, unsnapped, the frame's own by
*   default. A tween hands its frame's number, which snaps here, as a bar's base snaps.
* @returns The tick's centre along the value axis.
*/
function missingTickAt(frame, zero = valueAt(frame, 0)) {
	const { dpr } = frame.box;
	const width = tickWidth(frame.box);
	return snapAcross(frame, zero) - Math.floor(Math.round(width * dpr) / 2) / dpr + width / 2;
}
/**
* The endpoints of a missing tick: its span along the slot axis, the span a bar would take there,
* snapped through `snapBarSpan`, on the zero line drawn at a coordinate. A tween frame's numbers
* draw through here too.
*
* @param frame - The frame the series draws in.
* @param span - The tick's span along the slot axis.
* @param zero - Where the zero line draws along the value axis.
* @returns The line's endpoints.
*/
function tickEnds(frame, span, zero) {
	const [start, end] = snapBarSpan(frame, span[0], span[1]);
	const at = missingTickAt(frame, zero);
	return frame.orientation === "vertical" ? {
		x1: start,
		x2: end,
		y1: at,
		y2: at
	} : {
		x1: at,
		x2: at,
		y1: start,
		y2: end
	};
}
/**
* Lay out one series in the element form: a bar per reading and a tick per missing reading.
*
* @param input - The series, its frame and spacing, its look and paint.
* @returns The bars, the paint servers they need and the missing ticks.
*/
function layoutBars(input) {
	const { context, series, frame, metrics, sub, variant, paint, emphasised, prefix, entering } = input;
	const { model, update } = context;
	const { domain } = model;
	const window = model.window ?? {
		first: 0,
		last: -1
	};
	const count = window.last - window.first + 1;
	const fills = new FillNeeds(prefix);
	const listed = {
		positive: listFill(prefix, variant, paint, false),
		negative: listFill(prefix, variant, paint, true)
	};
	const bars = barCells(model, series).map((cell) => {
		const reading = series.readings[cell.slot];
		const value = reading?.kind === "reading" ? reading : void 0;
		const own = value === void 0 ? void 0 : valuePaint(paint, value.value);
		const emphasis = emphasised.has(cell.slot);
		const barPaint = emphasised.size > 0 && !emphasis ? greyed(own ?? paint.base) : own;
		const projected = cell.slot >= series.projectedFrom;
		if (projected) fills.use("projected", own ?? paint.base);
		const kind = fillKind(variant, projected);
		return {
			key: update.keys[cell.slot] ?? String(cell.slot),
			cell,
			...restingBar(frame, cell, metrics, sub),
			quality: value === void 0 || value.quality === "measured" ? void 0 : value.quality,
			time: domain.kind === "time" && context.now !== void 0 ? slotTime(...ownBounds(series, domain, cell.slot), context.now) : void 0,
			paint: barPaint,
			fills: kind === null ? listed : sameFill(fills.use(kind, barPaint ?? paint.base)),
			emphasis,
			projected,
			step: entering && context.intro !== "none" ? introStep(context.intro ?? "left", cell.position, count) : void 0
		};
	});
	const missing = [];
	for (let slot = window.first; slot <= window.last && !model.empty; slot = ownSlot(series, slot)[1] + 1) {
		if (series.readings[slot]?.kind !== "missing") continue;
		const [own] = ownSlot(series, slot);
		const { position, span } = ownSpan(series, window, slot);
		missing.push({
			key: update.keys[own] ?? String(own),
			span: barSpan(frame, position, metrics, sub, span)
		});
	}
	return {
		bars,
		needs: fills.needs,
		missing
	};
}
/**
* Where the past span of a path-form series ends: the end of the window's last own slot of the
* series that ended before Root's `now`, snapped, which `data-fade="past"` dims up to. A coarse
* series' slot is past only once its own interval ends, as the element form dates its bars.
*
* @param context - Root's model, `data-fade` and `now`.
* @param series - The series.
* @param frame - The frame the series draws in.
* @returns The end along the slot axis, or null when the chart does not dim the past.
*/
function pastSpanEnd(context, series, frame) {
	const { model } = context;
	const { domain } = model;
	const window = model.window ?? {
		first: 0,
		last: -1
	};
	if (context.fade !== "past" || context.now === void 0 || domain.kind !== "time") return null;
	let past = 0;
	for (let slot = window.first; slot <= window.last; slot += 1) if (slotTime(...ownBounds(series, domain, slot), context.now) === "past") past += 1;
	const step = frame.box.width / Math.max(window.last - window.first + 1, 1);
	return snapX(frame.box, past * step);
}
export { barAnchor, barAxes, barPlacement, fillPlot, layoutBars, listFill, missingTickAt, overlayFills, pastSpanEnd, tickEnds };

//# sourceMappingURL=chart-bar-draw.js.map