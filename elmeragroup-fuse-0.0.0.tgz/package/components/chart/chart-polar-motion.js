"use client";
import { sameItems } from "./layout/same-items.js";
import { SAME_PLOT } from "./chart-motion.js";
import { DEFAULT_PACE, cssTime, introDelay, introTiming } from "./layout/polar-motion.js";
import { useCallback, useId, useLayoutEffect, useMemo, useRef, useState } from "react";
// src/components/chart/chart-polar-motion.ts
/**
* How a polar mark moves on its Root's loop, the one module that places polar marks.
* The first draw plays the entrance: each item sweeps or grows from its start over `--chart-intro`,
* 1 s, after its family's stagger, and waits at that start until the chart comes into view. A data
* update moves every item that stays over `--chart-update`, 480 ms, grows an item that enters from
* its start, and collapses an item that leaves into a ghost: a path the writer draws in an empty
* `<g>` React never renders into, removed on its last frame. Reduced motion and print draw every
* mark at rest at once, through the loop's snap. The cartesian binder, `useMotionMark`, reads the
* cartesian layout, so a polar mark binds through `usePolarMark` and asks `usePolarCommit`.
*/
/**
* Register a polar mark with its Root's loop for as long as it is mounted. The loop draws into
* whichever node the mark renders now, in the latest look.
*
* @param motion - The Root's loop.
* @param write - Writes the loop's numbers onto the mark's node.
* @param look - What the writer reads beside the numbers, such as the dial's radii.
* @returns The ref and the placement function.
*/
function usePolarMark(motion, write, look) {
	const id = useId();
	const node = useRef(null);
	const latest = useRef({
		write,
		look
	});
	useLayoutEffect(() => {
		latest.current = {
			write,
			look
		};
	});
	useLayoutEffect(() => () => {
		motion.forget(id);
	}, [motion, id]);
	const ref = useCallback((element) => {
		node.current = element;
	}, []);
	const place = useCallback((target, placement) => {
		motion.place(id, target, (values) => {
			const shown = node.current;
			if (shown === null) return;
			latest.current.write(shown, latest.current.look, values);
		}, placement);
	}, [motion, id]);
	const shown = useCallback(() => node.current, []);
	const drawn = useCallback(() => motion.drawn(id), [motion, id]);
	return useMemo(() => ({
		ref,
		place,
		node: shown,
		drawn
	}), [
		ref,
		place,
		shown,
		drawn
	]);
}
/**
* Track the commits a polar mark draws, so its layout effect knows how to reach each one. The
* mark's first draw in the Root's first commit plays the entrance, or snaps without one. A mark
* that first draws in a data update enters: it grows from its start on the update's clock, as its
* key is new. A later data update moves it from what it drew, and any other commit lets a running
* tween finish. An update never replays the entrance. While the entrance still waits for the chart
* to come into view, every commit places the entrance again under its numbers, so the chart plays
* it with the latest data. Once the entrance has started it is spent: a mark that draws again from
* nothing, as every mark does when React Activity shows the chart again, or that mounts later with
* no new data, snaps to rest, as the cartesian marks do, so nothing grows a second time.
*
* @param polar - The mark's Root.
* @param anchor - The mark's node, which inherits the figure's pace. The marks place their entrance
*   before the Root's figure ref attaches, so the entrance reads its pace through the mark.
* @returns A function the mark's layout effect calls once per draw, with the mark's place in its
*   family's stagger, a slice, a ring or a series, where it starts when it enters: zero width at its
*   start angle, or radius 0, and for an update whose numbers change in length the route between
*   them, as a clock's slots pair across a change of slot count.
*/
function usePolarCommit(polar, anchor) {
	const last = useRef(null);
	const { update, entrance, kernel, model } = polar;
	const [born] = useState(() => ({
		update,
		hidden: kernel.hidden()
	}));
	useLayoutEffect(() => () => {
		last.current = null;
	}, []);
	return useCallback((index, from, via) => {
		const previous = last.current;
		last.current = update;
		const phase = kernel.store.get().phase;
		const waiting = entrance && phase === "waiting";
		if (previous === null && phase === "started") return update.kind === "data" && born.update === update && !born.hidden && !kernel.hidden() ? {
			kind: "enter",
			from,
			delay: 0
		} : { kind: "snap" };
		if (previous === null || waiting) {
			if (!entrance) return { kind: "snap" };
			const pace = introPace(kernel.root() ?? anchor(), update);
			return {
				kind: "enter",
				from,
				delay: introDelay(model.family, index, pace),
				...introTiming(model.family, pace)
			};
		}
		if (previous === update) return {
			kind: "settle",
			scale: SAME_PLOT
		};
		return via === void 0 ? { kind: "move" } : {
			kind: "move",
			via
		};
	}, [
		update,
		entrance,
		kernel,
		model,
		anchor,
		born
	]);
}
/** Each commit's pace, read once from the figure for every mark the commit places. */
const paces = /* @__PURE__ */ new WeakMap();
/**
* The entrance's pace as the figure's style sets it: `--chart-intro` and `--chart-stagger`, so a
* consumer's override changes the entrance. A commit reads it once, from the first element that
* reaches it, and an entrance placed with no element yet takes the stylesheet's pace unread.
*
* @param figure - The Root's figure, or any element inside it, whose custom properties it inherits.
* @param update - The commit, which keys the reading.
* @returns The pace.
*/
function introPace(figure, update) {
	const known = paces.get(update);
	if (known !== void 0) return known;
	if (figure === null) return DEFAULT_PACE;
	const style = getComputedStyle(figure);
	const pace = {
		intro: cssTime(style.getPropertyValue("--chart-intro")) ?? DEFAULT_PACE.intro,
		stagger: cssTime(style.getPropertyValue("--chart-stagger")) ?? DEFAULT_PACE.stagger
	};
	paces.set(update, pace);
	return pace;
}
/**
* Collapse a leaving item into a ghost: a path in `layer` that tweens from what the item drew
* to its collapsed numbers on the update's clock, then leaves the DOM. A second update while it
* collapses starts from where it shows, as every tween does.
*
* @param motion - The Root's loop.
* @param layer - An empty `<g>` the mark renders, which React never renders children into.
* @param id - The ghost's loop id, unique for the leaving key.
* @param from - What the item drew last.
* @param to - Its collapsed numbers, such as zero width at its end angle.
* @param write - Draws the numbers onto the ghost's path.
* @param attributes - The ghost path's own attributes, such as its slot and fill.
*/
function placeExit(motion, layer, id, from, to, write, attributes = {}) {
	const path = layer.ownerDocument.createElementNS("http://www.w3.org/2000/svg", "path");
	for (const [name, value] of Object.entries(attributes)) path.setAttribute(name, value);
	path.setAttribute("data-ghost", "");
	layer.append(path);
	const draw = (values) => {
		write(path, values);
		if (sameItems(values, to)) {
			path.remove();
			queueMicrotask(() => {
				motion.forget(id);
			});
		}
	};
	motion.place(id, from, draw, { kind: "snap" });
	motion.place(id, to, draw, { kind: "move" });
}
export { introPace, placeExit, usePolarCommit, usePolarMark };

//# sourceMappingURL=chart-polar-motion.js.map