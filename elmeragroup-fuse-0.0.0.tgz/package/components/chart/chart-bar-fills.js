"use client";
import { escapeColorKey } from "./layout/color-key.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
// src/components/chart/chart-bar-fills.tsx
/**
* The paint server a bar fills from, or null for a plain fill.
*
* @param variant - The bar's look.
* @param projected - Whether the bar draws a projected reading, which is hatched in every look.
* @returns The server's kind.
*/
function fillKind(variant, projected) {
	if (projected) return "projected";
	switch (variant) {
		case "hatched":
		case "gradient":
		case "duotone":
		case "duotone-reverse": return variant;
		default: return null;
	}
}
/**
* One paint server's id. The paint escapes one to one into id characters, so a bar and the active
* overlay name the same server for the same paint.
*
* @param prefix - The series' id prefix.
* @param kind - The server's look.
* @param paint - The paint the server draws in.
* @returns The id.
*/
function fillId(prefix, kind, paint) {
	return `${prefix}-${kind}-${escapeColorKey(paint)}`;
}
/** A pale tint of a paint, as the tinted looks fill most of a bar. */
function tint(paint, share) {
	return `color-mix(in oklab, ${paint} ${String(share)}%, transparent)`;
}
/** The period of a hatch across its stripes, in CSS pixels. */
const HATCH = 5;
/**
* A 45° hatch of a solid line and a tint, as CSS draws `repeating-linear-gradient(45deg, …)`: a
* gradient that repeats every 5 px toward the top right, with hard stops, so the stripes run from
* top left to bottom right and step from pixel to pixel as the CSS gradient's do.
*/
function Hatch({ id, paint, line, shade }) {
	const reach = HATCH / Math.SQRT2;
	const split = line / HATCH;
	return /* @__PURE__ */ jsxs("linearGradient", {
		id,
		gradientUnits: "userSpaceOnUse",
		spreadMethod: "repeat",
		x1: "0",
		y1: "0",
		x2: reach,
		y2: -reach,
		children: [
			/* @__PURE__ */ jsx("stop", {
				offset: "0",
				style: { "--chart-stop": paint }
			}),
			/* @__PURE__ */ jsx("stop", {
				offset: split,
				style: { "--chart-stop": paint }
			}),
			/* @__PURE__ */ jsx("stop", {
				offset: split,
				style: { "--chart-stop": tint(paint, shade) }
			}),
			/* @__PURE__ */ jsx("stop", {
				offset: "1",
				style: { "--chart-stop": tint(paint, shade) }
			})
		]
	});
}
/** One server of one kind for one paint. */
function Fill({ id, kind, paint, plot }) {
	const vertical = plot.orientation === "vertical";
	switch (kind) {
		case "hatched": return /* @__PURE__ */ jsx(Hatch, {
			id,
			paint,
			line: 1.5,
			shade: 30
		});
		case "projected": return /* @__PURE__ */ jsx(Hatch, {
			id,
			paint,
			line: 1,
			shade: 20
		});
		case "gradient": return /* @__PURE__ */ jsxs("linearGradient", {
			id,
			gradientUnits: "userSpaceOnUse",
			x1: vertical ? 0 : plot.width,
			y1: "0",
			x2: "0",
			y2: vertical ? plot.height : 0,
			children: [/* @__PURE__ */ jsx("stop", {
				offset: "0.2",
				style: { "--chart-stop": paint }
			}), /* @__PURE__ */ jsx("stop", {
				offset: "0.9",
				style: {
					"--chart-stop": paint,
					"--chart-stop-opacity": 0
				}
			})]
		});
		case "duotone":
		case "duotone-reverse": {
			const [first, second] = kind === "duotone" ? [tint(paint, 40), paint] : [paint, tint(paint, 40)];
			return /* @__PURE__ */ jsxs("linearGradient", {
				id,
				x1: "0",
				y1: "0",
				x2: "1",
				y2: "0",
				children: [/* @__PURE__ */ jsx("stop", {
					offset: "0.5",
					style: { "--chart-stop": first }
				}), /* @__PURE__ */ jsx("stop", {
					offset: "0.5",
					style: { "--chart-stop": second }
				})]
			});
		}
	}
}
/**
* The paint servers of one series.
*
* @param props - The id prefix, each kind's distinct paints in index order, and the plot.
* @returns The servers, for a `defs` element.
*/
function BarFills({ prefix, needs, plot }) {
	return /* @__PURE__ */ jsx(Fragment, { children: [...needs].flatMap(([kind, paints]) => [...paints].map((paint) => /* @__PURE__ */ jsx(Fill, {
		id: fillId(prefix, kind, paint),
		kind,
		paint,
		plot
	}, fillId(prefix, kind, paint)))) });
}
/**
* The two role-list gradients of a series, from the bar's tip, the list's first role, to its base.
* A negative bar's tip is its far end below zero, so it takes the reversed one.
*
* @param props - The id prefix, the colour stops and the orientation.
* @returns The gradients, for a `defs` element.
*/
function ListFills({ prefix, stops, orientation }) {
	const vertical = orientation === "vertical";
	return /* @__PURE__ */ jsx(Fragment, { children: [["positive", vertical ? [
		0,
		0,
		0,
		1
	] : [
		1,
		0,
		0,
		0
	]], ["negative", vertical ? [
		0,
		1,
		0,
		0
	] : [
		0,
		0,
		1,
		0
	]]].map(([sign, [x1, y1, x2, y2]]) => /* @__PURE__ */ jsx("linearGradient", {
		id: `${prefix}-list-${sign}`,
		x1,
		y1,
		x2,
		y2,
		children: stops.map((stop, index) => /* @__PURE__ */ jsx("stop", {
			offset: stops.length === 1 ? 0 : index / (stops.length - 1),
			style: { "--chart-stop": stop }
		}, index))
	}, sign)) });
}
Object.assign(BarFills, { displayName: "Chart.Bar.Fills" });
Object.assign(ListFills, { displayName: "Chart.Bar.ListFills" });
export { BarFills, ListFills, fillId, fillKind };

//# sourceMappingURL=chart-bar-fills.js.map