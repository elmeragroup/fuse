"use client";
import { useChartRoot } from "./chart-context.js";
import { seriesTable } from "./chart-series-readout.js";
import { ChartTableBody } from "./chart-table-body.js";
import { ChartTableColumn } from "./chart-table-column.js";
import { useMemo } from "react";
import { jsx } from "react/jsx-runtime";
// src/components/chart/chart-table.tsx
/**
* A "Vis som tabell" button and the chart's data as a table, which stays in the accessibility tree
* while it is visually collapsed. The table lists every slot of the full data, pages past 500 rows
* by calendar period, and carries one column per series and per multi-series stack total. Its
* `TableColumn` children render once in the header row and once in each body row.
*
* @beta
*/
function ChartTable(props) {
	const context = useChartRoot("Chart.Table");
	const table = useMemo(() => seriesTable(context, context.update.keys), [context]);
	return /* @__PURE__ */ jsx(ChartTableBody, {
		table,
		...props
	});
}
Object.assign(ChartTable, { displayName: "Chart.Table" });
export { ChartTable, ChartTableColumn };

//# sourceMappingURL=chart-table.js.map