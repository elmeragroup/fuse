"use client";
import { useActiveIndex } from "./chart-active-point.js";
import { useChartRoot } from "./chart-context.js";
import { TooltipTotalRow } from "./chart-tooltip-total-row.js";
import { jsx } from "react/jsx-runtime";
// src/components/chart/chart-tooltip-total.tsx
/**
* A tooltip row with one stack's net total at the active slot, followed by the incomplete word when
* a part is missing. Cartesian and clock config take `stack`, so `Chart` and `ClockChart` have this
* part. A `stack` that names no stack of two or more series throws `unknown-key`.
*
* @beta
*/
function ChartTooltipTotal(props) {
	const context = useChartRoot("Chart.TooltipTotal");
	const slot = useActiveIndex({
		store: context.store,
		window: context.model.window
	});
	return /* @__PURE__ */ jsx(TooltipTotalRow, {
		part: "Chart.TooltipTotal",
		context,
		at: slot,
		...props
	});
}
Object.assign(ChartTooltipTotal, { displayName: "Chart.TooltipTotal" });
export { ChartTooltipTotal };

//# sourceMappingURL=chart-tooltip-total.js.map