"use client";
import { useId } from "react";
// src/components/chart/chart-dom.ts
/**
* A prefix for the ids a part gives its clip paths, masks and paint servers. SVG references read
* the id inside `url()`, so the prefix keeps only characters an IRI fragment takes as they are.
*
* @param name - The part's own name, such as "chart-bar".
* @returns A prefix unique to the part's instance.
*/
function useSvgIdPrefix(name) {
	return `${name}-${useId().replace(/[^\w-]/gu, "")}`;
}
/**
* Set an attribute that changed, or remove it for null.
*
* @param node - The element.
* @param name - The attribute.
* @param value - The new value, or null to remove it.
*/
function writeAttribute(node, name, value) {
	if (value === null) {
		if (node.hasAttribute(name)) node.removeAttribute(name);
		return;
	}
	const text = String(value);
	if (node.getAttribute(name) !== text) node.setAttribute(name, text);
}
/**
* Set an inline style property that changed, or remove it for null.
*
* @param node - The element.
* @param name - The property, a custom property included.
* @param value - The new value, or null to remove it.
*/
function writeStyle(node, name, value) {
	if (value === null) {
		if (node.style.getPropertyValue(name) !== "") node.style.removeProperty(name);
		return;
	}
	if (node.style.getPropertyValue(name) !== value) node.style.setProperty(name, value);
}
/**
* Write a record of attributes through `writeAttribute`.
*
* @param node - The element, or null to write nothing.
* @param attributes - The values by attribute name.
*/
function writeAttributes(node, attributes) {
	if (node === null) return;
	for (const name in attributes) writeAttribute(node, name, attributes[name] ?? null);
}
/** Each mark node's latest commit, which every commit of its mark replaces. */
const commits = /* @__PURE__ */ new WeakMap();
/** The commit of a node no mark has committed, such as a test's bare element. */
const UNCOMMITTED = {};
/**
* Mark a commit of the mark that draws into `node`, so its writers find their parts again. React
* changes a mark's children only in a commit of the mark, as a variant that mounts a ring does.
* `useMotionMark` calls it before the mark places, in every commit that may change those children.
*
* @param node - The mark's node, or null before it mounts.
*/
function refreshParts(node) {
	if (node !== null) commits.set(node, {});
}
/**
* Find a writer's parts under a node once per commit of its mark. Every frame of a tween and every
* pointer step between two commits reads the parts found in the latest commit, with no query.
*
* @param find - Finds the parts under a node.
* @returns A function of the node that returns its parts.
*/
function partsCache(find) {
	const found = /* @__PURE__ */ new WeakMap();
	return (node) => {
		const commit = commits.get(node) ?? UNCOMMITTED;
		const cached = found.get(node);
		if (cached?.commit === commit) return cached.parts;
		const parts = find(node);
		found.set(node, {
			commit,
			parts
		});
		return parts;
	};
}
/**
* How many client pixels one layout pixel of an element spans, along x and y, so client boxes read
* under a transformed ancestor, such as a scaled portal, come back to the element's own pixels.
*
* @param element - The element.
* @returns The scale along each axis, 1 along an axis the element has no size on.
*/
function clientScale(element) {
	const box = element.getBoundingClientRect();
	return {
		x: element.offsetWidth === 0 ? 1 : box.width / element.offsetWidth,
		y: element.offsetHeight === 0 ? 1 : box.height / element.offsetHeight
	};
}
export { clientScale, partsCache, refreshParts, useSvgIdPrefix, writeAttribute, writeAttributes, writeStyle };

//# sourceMappingURL=chart-dom.js.map