"use client";
import { ownSpan, ownWindowFirsts } from "./layout/coarse-slots.js";
import "./layout/decimate.js";
import { barSpan, floorBody, frameRect, slotAxisAt, slotBandAt, snapBarSpan, snapSpan, valueAt } from "./layout/plot-frame.js";
import { apartEnds, bucketColumns, floorPlaces, isNegative, projectedEnds, rectsPath } from "./layout/bar-geometry.js";
import { slotId } from "./layout/slot-keys.js";
import { windowSlots } from "./layout/series-path.js";
import { readingPaint } from "./chart-paint.js";
import { missingTickAt } from "./chart-bar-draw.js";
// src/components/chart/chart-bar-columns.ts
/**
* The path form's columns as numbers the loop tweens, so a Bar above 100 slots moves on a data
* update as its element form does, through the modes of `layout/path-motion.ts`. Each slot of the
* window holds one entry, a column of no height where it has no reading, so a reading that appears
* grows out of the zero line. An entry holds its column's middle and tip first, where the marks
* attached to the series sit, then its span, its base, its missing tick's span and its emphasis
* box's span. Its paint step, quality, projection and emphasis are topology, which the topology holds.
* Above `DECIMATE_ABOVE` slots each M4 bucket is one entry, and each missing or emphasised slot one
* more, which draws its tick or its box and no column, so decimation never drops an annotation.
*/
/** The numbers of one column entry. */
const COLUMN_STRIDE = 9;
/** What each of an entry's numbers measures, on the vertical frame the path form draws in. */
const COLUMN_AXES = [
	"x",
	"y",
	"x",
	"x",
	"y",
	"x",
	"x",
	"x",
	"x"
];
/**
* Lay out a path-form series' entries.
*
* @param context - Root's model, and the key each slot renders under.
* @param series - The series.
* @param frame - The vertical frame it draws in.
* @param metrics - The bar spacing, which every column and its emphasis box read.
* @param sub - The Bar's sub-band.
* @param paint - The series' paint.
* @param emphasised - The emphasised slots.
* @returns The entries.
*/
function layoutColumns(context, series, frame, metrics, sub, paint, emphasised) {
	const { model, update } = context;
	const window = model.window;
	if (window === null) return {
		keys: [],
		positions: [],
		window: {
			keys: [],
			ids: []
		},
		values: [],
		topology: {
			count: 0,
			entries: []
		},
		fills: [],
		emphasis: []
	};
	const count = window.last - window.first + 1;
	const step = frame.box.width / Math.max(count, 1);
	const zero = valueAt(frame, 0);
	const { bins, ramp } = paint;
	const fills = bins === void 0 || ramp === void 0 ? [""] : ramp;
	/** A slot's column: its paint step and the path of its quality, or step -1 where it draws none. */
	const columnOf = (slot) => {
		const reading = series.readings[slot];
		const extent = series.extents[slot];
		if (extent === null || extent === void 0 || extent[0] === extent[1] || reading?.kind !== "reading") return {
			fill: -1,
			part: "fill"
		};
		return {
			fill: bins === void 0 ? 0 : bins(reading.value) - 1,
			part: reading.quality === "estimated" ? "estimated" : slot >= series.projectedFrom ? "projected" : "fill"
		};
	};
	const keyOf = (slot) => update.keys[slot] ?? slotId(model.domain, slot);
	const placeAt = floorPlaces(model, series);
	/** The entry of one own slot's column, its tick and its box, across every Root slot it covers. */
	const slotEntry = (slot) => {
		const { position, span } = ownSpan(series, window, slot);
		const [x0, x1] = barSpan(frame, position, metrics, sub, span);
		const tickAt = (share) => slotAxisAt(frame, (position + share * span) / frame.count);
		const reading = series.readings[slot];
		const extent = series.extents[slot];
		const negative = extent !== null && extent !== void 0 && extent[0] < 0 && extent[1] <= 0;
		const emphasis = emphasised.has(slot);
		const [base, tip] = reading?.kind === "reading" && extent !== null && extent !== void 0 ? projectedEnds(frame, extent, negative) : [zero, zero];
		return {
			key: keyOf(slot),
			at: position,
			numbers: [
				(x0 + x1) / 2,
				tip,
				x0,
				x1,
				base,
				tickAt(.25),
				tickAt(.75),
				x0,
				x1
			],
			entry: {
				...columnOf(slot),
				baseAt: 4,
				missing: reading?.kind === "missing" && !model.empty,
				emphasis,
				leaving: false,
				place: placeAt(slot)
			},
			paint: emphasis ? readingPaint(paint, reading) : void 0
		};
	};
	const slots = Array.from({ length: count }, (_, index) => window.first + index);
	const whole = windowSlots(model, update.keys);
	let entries;
	if (count <= 2e3) entries = ownWindowFirsts(series, window).map(slotEntry);
	else {
		const buckets = bucketColumns(model, series, frame.value.domain, sub).map((column) => {
			const toY = (percent) => percent / 100 * frame.box.height;
			const x0 = column.x0 * step;
			const x1 = column.x1 * step;
			const own = series.extents[column.slot];
			const side = own && isNegative(own) ? "negative" : "positive";
			const [top, bottom] = apartEnds(toY(column.top), toY(column.bottom), side);
			return {
				key: `bucket ${keyOf(column.first)} ${column.side}`,
				at: (column.x0 + column.x1) / 2 - .5,
				numbers: [
					(x0 + x1) / 2,
					top,
					x0,
					x1,
					bottom,
					x0,
					x0,
					x0,
					x0
				],
				entry: {
					...columnOf(column.slot),
					baseAt: side === "negative" ? 1 : 4,
					missing: false,
					emphasis: false,
					leaving: false,
					place: placeAt(column.slot)
				}
			};
		});
		const notes = slots.filter((slot) => series.readings[slot]?.kind === "missing" && !model.empty || emphasised.has(slot)).map((slot) => {
			const own = slotEntry(slot);
			const entry = {
				...own.entry,
				fill: -1,
				part: "fill"
			};
			return {
				...own,
				key: `note ${own.key}`,
				entry
			};
		});
		entries = [...buckets, ...notes].toSorted((a, b) => a.at - b.at);
	}
	return {
		keys: entries.map(({ key }) => key),
		positions: entries.map(({ at }) => at),
		window: whole,
		values: entries.flatMap(({ numbers }) => numbers),
		topology: {
			count: entries.length,
			entries: entries.map(({ entry }) => entry)
		},
		fills,
		emphasis: entries.flatMap(({ key, entry, paint: own }) => entry.emphasis ? [{
			key,
			paint: own
		}] : [])
	};
}
/**
* The topologies a path form draws from its entries' numbers, every edge on the device pixel grid. A
* column of one slot keeps its pixel among the pixels of the slot its middle lies in, as a bar does.
* Every slot's column, tick and emphasis box snaps through `snapBarSpan`, so a column at rest,
* which `barSpan` laid on the grid, draws as it is, and a tween frame's column draws whole device
* pixels no wider than its unsnapped span. A decimated window's buckets hold different counts of
* slots and tile the plot with no gap, so their columns share their edges.
*
* @param frame - The vertical frame.
* @param topology - The entries' topology.
* @param values - The entries' numbers, at rest or in a tween frame.
* @param placeOf - Whether an entry's column owns its stack side's pixel floor in this frame: the
*   stack floors' decision for a stacked series, and the entry's resting place by default.
* @param bodies - Each entry's column with no floor, where the caller snapped it for the stack
*   floors already, so the drawing floors it only where it owns the floor.
* @returns What each path and emphasis box draws.
*/
function columnsDrawing(frame, topology, values, placeOf = (entry) => entry.place, bodies) {
	const fillCount = Math.max(0, ...topology.entries.map((entry) => entry.fill + 1));
	const steps = () => Array.from({ length: fillCount }, () => []);
	const paths = {
		fill: steps(),
		estimated: steps(),
		projected: steps()
	};
	const emphasis = [];
	let missing = "";
	/** The band of the slot a coordinate along the slot axis lies in. */
	const bandAt = (along) => slotBandAt(frame, along, "band");
	topology.entries.forEach((entry, index) => {
		const at = (offset) => values[index * 9 + offset] ?? 0;
		const place = placeOf(entry, index);
		const ends = columnEnds(values, index, entry);
		const plain = bodies?.[index] ?? columnBody(frame, values, index, entry);
		const rect = place === "outer" ? floorBody(frame, plain, ends) : plain;
		if (entry.fill >= 0 && (!entry.leaving || rect.height > 0)) paths[entry.part][entry.fill]?.push(rect);
		if (entry.missing) {
			const [from, to] = snapBarSpan(frame, at(5), at(6), bandAt((at(5) + at(6)) / 2));
			missing += `M${String(from)} ${String(missingTickAt(frame, at(4)))}H${String(to)}`;
		}
		if (entry.emphasis) {
			const box = frameRect(frame, emphasisSpan(frame, values, index), ends);
			emphasis.push(place === "outer" ? floorBody(frame, box, ends) : box);
		}
	});
	return {
		fill: paths.fill.map((rects) => rectsPath(rects)),
		estimated: paths.estimated.map((rects) => rectsPath(rects)),
		projected: paths.projected.map((rects) => rectsPath(rects)),
		missing,
		emphasis
	};
}
/**
* One entry's column in a frame with no value-axis pixel floor, every edge on the device pixel
* grid, which `floorBody` floors where the column owns its stack side's floor. A column of one slot
* keeps its pixel among the pixels of the slot its middle lies in, as a bar does.
*
* @param frame - The vertical frame.
* @param values - The entries' numbers.
* @param index - The entry's index among them.
* @param entry - The entry.
* @returns The column's rectangle.
*/
function columnBody(frame, values, index, entry) {
	const at = (offset) => values[index * 9 + offset] ?? 0;
	const span = (frame.count > 2e3 ? snapSpan : snapBarSpan)(frame, at(2), at(3), slotBandAt(frame, at(0), "band"));
	return frameRect(frame, span, columnEnds(values, index, entry));
}
/**
* An entry's emphasis box span along the slot axis in a frame, snapped among the pixels of the slot
* its column's middle lies in.
*
* @param frame - The vertical frame.
* @param values - The entries' numbers.
* @param index - The entry's index among them.
* @returns The span's start and end.
*/
function emphasisSpan(frame, values, index) {
	const at = (offset) => values[index * 9 + offset] ?? 0;
	return snapBarSpan(frame, at(7), at(8), slotBandAt(frame, at(0), "band"));
}
/**
* An entry's column base and far end in a frame, as `baseAt` names them.
*
* @param values - The entries' numbers.
* @param index - The entry's index among them.
* @param entry - The entry.
* @returns The base and the far end, unsnapped.
*/
function columnEnds(values, index, entry) {
	const upper = values[index * 9 + 1] ?? 0;
	const lower = values[index * 9 + 4] ?? 0;
	return entry.baseAt === 4 ? [lower, upper] : [upper, lower];
}
/**
* The active overlay's bar geometry over one entry, from the entry's numbers in any frame: the
* emphasis box's span, which is the element form's bar span, then the column's base and tip, no
* seam and the overlay's top weight. A route's numbers move the span with the column as it slides.
*
* @param values - The entries' numbers, as a route or the rest lays them out.
* @param index - The entry's index among them.
* @param top - The overlay's top weight.
* @returns The geometry, in `BarGeometry`'s order.
*/
function columnOverlay(values, index, top) {
	const at = (offset) => values[index * 9 + offset] ?? 0;
	return [
		at(7),
		at(8),
		at(4),
		at(1),
		0,
		top
	];
}
/**
* The path kind of the path form: a slide moves an entry's middle and every span. A decimated
* window's tick or box that only one layout holds grows from or shrinks to the zero line in its own
* place, and a bucket's column only one holds starts or ends on the other layout's columns.
*
* @param step - The distance from one slot to the next along the slot axis.
* @param zero - Where the zero line lies across the value axis, unsnapped.
* @returns The kind.
*/
function columnKind(step, zero) {
	const along = /* @__PURE__ */ new Set([
		0,
		2,
		3,
		5,
		6,
		7,
		8
	]);
	return {
		stride: 9,
		at: (topology, index) => topology.entries[index] ?? {
			baseAt: 4,
			fill: -1,
			part: "fill",
			missing: false,
			emphasis: false,
			leaving: false,
			place: "outer"
		},
		of: (entries) => ({
			count: entries.length,
			entries
		}),
		keep: (old, next) => next.fill === -1 ? {
			...next,
			fill: old.fill,
			part: old.part,
			leaving: true
		} : next,
		shift: (vertex, by) => vertex.map((value, index) => along.has(index) ? value + by * step : value),
		flat: (vertex, entry) => entry.fill === -1 && (entry.missing || entry.emphasis) ? vertex.map((value, index) => index === 1 || index === 4 ? zero : value) : void 0
	};
}
export { COLUMN_AXES, COLUMN_STRIDE, columnBody, columnEnds, columnKind, columnOverlay, columnsDrawing, emphasisSpan, layoutColumns };

//# sourceMappingURL=chart-bar-columns.js.map