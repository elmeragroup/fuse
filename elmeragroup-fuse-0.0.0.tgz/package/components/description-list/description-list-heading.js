"use client";
import { cn } from "../../styles/cn.js";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
// src/components/description-list/description-list-heading.tsx
/**
* Plain semantic `<h2>` with the ref's level-2 type classes.
* Client only because polymorphism is `useRender`; the rest of the compound stays server.
*/
function DescriptionListHeading({ className, render, ...props }) {
	return useRender({
		defaultTagName: "h2",
		props: mergeProps({ className: cn("text-lg leading-snug font-medium font-heading text-inherit", className) }, props),
		render,
		state: { slot: "description-list-heading" }
	});
}
DescriptionListHeading.displayName = "DescriptionList.Heading";
export { DescriptionListHeading };

//# sourceMappingURL=description-list-heading.js.map