import { cn } from "../../styles/cn.js";
import { labelTypeClass } from "../../styles/label-type.js";
import { DescriptionListHeading } from "./description-list-heading.js";
import { jsx } from "react/jsx-runtime";
// src/components/description-list/description-list.tsx
/**
* Semantic `<dl>/<dt>/<dd>` composite. Every name-value group sits in an `Item`, the `<div>`
* HTML allows around one group, so a list never mixes Items and bare terms and details. A
* server compound: it owns no state, handlers or browser APIs. `Heading` is a client
* `useRender` island, so other outline levels stay possible without making this module a
* client boundary.
*/
function DescriptionListRoot(props) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "description-list",
		...props
	});
}
/**
* The responsive list: one column on phones, then a term column capped at min(50%, 20rem) that
* every Item shares through a subgrid, so the list sizes its columns to its widest term and widest
* details, as one grid would. Both lists start from one `minmax(0,1fr)` column, so an unbroken word
* can't widen the Items past the list on a phone.
*/
const responsiveContentClass = cn("text-base/6 sm:grid-cols-[min(50%,calc(var(--spacing)*80))_auto] sm:text-sm/6 grid grid-cols-1 [--description-list-details:initial] [--description-list-term:initial]");
/**
* The inline list: Items spaced by the small surface gap, the label type set here for the cells
* to inherit, and consecutive inline lists spaced by the large surface gap.
*/
const inlineContentClass = cn("grid grid-cols-1 gap-y-(--surface-gap-sm)", labelTypeClass, "[--description-list-details:currentColor] [--description-list-term:currentColor]", "[&+&]:mt-(--surface-gap-lg)");
function DescriptionListContent({ className, layout = "responsive", dividers = true, ...props }) {
	return /* @__PURE__ */ jsx("dl", {
		"data-slot": "description-list-content",
		"data-layout": layout,
		...dividers ? null : { "data-dividers": "false" },
		className: cn(layout === "inline" ? inlineContentClass : responsiveContentClass, className),
		...props
	});
}
function DescriptionListItem({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "description-list-item",
		className: cn("col-span-full grid grid-cols-subgrid border-t first-of-type:border-none [:where([data-dividers=false])>&]:border-none", "[:where([data-layout=inline])>&]:flex [:where([data-layout=inline])>&]:flex-wrap [:where([data-layout=inline])>&]:gap-x-(--surface-gap-md) [:where([data-layout=inline])>&]:border-none", className),
		...props
	});
}
function DescriptionListTerm({ className, ...props }) {
	return /* @__PURE__ */ jsx("dt", {
		"data-slot": "description-list-term",
		className: cn("col-start-1 py-(--row-py) pr-(--row-px) text-[color:var(--description-list-term,var(--muted-foreground))]", "[:where([data-layout=inline]>*)>&]:max-w-max [:where([data-layout=inline]>*)>&]:shrink-0 [:where([data-layout=inline]>*)>&]:grow [:where([data-layout=inline]>*)>&]:basis-[min-content] [:where([data-layout=inline]>*)>&]:p-0 [:where([data-layout=inline]>*)>&]:wrap-break-word [:where([data-layout=inline]>*)>&]:not-last-of-type:max-w-full [:where([data-layout=inline]>*)>&]:not-last-of-type:basis-full", className),
		...props
	});
}
function DescriptionListDetails({ className, ...props }) {
	return /* @__PURE__ */ jsx("dd", {
		"data-slot": "description-list-details",
		className: cn("sm:col-start-2 ms-0 py-(--row-py) text-[color:var(--description-list-details,var(--foreground))]", "[:where([data-layout=inline]>*)>&]:ms-auto [:where([data-layout=inline]>*)>&]:max-w-max [:where([data-layout=inline]>*)>&]:min-w-0 [:where([data-layout=inline]>*)>&]:grow [:where([data-layout=inline]>*)>&]:basis-[min-content] [:where([data-layout=inline]>*)>&]:py-0 [:where([data-layout=inline]>*)>&]:text-end [:where([data-layout=inline]>*)>&]:wrap-break-word [:where([data-layout=inline]>*)>&]:not-first-of-type:max-w-full [:where([data-layout=inline]>*)>&]:not-first-of-type:basis-full", className),
		...props
	});
}
DescriptionListRoot.displayName = "DescriptionList.Root";
DescriptionListContent.displayName = "DescriptionList.Content";
DescriptionListItem.displayName = "DescriptionList.Item";
DescriptionListTerm.displayName = "DescriptionList.Term";
DescriptionListDetails.displayName = "DescriptionList.Details";
const DescriptionList = {
	Root: DescriptionListRoot,
	Heading: DescriptionListHeading,
	Content: DescriptionListContent,
	Item: DescriptionListItem,
	Term: DescriptionListTerm,
	Details: DescriptionListDetails
};
export { DescriptionList };

//# sourceMappingURL=description-list.js.map