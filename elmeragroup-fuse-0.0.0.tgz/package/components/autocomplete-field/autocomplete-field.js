import { definedProps } from "../../internal/defined-props.js";
import { AutocompleteContent, AutocompleteInput, AutocompleteRoot, AutocompleteStatus } from "../autocomplete/autocomplete.js";
import { FieldFrame } from "../field/field-frame.js";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/autocomplete-field/autocomplete-field.tsx
/**
* Labeled autocomplete composite over Field and the `Autocomplete` parts: the label, the input
* with its suggestions, then the error and the description, laid out like `TextField`, with the
* label 4px from the input. The input fills the field's width, and its text is the value. The
* props the field does not name itself go to `Autocomplete.Root`, including `id`, which the label
* points at; a `ref` goes to the input. Use the `Autocomplete` namespace for a custom layout,
* such as a label row with an info button or a horizontal field.
*
* Server-renderable: it owns no state, and its parts are client modules.
*
* @template Items - The `items` array, flat or of groups.
* @template Filtered - The `filteredItems` array, flat or of groups.
* @template ItemValue - One item of `items`, which `itemToStringValue` receives. `items` decides
* it; without `items`, `filteredItems` does; when neither is given, an annotated callback such as
* `itemToStringValue` sets it.
*/
function AutocompleteField({ label, description, errorMessage, isInvalid = false, isRequired = false, isDisabled = false, name, placeholder, showTrigger = false, showClear = false, status, className, inputClassName, ref, children, ...props }) {
	return /* @__PURE__ */ jsx(FieldFrame, {
		className,
		name,
		invalid: isInvalid,
		disabled: isDisabled,
		label,
		description,
		errorMessage,
		children: /* @__PURE__ */ jsxs(AutocompleteRoot, {
			...definedProps(props),
			required: isRequired,
			disabled: isDisabled,
			children: [
				/* @__PURE__ */ jsx(AutocompleteInput, {
					ref,
					...definedProps({
						placeholder,
						className: inputClassName
					}),
					showTrigger,
					showClear
				}),
				/* @__PURE__ */ jsx(AutocompleteStatus, { children: status }),
				/* @__PURE__ */ jsx(AutocompleteContent, { children })
			]
		})
	});
}
AutocompleteField.displayName = "AutocompleteField";
export { AutocompleteField };

//# sourceMappingURL=autocomplete-field.js.map