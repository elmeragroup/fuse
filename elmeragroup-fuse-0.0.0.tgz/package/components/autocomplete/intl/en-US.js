// src/components/autocomplete/intl/en-US.ts
/** Default localized copy for autocomplete.empty / autocomplete.clear / autocomplete.toggle. */
const enUS = {
	empty: "No results.",
	clear: "Clear text",
	toggle: "Toggle suggestions"
};
export { enUS };

//# sourceMappingURL=en-US.js.map