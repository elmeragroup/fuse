// src/components/autocomplete/intl/fi-FI.ts
/** Default localized copy for autocomplete.empty / autocomplete.clear / autocomplete.toggle. */
const fiFI = {
	empty: "Ei tuloksia.",
	clear: "Tyhjennä teksti",
	toggle: "Näytä tai piilota ehdotukset"
};
export { fiFI };

//# sourceMappingURL=fi-FI.js.map