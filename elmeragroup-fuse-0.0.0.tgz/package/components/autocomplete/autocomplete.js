"use client";
import { CaretDown } from "../../icons/generated/caret-down.js";
import { cn } from "../../styles/cn.js";
import { useLocale } from "../../intl/locale-context.js";
import { useLocalizedStrings } from "../../hooks/use-localized-strings.js";
import { X } from "../../icons/generated/x.js";
import { mergeClassName } from "../../styles/merge-class-name.js";
import { definedProps } from "../../internal/defined-props.js";
import { overlayPositionerClass } from "../overlay/overlay-classes.js";
import { OverlayPortal } from "../overlay/overlay-portal.js";
import { InputGroupAddon, InputGroupButton, InputGroupPlainInput, InputGroupRoot } from "../input-group/input-group.js";
import { autocompleteVariants } from "./autocomplete-variants.js";
import { autocompleteStrings } from "./intl/index.js";
import { jsx, jsxs } from "react/jsx-runtime";
import { Autocomplete } from "@base-ui/react";
// src/components/autocomplete/autocomplete.tsx
const styles = autocompleteVariants();
/**
* The field's state, which renders no element. Its value is the text in the input, a string,
* whether the user typed it or picked a suggestion. `value`, `defaultValue` and `onValueChange`
* hold that text, and the form submits it under the enclosing `Field.Root`'s name, or under
* `name` outside one. A picked item fills the input with `itemToStringValue(item)`, or with its
* `label` when the item is a `{ value, label }` object. `onValueChange` receives only the
* string, so capture the picked item in `Autocomplete.Item`'s `onClick`.
*
* `items` is a flat array, or an array of groups that each carry their own `items`; with groups,
* `itemToStringValue` receives one item of a group. Base UI filters `items` against the text in
* the locale of `LocaleProvider`. For a search that runs elsewhere, such as on a server, pass
* `filter={null}` and the results as `items`: the list then shows them as given. Inside a
* `Field`, set `id` here rather than on the input, so the `Field.Label` points at it.
*
* @template Items - The `items` array, flat or of groups.
* @template Filtered - The `filteredItems` array, flat or of groups.
* @template ItemValue - One item of `items`, which `itemToStringValue` receives. `items` decides
* it; without `items`, `filteredItems` does; when neither is given, an annotated callback such as
* `itemToStringValue` or `onItemHighlighted` sets it.
*/
function AutocompleteRoot(props) {
	const { locale } = useLocale();
	const rootProps = props;
	return /* @__PURE__ */ jsx(Autocomplete.Root, {
		...rootProps,
		locale
	});
}
/** A button that opens and closes the popup, with a caret that turns while it is open. */
function AutocompleteTrigger({ className, children, ...props }) {
	return /* @__PURE__ */ jsxs(Autocomplete.Trigger, {
		"data-slot": "autocomplete-trigger",
		className: mergeClassName(className, styles.trigger()),
		...definedProps(props),
		children: [children, /* @__PURE__ */ jsx(CaretDown, { className: styles.caret() })]
	});
}
/** An icon button that empties the input. It shows only while the input holds text. */
function AutocompleteClear({ className, label, "aria-label": ariaLabel, ...props }) {
	const strings = useLocalizedStrings(autocompleteStrings);
	const accessibleName = ariaLabel ?? label ?? strings.format("clear");
	return /* @__PURE__ */ jsx(Autocomplete.Clear, {
		"data-slot": "autocomplete-clear",
		render: /* @__PURE__ */ jsx(InputGroupButton, {
			variant: "ghost",
			size: "icon-sm",
			"aria-label": accessibleName
		}),
		"aria-label": accessibleName,
		className: mergeClassName(className),
		...definedProps(props),
		children: /* @__PURE__ */ jsx(X, { className: "pointer-events-none" })
	});
}
/**
* The text field, an InputGroup around Base UI's Autocomplete input. The input carries the
* Root's `name`, so the form submits its text, and the popup takes the InputGroup's width.
*/
function AutocompleteInput({ className, children, disabled = false, showTrigger = false, showClear = false, clearLabel, triggerLabel, size = "default", ...props }) {
	const strings = useLocalizedStrings(autocompleteStrings);
	return /* @__PURE__ */ jsxs(Autocomplete.InputGroup, {
		render: /* @__PURE__ */ jsx(InputGroupRoot, {
			size,
			className: cn("w-auto", className)
		}),
		onMouseDown: (event) => {
			if (disabled) event.preventBaseUIHandler();
		},
		children: [
			/* @__PURE__ */ jsx(Autocomplete.Input, {
				disabled,
				render: /* @__PURE__ */ jsx(InputGroupPlainInput, {}),
				...definedProps(props)
			}),
			showTrigger || showClear ? /* @__PURE__ */ jsxs(InputGroupAddon, {
				align: "inline-end",
				children: [showTrigger ? /* @__PURE__ */ jsx(InputGroupButton, {
					size: "icon-sm",
					variant: "ghost",
					"aria-label": triggerLabel ?? strings.format("toggle"),
					"aria-labelledby": "",
					render: /* @__PURE__ */ jsx(AutocompleteTrigger, {}),
					"data-slot": "input-group-button",
					className: styles.inputTrigger(),
					disabled
				}) : null, showClear ? /* @__PURE__ */ jsx(AutocompleteClear, {
					disabled,
					label: clearLabel
				}) : null]
			}) : null,
			children
		]
	});
}
/** The popup of suggestions, as wide as the field box and portalled into the enclosing theme. */
function AutocompleteContent({ className, side = "bottom", sideOffset = 6, align = "start", alignOffset = 0, container, ...props }) {
	return /* @__PURE__ */ jsx(OverlayPortal, {
		portal: Autocomplete.Portal,
		container,
		children: /* @__PURE__ */ jsx(Autocomplete.Positioner, {
			side,
			sideOffset,
			align,
			alignOffset,
			className: overlayPositionerClass,
			children: /* @__PURE__ */ jsx(Autocomplete.Popup, {
				"data-slot": "autocomplete-content",
				className: mergeClassName(className, styles.content()),
				...props
			})
		})
	});
}
/**
* The scrolling list of suggestions. Like `Combobox.List`, it pads its rows inside the popup's
* corner and publishes `--inner-corner`.
*/
function AutocompleteList({ className, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete.List, {
		"data-slot": "autocomplete-list",
		className: mergeClassName(className, styles.list()),
		...props
	});
}
/**
* One suggestion. Picking it fills the input with its string value. Its `onClick` runs on a
* click, and on Enter while it is highlighted, so it can fill another field from the picked
* item.
*/
function AutocompleteItem({ className, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete.Item, {
		"data-slot": "autocomplete-item",
		className: mergeClassName(className, styles.item()),
		...props
	});
}
/** A group of suggestions. Pass the group's own `items` when the Root's items are grouped. */
function AutocompleteGroup({ className, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete.Group, {
		"data-slot": "autocomplete-group",
		className: mergeClassName(className),
		...props
	});
}
/** A group's visible name, which also names the group for assistive technology. */
function AutocompleteLabel({ className, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete.GroupLabel, {
		"data-slot": "autocomplete-label",
		className: mergeClassName(className, styles.label()),
		...props
	});
}
/** Renders the filtered items of the enclosing Root or Group through its child function. */
function AutocompleteCollection(props) {
	return /* @__PURE__ */ jsx(Autocomplete.Collection, { ...props });
}
/**
* The popup's message while the list is empty, the locale dictionary's by default. Pass the
* empty list's states as its children, such as loading, an error or no results. Base UI keeps it
* mounted as a polite live region and renders its children only while the list is empty. It
* needs `items` on `Autocomplete.Root`, since it reads the Root's filtered items. Place it beside
* `Autocomplete.List`, not inside it.
*/
function AutocompleteEmpty({ className, children, ...props }) {
	const strings = useLocalizedStrings(autocompleteStrings);
	return /* @__PURE__ */ jsx(Autocomplete.Empty, {
		"data-slot": "autocomplete-empty",
		className: mergeClassName(className, styles.empty()),
		...props,
		children: children ?? strings.format("empty")
	});
}
/**
* A visually hidden polite live region for the state of a search the app runs, such as
* "Searching…", an error or the number of results. Screen readers announce each change of its
* children while it stays mounted, so render the message as its children, and place it beside
* `Autocomplete.Input`, outside `Autocomplete.Content`, where it stays mounted while the popup
* opens and closes.
*/
function AutocompleteStatus({ className, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete.Status, {
		"data-slot": "autocomplete-status",
		className: mergeClassName(className, styles.status()),
		...props
	});
}
/** The hairline rule between groups of suggestions. */
function AutocompleteSeparator({ className, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete.Separator, {
		"data-slot": "autocomplete-separator",
		className: mergeClassName(className, styles.separator()),
		...props
	});
}
AutocompleteRoot.displayName = "Autocomplete.Root";
AutocompleteInput.displayName = "Autocomplete.Input";
AutocompleteTrigger.displayName = "Autocomplete.Trigger";
AutocompleteClear.displayName = "Autocomplete.Clear";
AutocompleteContent.displayName = "Autocomplete.Content";
AutocompleteList.displayName = "Autocomplete.List";
AutocompleteItem.displayName = "Autocomplete.Item";
AutocompleteGroup.displayName = "Autocomplete.Group";
AutocompleteLabel.displayName = "Autocomplete.Label";
AutocompleteCollection.displayName = "Autocomplete.Collection";
AutocompleteEmpty.displayName = "Autocomplete.Empty";
AutocompleteStatus.displayName = "Autocomplete.Status";
AutocompleteSeparator.displayName = "Autocomplete.Separator";
export { AutocompleteClear, AutocompleteCollection, AutocompleteContent, AutocompleteEmpty, AutocompleteGroup, AutocompleteInput, AutocompleteItem, AutocompleteLabel, AutocompleteList, AutocompleteRoot, AutocompleteSeparator, AutocompleteStatus, AutocompleteTrigger };

//# sourceMappingURL=autocomplete.js.map