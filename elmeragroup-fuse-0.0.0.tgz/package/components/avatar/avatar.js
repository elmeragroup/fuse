"use client";
import { cn } from "../../styles/cn.js";
import { mergeClassName } from "../../styles/merge-class-name.js";
import { avatarFallbackClass, avatarGroupClass, avatarImageClass, avatarRootClass } from "./avatar-class.js";
import { jsx } from "react/jsx-runtime";
import { Avatar } from "@base-ui/react/avatar";
// src/components/avatar/avatar.tsx
/**
* Client image-or-initials avatar. Base-ui Avatar owns image
* loading state.
*/
function AvatarRoot({ className, ...props }) {
	return /* @__PURE__ */ jsx(Avatar.Root, {
		"data-slot": "avatar",
		className: mergeClassName(className, avatarRootClass),
		...props
	});
}
/**
* Stacks its avatars and separates them with a background-coloured ring, so a group needs neither
* negative spacing nor a ring on every child.
*/
function AvatarGroup({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "avatar-group",
		className: cn(avatarGroupClass, className),
		...props
	});
}
function AvatarImage({ className, ...props }) {
	return /* @__PURE__ */ jsx(Avatar.Image, {
		"data-slot": "avatar-image",
		className: mergeClassName(className, avatarImageClass),
		...props
	});
}
function AvatarFallback({ className, ...props }) {
	return /* @__PURE__ */ jsx(Avatar.Fallback, {
		"data-slot": "avatar-fallback",
		className: mergeClassName(className, avatarFallbackClass),
		...props
	});
}
AvatarRoot.displayName = "Avatar.Root";
AvatarGroup.displayName = "Avatar.Group";
AvatarImage.displayName = "Avatar.Image";
AvatarFallback.displayName = "Avatar.Fallback";
export { AvatarFallback, AvatarGroup, AvatarImage, AvatarRoot };

//# sourceMappingURL=avatar.js.map