"use client";
import { cn } from "../../styles/cn.js";
import { mergeClassName } from "../../styles/merge-class-name.js";
import { Separator } from "../separator/separator.js";
import { buttonGroupVariants } from "./button-group-variants.js";
import { jsx } from "react/jsx-runtime";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
// src/components/button-group/button-group.tsx
/**
* Layout container that collapses inner radii and shared borders of `data-slot`
* children into one visual control. `orientation` defaults so
* `data-orientation` is always emitted. Filled Buttons (`default`, `secondary`) join
* with no visible seam because Button's fill paints under its transparent border, so put
* `ButtonGroup.Separator` between them; `outline` takes its seam from its own border.
*/
function ButtonGroupRoot({ className, orientation = "horizontal", ...props }) {
	return /* @__PURE__ */ jsx("div", {
		role: "group",
		"data-slot": "button-group",
		"data-orientation": orientation,
		className: cn(buttonGroupVariants({ orientation }), className),
		...props
	});
}
/**
* Hairline divider between segments. Forwards to the canonical library Separator so the
* group `[data-slot]` join contract stays intact. Default is
* `"vertical"` — a horizontal group needs a vertical hairline. It is the seam between
* filled segments (`default`, `secondary`), which otherwise join as one fill.
*/
function ButtonGroupSeparator({ className, orientation = "vertical", ...props }) {
	return /* @__PURE__ */ jsx(Separator, {
		"data-slot": "button-group-separator",
		orientation,
		className: mergeClassName(className, "relative self-stretch bg-input data-horizontal:w-auto data-vertical:h-auto"),
		...props
	});
}
/**
* Static label/affix segment styled to sit flush with buttons. Polymorphism is
* `render` via base-ui `useRender` + `mergeProps` — the convention exemplar
*/
function ButtonGroupText({ className, render, ...props }) {
	return useRender({
		defaultTagName: "div",
		props: mergeProps({ className: cn("text-sm font-medium shadow-xs flex items-center gap-2 rounded-md border bg-muted px-2.5 [&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4", className) }, props),
		render,
		state: { slot: "button-group-text" }
	});
}
ButtonGroupRoot.displayName = "ButtonGroup.Root";
ButtonGroupSeparator.displayName = "ButtonGroup.Separator";
ButtonGroupText.displayName = "ButtonGroup.Text";
export { ButtonGroupRoot, ButtonGroupSeparator, ButtonGroupText };

//# sourceMappingURL=button-group.js.map