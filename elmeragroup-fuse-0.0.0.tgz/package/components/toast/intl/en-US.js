// src/components/toast/intl/en-US.ts
/** Default localized copy for the `toast.*` rows. */
const enUS = { notifications: "Notifications" };
export { enUS };

//# sourceMappingURL=en-US.js.map