// src/components/toast/intl/fi-FI.ts
/** Default localized copy for the `toast.*` rows. */
const fiFI = { notifications: "Ilmoitukset" };
export { fiFI };

//# sourceMappingURL=fi-FI.js.map