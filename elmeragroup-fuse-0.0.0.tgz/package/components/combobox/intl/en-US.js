// src/components/combobox/intl/en-US.ts
/** Default localized copy for combobox.empty / combobox.clear / combobox.removeItem / combobox.toggle. */
const enUS = {
	empty: "No results.",
	clear: "Clear selection",
	toggle: "Toggle options",
	removeItem: (vars) => {
		const item = String(vars?.item ?? "").trim();
		return item === "" ? "Remove" : `Remove ${item}`;
	}
};
export { enUS };

//# sourceMappingURL=en-US.js.map