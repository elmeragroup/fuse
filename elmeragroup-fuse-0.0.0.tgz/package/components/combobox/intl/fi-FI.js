// src/components/combobox/intl/fi-FI.ts
/** Default localized copy for combobox.empty / combobox.clear / combobox.removeItem / combobox.toggle. */
const fiFI = {
	empty: "Ei tuloksia.",
	clear: "Tyhjennä valinta",
	toggle: "Näytä tai piilota vaihtoehdot",
	removeItem: (vars) => {
		const item = String(vars?.item ?? "").trim();
		return item === "" ? "Poista" : `Poista ${item}`;
	}
};
export { fiFI };

//# sourceMappingURL=fi-FI.js.map