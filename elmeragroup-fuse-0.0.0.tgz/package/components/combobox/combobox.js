"use client";
import { CaretDown } from "../../icons/generated/caret-down.js";
import { cn } from "../../styles/cn.js";
import { withinFocusRingControlClass } from "../../styles/utils.js";
import { withinStateFaceControlClass } from "../../styles/state-face.js";
import { useLocale } from "../../intl/locale-context.js";
import { useLocalizedStrings } from "../../hooks/use-localized-strings.js";
import { useMergedRefs } from "../../hooks/use-merged-refs.js";
import { X } from "../../icons/generated/x.js";
import { mergeClassName } from "../../styles/merge-class-name.js";
import { definedProps } from "../../internal/defined-props.js";
import { Button } from "../button/button.js";
import { overlayPositionerClass } from "../overlay/overlay-classes.js";
import { OverlayPortal } from "../overlay/overlay-portal.js";
import { pressesRegion } from "../../internal/own-click.js";
import { InputGroupAddon, InputGroupButton, InputGroupPlainInput, InputGroupRoot } from "../input-group/input-group.js";
import { chipRemoveShellClass } from "../../styles/inner-corner/listbox.js";
import { comboboxChipsVariants, comboboxVariants } from "./combobox-variants.js";
import { Check } from "../../icons/generated/check.js";
import { isTextValueNode } from "../../internal/is-text-node.js";
import { ChipIndexCommit, ChipIndexContext, createChipIndexRegistry, useChipIndex } from "./hooks/use-chip-index.js";
import { comboboxStrings } from "./intl/index.js";
import { createContext, useContext, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { Combobox } from "@base-ui/react";
// src/components/combobox/combobox.tsx
const comboboxSlots = comboboxVariants();
/** The chip slot, which no size changes. */
const chipsSlots = comboboxChipsVariants();
const ComboboxItemToStringLabelContext = createContext(void 0);
/**
* The combobox's state, which renders no element. Its value is the selected item, or an array of
* them with `multiple`.
*
* `items` is a flat array, or an array of groups that each carry their own `items`; with groups,
* the value and the callbacks take one item of a group.
*
* @template Items - The `items` array, flat or of groups.
* @template Filtered - The `filteredItems` array, flat or of groups.
* @template Value - One item of `items`, which is the selected value and what the callbacks
* receive. `items` decides it; without `items`, `filteredItems` does; when neither is given,
* `value`, `defaultValue` or an annotated callback sets it.
* @template Multiple - Whether the user can select more than one item, which `multiple` sets.
*/
function ComboboxRoot(props) {
	const { locale } = useLocale();
	const rootProps = props;
	const itemToStringLabel = rootProps.itemToStringLabel;
	return /* @__PURE__ */ jsx(ComboboxItemToStringLabelContext.Provider, {
		value: itemToStringLabel === void 0 ? void 0 : (itemValue) => {
			return itemToStringLabel(itemValue);
		},
		children: /* @__PURE__ */ jsx(Combobox.Root, {
			...rootProps,
			locale
		})
	});
}
function ComboboxValue({ ...props }) {
	return /* @__PURE__ */ jsx(Combobox.Value, {
		"data-slot": "combobox-value",
		...props
	});
}
function ComboboxTrigger({ className, children, ...props }) {
	return /* @__PURE__ */ jsxs(Combobox.Trigger, {
		"data-slot": "combobox-trigger",
		className: mergeClassName(className, comboboxSlots.trigger()),
		...definedProps(props),
		children: [children, /* @__PURE__ */ jsx(CaretDown, { className: comboboxSlots.caret() })]
	});
}
function ComboboxClear({ className, label, "aria-label": ariaLabel, ...props }) {
	const strings = useLocalizedStrings(comboboxStrings);
	const accessibleName = ariaLabel ?? label ?? strings.format("clear");
	return /* @__PURE__ */ jsx(Combobox.Clear, {
		"data-slot": "combobox-clear",
		render: /* @__PURE__ */ jsx(InputGroupButton, {
			variant: "ghost",
			size: "icon-sm",
			"aria-label": accessibleName
		}),
		"aria-label": accessibleName,
		className: mergeClassName(className),
		...definedProps(props),
		children: /* @__PURE__ */ jsx(X, { className: "pointer-events-none" })
	});
}
/**
* The text field, an InputGroup around Base UI's Combobox input with the caret and clear buttons
* in its trailing addon. The InputGroup is Base UI's `Combobox.InputGroup`, which the popup
* anchors to, so `Combobox.Content` takes the field box's width.
*/
function ComboboxInput({ className, children, disabled = false, showTrigger = true, showClear = false, clearLabel, triggerLabel, size = "default", ...props }) {
	const strings = useLocalizedStrings(comboboxStrings);
	return /* @__PURE__ */ jsxs(Combobox.InputGroup, {
		render: /* @__PURE__ */ jsx(InputGroupRoot, {
			size,
			className: cn("w-auto", className)
		}),
		onMouseDown: (event) => {
			if (disabled || !pressesRegion(event.target, event.currentTarget)) event.preventBaseUIHandler();
		},
		children: [
			/* @__PURE__ */ jsx(Combobox.Input, {
				disabled,
				render: /* @__PURE__ */ jsx(InputGroupPlainInput, {}),
				...definedProps(props)
			}),
			/* @__PURE__ */ jsxs(InputGroupAddon, {
				align: "inline-end",
				children: [showTrigger ? /* @__PURE__ */ jsx(InputGroupButton, {
					size: "icon-sm",
					variant: "ghost",
					"aria-label": triggerLabel ?? strings.format("toggle"),
					"aria-labelledby": "",
					render: /* @__PURE__ */ jsx(ComboboxTrigger, {}),
					"data-slot": "input-group-button",
					className: comboboxSlots.inputTrigger(),
					disabled
				}) : null, showClear ? /* @__PURE__ */ jsx(ComboboxClear, {
					disabled,
					label: clearLabel
				}) : null]
			}),
			children
		]
	});
}
function ComboboxContent({ className, side = "bottom", sideOffset = 6, align = "start", alignOffset = 0, anchor, container, ...props }) {
	return /* @__PURE__ */ jsx(OverlayPortal, {
		portal: Combobox.Portal,
		container,
		children: /* @__PURE__ */ jsx(Combobox.Positioner, {
			side,
			sideOffset,
			align,
			alignOffset,
			anchor,
			className: overlayPositionerClass,
			children: /* @__PURE__ */ jsx(Combobox.Popup, {
				"data-slot": "combobox-content",
				"data-external-anchor": anchor ? "true" : "false",
				className: mergeClassName(className, comboboxSlots.content()),
				...props
			})
		})
	});
}
/**
* The scrolling list of options. It is the part that publishes `--inner-corner`: it pads its
* rows inside the popup's corner, so a custom block placed in the List with `rounded-inner`
* rounds like the rows. A block directly in `Combobox.Content` rounds with `--radius`.
*/
function ComboboxList({ className, ...props }) {
	return /* @__PURE__ */ jsx(Combobox.List, {
		"data-slot": "combobox-list",
		className: mergeClassName(className, comboboxSlots.list()),
		...props
	});
}
function ComboboxItem({ className, children, ...props }) {
	return /* @__PURE__ */ jsxs(Combobox.Item, {
		"data-slot": "combobox-item",
		className: mergeClassName(className, comboboxSlots.item()),
		...props,
		children: [children, /* @__PURE__ */ jsx(Combobox.ItemIndicator, {
			render: /* @__PURE__ */ jsx("span", { className: comboboxSlots.itemIndicator() }),
			children: /* @__PURE__ */ jsx(Check, { className: "pointer-events-none" })
		})]
	});
}
function ComboboxGroup({ className, ...props }) {
	return /* @__PURE__ */ jsx(Combobox.Group, {
		"data-slot": "combobox-group",
		className: mergeClassName(className),
		...props
	});
}
function ComboboxLabel({ className, ...props }) {
	return /* @__PURE__ */ jsx(Combobox.GroupLabel, {
		"data-slot": "combobox-label",
		className: mergeClassName(className, comboboxSlots.label()),
		...props
	});
}
function ComboboxCollection({ ...props }) {
	return /* @__PURE__ */ jsx(Combobox.Collection, {
		"data-slot": "combobox-collection",
		...props
	});
}
function ComboboxEmpty({ className, children, ...props }) {
	const strings = useLocalizedStrings(comboboxStrings);
	return /* @__PURE__ */ jsx(Combobox.Empty, {
		"data-slot": "combobox-empty",
		className: mergeClassName(className, comboboxSlots.empty()),
		...props,
		children: children ?? strings.format("empty")
	});
}
function ComboboxSeparator({ className, ...props }) {
	return /* @__PURE__ */ jsx(Combobox.Separator, {
		"data-slot": "combobox-separator",
		className: mergeClassName(className, comboboxSlots.separator()),
		...props
	});
}
/**
* The chips field box. It publishes `--inner-corner`, the field corner less its border and padding,
* for the chips inside it.
*/
function ComboboxChips({ className, size = "default", ...props }) {
	const [registry] = useState(createChipIndexRegistry);
	return /* @__PURE__ */ jsxs(ChipIndexContext.Provider, {
		value: registry,
		children: [/* @__PURE__ */ jsx(Combobox.Value, { children: (selected) => /* @__PURE__ */ jsx(ChipIndexCommit, { selected }) }), /* @__PURE__ */ jsx(Combobox.Chips, {
			"data-slot": "combobox-chips",
			"data-size": size,
			className: mergeClassName(className, comboboxChipsVariants({ size }).chips()),
			...props
		})]
	});
}
function chipItemName(children) {
	if (!isTextValueNode(children)) return "";
	return children.toString().trim();
}
function chipValueAt(selected, index) {
	if (!Array.isArray(selected)) return selected;
	return selected[index] ?? null;
}
function stringifyChipValue(value, itemToStringLabel) {
	if (value == null || value === false || value === true) return "";
	if (itemToStringLabel !== void 0) return itemToStringLabel(value).trim();
	return chipItemName(value);
}
function ComboboxChip({ ref, className, children, showRemove = true, removeLabel, ...props }) {
	const { ref: indexRef, index } = useChipIndex();
	const mergedRef = useMergedRefs(ref, indexRef);
	return /* @__PURE__ */ jsxs(Combobox.Chip, {
		ref: mergedRef,
		"data-slot": "combobox-chip",
		className: mergeClassName(className, chipsSlots.chip()),
		...props,
		children: [children, showRemove ? /* @__PURE__ */ jsx(ComboboxChipRemoveLabel, {
			removeLabel,
			chipChildren: children,
			index
		}) : null]
	});
}
function ComboboxChipRemoveLabel({ removeLabel, chipChildren, index }) {
	const strings = useLocalizedStrings(comboboxStrings);
	const itemToStringLabel = useContext(ComboboxItemToStringLabelContext);
	return /* @__PURE__ */ jsx(Combobox.Value, { children: (selected) => {
		const item = chipItemName(chipChildren) || stringifyChipValue(chipValueAt(selected, index), itemToStringLabel);
		const accessibleName = removeLabel ?? strings.format("removeItem", { item });
		return /* @__PURE__ */ jsx(ComboboxChipRemove, { label: accessibleName });
	} });
}
function ComboboxChipRemove({ label }) {
	return /* @__PURE__ */ jsx(Combobox.ChipRemove, {
		"data-slot": "combobox-chip-remove",
		render: /* @__PURE__ */ jsx(Button, {
			variant: "ghost",
			size: "icon-inline",
			"aria-label": label,
			className: cn("text-xs border-0 opacity-50 enabled-hover:opacity-100", chipRemoveShellClass)
		}),
		"aria-label": label,
		children: /* @__PURE__ */ jsx(X, { className: "pointer-events-none size-3" })
	});
}
function ComboboxChipsInput({ className, ...props }) {
	return /* @__PURE__ */ jsx(Combobox.Input, {
		"data-slot": "combobox-chip-input",
		"data-focus-ring-control": "",
		className: mergeClassName(className, "min-w-16 flex-1 border-0 bg-transparent p-0 outline-none", "placeholder:text-muted-foreground", "entry-floor:[--entry-text:max(16px,1em)] text-[length:var(--entry-text,1em)] leading-[inherit]", withinFocusRingControlClass, withinStateFaceControlClass),
		...definedProps(props)
	});
}
/**
* Typed ref helper to anchor `Combobox.Content` to an external element
* (e.g. the `Combobox.Chips` container or an `InputGroup.Root`).
*/
function useComboboxAnchor() {
	return useRef(null);
}
ComboboxRoot.displayName = "Combobox.Root";
ComboboxInput.displayName = "Combobox.Input";
ComboboxTrigger.displayName = "Combobox.Trigger";
ComboboxClear.displayName = "Combobox.Clear";
ComboboxContent.displayName = "Combobox.Content";
ComboboxList.displayName = "Combobox.List";
ComboboxItem.displayName = "Combobox.Item";
ComboboxGroup.displayName = "Combobox.Group";
ComboboxLabel.displayName = "Combobox.Label";
ComboboxCollection.displayName = "Combobox.Collection";
ComboboxEmpty.displayName = "Combobox.Empty";
ComboboxSeparator.displayName = "Combobox.Separator";
ComboboxChips.displayName = "Combobox.Chips";
ComboboxChip.displayName = "Combobox.Chip";
ComboboxChipsInput.displayName = "Combobox.ChipsInput";
ComboboxValue.displayName = "Combobox.Value";
export { ComboboxChip, ComboboxChips, ComboboxChipsInput, ComboboxClear, ComboboxCollection, ComboboxContent, ComboboxEmpty, ComboboxGroup, ComboboxInput, ComboboxItem, ComboboxLabel, ComboboxList, ComboboxRoot, ComboboxSeparator, ComboboxTrigger, ComboboxValue, useComboboxAnchor };

//# sourceMappingURL=combobox.js.map