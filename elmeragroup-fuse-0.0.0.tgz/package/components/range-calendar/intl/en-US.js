// src/components/range-calendar/intl/en-US.ts
/**
* Default localized copy for the `rangeCalendar.*` rows: the description that names a range's
* ends, and the prompt the focused day describes itself with. The rows copy React Aria's
* `@react-aria/calendar` strings, so a screen reader hears the same words on the interim tier and
* on this one.
*/
const enUS = {
	selectedDateDescription: (vars) => `Selected Date: ${String(vars?.date)}`,
	selectedRangeDescription: (vars) => `Selected Range: ${String(vars?.dateRange)}`,
	dateRange: (vars) => `${String(vars?.startDate)} to ${String(vars?.endDate)}`,
	startRangeSelectionPrompt: "Click to start selecting date range",
	finishRangeSelectionPrompt: "Click to finish selecting date range"
};
export { enUS };

//# sourceMappingURL=en-US.js.map