// src/components/range-calendar/intl/fi-FI.ts
/**
* Default localized copy for the `rangeCalendar.*` rows, copied from React Aria's
* `@react-aria/calendar` strings.
*/
const fiFI = {
	selectedDateDescription: (vars) => `Valittu päivämäärä: ${String(vars?.date)}`,
	selectedRangeDescription: (vars) => `Valittu aikaväli: ${String(vars?.dateRange)}`,
	dateRange: (vars) => `${String(vars?.startDate)} \u2013 ${String(vars?.endDate)}`,
	startRangeSelectionPrompt: "Aloita päivämääräalueen valinta napsauttamalla tätä.",
	finishRangeSelectionPrompt: "Lopeta päivämääräalueen valinta napsauttamalla tätä."
};
export { fiFI };

//# sourceMappingURL=fi-FI.js.map