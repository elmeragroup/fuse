"use client";
import { createContext, use, useMemo } from "react";
// src/components/carousel/carousel-context.ts
/** The Root's context. `Carousel.Root` provides it. */
const CarouselContext = createContext(null);
/**
* The Root's last measurement: the slides in document order, their numbers, the pages and the
* slides in view. Every slide number, indicator name and inert slide reads it, so they always agree.
* `null` before the first measurement. Private to the parts.
*
* It is a context of its own, apart from {@link CarouselContext}, because it changes on every
* change to the slides in view, about twice per slide a scroll passes, while `state`, `actions`,
* `meta` and the wiring keep their identity. Only the parts that read it, Slide and Indicator,
* re-render then, not every part and every `useCarousel()` caller.
*/
const CarouselSnapshotContext = createContext(null);
/**
* The enclosing Root's last measurement, for a part that reads slide numbers or the slides in view.
*
* @returns The snapshot, or `null` before the first measurement or outside a Root.
*/
function useCarouselSnapshot() {
	return use(CarouselSnapshotContext);
}
/**
* The enclosing Root's context, for a part.
*
* @param part - The part's name, such as `Carousel.Next`, for the error message.
* @returns The context value.
* @throws When no `Carousel.Root` encloses the caller, which is a defect in the tree.
*/
function useCarouselContext(part) {
	const context = use(CarouselContext);
	if (context === null) throw new Error(`${part} must be used within Carousel.Root.`);
	return context;
}
/**
* The enclosing `Carousel.Root`'s state, actions and configuration, for a custom control such as
* a thumbnail strip or a page count of your own. The result keeps its identity until one of them
* changes.
*
* @returns The current page, the page count, whether each direction can move and whether the
*   pages rotate; the actions that change them; and the orientation.
* @throws When no `Carousel.Root` encloses the caller.
*/
function useCarousel() {
	const { state, actions, meta } = useCarouselContext("useCarousel");
	return useMemo(() => ({
		state,
		actions,
		meta
	}), [
		state,
		actions,
		meta
	]);
}
export { CarouselContext, CarouselSnapshotContext, useCarousel, useCarouselContext, useCarouselSnapshot };

//# sourceMappingURL=carousel-context.js.map