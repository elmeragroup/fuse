// src/components/carousel/intl/fi-FI.ts
/**
* Default localized copy for the `carousel.*` rows: the role descriptions, the automatic slide and
* indicator names, the controls' names and the visible status. Finnish writes a position in a set
* as `3/6`, which avoids inflecting the count.
*/
const fiFI = {
	carousel: "karuselli",
	slide: "dia",
	slideLabel: (vars) => `${String(vars?.position)}/${String(vars?.count)}`,
	previous: "Edellinen dia",
	next: "Seuraava dia",
	indicators: "Valitse näytettävä dia",
	indicator: (vars) => `Dia ${String(vars?.position)}/${String(vars?.count)}`,
	status: (vars) => `${String(vars?.position)}/${String(vars?.count)}`,
	startRotation: "Käynnistä automaattinen esitys",
	stopRotation: "Pysäytä automaattinen esitys"
};
export { fiFI };

//# sourceMappingURL=fi-FI.js.map