// src/components/carousel/intl/en-US.ts
/**
* Default localized copy for the `carousel.*` rows: the role descriptions, the automatic slide and
* indicator names, the controls' names and the visible status.
*/
const enUS = {
	carousel: "carousel",
	slide: "slide",
	slideLabel: (vars) => `${String(vars?.position)} of ${String(vars?.count)}`,
	previous: "Previous slide",
	next: "Next slide",
	indicators: "Choose slide to display",
	indicator: (vars) => `Slide ${String(vars?.position)} of ${String(vars?.count)}`,
	status: (vars) => `${String(vars?.position)} of ${String(vars?.count)}`,
	startRotation: "Start automatic slide show",
	stopRotation: "Stop automatic slide show"
};
export { enUS };

//# sourceMappingURL=en-US.js.map