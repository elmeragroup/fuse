"use client";
import { CaretDown } from "../../icons/generated/caret-down.js";
import { cn } from "../../styles/cn.js";
import { useLocalizedStrings } from "../../hooks/use-localized-strings.js";
import { definedProps } from "../../internal/defined-props.js";
import { Button } from "../button/button.js";
import { CaretRight } from "../../icons/generated/caret-right.js";
import { CaretLeft } from "../../icons/generated/caret-left.js";
import { useCarouselContext, useCarouselSnapshot } from "./carousel-context.js";
import { carouselVariants } from "./carousel-variants.js";
import { carouselStrings } from "./intl/index.js";
import { CaretUp } from "../../icons/generated/caret-up.js";
import { Pause } from "../../icons/generated/pause.js";
import { Play } from "../../icons/generated/play.js";
import { useLayoutEffect } from "react";
import { jsx } from "react/jsx-runtime";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
// src/components/carousel/carousel-controls.tsx
const styles = carouselVariants();
/**
* The two edges differ by their icons, their name and their step, so `Carousel.Previous` and
* `Carousel.Next` are one component parameterised by direction.
*/
const EDGES = {
	previous: {
		slot: "carousel-previous",
		step: -1,
		labelKey: "previous",
		horizontal: CaretLeft,
		vertical: CaretUp
	},
	next: {
		slot: "carousel-next",
		step: 1,
		labelKey: "next",
		horizontal: CaretRight,
		vertical: CaretDown
	}
};
/**
* The row the controls sit in: Previous, the indicators and Next, centred with the surface gap
* between them, and an `Autoplay` first when the pages rotate. It is layout only.
*/
function CarouselControls({ className, render, ...props }) {
	return useRender({
		defaultTagName: "div",
		render,
		props: {
			"data-slot": "carousel-controls",
			...mergeProps({ className: cn(styles.controls(), className) }, props)
		}
	});
}
function CarouselEdge({ direction, className, size = "icon-sm", "aria-label": ariaLabel, children, ...props }) {
	const edge = EDGES[direction];
	const { state, meta, wiring } = useCarouselContext(direction === "previous" ? "Carousel.Previous" : "Carousel.Next");
	const strings = useLocalizedStrings(carouselStrings);
	const Icon = edge[meta.orientation];
	const can = direction === "previous" ? state.canPrevious : state.canNext;
	return /* @__PURE__ */ jsx(Button, {
		"data-slot": edge.slot,
		...mergeProps({
			variant: "outline",
			disabled: !can,
			focusableWhenDisabled: true,
			onClick: () => wiring.navigate(state.index + edge.step, direction)
		}, definedProps(props)),
		size,
		"aria-label": ariaLabel ?? strings.format(edge.labelKey),
		className: cn(styles.edge(), className),
		children: children ?? /* @__PURE__ */ jsx(Icon, {
			"aria-hidden": "true",
			className: carouselVariants({ orientation: meta.orientation }).edgeIcon()
		})
	});
}
/** Scrolls to the previous page. It is disabled, and stays focusable, on the first page. */
function CarouselPrevious(props) {
	return /* @__PURE__ */ jsx(CarouselEdge, {
		direction: "previous",
		...props
	});
}
/** Scrolls to the next page. It is disabled, and stays focusable, on the last page. */
function CarouselNext(props) {
	return /* @__PURE__ */ jsx(CarouselEdge, {
		direction: "next",
		...props
	});
}
/**
* The slide picker: a `group` named "Choose slide to display" in the locale. With no children it
* renders one `Carousel.Indicator` per page, so the dots follow the layout. Map your own
* `Carousel.Indicator`s inside it for thumbnails.
*/
function CarouselIndicators({ className, render, children, ...props }) {
	const { state } = useCarouselContext("Carousel.Indicators");
	const strings = useLocalizedStrings(carouselStrings);
	return useRender({
		defaultTagName: "div",
		render,
		props: {
			"data-slot": "carousel-indicators",
			...mergeProps({
				role: "group",
				"aria-label": strings.format("indicators"),
				className: cn(styles.indicators(), className),
				children: children ?? Array.from({ length: state.pageCount }, (_, page) => /* @__PURE__ */ jsx(CarouselIndicator, { index: page }, page))
			}, definedProps(props))
		}
	});
}
/**
* One page's button in the slide picker. Without children it draws the design's mark, a dot that
* becomes a pill on the current page, inside a 24px target, and is named after the first slide on
* its page, such as "Slide 3 of 6". With children, such as a thumbnail, it draws only the focus
* ring around them, keeps a 24px target however small they are, and the children name it. Its
* `onClick` runs first, and `event.preventBaseUIHandler()` there keeps the page.
*
* The current page's indicator is `aria-disabled`, as APG's grouped carousel asks, so a screen
* reader hears that it would do nothing and it stays in the tab order. It also carries
* `data-current` for styling.
*/
function CarouselIndicator({ index, className, render, children, ...props }) {
	const { state, wiring } = useCarouselContext("Carousel.Indicator");
	const snapshot = useCarouselSnapshot();
	const strings = useLocalizedStrings(carouselStrings);
	const current = state.index === index;
	const slide = snapshot?.pages.leadingSlides[index] ?? index;
	const label = children === void 0 ? strings.format("indicator", {
		position: slide + 1,
		count: snapshot?.slides.length ?? 0
	}) : void 0;
	return useRender({
		defaultTagName: "button",
		render,
		props: {
			"data-slot": "carousel-indicator",
			...mergeProps({
				type: "button",
				...definedProps({
					"aria-label": label,
					"aria-disabled": current ? "true" : void 0,
					"data-current": current ? "" : void 0
				}),
				className: cn(children === void 0 ? styles.indicator() : styles.indicatorContent(), className),
				children,
				onClick: () => wiring.navigate(index, "indicator")
			}, definedProps(props))
		}
	});
}
/**
* The visible page count, such as "3 of 6" in the locale, for carousels with many pages or in
* place of the indicators. It announces a page change politely, and stays silent while the pages
* rotate. Before the viewport is measured it is empty. Children replace the text.
*/
function CarouselStatus({ className, render, children, ...props }) {
	const { state, wiring } = useCarouselContext("Carousel.Status");
	const strings = useLocalizedStrings(carouselStrings);
	const text = state.pageCount === 0 ? null : strings.format("status", {
		position: state.index + 1,
		count: state.pageCount
	});
	return useRender({
		defaultTagName: "div",
		render,
		props: {
			"data-slot": "carousel-status",
			...mergeProps({
				"aria-live": wiring.live,
				"aria-atomic": true,
				className: cn(styles.status(), className),
				children: children ?? text
			}, definedProps(props))
		}
	});
}
/**
* Automatic rotation, and the APG rotation control that starts and stops it. Mounting it is the
* opt-in, and `delay` has no default. The button's name says what pressing it does, "Stop
* automatic slide show" or "Start automatic slide show", so it carries no `aria-pressed`. Place
* it first in `Carousel.Controls` and put the controls before the Viewport in the source, so it
* precedes the rotating content in the tab order; `className="order-last"` on the controls still
* shows the row below the slides.
*
* Rotation starts on mount, unless the user prefers reduced motion. Keyboard focus on any element
* in the carousel, this button included, stops it, as the APG pattern asks, and so does any swipe,
* drag, wheel turn or press of another control; only this button starts it again. Once the user
* presses it to start rotation, keyboard focus and hover no longer stop or pause it, so it keeps
* running with focus on this button, until it is pressed again. Until then it pauses while a mouse
* or pen is over the carousel. It pauses while the document is hidden. A new `delay` keeps the
* user's choice to play or stop. It advances from the last page back to the first. Mounted with
* the Root or after it, it starts from what is already so: paused under a mouse or pen already
* over the carousel, even since before the page hydrated, and stopped with keyboard focus already
* inside it, as an `autoFocus` field in a slide takes. Keyboard focus inside a custom element's
* open shadow root counts as focus in the carousel. Focus that a mouse press moved in does not
* stop it.
*/
function CarouselAutoplay({ delay, startLabel, stopLabel, className, size = "icon-sm", ...props }) {
	const { state, actions, wiring } = useCarouselContext("Carousel.Autoplay");
	const strings = useLocalizedStrings(carouselStrings);
	const { mountAutoplay, setAutoplayDelay } = wiring;
	useLayoutEffect(() => mountAutoplay(), [mountAutoplay]);
	useLayoutEffect(() => setAutoplayDelay(delay), [setAutoplayDelay, delay]);
	return /* @__PURE__ */ jsx(Button, {
		"data-slot": "carousel-autoplay",
		...mergeProps({
			variant: "outline",
			onClick: state.rotating ? actions.stop : actions.play
		}, definedProps(props)),
		size,
		"aria-label": state.rotating ? stopLabel ?? strings.format("stopRotation") : startLabel ?? strings.format("startRotation"),
		className: cn(styles.edge(), className),
		children: state.rotating ? /* @__PURE__ */ jsx(Pause, { "aria-hidden": "true" }) : /* @__PURE__ */ jsx(Play, { "aria-hidden": "true" })
	});
}
CarouselControls.displayName = "Carousel.Controls";
CarouselPrevious.displayName = "Carousel.Previous";
CarouselNext.displayName = "Carousel.Next";
CarouselIndicators.displayName = "Carousel.Indicators";
CarouselIndicator.displayName = "Carousel.Indicator";
CarouselStatus.displayName = "Carousel.Status";
CarouselAutoplay.displayName = "Carousel.Autoplay";
export { CarouselAutoplay, CarouselControls, CarouselIndicator, CarouselIndicators, CarouselNext, CarouselPrevious, CarouselStatus };

//# sourceMappingURL=carousel-controls.js.map