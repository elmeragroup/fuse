import { documentOrder } from "../../internal/dom-node.js";
import { parseSnapAlign } from "./carousel-pages.js";
// src/components/carousel/carousel-measure.ts
/**
* The carousel engine's measurement: one read of a scroll-snap viewport and its slides, converted
* to the viewport's scroll coordinates. It reads the DOM, keeps nothing and reports only what it
* found; what to do with a reading, cache it, retry it or accept it, is the engine's
* (`carousel-engine.ts`).
*
* Every length is in the viewport's scroll coordinates, the space of `scrollLeft`, `clientWidth`
* and `scrollWidth`. A transform on an ancestor, such as `scale(0.5)`, scales the boxes
* `getBoundingClientRect` reports but not the scroll range, so a measurement divides each box by
* the viewport's painted size over its layout size, per axis. That keeps sub-pixel slide widths,
* which the integer `offsetLeft` and `offsetWidth` would round. A rotated or skewed ancestor is not
* supported: a box's bounds are then not a scaled copy of its layout.
*
* While a transform animates, a box is painted where the animation is when it is read, and WebKit
* samples a running animation afresh at each layout read in a task, so a slow read can find the
* viewport at one scale and the slides at another. A measurement therefore reads every style first
* and then every box back to back, between two reads of the viewport's box. When the viewport's
* box moved between them by enough to put a position off by `STEADY`, the reading is unsteady
* (`steady`). The painted boxes stay the one geometry throughout: they keep sub-pixel starts, and
* they include every border and transform between the viewport and a slide, and a transform on a
* slide itself, such as a hover scale, as the browser's snap areas do.
*/
/**
* The boxes a measurement read are one picture when an animating transform can have moved them by
* less than this, in scroll px, while it read them.
*/
const STEADY = .5;
/** A computed length in px, resolving a percentage against `basis` and `auto` to `0`. */
function lengthOf(value, basis) {
	const parsed = Number.parseFloat(value);
	if (Number.isNaN(parsed)) return 0;
	return value.trim().endsWith("%") ? parsed / 100 * basis : parsed;
}
function sidesOf(orientation, rtl) {
	if (orientation === "vertical") return {
		start: "top",
		end: "bottom"
	};
	return rtl ? {
		start: "right",
		end: "left"
	} : {
		start: "left",
		end: "right"
	};
}
function sideValue(style, property, side) {
	return style.getPropertyValue(`${property}-${side}`);
}
/**
* An element's border-box size as layout gives it, before any transform, from its computed
* style, which keeps fractions.
*/
function layoutSizeOf(style) {
	const width = Number.parseFloat(style.width) || 0;
	const height = Number.parseFloat(style.height) || 0;
	if (style.boxSizing === "border-box") return {
		width,
		height
	};
	const sum = (...values) => values.reduce((total, value) => total + (Number.parseFloat(value) || 0), 0);
	return {
		width: width + sum(style.paddingLeft, style.paddingRight, style.borderLeftWidth, style.borderRightWidth),
		height: height + sum(style.paddingTop, style.paddingBottom, style.borderTopWidth, style.borderBottomWidth)
	};
}
/** The scroll position on the axis in a direction, positive from the start in either. */
function scrollPositionOf(viewport, orientation, rtl) {
	if (orientation === "vertical") return viewport.scrollTop;
	return rtl ? -viewport.scrollLeft : viewport.scrollLeft;
}
/**
* The viewport's painted over layout size, per axis, or `null` when it is scaled to nothing, as
* under `scale(0)`, where no box says where anything is. An axis with no layout size reads as 1.
*/
function scaleOf(painted, layoutSize) {
	const x = layoutSize.width > 0 ? painted.width / layoutSize.width : 1;
	const y = layoutSize.height > 0 ? painted.height / layoutSize.height : 1;
	return Number.isFinite(x) && Number.isFinite(y) && x > 0 && y > 0 ? {
		x,
		y
	} : null;
}
/**
* Whether the viewport's box held still enough between its reads before and after the slides'
* that a move of that size would put no position off by `STEADY`. A shift moves every box
* alike; a change of scale moves each box by its distance from the scroll origin times the
* change, and no slide starts past the scroll range's length. Both are painted px, so they are
* divided by the scale. It judges the endpoints only: two reads that agree cannot prove that each
* slide read between them saw the same sample, as when a sample returns to an earlier one.
*
* @param scale - The painted over layout size along the axis, from `before`.
* @param layoutLength - The viewport's layout length along the axis.
* @param scrollSize - The scroll range's length.
*/
function steady(orientation, before, after, scale, layoutLength, scrollSize) {
	const [start, end, length] = orientation === "vertical" ? [
		after.top - before.top,
		after.bottom - before.bottom,
		after.height - before.height
	] : [
		after.left - before.left,
		after.right - before.right,
		after.width - before.width
	];
	return (Math.max(Math.abs(start), Math.abs(end)) + (layoutLength > 0 ? Math.abs(length) / layoutLength : 0) * scrollSize) / scale < STEADY;
}
/**
* The frame of a viewport painted as `box` at `scale`: its padding box's start edge on screen,
* from which the scroll origin is `scrolled` px back.
*/
function frameOf(orientation, rtl, box, scale, client, scrolled) {
	const top = box.top + client.clientTop * scale.y;
	const left = box.left + client.clientLeft * scale.x;
	return {
		orientation,
		rtl,
		scale,
		top,
		left,
		right: left + client.clientWidth * scale.x,
		scrolled
	};
}
/**
* A painted box in a frame's scroll coordinates: where it starts along the axis, from the scroll
* origin's start side, and its layout size.
*/
function placeBox(frame, box) {
	const { scale } = frame;
	let offset;
	if (frame.orientation === "vertical") offset = (box.top - frame.top) / scale.y;
	else if (frame.rtl) offset = (frame.right - box.right) / scale.x;
	else offset = (box.left - frame.left) / scale.x;
	return {
		start: offset + frame.scrolled,
		size: {
			width: box.width / scale.x,
			height: box.height / scale.y
		}
	};
}
/**
* Read the layout, once: the viewport's style and each slide's, then the viewport's box and each
* slide's, between two reads of the viewport's box. A slide without a layout box, such as one a
* host rule hides, takes no place in the reading: the user cannot reach it.
*
* @param viewport - The scroll-snap container.
* @param orientation - The axis it scrolls on.
* @param members - The mounted slides; the connected ones are read, in document order.
* @returns What the measurement found.
*/
function measureCarousel(viewport, orientation, members) {
	const vertical = orientation === "vertical";
	const axis = vertical ? "block" : "inline";
	const style = getComputedStyle(viewport);
	const rtl = !vertical && style.direction === "rtl";
	const sides = sidesOf(orientation, rtl);
	const viewportSize = layoutSizeOf(style);
	const size = vertical ? viewport.clientHeight : viewport.clientWidth;
	const port = {
		size,
		scrollSize: vertical ? viewport.scrollHeight : viewport.scrollWidth,
		paddingStart: lengthOf(sideValue(style, "scroll-padding", sides.start), size),
		paddingEnd: lengthOf(sideValue(style, "scroll-padding", sides.end), size)
	};
	const scrolled = scrollPositionOf(viewport, orientation, rtl);
	const candidates = [...members].filter((member) => member.isConnected).toSorted(documentOrder).map((slide) => {
		const slideStyle = getComputedStyle(slide);
		return {
			slide,
			marginStart: lengthOf(sideValue(slideStyle, "scroll-margin", sides.start), 0),
			marginEnd: lengthOf(sideValue(slideStyle, "scroll-margin", sides.end), 0),
			align: parseSnapAlign(slideStyle.getPropertyValue("scroll-snap-align"), axis)
		};
	});
	const [rect] = viewport.getClientRects();
	const read = candidates.map((candidate) => candidate.slide.getClientRects()[0]);
	const [after] = viewport.getClientRects();
	if (rect === void 0 || after === void 0) return { kind: "no-box" };
	const scale = scaleOf(rect, viewportSize);
	if (scale === null) return { kind: "non-finite" };
	const frame = frameOf(orientation, rtl, rect, scale, viewport, scrolled);
	const shown = candidates.flatMap((candidate, index) => {
		const box = read[index];
		return box === void 0 ? [] : [{
			...candidate,
			box
		}];
	});
	const slides = shown.map((candidate) => candidate.slide);
	const sizes = /* @__PURE__ */ new Map([[viewport, viewportSize]]);
	const geometry = shown.map(({ slide, box, marginStart, marginEnd, align }) => {
		const placed = placeBox(frame, box);
		sizes.set(slide, placed.size);
		return {
			start: placed.start,
			size: vertical ? placed.size.height : placed.size.width,
			marginStart,
			marginEnd,
			align
		};
	});
	if (!geometry.every((slide) => Number.isFinite(slide.start) && Number.isFinite(slide.size) && slide.size >= 0)) return { kind: "non-finite" };
	return {
		kind: "geometry",
		steady: vertical ? steady(orientation, rect, after, scale.y, viewportSize.height, port.scrollSize) : steady(orientation, rect, after, scale.x, viewportSize.width, port.scrollSize),
		slides,
		numbers: new Map(slides.map((slide, index) => [slide, index])),
		geometry,
		port,
		rtl,
		sizes
	};
}
export { measureCarousel, scrollPositionOf };

//# sourceMappingURL=carousel-measure.js.map