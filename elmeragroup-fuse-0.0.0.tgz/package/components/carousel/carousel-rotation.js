"use client";
import { containsAcrossShadowRoots } from "../../internal/dom-node.js";
import { deepActiveElement, hasFocus } from "../../internal/active-element.js";
import { useReducedMotion } from "../../hooks/use-reduced-motion.js";
import { useCallback, useEffect, useLayoutEffect, useRef, useState, useSyncExternalStore } from "react";
// src/components/carousel/carousel-rotation.ts
function subscribeToVisibility(onChange) {
	document.addEventListener("visibilitychange", onChange);
	return () => {
		document.removeEventListener("visibilitychange", onChange);
	};
}
function documentHidden() {
	return document.visibilityState === "hidden";
}
function serverDocumentHidden() {
	return false;
}
/**
* The element that has keyboard focus in `doc`, followed down through open shadow roots, or null.
* The browser's `:focus-visible` heuristic says whether focus arrived by keyboard: it matches
* after Tab, an arrow key or a programmatic focus that follows keyboard use, and on a text field
* however it was focused, and not after a click on a button, which is a control press and stops
* rotation on its own. It is read on the focused element itself, since a shadow host does not
* match `:focus-visible` for focus inside its shadow root.
*/
function keyboardFocusedElement(doc) {
	const active = deepActiveElement(doc);
	return active?.matches(":focus-visible") === true ? active : null;
}
/**
* Whether a mouse or pen is over `root` now, by the engine's own `:hover`, for hover that began
* before the Root could listen, such as while a server-rendered page hydrates. Only where the
* primary pointer can hover: a touch screen's tap leaves `:hover` on what it tapped, which mobile
* WebKit keeps until the next tap elsewhere, so where the primary pointer cannot hover,
* `:hover` does not say a pointer is over the carousel. `(hover: hover)` asks that of the
* primary pointer; `(any-hover: hover)` would also hold on a tablet with a trackpad attached,
* where a finger's tap still sets a `:hover` no pointer would ever clear, and `(pointer: fine)`
* asks about precision, not hover.
*/
function hoveredNow(root) {
	const view = root.ownerDocument.defaultView;
	return view !== null && view.matchMedia("(hover: hover)").matches && root.matches(":hover");
}
/**
* Whether keyboard focus is inside `root` now: the focused element, followed out of any shadow
* root, is `root` or inside it, and matches `:focus-visible`.
*/
function keyboardFocusInside(root) {
	const focused = keyboardFocusedElement(root.ownerDocument);
	return focused !== null && containsAcrossShadowRoots(root, focused);
}
/**
* Whether `element`, which the Root's focus event recorded, still has keyboard focus. Removing a
* focused element blurs it without a blur the Root can hear: React suppresses its synthetic blur
* during the commit that removes it, and Firefox fires none on removal, so the record can outlive
* the focus. The element must still be in the document and focused in its own root, which covers
* a shadow root and a same-origin frame, and still match `:focus-visible`.
*/
function stillKeyboardFocused(element) {
	return element !== null && element.isConnected && hasFocus(element) && element.matches(":focus-visible");
}
/**
* The carousel's automatic rotation, which exists while a `Carousel.Autoplay` is mounted. It
* follows the normative APG carousel pattern, which says "automatic slide rotation stops when any
* element in the carousel receives keyboard focus. It does not resume unless the user activates
* the rotation control", and, of a rotating carousel, that it "stops rotating when keyboard focus
* enters the carousel". The APG example's script leaves the rotation control out of its focus
* listeners; the pattern's text has no such exception, and the control is first in the tab
* order, so keeping it would leave the slides moving for a keyboard user who tabs in. So:
*
* - it starts on mount unless the user prefers reduced motion, and until the user chooses, it
*   follows that preference; an Autoplay starts from what is already so, whether it mounts with
*   the Root or after it: paused if a mouse or pen is over the Root, even since before
*   hydration where the primary pointer can hover, and stopped if keyboard
*   focus is inside it, an `autoFocus` field's and a portal's from a slide included; focus a mouse
*   press moved in is not keyboard focus, so it does not stop rotation;
* - keyboard focus on any element in the carousel, the rotation control included, stops it, and
*   the rotation control then reads "Start"; that is focus anywhere in its React tree, a portal,
*   one into a same-origin frame, or an open shadow root included;
* - pressing the rotation control to start it is the explicit restart: from then on, as the
*   example's `hasUserActivatedPlay` does, neither keyboard focus nor hover stops or pauses it, so
*   it keeps running with focus still on the control, until the control is pressed again;
* - until then it pauses while a mouse or pen is over the Root;
* - it pauses while the document is hidden;
* - any other user action, a control press or an interaction with the viewport, stops it, which
*   the Root does through `stop`;
* - every `delay` ms it advances a page, from the last page back to the first.
*
* @param index - The current page.
* @param pageCount - The page count; one page or none never rotates.
* @param advance - Change the page by rotation.
* @returns The rotation's state and controls.
*/
function useCarouselRotation(index, pageCount, advance) {
	const [delay, setDelay] = useState(null);
	const [choice, setChoice] = useState("unread");
	const [hovered, setHovered] = useState(false);
	const root = useRef(null);
	const pointerOver = useRef(false);
	const keyboardFocused = useRef(null);
	const reducedMotion = useReducedMotion();
	const hidden = useSyncExternalStore(subscribeToVisibility, documentHidden, serverDocumentHidden);
	const mounted = delay !== null;
	const rotating = mounted && (choice === "playing" || choice === "auto" && !reducedMotion);
	const running = rotating && !(hovered && choice !== "playing") && !hidden && pageCount > 1;
	useEffect(() => {
		if (!running) return;
		const timer = setTimeout(() => advance(index >= pageCount - 1 ? 0 : index + 1), delay);
		return () => clearTimeout(timer);
	}, [
		running,
		delay,
		index,
		pageCount,
		advance
	]);
	const mount = useCallback(() => {
		setChoice("unread");
		return () => setDelay(null);
	}, []);
	useLayoutEffect(() => {
		if (mounted && choice === "unread") {
			const element = root.current;
			setHovered(pointerOver.current || element !== null && hoveredNow(element));
			const focused = stillKeyboardFocused(keyboardFocused.current) || element !== null && keyboardFocusInside(element);
			setChoice(focused ? "stopped" : "auto");
		}
	}, [mounted, choice]);
	return {
		rotating,
		running,
		play: useCallback(() => setChoice("playing"), []),
		stop: useCallback(() => setChoice("stopped"), []),
		mount,
		setDelay,
		root,
		rootHandlers: {
			onPointerEnter: useCallback((event) => {
				if (event.pointerType === "touch") return;
				pointerOver.current = true;
				if (mounted) setHovered(true);
			}, [mounted]),
			onPointerLeave: useCallback(() => {
				pointerOver.current = false;
				setHovered(false);
			}, []),
			onFocus: useCallback((event) => {
				const focused = keyboardFocusedElement(event.target.ownerDocument);
				keyboardFocused.current = focused;
				if (mounted && focused !== null) setChoice((current) => current === "playing" ? current : "stopped");
			}, [mounted]),
			onBlur: useCallback(() => {
				keyboardFocused.current = null;
			}, [])
		}
	};
}
export { useCarouselRotation };

//# sourceMappingURL=carousel-rotation.js.map