"use client";
import { cn } from "../../styles/cn.js";
import { useLocalizedStrings } from "../../hooks/use-localized-strings.js";
import { useMergedRefs } from "../../hooks/use-merged-refs.js";
import { isNode } from "../../internal/dom-node.js";
import { definedProps } from "../../internal/defined-props.js";
import { CarouselContext, CarouselSnapshotContext, useCarouselContext, useCarouselSnapshot } from "./carousel-context.js";
import { clampIndex } from "./carousel-pages.js";
import { createCarouselEngine } from "./carousel-engine.js";
import { useCarouselRotation } from "./carousel-rotation.js";
import { carouselVariants } from "./carousel-variants.js";
import { carouselStrings } from "./intl/index.js";
import { useCallback, useLayoutEffect, useMemo, useRef, useState } from "react";
import { jsx } from "react/jsx-runtime";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
// src/components/carousel/carousel.tsx
const styles = carouselVariants();
const verticalStyles = carouselVariants({ orientation: "vertical" });
/**
* The provider every Carousel part reads, and the carousel container APG describes: a `region`
* landmark with the localized role description "carousel" and the name the types require. It owns
* the page, as `index` or `defaultIndex`, and the engine that measures `Carousel.Viewport`, so the
* parts and `useCarousel()` read one state.
*
* The pages are the viewport's snap positions, measured after mount, so the server renders no
* indicators and the page shown first moves into place before the first client paint. The slide
* numbers, the pages and the slides in view come from one measurement of the document, retaken
* after every change that can move a slide, a reorder included. While the viewport has no layout
* box, as under `display: none`, the Root keeps its page and measures again once it shows.
* Features exist by mounting their part: controls, indicators, a status and automatic rotation
* each come from their own part, never a boolean prop. The pages do not loop.
*/
function CarouselRoot({ index: indexProp, defaultIndex = 0, onIndexChange, orientation = "horizontal", className, render, ref, children, ...props }) {
	const strings = useLocalizedStrings(carouselStrings);
	const [uncontrolledIndex, setUncontrolledIndex] = useState(defaultIndex);
	const [viewport, setViewport] = useState(null);
	const engine = useRef(null);
	const members = useRef(/* @__PURE__ */ new Set());
	const [snapshot, setSnapshot] = useState(null);
	const [settled, setSettled] = useState(0);
	const pageCount = snapshot?.pages.positions.length ?? 0;
	const controlled = indexProp !== void 0;
	const index = clampIndex(indexProp ?? uncontrolledIndex, pageCount);
	const latest = useRef({
		index,
		pageCount,
		controlled,
		onIndexChange
	});
	useLayoutEffect(() => {
		latest.current = {
			index,
			pageCount,
			controlled,
			onIndexChange
		};
	});
	const change = useCallback((requested, reason, pageCount) => {
		const current = latest.current;
		const next = clampIndex(requested, pageCount);
		if (next === current.index) return;
		current.onIndexChange?.(next, { reason });
		if (!current.controlled) setUncontrolledIndex(next);
	}, []);
	const resolve = useCallback((requested, reason) => change(requested, reason, engine.current?.refresh() ?? latest.current.pageCount), [change]);
	const advance = useCallback((next) => resolve(next, "autoplay"), [resolve]);
	const rotation = useCarouselRotation(index, pageCount, advance);
	const { stop, play } = rotation;
	const navigate = useCallback((requested, reason) => {
		stop();
		resolve(requested, reason);
	}, [resolve, stop]);
	useLayoutEffect(() => {
		if (viewport === null) return;
		const created = createCarouselEngine(viewport, orientation, members.current, {
			onSnapshot: setSnapshot,
			onPage: (page, pages) => change(page, "scroll", pages),
			onInteract: stop,
			onSettle: () => setSettled((count) => count + 1)
		});
		engine.current = created;
		return () => {
			created.destroy();
			engine.current = null;
		};
	}, [
		viewport,
		orientation,
		change,
		stop
	]);
	useLayoutEffect(() => {
		engine.current?.commit({
			index,
			settled
		});
	});
	const registerSlide = useCallback((element) => {
		members.current.add(element);
		engine.current?.reconcileLater();
		return () => {
			members.current.delete(element);
			engine.current?.reconcileLater();
		};
	}, []);
	const state = useMemo(() => ({
		index,
		pageCount,
		canPrevious: index > 0,
		canNext: pageCount === 0 || index < pageCount - 1,
		rotating: rotation.rotating
	}), [
		index,
		pageCount,
		rotation.rotating
	]);
	const actions = useMemo(() => ({
		goTo: (next) => navigate(next, "action"),
		previous: () => navigate(latest.current.index - 1, "action"),
		next: () => navigate(latest.current.index + 1, "action"),
		play,
		stop
	}), [
		navigate,
		play,
		stop
	]);
	const meta = useMemo(() => ({ orientation }), [orientation]);
	const live = rotation.running ? "off" : "polite";
	const wiring = useMemo(() => ({
		setViewport,
		registerSlide,
		navigate,
		mountAutoplay: rotation.mount,
		setAutoplayDelay: rotation.setDelay,
		live
	}), [
		registerSlide,
		navigate,
		rotation.mount,
		rotation.setDelay,
		live
	]);
	const context = useMemo(() => ({
		state,
		actions,
		meta,
		wiring
	}), [
		state,
		actions,
		meta,
		wiring
	]);
	const rootRef = useMergedRefs(ref, rotation.root);
	const rendered = useRender({
		defaultTagName: "div",
		render,
		ref: rootRef,
		props: {
			"data-slot": "carousel",
			"data-orientation": orientation,
			...mergeProps({
				role: "region",
				"aria-roledescription": strings.format("carousel"),
				className: cn(styles.root(), className),
				children,
				...rotation.rootHandlers
			}, definedProps(props))
		}
	});
	return /* @__PURE__ */ jsx(CarouselContext, {
		value: context,
		children: /* @__PURE__ */ jsx(CarouselSnapshotContext, {
			value: snapshot,
			children: rendered
		})
	});
}
/**
* The scroll-snap container that holds the slides. The browser scrolls it natively: a swipe, a
* wheel, a trackpad and, once it has focus, the arrow keys, which the carousel never takes from a
* field inside a slide. It is in the tab order for that keyboard scroll. It is the slides' live
* region, `aria-live="polite"` while the pages do not rotate and `"off"` while they do.
*
* Space the slides with a margin on each slide, such as `me-4 last:me-0`. A vertical carousel
* needs a height.
*/
function CarouselViewport({ className, render, ref, ...props }) {
	const { meta, wiring } = useCarouselContext("Carousel.Viewport");
	const mergedRef = useMergedRefs(ref, wiring.setViewport);
	return useRender({
		defaultTagName: "div",
		render,
		ref: mergedRef,
		props: {
			"data-slot": "carousel-viewport",
			...mergeProps({
				tabIndex: 0,
				"aria-live": wiring.live,
				"aria-atomic": false,
				className: cn((meta.orientation === "vertical" ? verticalStyles : styles).viewport(), className)
			}, definedProps(props))
		}
	});
}
/**
* One slide: a `group` with the localized role description "slide". Without a name of its own it
* is named by its place, such as "3 of 6", which APG suggests when slides have no titles. Name it
* with `aria-labelledby` when it has a visible title.
*
* A slide fully outside the viewport is `inert`, so Tab and a screen reader's reading order skip
* what the user cannot see, as APG asks, and a slide in view or peeking in stays reachable. A
* slide that holds focus stays reachable too. In-page search does not find text in an inert slide.
* Size it with a class such as `basis-1/2`; it fills the viewport by default.
*/
function CarouselSlide({ className, render, ref, ...props }) {
	const { wiring } = useCarouselContext("Carousel.Slide");
	const strings = useLocalizedStrings(carouselStrings);
	const [element, setElement] = useState(null);
	const [focusWithin, setFocusWithin] = useState(false);
	const { registerSlide } = wiring;
	const snapshot = useCarouselSnapshot();
	const slideRef = useCallback((attached) => {
		setElement(attached);
		if (attached === null) return;
		const leave = registerSlide(attached);
		return () => {
			leave();
			setElement(null);
		};
	}, [registerSlide]);
	const mergedRef = useMergedRefs(ref, slideRef);
	const position = (element === null ? void 0 : snapshot?.numbers.get(element)) ?? -1;
	const named = props["aria-label"] !== void 0 || props["aria-labelledby"] !== void 0;
	const label = snapshot === null || position < 0 || named ? void 0 : strings.format("slideLabel", {
		position: position + 1,
		count: snapshot.slides.length
	});
	const outOfView = snapshot !== null && element !== null && position >= 0 && !snapshot.visible.has(element) && !focusWithin;
	return useRender({
		defaultTagName: "div",
		render,
		ref: mergedRef,
		props: {
			"data-slot": "carousel-slide",
			...mergeProps({
				role: "group",
				"aria-roledescription": strings.format("slide"),
				...definedProps({
					"aria-label": label,
					inert: outOfView || void 0
				}),
				className: cn(styles.slide(), className),
				onFocus: () => setFocusWithin(true),
				onBlur: (event) => {
					const next = event.relatedTarget;
					if (!isNode(next) || !event.currentTarget.contains(next)) setFocusWithin(false);
				}
			}, definedProps(props))
		}
	});
}
CarouselRoot.displayName = "Carousel.Root";
CarouselViewport.displayName = "Carousel.Viewport";
CarouselSlide.displayName = "Carousel.Slide";
export { CarouselRoot, CarouselSlide, CarouselViewport };

//# sourceMappingURL=carousel.js.map