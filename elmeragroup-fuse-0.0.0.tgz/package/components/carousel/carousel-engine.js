import { createCarouselInput } from "./carousel-input.js";
import { clampIndex, nearestPage, pagesOf, samePages, visibleSlides } from "./carousel-pages.js";
import { measureCarousel, scrollPositionOf } from "./carousel-measure.js";
// src/components/carousel/carousel-engine.ts
/**
* The carousel's DOM adapter. It measures a native scroll-snap viewport, reports which page the
* scroll position is on and which slides it shows, and scrolls to a page. It is React-free: the
* Root creates one per viewport and turns its reports into state, so no part reads it directly.
*
* The browser's own scroller runs every gesture. The engine listens to `scroll` passively and
* reads one `scrollLeft` or `scrollTop` per frame, with a horizontal viewport's computed
* `direction`, so it never delays a swipe, a wheel turn or a
* keyboard scroll, and it never writes a transform. A page change calls `scrollTo` without
* `behavior`, so the viewport's own `scroll-behavior: smooth` animates it and the central
* reduced-motion rule in `fuse.css` turns that animation off.
*
* The engine keeps these apart:
*
* - Reconciliation. The Root's commit and every invalidation, a resize, a change to the viewport's
*   subtree, a slide mounting or unmounting, end in one `flush`. It measures the layout at most
*   once, applies the committed slides and page, and only then publishes one
*   {@link CarouselSnapshot}: the slides in document order, the pages their snap positions make and
*   the slides in view. It never reports a page, since the page it applies is the Root's own.
*   A layout with no usable box, under `display: none` or `scale(0)`, is never cached: the last
*   usable one stands, and the engine measures again once the box resizes or, for a scale, on the
*   next frame. With no slides there is nothing placed, so slides that return are placed afresh.
* - Freshness where the layout is used. Layout inherited from outside, such as an ancestor's gap or
*   a class that changes which slides snap, moves slides without any report, and no cheap check
*   can prove it did not. So each user action that resolves a page measures first: a navigation
*   calls `refresh`, which runs the one `flush` with the layout marked dirty, before the Root picks
*   the destination, and a scroll's end measures before it reads which page the viewport settled
*   on. That is one measurement per action. Without an action, an inherited change reaches the
*   indicators only at the next scroll end, navigation, resize, mutation or commit.
* - Observation. Live page reports belong to a scroll session, which the engine alone owns. User
*   input that can scroll the viewport, a pointer down, a key down or a wheel turn along its axis,
*   arms it for as long as that input is held. `carousel-input.ts` alone owns those lifetimes, and
*   catches each release wherever it lands. A scroll frame while it is armed starts the session: the layout is measured once, through the one `flush`, so live reports
*   never read a stale page count, and from then each frame reads the position against that
*   measurement, with no box read, and reports the nearest page, so the indicators follow a swipe
*   and its inertia live. The session ends at the scroll's end, or when the engine itself scrolls
*   to a page. Input that ends without scrolling, such as a tap, a click on a control in a slide or
*   keys typed into a field, leaves nothing live. Any scroll without a session, such as the
*   browser re-snapping after a layout change, a focus scroll or a programmatic one, reports its
*   page only at its end, from a fresh measurement, so a re-snap never publishes a page read from
*   stale geometry. The one exception is the engine's own scroll, a page change or a placement:
*   when it ends where its page was, while the slides moved under it, the engine puts its own
*   page back where the layout now has it, as Firefox may not re-snap it (`flush`). Every scroll
*   frame still updates the slides in view. Notifying the Root that the user acted, which stops
*   rotation, is separate: any user input does it, scroll or not.
* - Ends. A scroll ends at `scrollend`, or, without it, after a quiet spell with no scroll event.
*   What a scroll is owed, its settle, is kept apart from the one timer that counts out its spell.
*   Nothing ends while input is held, as a finger at rest mid-drag sends no scroll events: new
*   input stops the timer but keeps what is owed, and when the last input is released a fresh
*   spell starts for it, or for a live session still under way. Only the engine's own page change,
*   whose scroll brings its own end, replaces what an earlier scroll was owed.
*
* Measurement is `carousel-measure.ts`'s: every length is in the viewport's scroll coordinates,
* read from the painted boxes, and it says whether a reading is steady, taken with the viewport's
* box holding still, or unsteady, taken while an animating transform moved it, as WebKit samples a
* running transform afresh at each layout read. The engine treats an unsteady reading as it treats
* a box scaled to nothing: the viewport has no usable layout for now, and it measures again on the
* next frame. After `UNSTEADY_READINGS` unsteady readings in a row it accepts the latest as it is,
* and every one after it until one is steady, so an animation that never rests cannot stall the
* carousel. An accepted reading puts no page back, unlike one after a box that was gone: the
* viewport stayed scrollable, so the browser reset no scroll position.
*
* A scroll that ends while the reading is unsteady is owed its end again, as one that ends under
* held input is, and its end is read afresh after the next quiet spell, up to `END_READS` reads in
* all; the last accepts what it reads, as a reading past `UNSTEADY_READINGS` is accepted. Nothing
* from an earlier read is kept for a later one, no layout and no reckoning of the engine's own
* scroll, as each could be undone by what came between: a later scroll, a gap change or a
* navigation. So the end is read as the end of whatever scroll last moved the viewport, and every
* scroll event starts the count over, as the end owed is now that scroll's. Nothing else needs to:
* after the engine's own scroll begins or input goes down, an end is read only once a scroll event
* has come, and input that never scrolls, such as a tap, leaves the end owed to the same scroll.
*/
/** The session with no user input that can scroll under way. */
const IDLE = { kind: "idle" };
/**
* A quiet spell: a scroll counts as ended once no `scroll` event has fired for this long. It ends
* every scroll in a browser without `scrollend`, and a scroll end that arrived short of the
* engine's own page in one with it. It outlasts the gap between the frames of a momentum scroll.
*/
const SETTLE_FALLBACK_MS = 150;
/** A programmatic scroll has arrived once it is this close to its page. */
const ARRIVED = 1;
/** A resize smaller than this is the rounding of a size the last measurement already read. */
const SAME_SIZE = .5;
/**
* The most unsteady readings in a row the engine sets aside before it accepts one. It measures
* again once a frame while it waits, so this is about half a second at 60 frames a second, which
* outlasts a popup's opening transition, typically 150 to 300ms; a loaded runner, which renders
* frames further apart, waits longer still. Past it, an animation that never rests gets what the
* engine read before it waited at all: a slow read may mix two samples, but the carousel gets pages
* and places its page rather than wait without end.
*/
const UNSTEADY_READINGS = 30;
/**
* The most reads of one scroll's end: one, and a quiet spell before each read after it while they
* are unsteady, so over half a second, as long as `UNSTEADY_READINGS` waits. The last accepts what
* it reads, so an end whose every read is unsteady settles though the next-frame retries between
* them hold still and start `UNSTEADY_READINGS` over.
*/
const END_READS = 5;
/** The attributes whose change can move a slide without resizing anything. */
const LAYOUT_ATTRIBUTES = [
	"class",
	"style",
	"dir",
	"hidden"
];
function sameSnapshot(left, right) {
	return (left.slides === right.slides && left.pages === right.pages || left.slides.length === right.slides.length && left.slides.every((slide, index) => slide === right.slides[index]) && samePages(left.pages, right.pages)) && left.visible.size === right.visible.size && [...left.visible].every((slide) => right.visible.has(slide));
}
/**
* Create the engine for a viewport. It reads nothing until the Root's first commit.
*
* @param viewport - The scroll-snap container.
* @param orientation - The axis it scrolls on.
* @param members - The mounted slides, which the Root keeps current; their order comes from the
*   document.
* @param listener - Where the engine reports.
* @returns The engine. Call `destroy` when the viewport unmounts.
*/
function createCarouselEngine(viewport, orientation, members, listener) {
	const view = viewport.ownerDocument.defaultView;
	const vertical = orientation === "vertical";
	const observed = /* @__PURE__ */ new Set();
	const sizes = /* @__PURE__ */ new Map();
	let layout = null;
	let published = null;
	let dirty = true;
	let scheduled = false;
	let destroyed = false;
	let unmeasured = false;
	let vanished = false;
	let unsteadyReadings = 0;
	let endReads = 0;
	let retryFrame = null;
	let page = 0;
	let target = null;
	let ending = null;
	let session = IDLE;
	let committed = {
		index: 0,
		settled: 0
	};
	let applied = null;
	let frame = null;
	let owed = null;
	let quietTimer = null;
	const hasScrollEnd = "onscrollend" in viewport;
	function readsRtl() {
		return !vertical && getComputedStyle(viewport).direction === "rtl";
	}
	/** The scroll position in the last measured direction. */
	function position() {
		return scrollPositionOf(viewport, orientation, layout?.rtl === true);
	}
	/** The last measurement, unless the latest found no usable layout. */
	function usable() {
		return unmeasured ? null : layout;
	}
	/** Where the engine's own scroll is heading, in the last measurement. */
	function ownDestination() {
		return target === null ? void 0 : layout?.pages.positions[target];
	}
	/**
	* Whether the engine's own scroll is under way, short of its page: a scroll end that comes now is
	* the end of a scroll before it, or of one that superseded it.
	*/
	function short() {
		const destination = ownDestination();
		return destination !== void 0 && Math.abs(position() - destination) >= ARRIVED;
	}
	/**
	* A measurement with no usable layout: keep the last one, and retry once there may be one.
	*
	* @param retry - When to measure again.
	* @param cause - Whether the box is gone or scaled to nothing, or the reading was unsteady.
	*/
	function unusable(retry, cause) {
		unmeasured = true;
		if (cause === "vanished") {
			vanished = true;
			unsteadyReadings = 0;
		} else unsteadyReadings += 1;
		sizes.clear();
		if (retry === "next frame" && retryFrame === null && view !== null) retryFrame = view.requestAnimationFrame(() => {
			retryFrame = null;
			invalidate();
		});
		return "unmeasurable";
	}
	/** Watch exactly the mounted slides. Returns whether the set changed. */
	function syncMembers() {
		let changed = false;
		for (const slide of observed) if (!members.has(slide)) {
			observed.delete(slide);
			resizeObserver?.unobserve(slide);
			sizes.delete(slide);
			changed = true;
		}
		for (const slide of members) if (!observed.has(slide)) {
			observed.add(slide);
			resizeObserver?.observe(slide);
			changed = true;
		}
		return changed;
	}
	/**
	* Measure the layout, once, and keep it if it is usable. What the measurement found decides: no
	* box, as under `display: none`, waits for the resize that showing again brings; geometry that is
	* not finite, as under `scale(0)`, and an unsteady reading are retried on the next frame, since
	* no observer reports a transform changing; and an unsteady reading is accepted once
	* `UNSTEADY_READINGS` have come in a row, or as the last of `END_READS` reads of a scroll's end.
	* Meanwhile the last layout and the selected page stand: see the module comment.
	*
	* @returns Whether the viewport has no usable layout, and otherwise whether the selected page must
	*   be put back, as after showing again or a change of direction, since the browser may have reset
	*   or mirrored the scroll position meanwhile.
	*/
	function measure() {
		const result = measureCarousel(viewport, orientation, members);
		if (result.kind === "no-box") return unusable("on resize", "vanished");
		if (result.kind === "non-finite") return unusable("next frame", "vanished");
		if (!result.steady && unsteadyReadings < UNSTEADY_READINGS && endReads < END_READS) return unusable("next frame", "unsteady");
		const { slides, numbers, geometry, port, rtl } = result;
		const restore = applied !== null && (vanished || layout !== null && layout.rtl !== rtl);
		unmeasured = false;
		vanished = false;
		if (result.steady) unsteadyReadings = 0;
		sizes.clear();
		for (const [box, size] of result.sizes) sizes.set(box, size);
		layout = {
			slides,
			numbers,
			geometry,
			port,
			pages: pagesOf(port, geometry),
			rtl
		};
		return restore ? "restore" : "measured";
	}
	/** Publish the snapshot for the current layout and scroll position, if it differs. */
	function publish(current) {
		const indexes = visibleSlides(current.port, current.geometry, position());
		const next = {
			slides: current.slides,
			numbers: current.numbers,
			pages: current.pages,
			visible: new Set(current.slides.filter((_, index) => indexes.has(index)))
		};
		if (published === null || !sameSnapshot(next, published)) {
			published = next;
			listener.onSnapshot(next);
		}
	}
	function scrollToPosition(destination, motion) {
		session = IDLE;
		forgive();
		const physical = layout?.rtl === true ? -destination : destination;
		const options = vertical ? { top: physical } : { left: physical };
		viewport.scrollTo(motion === "instant" ? {
			...options,
			behavior: "instant"
		} : options);
	}
	/**
	* Jump to the selected page without motion. A jump that moves the viewport is the engine's own
	* scroll until it ends, like a page change.
	*/
	function place(positions) {
		const destination = positions[page] ?? 0;
		target = Math.abs(position() - destination) < ARRIVED ? null : page;
		scrollToPosition(destination, "instant");
	}
	/** Scroll to a page with the viewport's own motion, unless it is there or the user is. */
	function move(positions, next) {
		if (next === page && target === null) return;
		const destination = positions[next] ?? 0;
		page = next;
		if (Math.abs(position() - destination) < ARRIVED) {
			target = null;
			return;
		}
		target = next;
		scrollToPosition(destination, "css");
	}
	/** Apply the committed page to a fresh layout. */
	function apply(current, restore) {
		const positions = current.pages.positions;
		if (positions.length === 0) {
			applied = null;
			target = null;
			page = 0;
			return;
		}
		const last = positions.length - 1;
		const wanted = clampIndex(committed.index, positions.length);
		const first = applied === null;
		const requested = first || applied?.index !== committed.index || applied.settled !== committed.settled;
		applied = committed;
		if (first || restore) {
			page = requested ? wanted : Math.min(last, page);
			place(positions);
			return;
		}
		if (requested) move(positions, wanted);
		else if (page > last) {
			page = last;
			if (session.kind === "idle") place(positions);
		}
	}
	/** The one reconciliation point: measure at most once, apply the commit, then publish. */
	function flush() {
		scheduled = false;
		if (destroyed) return;
		const pending = mutationObserver?.takeRecords() ?? [];
		const membersChanged = syncMembers();
		const moved = pending.some(movesSlides);
		const current = usable();
		const mirrored = current !== null && readsRtl() !== current.rtl;
		if (membersChanged || moved || mirrored) dirty = true;
		let restore = false;
		if (dirty) {
			dirty = false;
			const result = measure();
			if (result === "unmeasurable") return;
			restore = result === "restore" || strandedUnderOwnScroll();
		}
		const fresh = usable();
		if (fresh === null) return;
		apply(fresh, restore);
		publish(fresh);
	}
	/**
	* Whether the engine's own scroll ended where its page was in the layout it was measured
	* against, while this measurement has the slides elsewhere: the layout moved under that scroll,
	* so the position it left no longer shows the page the engine itself scrolled to, and the page
	* is put back. CSS Scroll Snap 1 § 6.2 has the browser re-snap to the slide it was snapped to,
	* which Chromium and WebKit do, so their scroll ends on the page's new position. Firefox does
	* not re-snap the slide of a jump whose layout changes in the same task, before the jump's
	* scroll is processed, as when an ancestor sets a spacing variable as the carousel mounts: it
	* leaves the viewport where the jump put it, on another slide's snap position or between two.
	* Any other scroll, a script's, a focus scroll or the user's, keeps the page it ends on.
	*/
	function strandedUnderOwnScroll() {
		return ending !== null && layout !== null && Math.abs(position() - ending.start) < ARRIVED && !samePages(ending.pages, layout.pages);
	}
	function reconcileLater() {
		if (!scheduled) {
			scheduled = true;
			queueMicrotask(flush);
		}
	}
	/** An observer saw the layout move: measure at the next reconciliation, once this task ends. */
	function invalidate() {
		dirty = true;
		reconcileLater();
	}
	/** Report the nearest page and the slides in view for the current scroll position. */
	function track() {
		const current = usable();
		if (current === null) return;
		if (readsRtl() !== current.rtl) {
			invalidate();
			return;
		}
		if (session.kind === "armed") {
			session = {
				kind: "live",
				still: session.still
			};
			dirty = true;
			flush();
		}
		const measured = usable();
		if (measured === null) return;
		publish(measured);
		if (session.kind === "live") observe(measured);
	}
	/** Report the page nearest the scroll position, by a layout's positions. */
	function observe(current) {
		const positions = current.pages.positions;
		if (positions.length === 0) return;
		const nearest = nearestPage(positions, position());
		if (nearest !== page) {
			page = nearest;
			listener.onPage(page, positions.length);
		}
	}
	/** Owe a scroll its end, `then`, after a full quiet spell from now. */
	function owe(then) {
		owed = then;
		countQuiet();
	}
	/**
	* Count a full quiet spell from now for what is owed. While the user holds input it cannot end:
	* the release counts a fresh one.
	*/
	function countQuiet() {
		stopTimer();
		if (owed === null) return;
		quietTimer = setTimeout(() => {
			quietTimer = null;
			const then = owed;
			if (then !== null && !input.held()) {
				owed = null;
				then();
			}
		}, SETTLE_FALLBACK_MS);
	}
	/** Stop counting, keeping what is owed. */
	function stopTimer() {
		if (quietTimer !== null) {
			clearTimeout(quietTimer);
			quietTimer = null;
		}
	}
	/** Nothing is owed any more: the scroll has settled, or the engine's own scroll replaces it. */
	function forgive() {
		stopTimer();
		owed = null;
	}
	/** A scroll ended, by `scrollend` or a quiet spell without it. */
	function settle() {
		if (input.held()) {
			owe(ended);
			return;
		}
		if (short()) {
			owe(ended);
			return;
		}
		forgive();
		ended();
	}
	/**
	* A scroll ended: read where, from a fresh measurement, and tell the Root. A read that is unsteady
	* leaves where the scroll ended unread, so its end is owed again, as under held input, up to
	* `END_READS` reads: see the module comment.
	*/
	function ended() {
		const own = ownDestination();
		ending = own === void 0 || layout === null ? null : {
			pages: layout.pages,
			start: own
		};
		target = null;
		session = IDLE;
		endReads += 1;
		dirty = true;
		flush();
		ending = null;
		if (unmeasured && unsteadyReadings > 0) {
			owe(ended);
			return;
		}
		endReads = 0;
		if (short()) return;
		const settled = usable();
		if (settled !== null) observe(settled);
		listener.onSettle();
	}
	function onScroll() {
		endReads = 0;
		if (session.kind !== "idle" && session.still !== null && applied !== null && applied !== committed && Math.abs(position() - session.still) >= ARRIVED) {
			applied = committed;
			const count = layout?.pages.positions.length ?? 0;
			if (count > 0) page = clampIndex(committed.index, count);
		}
		if (frame === null && view !== null) frame = view.requestAnimationFrame(() => {
			frame = null;
			track();
		});
		if (owed === null && !hasScrollEnd) owed = settle;
		countQuiet();
	}
	/**
	* User input that can scroll the viewport began: it takes over from a page change, stops the
	* spell's count while keeping what is owed, tells the Root, which stops rotation, and arms a
	* scroll session for as long as the input is held.
	*/
	function interact() {
		target = null;
		stopTimer();
		listener.onInteract();
		if (session.kind === "idle") session = {
			kind: "armed",
			still: position()
		};
		else if (session.kind === "live" && session.still === null) session = {
			kind: "live",
			still: position()
		};
	}
	/**
	* Every held input was released. Input that never scrolled leaves nothing live. What a scroll is
	* owed, or a live session still under way, counts a fresh spell from now: a live session's end
	* may not come by `scrollend`, as when a tap stops its inertia.
	*/
	function released() {
		if (session.kind === "armed") session = IDLE;
		else if (session.kind === "live") {
			session = {
				kind: "live",
				still: null
			};
			owed ??= settle;
		}
		countQuiet();
	}
	/**
	* Whether a mutation can have moved a slide. A change inside one slide's content cannot, except
	* by resizing that slide, which the resize observer reports; anything at or above the slides,
	* such as a reorder or a class on a slide or its wrapper, can.
	*
	* A record's target is the node whose children or attribute changed, so the test is on it alone,
	* whatever the record's type: a target strictly inside a measured slide moves nothing, and any
	* other target, a slide itself (its class, or children added to it), a wrapper or the viewport,
	* can. The walk therefore starts at the target's parent, so a slide that is the target does not
	* count as lying in itself, and climbs to the viewport, which no slide is inside. It costs the
	* target's depth below the viewport, not one `contains` per slide.
	*/
	function movesSlides(record) {
		const numbers = layout?.numbers;
		if (numbers === void 0 || record.target === viewport) return true;
		for (let node = record.target.parentNode; node !== null && node !== viewport; node = node.parentNode) if (numbers.has(node)) return false;
		return true;
	}
	/** Whether a resize report differs from the size the last measurement read. */
	function resized(entry) {
		const known = sizes.get(entry.target);
		const box = entry.borderBoxSize[0];
		if (known === void 0 || box === void 0) return true;
		return Math.abs(box.inlineSize - known.width) >= SAME_SIZE || Math.abs(box.blockSize - known.height) >= SAME_SIZE;
	}
	const resizeObserver = view === null ? null : new view.ResizeObserver((entries) => {
		if (entries.some(resized)) invalidate();
	});
	resizeObserver?.observe(viewport);
	const mutationObserver = view === null ? null : new view.MutationObserver((records) => {
		if (records.some(movesSlides)) invalidate();
	});
	mutationObserver?.observe(viewport, {
		childList: true,
		subtree: true,
		attributes: true,
		attributeFilter: LAYOUT_ATTRIBUTES
	});
	const passive = { passive: true };
	viewport.addEventListener("scroll", onScroll, passive);
	viewport.addEventListener("scrollend", settle, passive);
	const input = createCarouselInput(viewport, orientation, {
		onInput: interact,
		onRelease: released
	});
	return {
		commit(next) {
			committed = next;
			flush();
			if (session.kind !== "idle" && session.still !== null && applied !== null && applied !== committed) session = {
				...session,
				still: position()
			};
		},
		refresh() {
			dirty = true;
			flush();
			return layout?.pages.positions.length ?? 0;
		},
		reconcileLater,
		destroy() {
			destroyed = true;
			resizeObserver?.disconnect();
			mutationObserver?.disconnect();
			viewport.removeEventListener("scroll", onScroll);
			viewport.removeEventListener("scrollend", settle);
			input.destroy();
			if (frame !== null) view?.cancelAnimationFrame(frame);
			if (retryFrame !== null) view?.cancelAnimationFrame(retryFrame);
			forgive();
		}
	};
}
export { createCarouselEngine };

//# sourceMappingURL=carousel-engine.js.map