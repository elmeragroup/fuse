// src/components/carousel/carousel-input.ts
/**
* Own the input lifetimes of a viewport.
*
* @param viewport - The scroll container input begins on.
* @param orientation - The axis it scrolls on, which says which wheel turns can scroll it.
* @param listener - Where the owner reports.
* @returns The owner. Call `destroy` when the viewport unmounts.
*/
function createCarouselInput(viewport, orientation, listener) {
	const doc = viewport.ownerDocument;
	const vertical = orientation === "vertical";
	const view = doc.defaultView;
	const touchEvents = view !== null && "ontouchstart" in view;
	const pointers = /* @__PURE__ */ new Map();
	let panning = false;
	const keys = /* @__PURE__ */ new Set();
	let wheelFrame = null;
	const capture = {
		capture: true,
		passive: true
	};
	const passive = { passive: true };
	function held() {
		return pointers.size > 0 || panning || keys.size > 0 || wheelFrame !== null;
	}
	/** Run a change to what is held, and report the input beginning or all of it ending. */
	function change(apply, began) {
		const before = held();
		apply();
		const after = held();
		if (!before && after) listen();
		if (began) listener.onInput();
		if (before && !after) {
			unlisten();
			listener.onRelease();
		}
	}
	function endAll() {
		change(() => {
			pointers.clear();
			panning = false;
			keys.clear();
			if (wheelFrame !== null) {
				view?.cancelAnimationFrame(wheelFrame);
				wheelFrame = null;
			}
		}, false);
	}
	function onPointerDown(event) {
		change(() => pointers.set(event.pointerId, event.pointerType === "touch" ? "touch" : "other"), true);
	}
	function onPointerUp(event) {
		change(() => pointers.delete(event.pointerId), false);
	}
	function onPointerCancel(event) {
		change(() => {
			if (pointers.delete(event.pointerId) && event.pointerType === "touch" && touchEvents) panning = true;
		}, false);
	}
	function onTouchEnd(event) {
		if (event.touches.length === 0) change(() => {
			panning = false;
			for (const [id, kind] of pointers) if (kind === "touch") pointers.delete(id);
		}, false);
	}
	function onKeyDown(event) {
		change(() => keys.add(event.code), true);
	}
	function onKeyUp(event) {
		change(() => keys.delete(event.code), false);
	}
	function onLostCapture(event) {
		if (event.pointerType !== "touch") change(() => pointers.delete(event.pointerId), false);
	}
	function onWheel(event) {
		if (!(vertical ? event.deltaY !== 0 && !event.shiftKey : event.deltaX !== 0 || event.shiftKey && event.deltaY !== 0) || view === null) return;
		change(() => {
			if (wheelFrame !== null) view.cancelAnimationFrame(wheelFrame);
			wheelFrame = view.requestAnimationFrame(() => {
				wheelFrame = view.requestAnimationFrame(() => {
					change(() => {
						wheelFrame = null;
					}, false);
				});
			});
		}, true);
	}
	function listen() {
		doc.addEventListener("pointerup", onPointerUp, capture);
		doc.addEventListener("pointercancel", onPointerCancel, capture);
		doc.addEventListener("lostpointercapture", onLostCapture, capture);
		doc.addEventListener("touchend", onTouchEnd, capture);
		doc.addEventListener("touchcancel", onTouchEnd, capture);
		doc.addEventListener("keyup", onKeyUp, capture);
		view?.addEventListener("blur", endAll, passive);
	}
	function unlisten() {
		doc.removeEventListener("pointerup", onPointerUp, capture);
		doc.removeEventListener("pointercancel", onPointerCancel, capture);
		doc.removeEventListener("lostpointercapture", onLostCapture, capture);
		doc.removeEventListener("touchend", onTouchEnd, capture);
		doc.removeEventListener("touchcancel", onTouchEnd, capture);
		doc.removeEventListener("keyup", onKeyUp, capture);
		view?.removeEventListener("blur", endAll);
	}
	viewport.addEventListener("pointerdown", onPointerDown, passive);
	viewport.addEventListener("keydown", onKeyDown, passive);
	viewport.addEventListener("wheel", onWheel, passive);
	return {
		held,
		destroy() {
			viewport.removeEventListener("pointerdown", onPointerDown);
			viewport.removeEventListener("keydown", onKeyDown);
			viewport.removeEventListener("wheel", onWheel);
			if (wheelFrame !== null) {
				view?.cancelAnimationFrame(wheelFrame);
				wheelFrame = null;
			}
			pointers.clear();
			panning = false;
			keys.clear();
			unlisten();
		}
	};
}
export { createCarouselInput };

//# sourceMappingURL=carousel-input.js.map