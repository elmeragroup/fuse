// src/components/carousel/carousel-pages.ts
/** Two snap positions closer than this are one page: layout rounds lengths to a fraction of a px. */
const SAME_POSITION = 1;
/** A slide shows when more than this much of it is inside the viewport. */
const VISIBLE_OVERLAP = 1;
const ALIGNS = /* @__PURE__ */ new Set([
	"start",
	"center",
	"end",
	"none"
]);
function isSnapAlign(value) {
	return ALIGNS.has(value);
}
/**
* Read a computed `scroll-snap-align` for one axis. The property takes one value for both axes or
* two, block first and inline second.
*
* @param computed - The computed value, such as `"start"` or `"none center"`.
* @param axis - The axis the carousel scrolls on.
* @returns The alignment on that axis, `none` for a value the property does not define.
*/
function parseSnapAlign(computed, axis) {
	const [first = "none", second] = computed.trim().split(/\s+/u);
	const value = second === void 0 || axis === "block" ? first : second;
	return isSnapAlign(value) ? value : "none";
}
/**
* The scroll position at which a slide's snap area aligns in the snapport, the viewport inset by
* its scroll padding, before clamping to the scroll range.
*/
function snapPosition(port, slide, align) {
	const areaStart = slide.start - slide.marginStart;
	const areaSize = slide.size + slide.marginStart + slide.marginEnd;
	const snapportSize = port.size - port.paddingStart - port.paddingEnd;
	switch (align) {
		case "start": return areaStart - port.paddingStart;
		case "end": return areaStart + areaSize - (port.paddingStart + snapportSize);
		case "center": return areaStart + areaSize / 2 - (port.paddingStart + snapportSize / 2);
	}
}
/**
* The pages a scroll-snap layout stops at. Each slide that snaps adds its snap position, clamped
* to the scroll range, and positions within a pixel of each other are one page. So six slides a
* third of the viewport wide make four pages, as the browser stops at four positions, and slides
* whose `scroll-snap-align` is `none` add none, so a layout that snaps every third slide pages by
* three.
*
* @param port - The viewport's geometry.
* @param slides - Every slide, in document order.
* @returns The pages, ascending. No slides make no pages; slides that never snap make one page at
*   the start.
*/
function pagesOf(port, slides) {
	if (slides.length === 0) return {
		positions: [],
		leadingSlides: []
	};
	const max = Math.max(0, port.scrollSize - port.size);
	const snaps = slides.flatMap((slide, index) => slide.align === "none" ? [] : [{
		position: Math.min(max, Math.max(0, snapPosition(port, slide, slide.align))),
		index
	}]).toSorted((left, right) => left.position - right.position || left.index - right.index);
	if (snaps.length === 0) return {
		positions: [0],
		leadingSlides: [0]
	};
	const positions = [];
	const leadingSlides = [];
	for (const snap of snaps) {
		const last = positions.at(-1);
		if (last !== void 0 && snap.position - last < SAME_POSITION) {
			const lastIndex = leadingSlides.length - 1;
			leadingSlides[lastIndex] = Math.min(leadingSlides[lastIndex] ?? snap.index, snap.index);
			continue;
		}
		positions.push(snap.position);
		leadingSlides.push(snap.index);
	}
	return {
		positions,
		leadingSlides
	};
}
/**
* Whether two measurements make the same pages: as many, each at the same position within a
* pixel, as `pagesOf` merges positions, and each led by the same slide.
*
* @param left - One measurement's pages.
* @param right - The other's.
* @returns `true` when every page matches.
*/
function samePages(left, right) {
	return left.positions.length === right.positions.length && left.positions.every((value, index) => Math.abs(value - (right.positions[index] ?? NaN)) < SAME_POSITION) && left.leadingSlides.every((value, index) => value === right.leadingSlides[index]);
}
/**
* A requested page as one the layout has: truncated to a whole page, and clamped to the first
* and last. Without pages nothing clamps it from above, so a page asked for before the first
* measurement stands until one arrives.
*
* @param index - The requested page.
* @param pageCount - How many pages there are, `0` before any measurement.
* @returns The page.
*/
function clampIndex(index, pageCount) {
	const floor = Math.max(0, Math.trunc(index));
	return pageCount === 0 ? floor : Math.min(pageCount - 1, floor);
}
/**
* The page whose position is nearest a scroll position. A position halfway between two pages
* belongs to the earlier one.
*
* @param positions - The pages' positions, ascending.
* @param position - The scroll position.
* @returns The page's index, `0` when there are no pages.
*/
function nearestPage(positions, position) {
	let nearest = 0;
	for (const [index, candidate] of positions.entries()) {
		const best = positions[nearest] ?? candidate;
		if (Math.abs(candidate - position) < Math.abs(best - position)) nearest = index;
	}
	return nearest;
}
/**
* The slides a scroll position shows: those with more than a pixel of their border box inside the
* viewport, so a slide that only touches its edge does not count and a peeking one does.
*
* @param port - The viewport's geometry.
* @param slides - Every slide, in document order.
* @param position - The scroll position.
* @returns The indexes of the slides in view.
*/
function visibleSlides(port, slides, position) {
	const end = position + port.size;
	const visible = /* @__PURE__ */ new Set();
	for (const [index, slide] of slides.entries()) if (Math.min(end, slide.start + slide.size) - Math.max(position, slide.start) > VISIBLE_OVERLAP) visible.add(index);
	return visible;
}
export { clampIndex, nearestPage, pagesOf, parseSnapAlign, samePages, visibleSlides };

//# sourceMappingURL=carousel-pages.js.map