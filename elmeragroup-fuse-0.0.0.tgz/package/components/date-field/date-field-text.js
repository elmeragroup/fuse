import { canonicalSpaces } from "../../intl/canonical-spaces.js";
import { LEFT_TO_RIGHT_ISOLATE, POP_DIRECTIONAL_ISOLATE, dayPeriodNames, fieldParts, zoneNameAt } from "./date-field-format.js";
// src/components/date-field/date-field-text.ts
/** One run of separators: spaces, punctuation and format characters, the time's isolates among them. */
const SEPARATOR_RUN = String.raw`[\p{P}\p{Z}\s\p{Cf}]+`;
/** Separators the reading skips between parts. */
const SEPARATORS = new RegExp(`^(?:${SEPARATOR_RUN})?`, "u");
/** Separators around a literal's own word. */
const EDGE_SEPARATORS = new RegExp(`^${SEPARATOR_RUN}|${SEPARATOR_RUN}$`, "gu");
/** What may stand around a zone's name the text wrote: spaces, a comma and the time's isolates. */
const ZONE_NAME_EDGES = new RegExp(`^[\\s,${LEFT_TO_RIGHT_ISOLATE}${POP_DIRECTIONAL_ISOLATE}]+|[\\s,${LEFT_TO_RIGHT_ISOLATE}${POP_DIRECTIONAL_ISOLATE}]+$`, "gu");
/** Whether a literal is one of the isolates around the time, which carry no text of their own. */
function isIsolate(text) {
	return text === LEFT_TO_RIGHT_ISOLATE || text === POP_DIRECTIONAL_ISOLATE;
}
/** A literal's own text: what is left once its spaces, punctuation and isolates are taken off. */
function literalWord(text) {
	return text.replace(EDGE_SEPARATORS, "");
}
/**
* `text` after a word the field writes, the word matched by case alone: its accents count, so a
* word of another spelling is no match, composed or decomposed. Only a slice of the word's own
* length is compared, so the rest returned is the raw text that follows it.
*
* @returns The text after the word, or `undefined` when it does not start with the word.
*/
function afterWord(text, word, locale) {
	const head = text.slice(0, word.length);
	return word !== "" && head.localeCompare(word, locale, { sensitivity: "accent" }) === 0 ? text.slice(word.length) : void 0;
}
/** A literal with a word of its own, such as fi-FI's `klo`, reads that word; any other, nothing. */
function readLiteral(rest, text, locale) {
	const word = literalWord(text);
	if (word === "") return { rest };
	const after = afterWord(rest, word, locale);
	return after === void 0 ? void 0 : { rest: after };
}
/** The day period reads the next word, the locale's morning or afternoon word. */
function readDayPeriod(rest, locale) {
	const [match] = dayPeriodNames(locale).map((name, value) => ({
		value,
		after: afterWord(rest, name, locale),
		length: name.length
	})).filter((candidate) => candidate.after !== void 0).sort((left, right) => right.length - left.length);
	return match?.after === void 0 ? void 0 : {
		rest: match.after,
		entry: {
			type: "dayPeriod",
			value: match.value
		}
	};
}
/** A number unit reads the next run of digits. */
function readNumber(rest, type) {
	const digits = /^\d+/u.exec(rest);
	return digits === null ? void 0 : {
		rest: rest.slice(digits[0].length),
		entry: {
			type,
			value: Number.parseInt(digits[0], 10)
		}
	};
}
/**
* The zone's name reads the text up to the next literal the field writes with text of its own, or
* to the end when nothing follows it, kept apart from the units so its offset digits ("GMT+2") are
* never a unit's.
*/
function readZoneName(rest, later) {
	const [next] = later.flatMap((part) => part.kind === "literal" && part.text.trim() !== "" && !isIsolate(part.text) ? [part.text.trim()] : []);
	const end = next === void 0 ? rest.length : rest.indexOf(next);
	return end < 0 ? void 0 : {
		rest: rest.slice(end),
		zoneName: rest.slice(0, end)
	};
}
/** One part read from the text left, with the parts the field writes after it. */
function readPart(part, rest, later, locale) {
	switch (part.kind) {
		case "literal": return readLiteral(rest, part.text, locale);
		case "timeZoneName": return readZoneName(rest, later);
		case "segment": return part.type === "dayPeriod" ? readDayPeriod(rest, locale) : readNumber(rest, part.type);
	}
}
/**
* Text written in the field's own format read back into its units, part by part along the parts
* the field writes itself, consuming the whole text:
*
* - each number unit takes the next run of digits;
* - the day period, the next word, which must be the locale's morning or afternoon word;
* - a literal with a word of its own, such as fi-FI's `klo`, that word, in any case but with its
*   own accents (see `afterWord`);
* - the zone's name, the text up to the next literal or the end; `namesZoneAt` compares it with the
*   name the field writes at an instant, so a caller can pick the instant the text meant.
*
* Between them only spaces, punctuation and the isolates around the time may stand, whatever
* punctuation the field itself writes, so "10/05/2026" and "10-05-2026" both read in en-US. A letter
* or a digit anywhere else, such as ISO's `T` or a UTC `Z`, or another word than the locale's, makes
* the text no reading of the field's format.
*
* @param format - The field's format.
* @param text - The text, such as `10/05/2026, 02:30 PM GMT+2`.
* @returns The units and the zone check, or `undefined` when the text does not read.
*/
function readFieldText(format, text) {
	const parts = fieldParts(format);
	const entries = [];
	let rest = text;
	let zoneName = "";
	for (const [index, part] of parts.entries()) {
		const read = readPart(part, rest.replace(SEPARATORS, ""), parts.slice(index + 1), format.locale);
		if (read === void 0) return;
		rest = read.rest;
		if (read.entry !== void 0) entries.push(read.entry);
		zoneName = read.zoneName ?? zoneName;
	}
	if (rest.replace(SEPARATORS, "") !== "") return;
	const written = canonicalSpaces(zoneName).replace(ZONE_NAME_EDGES, "");
	return {
		entries,
		namesZoneAt: format.timeZone === void 0 || written === "" ? () => true : (instant) => canonicalSpaces(zoneNameAt(format, instant)) === written
	};
}
export { readFieldText };

//# sourceMappingURL=date-field-text.js.map