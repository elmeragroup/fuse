"use client";
import { createContext, use } from "react";
// src/components/date-field/date-input-context.ts
/** The Root's context for its segments. */
const DateInputRootContext = createContext(void 0);
/**
* The enclosing `DateInput.Root`'s context.
*
* @returns The context.
* @throws Error when a Segment renders outside a Root, a composition defect.
*/
function useDateInputRootContext() {
	const context = use(DateInputRootContext);
	if (context === void 0) throw new Error("DateInput.Segment must be rendered inside DateInput.Root");
	return context;
}
/** The selector that finds a Root's focusable segments, in document order. */
const SEGMENT_SELECTOR = "[data-slot=\"date-input-segment\"][tabindex]";
export { DateInputRootContext, SEGMENT_SELECTOR, useDateInputRootContext };

//# sourceMappingURL=date-input-context.js.map