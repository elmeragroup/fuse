import { temporal } from "../../temporal/temporal.js";
// src/components/date-field/date-draft.ts
/** A draft with every segment showing its placeholder. */
const EMPTY_DRAFT = {
	year: null,
	month: null,
	day: null,
	hour: null,
	dayPeriod: null,
	minute: null,
	second: null,
	offsetNanoseconds: null
};
const ONE_HOUR_MS = 36e5;
/**
* The segments a field edits, in React Aria's order: the date, then the time down to the
* granularity, with the day period after the hour under a 12-hour cycle.
*
* @param granularity - The smallest unit edited.
* @param hourCycle - The hour cycle shown.
* @returns The editable segment types.
*/
function editableSegments(granularity, hourCycle) {
	const all = [
		"year",
		"month",
		"day",
		"hour",
		...hourCycle === "h12" ? ["dayPeriod"] : [],
		"minute",
		"second"
	];
	const last = granularity === "day" ? "day" : granularity === "hour" && hourCycle === "h12" ? "dayPeriod" : granularity;
	return all.slice(0, all.indexOf(last) + 1);
}
/**
* A segment's limits. The day runs to 31, the most any month holds, so a day typed before its
* month is kept; committing constrains it.
*
* @param type - The segment.
* @param hourCycle - The hour cycle shown.
* @returns Its smallest and largest value.
*/
function segmentLimits(type, hourCycle) {
	switch (type) {
		case "year": return {
			min: 1,
			max: 9999
		};
		case "month": return {
			min: 1,
			max: 12
		};
		case "day": return {
			min: 1,
			max: 31
		};
		case "hour": return hourCycle === "h12" ? {
			min: 1,
			max: 12
		} : {
			min: 0,
			max: 23
		};
		case "dayPeriod": return {
			min: 0,
			max: 1
		};
		case "minute":
		case "second": return {
			min: 0,
			max: 59
		};
	}
}
/**
* A 24-hour hour in an hour cycle.
*
* @param hour - The hour, 0–23.
* @param hourCycle - The cycle.
* @returns The day period (`null` under `h23`) and the hour in that cycle.
*/
function toHourCycle(hour, hourCycle) {
	if (hourCycle === "h23") return [null, hour];
	const dayPeriod = hour >= 12 ? 1 : 0;
	const twelve = hour % 12;
	return [dayPeriod, twelve === 0 ? 12 : twelve];
}
/**
* An hour in a cycle as a 24-hour hour.
*
* @param hour - The hour in the cycle: 1–12 under `h12`, 0–23 under `h23`.
* @param dayPeriod - The day period, which only `h12` reads.
* @param hourCycle - The cycle.
* @returns The hour, 0–23.
*/
function fromHourCycle(hour, dayPeriod, hourCycle) {
	if (hourCycle === "h23") return hour;
	return (hour === 12 ? 0 : hour) + (dayPeriod === 1 ? 12 : 0);
}
/**
* The draft that shows a value: every segment filled from it, or every segment empty for `null`.
*
* @param value - The committed value, or `null`.
* @param hourCycle - The hour cycle shown.
* @returns The draft.
*/
function draftOf(value, hourCycle) {
	if (value === null) return EMPTY_DRAFT;
	if (!("hour" in value)) return {
		...EMPTY_DRAFT,
		year: value.year,
		month: value.month,
		day: value.day
	};
	const [dayPeriod, hour] = toHourCycle(value.hour, hourCycle);
	return {
		year: value.year,
		month: value.month,
		day: value.day,
		hour,
		dayPeriod,
		minute: value.minute,
		second: value.second,
		offsetNanoseconds: "offsetNanoseconds" in value ? value.offsetNanoseconds : null
	};
}
/** Whether every one of `segments` holds a number. */
function isComplete(draft, segments) {
	return segments.every((segment) => draft[segment] !== null);
}
/** Whether every one of `segments` shows its placeholder. */
function isCleared(draft, segments) {
	return segments.every((segment) => draft[segment] === null);
}
/** The day period a placeholder's time falls in, for an hour typed into an empty field. */
function placeholderDayPeriod(placeholder, hourCycle) {
	return "hour" in placeholder ? toHourCycle(placeholder.hour, hourCycle)[0] : null;
}
/**
* The draft with one segment set, as typing sets it. An hour typed while the day period is empty
* takes the placeholder's, and any edit but the second drops the held offset.
*
* @param draft - The draft.
* @param type - The segment.
* @param value - Its new number. It may lie outside what a value allows, such as day 31 in
*   February; the draft keeps it until it commits.
* @param placeholder - The value that fills empty segments, today at midnight.
* @param hourCycle - The hour cycle shown.
* @returns The new draft.
*/
function setSegment(draft, type, value, placeholder, hourCycle) {
	const offsetNanoseconds = type === "second" ? draft.offsetNanoseconds : null;
	if (type === "dayPeriod") return {
		...draft,
		dayPeriod: asDayPeriod(value),
		offsetNanoseconds
	};
	const dayPeriod = type === "hour" && draft.dayPeriod === null ? placeholderDayPeriod(placeholder, hourCycle) : draft.dayPeriod;
	return {
		...draft,
		[type]: value,
		dayPeriod,
		offsetNanoseconds
	};
}
function asDayPeriod(value) {
	return value === 1 ? 1 : 0;
}
/**
* The draft with one segment back on its placeholder.
*
* @param draft - The draft.
* @param type - The segment.
* @returns The new draft, without a held offset.
*/
function clearSegment(draft, type) {
	return {
		...draft,
		[type]: null,
		offsetNanoseconds: null
	};
}
/**
* `value + amount`, wrapping inside `min..max`. Rounded, it first steps one and then snaps to the
* next multiple of `amount` in the step's direction, so 2026 pages up by five to 2030.
*/
function cycleValue(value, amount, min, max, round) {
	if (!round) {
		const next = value + amount;
		if (next < min) return max - (min - next - 1);
		return next > max ? min + (next - max - 1) : next;
	}
	let next = value + Math.sign(amount);
	if (next < min) next = max;
	const step = Math.abs(amount);
	next = amount > 0 ? Math.ceil(next / step) * step : Math.floor(next / step) * step;
	return next > max ? min : next;
}
/**
* The draft with one segment stepped by `amount`, wrapping at its limits: an arrow key steps by
* one, Page Up and Page Down by the segment's page. An empty segment takes the placeholder's value
* instead, except the day period, which steps from AM.
*
* @param draft - The draft.
* @param type - The segment.
* @param amount - The step, negative to go down.
* @param placeholder - The value that fills empty segments, today at midnight in the field's zone.
* @param hourCycle - The hour cycle shown.
* @returns The new draft.
*/
function cycleSegment(draft, type, amount, placeholder, hourCycle) {
	if (draft[type] === null && type !== "dayPeriod") return fillFromPlaceholder(draft, type, placeholder, hourCycle);
	if (type === "hour") return cycleHour(draft, amount, placeholder, hourCycle);
	const { min, max } = segmentLimits(type, hourCycle);
	const next = cycleValue(draft[type] ?? min, amount, min, max, ROUNDED_SEGMENTS.has(type));
	return type === "dayPeriod" ? {
		...draft,
		dayPeriod: asDayPeriod(next)
	} : {
		...draft,
		[type]: next
	};
}
/** The segments whose page step lands on a multiple of the step, as React Aria's `cycleValue` rounds. */
const ROUNDED_SEGMENTS = /* @__PURE__ */ new Set([
	"year",
	"minute",
	"second"
]);
/** A placeholder's number for a segment; a PlainDate's time reads as midnight. */
function placeholderField(placeholder, type) {
	if (type === "minute" || type === "second") return "hour" in placeholder ? placeholder[type] : 0;
	return placeholder[type];
}
function fillFromPlaceholder(draft, type, placeholder, hourCycle) {
	if (type === "hour") {
		const [dayPeriod, hour] = toHourCycle("hour" in placeholder ? placeholder.hour : 0, hourCycle);
		return {
			...draft,
			hour,
			dayPeriod
		};
	}
	return {
		...draft,
		[type]: placeholderField(placeholder, type)
	};
}
function cycleHour(draft, amount, placeholder, hourCycle) {
	if ("timeZoneId" in placeholder && draft.year !== null && draft.month !== null && draft.day !== null) {
		const zoned = draftToValue(draft, placeholder, hourCycle);
		if ("timeZoneId" in zoned) {
			const cycled = cycleZonedHour(zoned, amount, hourCycle);
			const [dayPeriod, hour] = toHourCycle(cycled.hour, hourCycle);
			return {
				...draft,
				hour,
				dayPeriod,
				offsetNanoseconds: cycled.offsetNanoseconds
			};
		}
	}
	const limits = segmentLimits("hour", hourCycle);
	return {
		...draft,
		hour: cycleValue(draft.hour ?? 0, amount, limits.min, limits.max, false),
		dayPeriod: draft.dayPeriod ?? placeholderDayPeriod(placeholder, hourCycle)
	};
}
/**
* A wall clock's instants in a zone: the earlier and the later one, which differ for a wall time
* the zone repeats (the night the clocks go back) and are the one instant of any other. In a
* skipped wall time both resolve outside it, the earlier before the gap and the later after it.
*
* @param wallClock - The wall clock.
* @param zone - The zone.
* @returns The earlier and the later instant.
*/
function wallClockInstants(wallClock, zone) {
	return [wallClock.toZonedDateTime(zone, { disambiguation: "earlier" }), wallClock.toZonedDateTime(zone, { disambiguation: "later" })];
}
/** The instant of `wallClock` in `zone` that stays on its own day, earliest or latest. */
function instantOnDay(wallClock, zone, pick) {
	const candidates = wallClockInstants(wallClock, zone).filter((candidate) => candidate.day === wallClock.day);
	return pick === "first" ? candidates[0] : candidates.at(-1);
}
/**
* A zoned value's hour stepped through the day's real hours, as `@internationalized/date`'s
* `cycleZoned` does: the step counts whole hours since the epoch, wrapping between the day's first
* and last hour (that half of the day under a 12-hour cycle), so a repeated hour is visited twice
* and a skipped hour never.
*
* @param value - The value.
* @param amount - Hours to step, negative to go back.
* @param hourCycle - The hour cycle shown.
* @returns The value at the stepped instant, in its zone.
*/
function cycleZonedHour(value, amount, hourCycle) {
	const afternoon = value.hour >= 12;
	const minHour = hourCycle === "h12" && afternoon ? 12 : 0;
	const maxHour = hourCycle === "h12" && !afternoon ? 11 : 23;
	const wallClock = value.toPlainDateTime();
	const first = instantOnDay(wallClock.with({ hour: minHour }), value.timeZoneId, "first") ?? value;
	const last = instantOnDay(wallClock.with({ hour: maxHour }), value.timeZoneId, "last") ?? value;
	const epoch = value.epochMilliseconds;
	const hours = Math.floor(epoch / ONE_HOUR_MS);
	const remainder = epoch - hours * ONE_HOUR_MS;
	const stepped = cycleValue(hours, amount, Math.floor(first.epochMilliseconds / ONE_HOUR_MS), Math.floor(last.epochMilliseconds / ONE_HOUR_MS), false);
	return temporal().Instant.fromEpochMilliseconds(stepped * ONE_HOUR_MS + remainder).toZonedDateTimeISO(value.timeZoneId);
}
/**
* The value a draft makes: its segments over `base`, which fills the empty ones and gives the
* kind, zone and sub-second fields. Fields a value cannot hold are constrained, so February 30
* becomes February 28 or 29; under a 12-hour cycle an empty hour reads as the start of its day
* period. A zoned value keeps the draft's offset when it is one of that wall clock's offsets.
*
* @param draft - The draft.
* @param base - The committed value, or the placeholder when there is none.
* @param hourCycle - The hour cycle shown.
* @returns The value, of `base`'s kind.
*/
function draftToValue(draft, base, hourCycle) {
	const runtime = temporal();
	const date = {
		year: Math.max(1, draft.year ?? base.year),
		month: Math.max(1, draft.month ?? base.month),
		day: Math.max(1, draft.day ?? base.day)
	};
	if (!("hour" in base)) return runtime.PlainDate.from(date, { overflow: "constrain" });
	const hour = hourCycle === "h12" || draft.hour !== null ? fromHourCycle(draft.hour ?? 12, draft.dayPeriod ?? 0, hourCycle) : base.hour;
	const wallClock = runtime.PlainDateTime.from({
		...date,
		hour,
		minute: draft.minute ?? base.minute,
		second: draft.second ?? base.second,
		millisecond: base.millisecond,
		microsecond: base.microsecond,
		nanosecond: base.nanosecond
	}, { overflow: "constrain" });
	if (!("timeZoneId" in base)) return wallClock;
	const compatible = wallClock.toZonedDateTime(base.timeZoneId, { disambiguation: "compatible" });
	if (draft.offsetNanoseconds === null || compatible.offsetNanoseconds === draft.offsetNanoseconds) return compatible;
	return wallClockInstants(wallClock, base.timeZoneId).find((candidate) => candidate.offsetNanoseconds === draft.offsetNanoseconds) ?? compatible;
}
/**
* Whether a value shows exactly the draft's segments, so committing it changes nothing the user
* typed. February 30 constrained to February 28 does not.
*
* @param draft - The draft.
* @param value - The value it made.
* @param segments - The segments the field shows.
* @param hourCycle - The hour cycle shown.
* @returns Whether every shown segment matches.
*/
function roundTrips(draft, value, segments, hourCycle) {
	return segments.every((segment) => {
		if (segment === "hour" || segment === "dayPeriod") {
			if (!("hour" in value)) return false;
			const [dayPeriod, hour] = toHourCycle(value.hour, hourCycle);
			return draft.hour === hour && draft.dayPeriod === dayPeriod;
		}
		if (segment === "minute" || segment === "second") return "hour" in value && draft[segment] === value[segment];
		return draft[segment] === value[segment];
	});
}
/**
* The value that fills an empty field's segments: today at midnight, of the field's kind.
*
* @param today - Today's date in the field's zone, read when the user acts.
* @param kind - The field's value kind.
* @returns The placeholder value.
*/
function placeholderValue(today, kind) {
	switch (kind.kind) {
		case "PlainDate": return today;
		case "PlainDateTime": return today.toPlainDateTime();
		case "ZonedDateTime": return today.toZonedDateTime({ timeZone: kind.timeZone });
	}
}
export { EMPTY_DRAFT, clearSegment, cycleSegment, draftOf, draftToValue, editableSegments, fromHourCycle, isCleared, isComplete, placeholderValue, roundTrips, segmentLimits, setSegment, toHourCycle, wallClockInstants };

//# sourceMappingURL=date-draft.js.map