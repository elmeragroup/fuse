import { hasTime, isZoned, parseTemporal, parseWallTime } from "../../temporal/temporal-value.js";
import { boundDay } from "../calendar/calendar-dates.js";
import { draftOf, draftToValue, roundTrips, segmentLimits, setSegment, wallClockInstants } from "./date-draft.js";
// src/components/date-field/date-input-paste.ts
/** A value in a kind: a date-time's date for a PlainDate input, a zone's wall clock, a wall clock in a zone. */
function convertToKind(value, kind) {
	switch (kind.kind) {
		case "PlainDate": return boundDay(value);
		case "PlainDateTime":
			if (isZoned(value)) return value.toPlainDateTime();
			return hasTime(value) ? value : void 0;
		case "ZonedDateTime":
			if (isZoned(value)) return value.withTimeZone(kind.timeZone);
			return hasTime(value) ? value.toZonedDateTime(kind.timeZone, { disambiguation: "compatible" }) : void 0;
	}
}
/**
* The instant of a zoned wall time that the text's zone name names: the earlier or the later one of
* a wall time the zone repeats, the one instant of any other; `undefined` when the name is neither.
* Each candidate's name is the one the input writes for it (`settings.zoneInstant`), so a time on
* the stand-in day carries today's name, as its segments show it.
*/
function namedInstant(value, read, settings) {
	return wallClockInstants(value.toPlainDateTime(), value.timeZoneId).find((candidate) => read.namesZoneAt(settings.zoneInstant(candidate)));
}
/**
* The value a pasted draft forms, as typing forms it: a value that holds exactly what was pasted,
* so `02/30/2026`, or 02:30 on a night the clocks skip it, is no value. Text that wrote a zone name
* picks the instant it names of a repeated wall time; otherwise the wall time resolves as typed.
*/
function formedValue({ draft, base, settings, read }) {
	const formed = draftToValue(draft, base, settings.hourCycle);
	const value = read !== void 0 && isZoned(formed) ? namedInstant(formed, read, settings) : formed;
	return value !== void 0 && roundTrips(draft, value, settings.fields, settings.hourCycle) ? value : void 0;
}
/**
* Text in the field's own format, read by the field's format (`readFieldText`), as the value of the
* units it names: over the committed value (or the placeholder), every number inside its unit's
* limits and every shown unit named, since one the text left out would silently keep the base's.
*/
function formattedValue(text, settings) {
	const read = settings.readText(text);
	if (read === void 0) return;
	const base = settings.committed ?? settings.placeholder();
	let draft = draftOf(base, settings.hourCycle);
	for (const { type, value } of read.entries) {
		const { min, max } = segmentLimits(type, settings.hourCycle);
		if (type !== "dayPeriod" && !(value >= min && value <= max)) return;
		draft = setSegment(draft, type, value, base, settings.hourCycle);
	}
	if (!settings.fields.every((field) => read.entries.some((entry) => entry.type === field))) return;
	return formedValue({
		draft,
		base,
		settings,
		read
	});
}
/**
* A wall-clock time pasted into a time-only input. The input edits the time of its own day, the
* committed value's or the placeholder's, so the time names that day's instant; it resolves as
* typed: on a repeated hour, the earlier instant; in a skipped one, nothing, as typing leaves such
* a time a draft. The shown units take the time as `draftOf` splits it into the hour cycle; the
* hidden ones keep the base's, and no offset is held.
*/
function wallTimeValue(time, settings) {
	const base = settings.committed ?? settings.placeholder();
	const pasted = draftOf(boundDay(base).toPlainDateTime(time), settings.hourCycle);
	return formedValue({
		draft: settings.fields.reduce((shown, type) => ({
			...shown,
			[type]: pasted[type]
		}), {
			...draftOf(base, settings.hourCycle),
			offsetNanoseconds: null
		}),
		base,
		settings
	});
}
/**
* Pasted text in an input that shows its date: ISO text of a kind the input can hold, converted to
* its kind, else text in the field's own format. sv-SE writes a day as `2026-10-12`, which reads as
* a PlainDate a date-time input cannot take but its format can.
*
* @param text - The trimmed clipboard text.
* @param settings - The input's settings.
* @returns The value, or `undefined` when the text names none the input can hold.
*/
function pastedValue(text, settings) {
	const parsed = parseTemporal(text);
	return (parsed._tag === "ok" ? convertToKind(parsed.value, settings.kind) : void 0) ?? formattedValue(text, settings);
}
/**
* Pasted text in a time-only input: ISO text that names a wall-clock time takes that time alone,
* its date, offset and zone dropped (see `parseWallTime`). ISO text of a date alone names no time
* and reads as nothing, rather than its digits as one. A UTC time (`Z`) names an instant, not a
* wall time: it is read as any other text, in the field's own format, which it never matches.
*
* @param text - The trimmed clipboard text.
* @param settings - The input's settings.
* @returns The value on the input's day, or `undefined` when the text names no time it can hold.
*/
function pastedTime(text, settings) {
	const time = parseWallTime(text);
	if (time._tag === "ok") return wallTimeValue(time.value, settings);
	return parseTemporal(text)._tag === "ok" ? void 0 : formattedValue(text, settings);
}
export { pastedTime, pastedValue };

//# sourceMappingURL=date-input-paste.js.map