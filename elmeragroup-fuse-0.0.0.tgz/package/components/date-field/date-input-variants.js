import { cn } from "../../styles/cn.js";
import { tv } from "../../styles/tv.js";
import { dataWithinInvalidFocusRingClass, withinFocusRingClass, withinFocusRingControlClass } from "../../styles/utils.js";
import { dataStateFaceClass } from "../../styles/state-face.js";
import { fieldEntryClass, fieldReads, fieldSize } from "../../styles/field-size.js";
import { fieldBoxChromeClass } from "../../styles/field-box.js";
import { dateInputShellClass } from "../../styles/inner-corner/date-field.js";
// src/components/date-field/date-input-variants.ts
/**
* DateInput's module-private recipe. No entry exports it.
*
* - `root` is the field box around the segments, the box the interim React Aria DateInput paints:
*   the shared field chrome, the field height of its `size`, the md control inset and the text-entry
*   type, floored at 150px wide. Its segments are direct children marked `data-focus-ring-control`,
*   so the box rings while one has keyboard focus. Base UI-style `data-invalid` and `data-disabled`
*   give it the data-target state face, and `data-readonly` the muted read-only fill.
* - `segment` is one segment: a span the box's type sizes, highlighted while focused, muted and
*   italic while it shows its placeholder, muted while disabled. A literal takes no padding.
*/
const dateInputVariants = tv({
	slots: {
		root: cn(fieldBoxChromeClass, fieldReads.height(), fieldEntryClass, dateInputShellClass, "flex w-full min-w-[150px] cursor-text items-center overflow-hidden whitespace-nowrap", dataStateFaceClass, withinFocusRingClass, dataWithinInvalidFocusRingClass, "data-readonly:bg-muted"),
		hiddenInput: "pointer-events-none sr-only",
		segment: cn("inline rounded-inner p-0.5 text-foreground tabular-nums caret-transparent forced-color-adjust-none", withinFocusRingControlClass, "data-[type=literal]:px-0 data-[type=literal]:whitespace-pre", "data-placeholder:text-muted-foreground data-placeholder:italic", "data-disabled:text-muted-foreground forced-colors:data-disabled:text-[GrayText]", "focus:bg-primary focus:text-primary-foreground forced-colors:focus:bg-[Highlight] forced-colors:focus:text-[HighlightText]")
	},
	variants: { size: {
		default: { root: fieldSize({ size: "default" }).box() },
		sm: { root: fieldSize({ size: "sm" }).box() }
	} },
	defaultVariants: { size: "default" }
});
export { dateInputVariants };

//# sourceMappingURL=date-input-variants.js.map