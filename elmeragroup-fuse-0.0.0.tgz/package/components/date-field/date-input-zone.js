"use client";
import { onStandInDay } from "./date-input-scope.js";
import { EMPTY_ZONE_INSTANT, formatInstant, writesZoneName, zoneNameAt } from "./date-field-format.js";
import { useLayoutEffect, useMemo, useState } from "react";
// src/components/date-field/date-input-zone.ts
/**
* The instant an input names a value's zone at: the value's own, or `null` for today while it shows
* no value, or a time on the stand-in day, which names no day anyone chose. The name the segments
* write (`useFieldZoneName`) and the name pasted text must carry (`date-input-paste.ts`) both read
* it, so the input reads back the text it writes.
*
* @param value - The value shown, or `null` for none.
* @param scope - The input's scope.
* @returns The instant in epoch milliseconds, or `null` for today (see `todayInstant`).
*/
function zoneNamingInstant(value, scope) {
	return value === null || onStandInDay(scope) ? null : formatInstant(value);
}
/**
* Today, as `zoneNamingInstant`'s `null` means it: `Date.now()` rather than `Temporal.Now`, so a
* test that fakes `Date` fakes it too, as `today()` does.
*
* @returns Epoch milliseconds.
*/
function todayInstant() {
	return Date.now();
}
/**
* The zone's name a field's segments and description write.
*
* The clock is read once the input has mounted, never while rendering, so the server and the
* hydrating render write the same fixed instant's name (`EMPTY_ZONE_INSTANT`), and only by a field
* that writes a zone name and names it for today (`todayInstant`). The name read is kept, `null`
* while it is the fixed instant's, so a clock read that changes no name renders nothing again.
*
* @param format - The field's format.
* @param instant - The instant the field names its zone at (`zoneNamingInstant`), or `null` for today.
* @returns The name, such as "GMT+2"; empty for a field that writes none.
*/
function useFieldZoneName(format, instant) {
	const readsClock = instant === null && writesZoneName(format);
	const [todayName, setTodayName] = useState(null);
	useLayoutEffect(() => {
		if (readsClock) {
			const name = zoneNameAt(format, todayInstant());
			setTodayName(name === zoneNameAt(format, EMPTY_ZONE_INSTANT) ? null : name);
		}
	}, [readsClock, format]);
	return useMemo(() => {
		if (!writesZoneName(format)) return "";
		return instant === null ? todayName ?? zoneNameAt(format, EMPTY_ZONE_INSTANT) : zoneNameAt(format, instant);
	}, [
		format,
		instant,
		todayName
	]);
}
export { todayInstant, useFieldZoneName, zoneNamingInstant };

//# sourceMappingURL=date-input-zone.js.map