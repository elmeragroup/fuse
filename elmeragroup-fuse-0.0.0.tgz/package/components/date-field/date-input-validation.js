import { checkBounds } from "../../temporal/bounds.js";
import { formatBound } from "./date-field-format.js";
// src/components/date-field/date-input-validation.ts
/**
* A committed value's error against the bounds and `isDateUnavailable`, minimum first.
*
* @param value - The value.
* @param rules - The bounds and the unavailable check.
* @returns The error, or `null`.
*/
function valueError(value, rules) {
	switch (checkBounds(value, rules.bounds)) {
		case "underflow": return "rangeUnderflow";
		case "overflow": return "rangeOverflow";
		case "within": return rules.isDateUnavailable?.(value) === true ? "unavailable" : null;
	}
}
/**
* The input's error: an incomplete entry first, then a missing required value, then the value's
* own.
*
* @param entry - What the segments show.
* @param required - Whether the input needs a value.
* @param rules - The bounds and the unavailable check.
* @returns The error, or `null`.
*/
function entryError(entry, required, rules) {
	switch (entry.kind) {
		case "partial": return "incomplete";
		case "empty": return required ? "valueMissing" : null;
		case "value": return valueError(entry.value, rules);
	}
}
/**
* The message for an error, in the field's locale, with the bound written as React Aria writes it.
*
* @param error - The error.
* @param strings - DateField's strings.
* @param format - The field's format.
* @param bounds - The bounds a range error names.
* @returns The message, such as "Value must be 10/31/2026 or earlier."
*/
function errorMessage(error, strings, format, bounds) {
	switch (error) {
		case "valueMissing": return strings.format("valueMissing");
		case "incomplete": return strings.format("incomplete");
		case "unavailable": return strings.format("unavailableDate");
		case "rangeUnderflow": return bounds.min === void 0 ? strings.format("incomplete") : strings.format("rangeUnderflow", { minValue: formatBound(format, bounds.min) });
		case "rangeOverflow": return bounds.max === void 0 ? strings.format("incomplete") : strings.format("rangeOverflow", { maxValue: formatBound(format, bounds.max) });
	}
}
export { entryError, errorMessage, valueError };

//# sourceMappingURL=date-input-validation.js.map