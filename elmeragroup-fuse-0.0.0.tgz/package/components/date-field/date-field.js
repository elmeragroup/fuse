import { definedProps } from "../../internal/defined-props.js";
import { FieldFrame } from "../field/field-frame.js";
import { DateInputRoot } from "./date-input.js";
import { jsx } from "react/jsx-runtime";
// src/components/date-field/date-field.tsx
/**
* Labeled date field composite over Field and `DateInput`: a label, the segments, the error and
* the description, with the interim React Aria DateField's prop names. Values are Temporal values,
* which a client component builds. The composite itself holds no state, so a server component can
* render it without a value.
*
* @template P - The props, inferred: only their `granularity` and `timeZone` count.
* @template T - The value's kind, inferred as `DateInput.Root`'s is.
*/
function DateField({ label, description, errorMessage, value, defaultValue, onChange, minValue, maxValue, isDateUnavailable, granularity, hourCycle, hideTimeZone, timeZone, shouldForceLeadingZeros = true, name, isDisabled = false, isReadOnly = false, isRequired = false, isInvalid = false, size = "default", className, ...props }) {
	return /* @__PURE__ */ jsx(FieldFrame, {
		className,
		name,
		invalid: isInvalid,
		disabled: isDisabled,
		label,
		description,
		errorMessage,
		isErrorMessageAlwaysShown: isInvalid,
		children: /* @__PURE__ */ jsx(DateInputRoot, {
			...definedProps({
				value,
				defaultValue,
				onValueChange: onChange,
				minValue,
				maxValue,
				isDateUnavailable,
				granularity,
				hourCycle,
				hideTimeZone,
				timeZone,
				"aria-label": props["aria-label"]
			}),
			shouldForceLeadingZeros,
			readOnly: isReadOnly,
			required: isRequired,
			invalid: isInvalid,
			size
		})
	});
}
DateField.displayName = "DateField";
export { DateField };

//# sourceMappingURL=date-field.js.map