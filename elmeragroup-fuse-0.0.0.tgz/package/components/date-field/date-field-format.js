import { dateTimeFormat } from "../../internal/intl-cache.js";
import { canonicalSpaces } from "../../intl/canonical-spaces.js";
import { formatDateTime, formatDateTimeToParts } from "../../intl/date-time-join.js";
import { scopeShows } from "./date-input-scope.js";
// src/components/date-field/date-field-format.ts
/** U+2066, which React Aria writes before a time so it reads left to right in any direction. */
const LEFT_TO_RIGHT_ISOLATE = String.fromCodePoint(8294);
/** U+2069, which closes {@link LEFT_TO_RIGHT_ISOLATE} after the time's last segment. */
const POP_DIRECTIONAL_ISOLATE = String.fromCodePoint(8297);
/**
* The hour cycle a locale shows, or the one `hourCycle` asks for. The four Fuse locales write
* `h12` or `h23`; a locale's `h11` or `h24` reads as its nearest.
*
* @param locale - The locale.
* @param hourCycle - React Aria's `hourCycle` prop: `12`, `24`, or `undefined` for the locale's.
* @returns The hour cycle.
*/
function resolveHourCycle(locale, hourCycle) {
	if (hourCycle !== void 0) return hourCycle === 12 ? "h12" : "h23";
	const resolved = dateTimeFormat(locale, {
		hour: "numeric",
		timeZone: "UTC"
	}).resolvedOptions().hourCycle;
	return resolved === "h11" || resolved === "h12" ? "h12" : "h23";
}
const FIELD_KEYS = [
	"year",
	"month",
	"day",
	"hour",
	"minute",
	"second"
];
/**
* The Intl options a field writes its value with, as React Aria's `getFormatOptions`: year to
* granularity, numeric with two-digit minutes and seconds, or two-digit days, months and hours when
* leading zeros are forced; the zone name for a zoned field with a time unless hidden.
*
* @param format - The field's format.
* @param overrides - Options that replace a field's style, such as a long month.
* @returns The options, with the zone the field formats in.
*/
function fieldFormatOptions(format, overrides = {}) {
	const twoDigit = format.forceLeadingZeros;
	const styles = {
		year: "numeric",
		month: twoDigit ? "2-digit" : "numeric",
		day: twoDigit ? "2-digit" : "numeric",
		hour: twoDigit ? "2-digit" : "numeric",
		minute: "2-digit",
		second: "2-digit",
		...overrides
	};
	const last = FIELD_KEYS.indexOf(format.granularity);
	const options = { timeZone: format.timeZone ?? "UTC" };
	for (const key of FIELD_KEYS.slice(0, last + 1).filter((unit) => scopeShows(format.scope, unit))) Object.assign(options, { [key]: styles[key] });
	if (format.granularity !== "day") {
		options.hourCycle = format.hourCycle;
		if (format.timeZone !== void 0 && !format.hideTimeZone) options.timeZoneName = "short";
	}
	return options;
}
/** An instant whose UTC fields are `fields`, for years below 100 too. */
function utcInstant(fields) {
	const date = /* @__PURE__ */ new Date(0);
	date.setUTCFullYear(fields.year, fields.month - 1, fields.day);
	date.setUTCHours(fields.hour ?? 0, fields.minute ?? 0, fields.second ?? 0, 0);
	return date.getTime();
}
/**
* The instant Intl formats a value at: a zoned value's own instant, which the field formats in its
* zone; a plain value's fields as UTC, which the field formats in UTC.
*
* @param value - The value.
* @returns Epoch milliseconds.
*/
function formatInstant(value) {
	return "epochMilliseconds" in value ? value.epochMilliseconds : utcInstant(value);
}
/** The instant the layout formats: one past noon, so no zone moves it to another day or period. */
const LAYOUT_INSTANT = utcInstant({
	year: 2001,
	month: 1,
	day: 1,
	hour: 13
});
/**
* A field's parts in display order, from `formatToParts` of the layout instant, with React Aria's
* isolates around the time: U+2066 before the hour and U+2069 after the granularity's segment.
* Engines write the literal between a date and a time from their own CLDR data, which differs
* between versions, so the layout takes the join Fuse owns (`date-time-join.ts`), as the
* validation copy does.
*
* @param format - The field's format.
* @returns The parts.
*/
function fieldParts(format) {
	const parts = formatDateTimeToParts(format.locale, fieldFormatOptions(format), LAYOUT_INSTANT);
	const result = [];
	for (const part of parts) {
		const type = part.type;
		switch (type) {
			case "year":
			case "month":
			case "day":
			case "hour":
			case "minute":
			case "second":
			case "dayPeriod":
				if (type === "hour") result.push({
					kind: "literal",
					text: LEFT_TO_RIGHT_ISOLATE
				});
				result.push({
					kind: "segment",
					type
				});
				if (type === format.granularity && type !== "day") result.push({
					kind: "literal",
					text: POP_DIRECTIONAL_ISOLATE
				});
				break;
			case "timeZoneName":
				result.push({ kind: "timeZoneName" });
				break;
			default: result.push({
				kind: "literal",
				text: part.value
			});
		}
	}
	return result;
}
/** The locale's words for before and after noon, as the field writes its day period. */
function dayPeriodNames(locale) {
	const formatter = dateTimeFormat(locale, {
		hour: "numeric",
		hourCycle: "h12",
		timeZone: "UTC"
	});
	const name = (hour) => formatter.formatToParts(utcInstant({
		year: 2001,
		month: 1,
		day: 1,
		hour
	})).find((part) => part.type === "dayPeriod")?.value ?? "";
	return [name(0), name(12)];
}
const ENGLISH_PLACEHOLDERS = {
	year: "yyyy",
	month: "mm",
	day: "dd"
};
const DATE_PLACEHOLDERS = /* @__PURE__ */ new Map([
	["en", ENGLISH_PLACEHOLDERS],
	["nb", {
		year: "åååå",
		month: "mm",
		day: "dd"
	}],
	["sv", {
		year: "åååå",
		month: "mm",
		day: "dd"
	}],
	["fi", {
		year: "vvvv",
		month: "kk",
		day: "pp"
	}]
]);
/** Each locale's date placeholders, read once per locale rather than per segment. */
const placeholdersByLocale = /* @__PURE__ */ new Map();
function datePlaceholders(locale) {
	let placeholders = placeholdersByLocale.get(locale);
	if (placeholders === void 0) {
		placeholders = DATE_PLACEHOLDERS.get(new Intl.Locale(locale).language) ?? ENGLISH_PLACEHOLDERS;
		placeholdersByLocale.set(locale, placeholders);
	}
	return placeholders;
}
/** Two en dashes, React Aria's placeholder for every time segment. */
const TIME_PLACEHOLDER = "––";
/**
* The text an empty segment shows: React Aria's per-language letters for the date, two en dashes
* for the time, and the morning's word for the day period.
*
* @param type - The segment.
* @param locale - The locale.
* @returns The placeholder.
*/
function segmentPlaceholder(type, locale) {
	if (type === "year" || type === "month" || type === "day") return datePlaceholders(locale)[type];
	return type === "dayPeriod" ? dayPeriodNames(locale)[0] : TIME_PLACEHOLDER;
}
/**
* The text a filled segment shows. The draft's own number is written, not a formatted value, so a
* day typed before its month, such as 31 in February, shows as typed until the field commits.
*
* @param type - The segment.
* @param draft - The draft, whose `type` is filled.
* @param resolved - The field formatter's resolved options.
* @param locale - The locale, for the day period's word.
* @returns The text.
*/
function segmentText(type, draft, resolved, locale) {
	if (type === "dayPeriod") return dayPeriodNames(locale)[draft.dayPeriod ?? 0];
	const value = draft[type] ?? 0;
	return type === "minute" || type === "second" || type !== "year" && resolved[type] === "2-digit" ? String(value).padStart(2, "0") : String(value);
}
/**
* A month's long name, which a month segment adds to its spoken value.
*
* @param locale - The locale.
* @param month - The month, 1–12.
* @returns The name, such as "October".
*/
function monthName(locale, month) {
	return dateTimeFormat(locale, {
		month: "long",
		timeZone: "UTC"
	}).format(utcInstant({
		year: 2001,
		month,
		day: 1
	}));
}
/**
* An hour as the locale says it alone, which an hour segment speaks: "2 PM" in en-US, "14" in nb-NO.
*
* @param locale - The locale.
* @param hour - The hour, 0–23.
* @param hourCycle - The hour cycle shown.
* @returns The text.
*/
function hourName(locale, hour, hourCycle) {
	return dateTimeFormat(locale, {
		hour: "numeric",
		hourCycle,
		timeZone: "UTC"
	}).format(utcInstant({
		year: 2001,
		month: 1,
		day: 1,
		hour
	}));
}
/**
* The zone's short name at an instant, which a zoned field shows after its time.
*
* @param locale - The locale.
* @param timeZone - The zone.
* @param instant - Epoch milliseconds, since a zone's name changes with DST.
* @returns The name, such as "GMT+2" or "EST".
*/
function timeZoneNameText(locale, timeZone, instant) {
	return dateTimeFormat(locale, {
		timeZone,
		timeZoneName: "short",
		hour: "numeric"
	}).formatToParts(instant).find((part) => part.type === "timeZoneName")?.value ?? timeZone;
}
/**
* A value written in the field's format with a long month, for the "Selected Date" description.
* The zone's name is the one the field's segments write (see `useFieldZoneName`), so a time held on
* the stand-in day is described in today's zone name, as it is shown. Spaces are canonical, since
* the description is server-rendered and engines write different ones.
*
* @param format - The field's format.
* @param value - The value.
* @param zoneName - The zone's name the field writes, which replaces the value's own.
* @returns The text, such as "October 05, 2026".
*/
function describeValue(format, value, zoneName) {
	return canonicalSpaces(formatDateTimeToParts(format.locale, fieldFormatOptions(format, { month: "long" }), formatInstant(value)).map((part) => part.type === "timeZoneName" ? zoneName : part.value).join(""));
}
/**
* A bound as a validation message writes it, on the clock `checkBounds` compares it by: a zoned
* field prints a zoned bound's instant in the field's zone and a plain bound's wall clock as that
* zone's; a plain field prints any bound's own wall clock, a zoned bound's included, since a plain
* value is compared with it there.
*
* @param format - The field's format.
* @param bound - The bound, of any kind.
* @returns The text, such as "10/31/2026, 23:30".
*/
function formatBound(format, bound) {
	let instant;
	if (format.timeZone === void 0) instant = formatInstant("timeZoneId" in bound ? bound.toPlainDateTime() : bound);
	else if ("epochMilliseconds" in bound) instant = bound.epochMilliseconds;
	else instant = ("hour" in bound ? bound : bound.toPlainDateTime()).toZonedDateTime(format.timeZone, { disambiguation: "compatible" }).epochMilliseconds;
	return formatDateTime(format.locale, fieldFormatOptions(format), instant);
}
/**
* A field's segments in display order: the literals, the zone's name and each unit, written from
* the draft or as its placeholder.
*
* @param format - The field's format.
* @param draft - What the segments show.
* @param zoneName - The zone's name a field that writes one shows (see `zoneNameAt`).
* @returns The segments.
*/
function fieldSegments(format, draft, zoneName) {
	const resolved = dateTimeFormat(format.locale, fieldFormatOptions(format)).resolvedOptions();
	return fieldParts(format).map((part, index) => {
		switch (part.kind) {
			case "literal": return {
				type: "literal",
				index,
				text: part.text,
				isPlaceholder: false,
				isEditable: false
			};
			case "timeZoneName": return {
				type: "timeZoneName",
				index,
				text: zoneName,
				isPlaceholder: false,
				isEditable: false
			};
			case "segment": {
				const isPlaceholder = draft[part.type] === null;
				return {
					type: part.type,
					index,
					text: isPlaceholder ? segmentPlaceholder(part.type, format.locale) : segmentText(part.type, draft, resolved, format.locale),
					isPlaceholder,
					isEditable: true
				};
			}
		}
	});
}
/**
* Whether a field writes its zone's name: a zoned field with a time that does not hide it.
*
* @param format - The field's format.
* @returns Whether its segments hold the zone's name.
*/
function writesZoneName(format) {
	return fieldFormatOptions(format).timeZoneName !== void 0;
}
/**
* The zone's name a field writes at an instant, which changes with summer time.
*
* @param format - The field's format.
* @param instant - Epoch milliseconds.
* @returns The name, such as "GMT+2"; a plain field's is UTC's.
*/
function zoneNameAt(format, instant) {
	return timeZoneNameText(format.locale, format.timeZone ?? "UTC", instant);
}
/**
* The instant a field with no value names its zone at before it has read the clock: January 1,
* 2001, which the server and the hydrating render write alike. The input reads today once mounted.
*/
const EMPTY_ZONE_INSTANT = utcInstant({
	year: 2001,
	month: 1,
	day: 1
});
export { EMPTY_ZONE_INSTANT, LEFT_TO_RIGHT_ISOLATE, POP_DIRECTIONAL_ISOLATE, dayPeriodNames, describeValue, fieldParts, fieldSegments, formatBound, formatInstant, hourName, monthName, resolveHourCycle, writesZoneName, zoneNameAt };

//# sourceMappingURL=date-field-format.js.map