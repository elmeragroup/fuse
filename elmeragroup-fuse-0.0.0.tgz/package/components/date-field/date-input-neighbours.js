"use client";
import { createContext } from "react";
// src/components/date-field/date-input-neighbours.ts
/** The neighbour lookup of the control around a DateInput; none outside such a control. */
const DateInputNeighbourContext = createContext(void 0);
export { DateInputNeighbourContext };

//# sourceMappingURL=date-input-neighbours.js.map