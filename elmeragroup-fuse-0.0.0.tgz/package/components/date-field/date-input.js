"use client";
import { cn } from "../../styles/cn.js";
import { useLocale } from "../../intl/locale-context.js";
import { useLocalizedStrings } from "../../hooks/use-localized-strings.js";
import { isElement, isNode } from "../../internal/dom-node.js";
import { definedProps } from "../../internal/defined-props.js";
import { displayNames } from "../../internal/intl-cache.js";
import { createChangeEventDetails } from "../calendar/calendar-change-details.js";
import { createCalendarStore } from "../calendar/calendar-store.js";
import { temporal } from "../../temporal/temporal.js";
import { useTemporalProp } from "../calendar/calendar-input.js";
import { today } from "../../temporal/today.js";
import { useFormReset } from "../../hooks/use-form-reset.js";
import { draftOf, editableSegments, placeholderValue } from "./date-draft.js";
import { DateInputScopeContext, scopeShows, standInDay } from "./date-input-scope.js";
import { dayPeriodNames, describeValue, fieldSegments, resolveHourCycle } from "./date-field-format.js";
import { readFieldText } from "./date-field-text.js";
import { DateInputRootContext } from "./date-input-context.js";
import { useDateInputField } from "./date-input-field.js";
import { DateInputNeighbourContext } from "./date-input-neighbours.js";
import { dateInputVariants } from "./date-input-variants.js";
import { DateInputSegment } from "./date-input-segment.js";
import { basisOf, canceled, confirm, draftOver, entryOf, erase, focusEntered, initialSession, paste, rebase, resetSession, segmentFocused, step, toEdge, typeKey } from "./date-input-session.js";
import { entryError, errorMessage, valueError } from "./date-input-validation.js";
import { todayInstant, useFieldZoneName, zoneNamingInstant } from "./date-input-zone.js";
import { dateFieldStrings } from "./intl/index.js";
import { useValueKind } from "./use-value-kind.js";
import { Fragment, use, useCallback, useId, useLayoutEffect, useMemo, useRef, useState, useSyncExternalStore } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
// src/components/date-field/date-input.tsx
/** The part diagnostics name. */
const OWNER = "DateInput.Root";
/** React Aria's page steps: Page Up and Page Down move a segment this far. */
const PAGE_STEP = {
	year: 5,
	month: 2,
	day: 7,
	hour: 2,
	minute: 15,
	second: 15,
	dayPeriod: 1
};
function isIOS() {
	const { platform, maxTouchPoints } = navigator;
	return /^iP(?:hone|ad|od)/u.test(platform) || platform.startsWith("Mac") && maxTouchPoints > 1;
}
const noSubscription = () => () => void 0;
function useIsIOS() {
	return useSyncExternalStore(noSubscription, isIOS, () => false);
}
/** A Root element's focusable segments, in document order. */
function focusableSegments(root) {
	return [...root?.querySelectorAll("[data-slot=\"date-input-segment\"][tabindex]") ?? []];
}
/** Focus the last segment before `target`, then back over empty ones, as React Aria's field press. */
function focusBefore(root, target) {
	const list = focusableSegments(root);
	const before = isNode(target) && target !== root ? list.filter((element) => (element.compareDocumentPosition(target) & Node.DOCUMENT_POSITION_FOLLOWING) !== 0) : list;
	let index = (before.length > 0 ? before : list).length - 1;
	while (index > 0 && list[index]?.hasAttribute("data-placeholder") === true && list[index - 1]?.hasAttribute("data-placeholder") === true) index -= 1;
	list[index]?.focus();
}
/**
* Focus the segment `direction` places from `from` among the Root's focusable segments; past the
* first or last, the nearest segment of the input beside this one, when a control owns both.
*/
function focusSibling(root, from, direction, neighbour) {
	const list = focusableSegments(root);
	const index = list.findIndex((element) => element === from);
	if (index < 0) return;
	const sibling = list[index + (direction === "next" ? 1 : -1)];
	if (sibling !== void 0) {
		sibling.focus();
		return;
	}
	const segments = focusableSegments(root === null ? null : neighbour?.(root, direction) ?? null);
	(direction === "next" ? segments[0] : segments.at(-1))?.focus();
}
/** The transition a key makes on a segment, or `undefined` for a key the segment leaves alone. */
function keyTransition(key, type, page, settings, state) {
	switch (key) {
		case "ArrowUp": return step(state, type, 1, settings);
		case "ArrowDown": return step(state, type, -1, settings);
		case "PageUp": return step(state, type, page, settings);
		case "PageDown": return step(state, type, -page, settings);
		case "Home": return toEdge(state, type, "min", settings);
		case "End": return toEdge(state, type, "max", settings);
		default: return;
	}
}
const ROOT_STATE_ATTRIBUTES = { invalid: (value) => value ? { "data-invalid": "true" } : null };
/**
* A date, date-time or zoned date-time edited in segments: one per unit, in the locale's order,
* with the locale's literals between them. Typing fills a segment and moves on, arrow keys step
* it, Backspace clears it; the value commits once every segment is filled. It is a `group` named
* by its Field's label, `aria-label` or `aria-labelledby`, and each segment's name starts with its
* unit: "month, Start date".
*
* Inside a Base UI Field (`Field.Root`, Fuse's `Field` or a labeled composite) the first editable
* segment is the Field's control: a `Form` focuses it for an error, its value reaches
* `onFormSubmit` as ISO text, and its validity (missing, incomplete, out of bounds, unavailable)
* is the Field's, committed on blur and on submit. A visually hidden text input submits the ISO
* value under `name` in a native form.
*
* Values are Temporal values; it reads `globalThis.Temporal`, so a host without native Temporal
* imports `@elmeragroup/fuse/temporal-polyfill` once. It never reads the clock while rendering:
* today fills an empty segment only when the user steps it.
*
* @template P - The props, inferred: only their `granularity` and `timeZone` count.
* @template T - The value's kind, inferred: the kind `value` or `defaultValue` names, and without
*   either the kind `granularity` and `timeZone` make, as the runtime resolves it.
* @throws TypeError naming the prop and the fix when `value`, `defaultValue`, `minValue` or
*   `maxValue` is a string rather than a Temporal object, or when a time `granularity` meets a
*   PlainDate value: host defects.
*/
function DateInputRoot(props) {
	const { value: valueProp, defaultValue, onValueChange, minValue, maxValue, isDateUnavailable, granularity: granularityProp, hourCycle: hourCycleProp, hideTimeZone = false, timeZone: timeZoneProp, shouldForceLeadingZeros = false, disabled: disabledProp = false, readOnly = false, required = false, invalid: invalidProp = false, name: nameProp, form, size = "default", children, className, render, ref, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledBy, "aria-describedby": ariaDescribedBy, ...elementProps } = props;
	const { locale, timeZone: localeTimeZone } = useLocale();
	const strings = useLocalizedStrings(dateFieldStrings);
	const ios = useIsIOS();
	const neighbour = use(DateInputNeighbourContext);
	const inputScope = use(DateInputScopeContext);
	const scope = inputScope.units;
	const controlled = valueProp !== void 0;
	const parsedValue = useTemporalProp(valueProp, OWNER, "value");
	const parsedDefault = useTemporalProp(defaultValue, OWNER, "defaultValue");
	const minBound = useTemporalProp(minValue, OWNER, "minValue") ?? void 0;
	const maxBound = useTemporalProp(maxValue, OWNER, "maxValue") ?? void 0;
	const hourCycle = resolveHourCycle(locale, hourCycleProp);
	const [store] = useState(() => createCalendarStore(initialSession(parsedDefault, "")));
	const session = useSyncExternalStore(store.subscribe, store.get, () => store.initial);
	const committed = controlled ? parsedValue : session.own;
	const { kind } = useValueKind({
		value: committed,
		defaultValue: parsedDefault,
		granularity: granularityProp,
		timeZone: timeZoneProp
	}, OWNER, inputScope.units === "time" ? { supplied: inputScope.kind } : { warnOnKindChange: true });
	const granularity = granularityProp ?? (kind.kind === "PlainDate" ? "day" : "minute");
	const zone = kind.kind === "ZonedDateTime" ? kind.timeZone : void 0;
	const format = useMemo(() => ({
		locale,
		granularity,
		hourCycle,
		forceLeadingZeros: shouldForceLeadingZeros,
		timeZone: zone,
		hideTimeZone,
		scope
	}), [
		locale,
		granularity,
		hourCycle,
		shouldForceLeadingZeros,
		zone,
		hideTimeZone,
		scope
	]);
	const fields = useMemo(() => editableSegments(granularity, hourCycle).filter((type) => scopeShows(scope, type)), [
		granularity,
		hourCycle,
		scope
	]);
	const readText = useCallback((text) => readFieldText(format, text), [format]);
	const basis = basisOf(committed, hourCycle, fields, scope);
	const valueDraft = useMemo(() => draftOf(committed, hourCycle), [committed, hourCycle]);
	const draft = draftOver(session, basis) ?? valueDraft;
	const bounds = useMemo(() => ({
		min: minBound,
		max: maxBound
	}), [minBound, maxBound]);
	const rules = useMemo(() => ({
		bounds,
		isDateUnavailable
	}), [bounds, isDateUnavailable]);
	const entry = entryOf(session, committed, basis);
	const currentError = entryError(entry, required, rules);
	const message = currentError === null ? "" : errorMessage(currentError, strings, format, bounds);
	const iso = committed === null ? "" : committed.toString();
	const rootRef = useRef(null);
	const firstSegment = useMemo(() => ({ get current() {
		return rootRef.current?.querySelector("[data-slot=\"date-input-segment\"][tabindex]") ?? null;
	} }), []);
	const fallbackId = useId();
	const field = useDateInputField({
		name: nameProp,
		disabled: disabledProp,
		invalid: invalidProp,
		iso,
		error: currentError,
		message,
		firstSegment
	}, fallbackId);
	const { disabled, invalid, hiddenInput, hiddenInputId, labelId, setFocused, blurred, revalidate } = field;
	useLayoutEffect(() => {
		const before = store.get();
		const after = rebase(before, basis);
		store.set(after);
		if (before.draft !== null && after.draft === null) revalidate();
	}, [
		store,
		basis,
		revalidate
	]);
	const zoneName = useFieldZoneName(format, zoneNamingInstant(committed, inputScope));
	const segments = useMemo(() => fieldSegments(format, draft, zoneName), [
		format,
		draft,
		zoneName
	]);
	const firstEditableIndex = segments.find((segment) => segment.type !== "literal")?.index ?? -1;
	const placeholderZone = zone ?? localeTimeZone;
	const settings = useMemo(() => ({
		committed,
		controlled,
		editable: !disabled && !readOnly,
		fields,
		units: scope,
		readText,
		zoneInstant: (value) => zoneNamingInstant(value, inputScope) ?? todayInstant(),
		hourCycle,
		kind,
		dayPeriods: dayPeriodNames(locale),
		locale,
		placeholder: () => placeholderValue(inputScope.units === "time" ? inputScope.day ?? standInDay() : today(placeholderZone ?? temporal().Now.timeZoneId()), kind)
	}), [
		committed,
		controlled,
		disabled,
		readOnly,
		fields,
		scope,
		readText,
		hourCycle,
		kind,
		locale,
		placeholderZone,
		inputScope
	]);
	const eventProps = useRef({
		settings,
		rules,
		onValueChange,
		neighbour
	});
	useLayoutEffect(() => {
		eventProps.current = {
			settings,
			rules,
			onValueChange,
			neighbour
		};
	});
	/** Applies a transition: reports its commit, keeps the edit unless the commit is canceled. */
	const run = useCallback((transition, event, trigger) => {
		const before = store.get();
		const { commit } = transition;
		if (commit !== void 0) {
			const details = createChangeEventDetails(commit.reason, event, trigger, { getValidationError: () => commit.value === null ? null : valueError(commit.value, eventProps.current.rules) });
			eventProps.current.onValueChange?.(commit.value, details);
			if (details.isCanceled) {
				store.set(canceled(before));
				return;
			}
		}
		store.set(transition.state);
		if (transition.focus !== void 0 && trigger !== void 0) focusSibling(rootRef.current, trigger, transition.focus, eventProps.current.neighbour);
	}, [store]);
	const actions = useMemo(() => ({
		keyDown(segment, event) {
			const { settings: current } = eventProps.current;
			const { currentTarget, nativeEvent } = event;
			if (event.ctrlKey || event.metaKey || event.altKey) return;
			if (event.key === "ArrowLeft" || event.key === "ArrowRight") {
				event.preventDefault();
				focusSibling(rootRef.current, currentTarget, event.key === "ArrowRight" ? "next" : "previous", eventProps.current.neighbour);
				return;
			}
			if (event.key === "Backspace" || event.key === "Delete") {
				event.preventDefault();
				if (segment.isEditable) run(erase(store.get(), segment, current), nativeEvent, currentTarget);
				return;
			}
			if (!segment.isEditable || !current.editable) return;
			const transition = keyTransition(event.key, segment.type, PAGE_STEP[segment.type], current, store.get());
			if (transition !== void 0) {
				event.preventDefault();
				run(transition, nativeEvent, currentTarget);
			}
		},
		erase(segment, event, target) {
			run(erase(store.get(), segment, eventProps.current.settings), event, target);
		},
		type(type, key, event, target) {
			run(typeKey(store.get(), type, key, eventProps.current.settings), event, target);
		},
		segmentFocused() {
			store.set(segmentFocused(store.get()));
		},
		segmentRemoved(element) {
			const list = focusableSegments(rootRef.current);
			const index = list.indexOf(element);
			if (index >= 0) (list[index - 1] ?? list[index + 1])?.focus();
		}
	}), [store, run]);
	useFormReset(hiddenInput, controlled ? null : () => {
		store.set(resetSession(parsedDefault, hourCycle, fields, scope));
		field.reset();
	});
	const description = committed === null ? void 0 : scope === "time" ? strings.format("selectedTimeDescription", { time: describeValue(format, committed, zoneName) }) : strings.format("selectedDateDescription", { date: describeValue(format, committed, zoneName) });
	const descriptionId = `${fallbackId}-description`;
	const describedBy = [
		description === void 0 ? void 0 : descriptionId,
		ariaDescribedBy,
		field.describedBy
	].filter((id) => id !== void 0 && id !== "").join(" ") || void 0;
	const labelledBy = ariaLabelledBy ?? labelId;
	const segmentName = useCallback((type) => {
		try {
			return displayNames(locale, { type: "dateTimeField" }).of(type) ?? strings.format(type);
		} catch {
			return strings.format(type);
		}
	}, [locale, strings]);
	const context = useMemo(() => ({
		disabled,
		readOnly,
		required,
		invalid,
		ios,
		locale,
		hourCycle,
		draft,
		firstEditableIndex,
		ariaLabel,
		ariaLabelledBy: labelledBy,
		describedBy,
		segmentName,
		emptyText: strings.format("empty"),
		actions
	}), [
		disabled,
		readOnly,
		required,
		invalid,
		ios,
		locale,
		hourCycle,
		draft,
		firstEditableIndex,
		ariaLabel,
		labelledBy,
		describedBy,
		segmentName,
		strings,
		actions
	]);
	const state = useMemo(() => ({
		disabled,
		readonly: readOnly,
		required,
		invalid,
		empty: entry.kind === "empty"
	}), [
		disabled,
		readOnly,
		required,
		invalid,
		entry.kind
	]);
	const element = useRender({
		defaultTagName: "div",
		render,
		ref: ref === void 0 ? rootRef : [rootRef, ref],
		state,
		stateAttributesMapping: ROOT_STATE_ATTRIBUTES,
		props: {
			"data-slot": "field-group",
			"data-size": size,
			...mergeProps({
				role: "group",
				"aria-label": ariaLabel,
				"aria-labelledby": labelledBy,
				"aria-describedby": describedBy,
				"aria-disabled": disabled || void 0,
				className: cn(dateInputVariants({ size }).root(), className),
				style: { unicodeBidi: "isolate" },
				onFocus(event) {
					if (isNode(event.relatedTarget) && event.currentTarget.contains(event.relatedTarget)) return;
					store.set(focusEntered(store.get()));
					setFocused(true);
				},
				onBlur(event) {
					if (isNode(event.relatedTarget) && event.currentTarget.contains(event.relatedTarget)) return;
					run(confirm(store.get(), eventProps.current.settings), event.nativeEvent, void 0);
					blurred(store.get().edited);
				},
				onPointerDown(event) {
					if (disabled || event.pointerType !== "mouse") return;
					event.preventDefault();
					focusBefore(event.currentTarget, event.target);
				},
				onPointerUp(event) {
					if (disabled || event.pointerType === "mouse") return;
					if (isElement(event.target) && event.target.closest("[data-slot=\"date-input-segment\"][tabindex]") !== null) return;
					focusBefore(event.currentTarget, event.target);
				},
				onPaste(event) {
					event.preventDefault();
					const trigger = isElement(event.target) ? event.target : void 0;
					run(paste(store.get(), event.clipboardData.getData("text"), eventProps.current.settings), event.nativeEvent, trigger);
				},
				children: segments.map((segment) => children === void 0 ? /* @__PURE__ */ jsx(DateInputSegment, { segment }, segmentKey(segment)) : /* @__PURE__ */ jsx(Fragment, { children: children(segment) }, segmentKey(segment)))
			}, definedProps(elementProps))
		}
	});
	return /* @__PURE__ */ jsxs(DateInputRootContext, {
		value: context,
		children: [
			element,
			/* @__PURE__ */ jsx("input", {
				ref: hiddenInput,
				id: hiddenInputId,
				type: "text",
				tabIndex: -1,
				"aria-hidden": true,
				name: field.name,
				form,
				value: iso,
				onChange: noChange,
				disabled,
				onFocus: () => firstSegment.current?.focus(),
				className: dateInputVariants().hiddenInput()
			}),
			description === void 0 ? null : /* @__PURE__ */ jsx("span", {
				id: descriptionId,
				hidden: true,
				children: description
			})
		]
	});
}
/**
* A segment's React key: a unit or the zone's name by its type, which appears once, so a unit keeps
* its element (and focus) when a granularity change adds or removes others around it, and a removed
* unit unmounts rather than turning into its neighbour; a literal by its place.
*/
function segmentKey(segment) {
	return segment.type === "literal" ? `literal-${String(segment.index)}` : segment.type;
}
function noChange() {}
export { DateInputRoot, DateInputSegment };

//# sourceMappingURL=date-input.js.map