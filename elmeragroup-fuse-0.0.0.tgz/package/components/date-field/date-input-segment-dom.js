"use client";
import { isInputEvent } from "../../internal/dom-node.js";
import { hasFocus } from "../../internal/active-element.js";
import { useCallback, useLayoutEffect, useRef } from "react";
// src/components/date-field/date-input-segment-dom.ts
/**
* A callback ref that wires a segment element's `beforeinput`, `input` and the document's
* `selectionchange` while it is mounted, reading the latest handlers at event time.
*
* @param handlers - The segment's handlers this render.
* @returns The ref to put on the segment element.
*/
function useSegmentInput(handlers) {
	const latest = useRef(handlers);
	useLayoutEffect(() => {
		latest.current = handlers;
	});
	return useCallback((element) => {
		if (element === null) return;
		const document = element.ownerDocument;
		let composed = null;
		function onBeforeInput(event) {
			if (element === null || !isInputEvent(event, element) || !latest.current.editable) return;
			switch (event.inputType) {
				case "deleteContentBackward":
				case "deleteContentForward":
					event.preventDefault();
					latest.current.erase(event);
					return;
				case "insertCompositionText":
					composed = element.textContent;
					element.textContent = element.textContent;
					return;
				default:
					event.preventDefault();
					for (const character of event.data ?? "") latest.current.type(character, event);
			}
		}
		function onInput(event) {
			if (element === null || !isInputEvent(event, element) || event.inputType !== "insertCompositionText") return;
			element.textContent = composed;
			if (event.data !== null && latest.current.editable && latest.current.dayPeriod) latest.current.type(event.data, event);
		}
		function onSelectionChange() {
			if (element === null || !hasFocus(element) || !latest.current.editable) return;
			const selection = document.getSelection();
			if (selection?.anchorNode != null && element.contains(selection.anchorNode)) selection.collapse(element);
		}
		element.addEventListener("beforeinput", onBeforeInput);
		element.addEventListener("input", onInput);
		document.addEventListener("selectionchange", onSelectionChange);
		return () => {
			element.removeEventListener("beforeinput", onBeforeInput);
			element.removeEventListener("input", onInput);
			document.removeEventListener("selectionchange", onSelectionChange);
		};
	}, []);
}
export { useSegmentInput };

//# sourceMappingURL=date-input-segment-dom.js.map