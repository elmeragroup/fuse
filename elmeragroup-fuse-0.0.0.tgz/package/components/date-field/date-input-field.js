"use client";
import { useCallback, useLayoutEffect, useMemo, useRef, useState } from "react";
import { useFieldRootContext } from "@base-ui/react/internals/field-root-context";
import { DEFAULT_VALIDITY_STATE } from "@base-ui/react/internals/field-constants";
import { useRegisterFieldControl } from "@base-ui/react/internals/field-register-control";
import { useFormContext } from "@base-ui/react/internals/form-context";
import { useLabelableContext } from "@base-ui/react/internals/labelable-provider";
import { NOOP } from "@base-ui/react/internals/noop";
import { useValueChanged } from "@base-ui/react/internals/useValueChanged";
// src/components/date-field/date-input-field.ts
/**
* Registers a date input with its Field and Form, and keeps its validity on the hidden input.
*
* @param options - What the integration reads.
* @param fallbackId - An id for the hidden input outside a Field.
* @returns The answers and actions.
*/
function useDateInputField(options, fallbackId) {
	const { iso, error, message, firstSegment } = options;
	const field = useFieldRootContext();
	const labelable = useLabelableContext();
	const { clearErrors } = useFormContext();
	const inField = field.setValidityData !== NOOP;
	const disabled = options.disabled || field.disabled === true;
	const name = field.name ?? options.name;
	const hiddenInputId = labelable.controlId ?? `${fallbackId}-input`;
	const hiddenInput = useRef(null);
	const [shownError, setShownError] = useState(null);
	const { validation, setFilled, setDirty, setTouched, setFocused, setValidityData } = field;
	useLayoutEffect(() => {
		if (!inField) return;
		const { inputRef } = validation;
		const node = hiddenInput.current;
		inputRef.current = node;
		return () => {
			if (inputRef.current === node) inputRef.current = null;
		};
	}, [inField, validation]);
	const getValue = useCallback(() => hiddenInput.current?.value ?? "", []);
	useRegisterFieldControl(firstSegment, hiddenInputId, iso, getValue, !disabled, name);
	useLayoutEffect(() => {
		hiddenInput.current?.setCustomValidity(message);
	}, [message]);
	useLayoutEffect(() => {
		setFilled(iso !== "");
	}, [iso, setFilled]);
	const resetting = useRef(false);
	const initialValue = field.validityData.initialValue;
	useValueChanged(iso, () => {
		clearErrors(name);
		if (resetting.current) {
			validation.change(iso, true);
			return;
		}
		setDirty(iso !== initialValue);
		validation.change(iso);
		setShownError((shown) => shown === null ? null : error);
	});
	useLayoutEffect(() => {
		resetting.current = false;
	});
	const [validationRequest, setValidationRequest] = useState(0);
	const handledRequest = useRef(0);
	useLayoutEffect(() => {
		if (handledRequest.current === validationRequest) return;
		handledRequest.current = validationRequest;
		setShownError(error);
		validation.commit(iso);
	}, [
		validationRequest,
		error,
		iso,
		validation
	]);
	const blurred = useCallback((edited) => {
		setFocused(false);
		setTouched(true);
		if (edited) setValidationRequest((request) => request + 1);
	}, [setFocused, setTouched]);
	const errorShown = shownError !== null || field.state.valid === false;
	const revalidate = useCallback(() => {
		if (errorShown) setValidationRequest((request) => request + 1);
	}, [errorShown]);
	const reset = useCallback(() => {
		resetting.current = true;
		setShownError(null);
		setDirty(false);
		setTouched(false);
		setValidityData((data) => ({
			...data,
			state: DEFAULT_VALIDITY_STATE,
			error: "",
			errors: []
		}));
	}, [
		setDirty,
		setTouched,
		setValidityData
	]);
	const invalid = options.invalid || field.invalid === true || field.state.valid === false || shownError !== null;
	const describedBy = labelable.getDescriptionProps({})["aria-describedby"];
	return useMemo(() => ({
		name,
		disabled,
		invalid,
		labelId: labelable.labelId,
		describedBy,
		hiddenInputId,
		hiddenInput,
		setFocused,
		blurred,
		revalidate,
		reset
	}), [
		name,
		disabled,
		invalid,
		labelable.labelId,
		describedBy,
		hiddenInputId,
		setFocused,
		blurred,
		revalidate,
		reset
	]);
}
export { useDateInputField };

//# sourceMappingURL=date-input-field.js.map