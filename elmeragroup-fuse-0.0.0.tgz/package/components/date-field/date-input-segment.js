"use client";
import { cn } from "../../styles/cn.js";
import { isHTMLElement } from "../../internal/dom-node.js";
import { hasFocus } from "../../internal/active-element.js";
import { definedProps } from "../../internal/defined-props.js";
import { fromHourCycle, segmentLimits } from "./date-draft.js";
import { hourName, monthName } from "./date-field-format.js";
import { useDateInputRootContext } from "./date-input-context.js";
import { useSegmentInput } from "./date-input-segment-dom.js";
import { dateInputVariants } from "./date-input-variants.js";
import { useId, useLayoutEffect, useMemo, useRef } from "react";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
// src/components/date-field/date-input-segment.tsx
const SEGMENT_STATE_ATTRIBUTES = {
	type: (value) => ({ "data-type": value }),
	invalid: (value) => value ? { "data-invalid": "true" } : null
};
/**
* One segment of a `DateInput.Root`. An editable one is a `spinbutton` (a `textbox` on iOS, whose
* VoiceOver cannot focus a spinbutton) named by its unit and the field's label, with its number as
* its value and the month's name or the hour as said in its value text. It edits through the
* keyboard: digits fill it and move on, the arrows step it, Page Up and Page Down by a page, Home
* and End to its ends, Backspace and Delete clear a digit. A literal is hidden from assistive
* technology.
*/
function DateInputSegment({ segment, className, render, ref, ...props }) {
	const root = useDateInputRootContext();
	const { actions } = root;
	const generatedId = useId();
	const id = props.id ?? generatedId;
	const isZone = segment.type === "timeZoneName";
	const editable = segment.isEditable && !root.disabled && !root.readOnly;
	const inputRef = useSegmentInput({
		editable,
		dayPeriod: segment.type === "dayPeriod",
		erase(event) {
			if (segment.isEditable && isHTMLElement(event.currentTarget)) actions.erase(segment, event, event.currentTarget);
		},
		type(key, event) {
			if (segment.isEditable && isHTMLElement(event.currentTarget)) actions.type(segment.type, key, event, event.currentTarget);
		}
	});
	const elementRef = useRef(null);
	const actionsRef = useRef(actions);
	useLayoutEffect(() => {
		actionsRef.current = actions;
	});
	useLayoutEffect(() => () => {
		const element = elementRef.current;
		if (element !== null && hasFocus(element)) actionsRef.current.segmentRemoved(element);
	}, []);
	const state = useMemo(() => ({
		type: segment.type,
		placeholder: segment.isPlaceholder,
		disabled: root.disabled,
		readonly: root.readOnly || isZone,
		invalid: root.invalid
	}), [
		segment.type,
		segment.isPlaceholder,
		root.disabled,
		root.readOnly,
		root.invalid,
		isZone
	]);
	const own = segment.type === "literal" ? {
		"aria-hidden": true,
		suppressHydrationWarning: true
	} : {
		...segmentAttributes(root, segment, id, editable),
		onKeyDown(event) {
			actions.keyDown(segment, event);
		},
		onFocus(event) {
			actions.segmentFocused();
			event.currentTarget.ownerDocument.getSelection()?.collapse(event.currentTarget);
		}
	};
	return useRender({
		defaultTagName: "span",
		render,
		ref: segment.type === "literal" ? ref : ref === void 0 ? [inputRef, elementRef] : [
			inputRef,
			elementRef,
			ref
		],
		state,
		stateAttributesMapping: SEGMENT_STATE_ATTRIBUTES,
		props: {
			"data-slot": "date-input-segment",
			...mergeProps({
				...own,
				className: cn(dateInputVariants().segment(), className),
				children: segment.text
			}, definedProps(props))
		}
	});
}
/** A focusable segment's attributes: a unit, or the zone's name, which is a read-only textbox. */
function segmentAttributes(root, segment, id, editable) {
	const isZone = segment.type === "timeZoneName";
	const label = `${root.segmentName(segment.type)}${root.ariaLabel === void 0 ? "" : `, ${root.ariaLabel}`}${root.ariaLabelledBy === void 0 ? "" : ", "}`;
	const attributes = {
		id,
		role: root.ios || isZone ? "textbox" : "spinbutton",
		"aria-label": label,
		"aria-labelledby": root.ariaLabelledBy === void 0 ? void 0 : `${id} ${root.ariaLabelledBy}`,
		"aria-describedby": segment.index === root.firstEditableIndex || root.invalid ? root.describedBy : void 0,
		"aria-invalid": root.invalid || void 0,
		"aria-readonly": root.readOnly || isZone || void 0,
		"aria-disabled": root.disabled || void 0,
		"aria-required": root.required && !isZone || void 0,
		tabIndex: root.disabled ? void 0 : 0,
		contentEditable: editable,
		suppressContentEditableWarning: editable,
		spellCheck: editable ? "false" : void 0,
		autoCorrect: editable ? "off" : void 0,
		autoCapitalize: editable ? "off" : void 0,
		enterKeyHint: editable ? "next" : void 0,
		inputMode: editable && segment.type !== "dayPeriod" ? "numeric" : void 0,
		onPointerDown(event) {
			event.stopPropagation();
		}
	};
	if (root.ios || !segment.isEditable) return attributes;
	return {
		...attributes,
		...spinAttributes(root, segment)
	};
}
function spinAttributes(root, segment) {
	const { type } = segment;
	const limits = segmentLimits(type, root.hourCycle);
	const number = root.draft[type];
	let text = segment.isPlaceholder ? "" : segment.text;
	if (!segment.isPlaceholder && type === "month" && root.draft.month !== null) {
		const name = monthName(root.locale, root.draft.month);
		text = name === segment.text ? name : `${segment.text} – ${name}`;
	} else if (!segment.isPlaceholder && type === "hour" && root.draft.hour !== null) {
		const hour24 = fromHourCycle(root.draft.hour, root.draft.dayPeriod ?? 0, root.hourCycle);
		text = hourName(root.locale, hour24, root.hourCycle);
	}
	return {
		"aria-valuenow": number ?? void 0,
		"aria-valuemin": limits.min,
		"aria-valuemax": limits.max,
		"aria-valuetext": text === "" ? root.emptyText : text
	};
}
export { DateInputSegment };

//# sourceMappingURL=date-input-segment.js.map