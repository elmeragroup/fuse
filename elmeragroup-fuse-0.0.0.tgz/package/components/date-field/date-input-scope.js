"use client";
import { referenceDay } from "../../temporal/reference-day.js";
import { createContext } from "react";
// src/components/date-field/date-input-scope.ts
/** The units a time-only input leaves out. */
const DATE_UNITS = /* @__PURE__ */ new Set([
	"year",
	"month",
	"day"
]);
/**
* Whether an input of these units shows a unit, which both its segments and the format it writes
* them in read: every unit, or a time-only input's units from the hour on.
*
* @param units - The input's units.
* @param unit - The unit.
* @returns Whether it is shown.
*/
function scopeShows(units, unit) {
	return units === "date-time" || !DATE_UNITS.has(unit);
}
/** The scope of a DateInput that no control decides about: every unit, on today's day. */
const FULL_SCOPE = { units: "date-time" };
/** The scope the control around a DateInput gives it; a DateInput anywhere else shows every unit. */
const DateInputScopeContext = createContext(FULL_SCOPE);
/**
* The day a time-only input forms and shows a time on while its control holds no day: the
* reference day, on which the zones Fuse's markets use move no clocks, so no wall time typed on it
* falls in a gap. The control commits the time on its own day once one comes. Forming and showing
* a held time on this one day keeps the value the input commits and the one it is shown the same,
* so the digits typed so far carry on. It is no day anyone chose, so the input names its zone for
* today, as it does while empty.
*
* @returns The day, a new object each call.
*/
function standInDay() {
	return referenceDay();
}
/**
* Whether a scope's input shows a time its control holds with no day, on {@link standInDay}.
*
* @param scope - The input's scope.
* @returns Whether the scope is time-only and its control holds no day.
*/
function onStandInDay(scope) {
	return scope.units === "time" && scope.day === null;
}
export { DATE_UNITS, DateInputScopeContext, FULL_SCOPE, onStandInDay, scopeShows, standInDay };

//# sourceMappingURL=date-input-scope.js.map