// src/components/loader/intl/en-US.ts
/** Default localized copy for the `loader.*` rows. */
const enUS = { loading: "Loading" };
export { enUS };

//# sourceMappingURL=en-US.js.map