// src/components/loader/intl/fi-FI.ts
/** Default localized copy for the `loader.*` rows. */
const fiFI = { loading: "Ladataan" };
export { fiFI };

//# sourceMappingURL=fi-FI.js.map