// src/components/alert-dialog/intl/fi-FI.ts
/** Default localized copy for `alertDialog.cancel`. */
const fiFI = { cancel: "Peruuta" };
export { fiFI };

//# sourceMappingURL=fi-FI.js.map