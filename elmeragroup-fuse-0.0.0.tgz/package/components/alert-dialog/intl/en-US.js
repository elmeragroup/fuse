// src/components/alert-dialog/intl/en-US.ts
/** Default localized copy for `alertDialog.cancel`. */
const enUS = { cancel: "Cancel" };
export { enUS };

//# sourceMappingURL=en-US.js.map