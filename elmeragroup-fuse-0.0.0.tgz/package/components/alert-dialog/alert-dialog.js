"use client";
import { useLocalizedStrings } from "../../hooks/use-localized-strings.js";
import { Button } from "../button/button.js";
import { Info } from "../../icons/generated/info.js";
import { WarningOctagon } from "../../icons/generated/warning-octagon.js";
import { useOverlayRootOverride } from "../../internal/overlay-exclusion.js";
import { DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "../dialog/dialog.js";
import { alertDialogVariants } from "./alert-dialog-variants.js";
import { alertDialogStrings } from "./intl/index.js";
import { useRef } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { AlertDialog } from "@base-ui/react/alert-dialog";
// src/components/alert-dialog/alert-dialog.tsx
/**
* Root runs Base UI's alert-dialog mode, which is always modal and ignores backdrop
* clicks: a destructive confirmation must be answered, not dismissed by a stray pointer.
* Escape still closes it. Its props type omits `modal` and `disablePointerDismissal`, so
* neither can be opted back in. The rest is Dialog machinery with `role="alertdialog"`:
* Trigger and Content render through the public Dialog parts, which read the same root
* context, so the self-focus ring and every other Dialog behaviour come with them.
*/
function AlertDialogRoot(props) {
	const override = useOverlayRootOverride();
	return /* @__PURE__ */ jsx(AlertDialog.Root, {
		...props,
		...override
	});
}
/**
* Trigger restamps its own `data-slot`: Dialog's parts write theirs before spreading the
* rest, so the value passed here wins.
*/
function AlertDialogTrigger(props) {
	return /* @__PURE__ */ jsx(DialogTrigger, {
		"data-slot": "alert-dialog-trigger",
		...props
	});
}
function AlertDialogContent({ title, icon, variant = "destructive", children, actionLabel, cancelLabel, onAction, onCancel, isPerformingAction = false, isActionDisabled = false, isAutomaticallyCloseOnActionEnabled = false, className, initialFocus, ...props }) {
	const strings = useLocalizedStrings(alertDialogStrings);
	const actionRef = useRef(null);
	const cancelRef = useRef(null);
	const fallbackFocus = variant === "destructive" || isActionDisabled ? cancelRef : actionRef;
	const slots = alertDialogVariants({ variant });
	const fallbackIcon = variant === "destructive" ? /* @__PURE__ */ jsx(WarningOctagon, { className: slots.icon() }) : /* @__PURE__ */ jsx(Info, { className: slots.icon() });
	const actionButton = /* @__PURE__ */ jsx(Button, {
		ref: actionRef,
		size: "sm",
		variant: variant === "destructive" ? "destructive" : "default",
		isPending: isPerformingAction,
		disabled: isActionDisabled,
		onClick: onAction,
		"data-dialog-action-type": "primary",
		children: actionLabel
	});
	return /* @__PURE__ */ jsxs(DialogContent, {
		className,
		initialFocus: initialFocus ?? fallbackFocus,
		...props,
		role: "alertdialog",
		showCloseButton: false,
		children: [
			/* @__PURE__ */ jsxs(DialogHeader, {
				className: slots.header(),
				children: [/* @__PURE__ */ jsx(DialogTitle, {
					className: slots.title(),
					children: title
				}), /* @__PURE__ */ jsx("div", {
					className: slots.titleLine(),
					children: icon ?? fallbackIcon
				})]
			}),
			/* @__PURE__ */ jsx(DialogDescription, { children }),
			/* @__PURE__ */ jsxs(DialogFooter, { children: [/* @__PURE__ */ jsx(AlertDialog.Close, {
				render: /* @__PURE__ */ jsx(Button, {
					ref: cancelRef,
					size: "sm",
					variant: "ghost",
					"data-dialog-action-type": "secondary"
				}),
				onClick: onCancel,
				children: cancelLabel ?? strings.format("cancel")
			}), isAutomaticallyCloseOnActionEnabled ? /* @__PURE__ */ jsx(AlertDialog.Close, { render: actionButton }) : actionButton] })
		]
	});
}
AlertDialogRoot.displayName = "AlertDialog.Root";
AlertDialogTrigger.displayName = "AlertDialog.Trigger";
AlertDialogContent.displayName = "AlertDialog.Content";
export { AlertDialogContent, AlertDialogRoot, AlertDialogTrigger };

//# sourceMappingURL=alert-dialog.js.map