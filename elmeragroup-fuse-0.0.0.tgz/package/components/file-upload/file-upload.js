"use client";
import { cn } from "../../styles/cn.js";
import { useMergedRefs } from "../../hooks/use-merged-refs.js";
import { isFocusRoot } from "../../internal/dom-node.js";
import { deepActiveElement } from "../../internal/active-element.js";
import { isThemeDevelopment } from "../../theme/validate-theme.js";
import { useFieldDisabled } from "../../internal/field-set-disabled.js";
import { useFormReset } from "../../hooks/use-form-reset.js";
import { isTextEntry } from "../../internal/text-entry.js";
import { parse } from "./accept.js";
import { registerDocumentDropGuard } from "./document-drop-guard.js";
import { FileUploadContext } from "./file-upload-context.js";
import { fileUploadVariants } from "./file-upload-variants.js";
import { expand, read } from "./read-files.js";
import { split } from "./split-files.js";
import { useCallback, useEffect, useLayoutEffect, useMemo, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
import { useFieldRootContext } from "@base-ui/react/internals/field-root-context";
// src/components/file-upload/file-upload.tsx
const styles = fileUploadVariants();
const NO_DROP_TARGETS = /* @__PURE__ */ new Set();
/** The element of every mounted Root, so a paste finds the Root nearest to the focus. */
const rootElements = /* @__PURE__ */ new WeakSet();
/**
* The nearest Root element above `node`, walking out of shadow roots to their hosts, so focus
* inside a shadow tree still finds the Root that holds the host.
*/
function nearestRoot(node) {
	for (let current = node; current !== null;) {
		if (rootElements.has(current)) return current;
		const parent = current.parentNode;
		current = parent !== null && isFocusRoot(parent) && "host" in parent ? parent.host : parent;
	}
	return null;
}
function fileEntries(files) {
	return files.map((file) => ({
		kind: "file",
		file
	}));
}
/**
* Makes `input.files` hold exactly `files`. A `FileList` has no constructor, so a `DataTransfer`
* builds one. Assigning it fires no `change`, so the Root never hears its own write.
*/
function writeFiles(input, files) {
	const transfer = new DataTransfer();
	for (const file of files) transfer.items.add(file);
	input.files = transfer.files;
}
/**
* The provider every FileUpload part reads. It renders a `div` with the hidden file input the
* picker opens, and writes `data-disabled` and `data-dragging`. A pick, a paste while focus is
* inside it, `useFileUpload().actions.add` and a drop on `FileUpload.Dropzone` all end in the
* same split, which calls `onSelect` with the files that pass and `onReject` with the rest.
*
* To post with a native form, pass `name` and the controlled `files`, and add each `onSelect`
* to `files`. The Root writes `files` into a second hidden file input, apart from the picker's,
* so a submit or `new FormData(form)` carries exactly that list under `name`; an empty list posts
* as a native file input with no selection does. The picker's input stays empty between picks,
* so every pick reaches `onSelect` or `onReject`, and only what the parent adds is posted.
* Chromium and WebKit empty a file input on a form reset, so the Root writes the list back after
* a native reset, including the one React runs after a form action. A disabled Root posts
* nothing. Without `files` there is no posting input, and nothing is posted.
*
* A disabled `Field.Root` or `Field.Set` disables the Root. `FileUpload.Trigger` documents the
* rest of the Field wiring.
*/
function FileUploadRoot({ name: nameProp, files, accept, multiple = false, directory = false, capture, disabled: disabledProp = false, onSelect, onReject, className, render, ref, children, ...props }) {
	const disabled = useFieldDisabled(disabledProp);
	const fieldName = useFieldRootContext().name;
	const name = files === void 0 ? void 0 : fieldName ?? nameProp;
	const [element, setElement] = useState(null);
	const mergedRef = useMergedRefs(ref, setElement);
	const inputRef = useRef(null);
	const postingRef = useRef(null);
	const [dropTargets, setDropTargets] = useState(NO_DROP_TARGETS);
	if (disabled && dropTargets.size > 0) setDropTargets(NO_DROP_TARGETS);
	const [descriptionIds, setDescriptionIds] = useState([]);
	const rules = useMemo(() => ({
		accept: parse(accept),
		multiple
	}), [accept, multiple]);
	const latest = useRef({
		rules,
		directory,
		disabled,
		onSelect,
		onReject
	});
	useLayoutEffect(() => {
		latest.current = {
			rules,
			directory,
			disabled,
			onSelect,
			onReject
		};
	});
	const deliver = useCallback((entries) => {
		const current = latest.current;
		if (current.disabled) return;
		const { accepted, rejected } = split(entries, current.rules);
		if (accepted.length > 0) current.onSelect?.(accepted);
		if (rejected.length > 0) current.onReject?.(rejected);
	}, []);
	const unmounted = useRef(false);
	useEffect(() => {
		unmounted.current = false;
		return () => {
			unmounted.current = true;
		};
	}, []);
	const receive = useCallback((entries) => {
		expand(entries, { directory: latest.current.directory }).then((expanded) => {
			if (!unmounted.current) deliver(expanded);
		});
	}, [deliver]);
	const actions = useMemo(() => ({
		open: () => {
			if (!latest.current.disabled) inputRef.current?.click();
		},
		add: (files) => deliver(fileEntries(files))
	}), [deliver]);
	const setDropTarget = useCallback((zone, shown) => {
		setDropTargets((zones) => {
			if (zones.has(zone) === shown) return zones;
			const next = new Set(zones);
			if (shown) next.add(zone);
			else next.delete(zone);
			return next;
		});
	}, []);
	const descriptionCounts = useRef(/* @__PURE__ */ new Map());
	const registerDescription = useCallback((id) => {
		const counts = descriptionCounts.current;
		const count = counts.get(id) ?? 0;
		counts.set(id, count + 1);
		if (count === 0) setDescriptionIds((ids) => [...ids, id]);
		let registered = true;
		return () => {
			if (!registered) return;
			registered = false;
			const remaining = (counts.get(id) ?? 1) - 1;
			if (remaining > 0) {
				counts.set(id, remaining);
				return;
			}
			counts.delete(id);
			setDescriptionIds((ids) => ids.filter((listed) => listed !== id));
		};
	}, []);
	const fieldTriggers = useRef(0);
	const registerFieldTrigger = useCallback(() => {
		fieldTriggers.current += 1;
		if (fieldTriggers.current > 1 && isThemeDevelopment()) console.error("FileUpload: render one FileUpload.Trigger inside a Field. The Field's label, description and error belong to one control.");
		return () => {
			fieldTriggers.current -= 1;
		};
	}, []);
	useLayoutEffect(() => {
		if (element === null) return;
		rootElements.add(element);
		return () => {
			rootElements.delete(element);
		};
	}, [element]);
	useEffect(() => element === null ? void 0 : registerDocumentDropGuard(element.ownerDocument), [element]);
	useEffect(() => {
		if (disabled || element === null) return;
		const ownerDocument = element.ownerDocument;
		const focusedInside = () => {
			const active = deepActiveElement(ownerDocument);
			return active !== null && nearestRoot(active) === element && !isTextEntry(active);
		};
		const onBeforePaste = (event) => {
			if (focusedInside()) event.preventDefault();
		};
		const onPaste = (event) => {
			if (!focusedInside() || event.clipboardData === null) return;
			const entries = read(event.clipboardData);
			if (entries.length === 0) return;
			event.preventDefault();
			receive(entries);
		};
		ownerDocument.addEventListener("beforepaste", onBeforePaste);
		ownerDocument.addEventListener("paste", onPaste);
		return () => {
			ownerDocument.removeEventListener("beforepaste", onBeforePaste);
			ownerDocument.removeEventListener("paste", onPaste);
		};
	}, [
		disabled,
		element,
		receive
	]);
	const dragging = dropTargets.size > 0;
	const state = useMemo(() => ({
		dragging,
		disabled
	}), [dragging, disabled]);
	const context = useMemo(() => ({
		state,
		actions,
		meta: {
			descriptionIds,
			registerDescription,
			registerFieldTrigger,
			dropTargets,
			setDropTarget,
			receive,
			rules
		}
	}), [
		state,
		actions,
		descriptionIds,
		registerDescription,
		registerFieldTrigger,
		dropTargets,
		setDropTarget,
		receive,
		rules
	]);
	const writePosted = useCallback((input) => {
		if (input !== null && files !== void 0) writeFiles(input, files);
	}, [files]);
	const postingInputRef = useMergedRefs(postingRef, writePosted);
	useFormReset(postingRef, name === void 0 ? null : () => writePosted(postingRef.current));
	const onChange = (event) => {
		const input = event.currentTarget;
		const files = [...input.files ?? []];
		input.value = "";
		deliver(fileEntries(files));
	};
	const directoryAttribute = {};
	if (directory) directoryAttribute.webkitdirectory = "";
	const rendered = useRender({
		defaultTagName: "div",
		render,
		ref: mergedRef,
		state,
		props: {
			"data-slot": "file-upload",
			...mergeProps({
				className: cn(styles.root(), className),
				children: /* @__PURE__ */ jsxs(Fragment$1, { children: [
					children,
					/* @__PURE__ */ jsx("input", {
						ref: inputRef,
						type: "file",
						hidden: true,
						tabIndex: -1,
						accept,
						multiple,
						capture,
						...directoryAttribute,
						onChange,
						onClick: (event) => event.stopPropagation()
					}),
					name === void 0 ? null : /* @__PURE__ */ jsx("input", {
						ref: postingInputRef,
						type: "file",
						hidden: true,
						tabIndex: -1,
						multiple: true,
						name,
						disabled
					})
				] })
			}, props)
		}
	});
	return /* @__PURE__ */ jsx(FileUploadContext, {
		value: context,
		children: rendered
	});
}
FileUploadRoot.displayName = "FileUpload.Root";
export { FileUploadRoot };

//# sourceMappingURL=file-upload.js.map