import { cn } from "../../styles/cn.js";
import { tv } from "../../styles/tv.js";
import { dataStateFaceClass } from "../../styles/state-face.js";
import { itemDefaultShellClass, itemShellClass } from "../../styles/inner-corner/item.js";
import { labelTypeClass } from "../../styles/label-type.js";
// src/components/file-upload/file-upload-variants.ts
/**
* The FileUpload recipe, one slot per styled part. The Trigger takes no slot: like
* `Dialog.Trigger` it is a plain button with the focus ring, and `render={<Button />}` gives it
* a size. Package-private: the facade exports the parts, not the recipe.
*/
const fileUploadVariants = tv({ slots: {
	root: "flex min-w-0 flex-col gap-(--surface-gap-sm)",
	dropzone: cn(itemShellClass, itemDefaultShellClass, "flex min-w-0 items-center gap-(--surface-gap-sm) border-dashed border-border transition-colors duration-100", "has-focus-visible:border-muted-foreground/50 enabled-hover:border-muted-foreground/50", "data-drop-target:border-solid data-drop-target:border-primary data-drop-target:bg-primary-soft", dataStateFaceClass),
	description: cn(labelTypeClass, "text-muted-foreground")
} });
export { fileUploadVariants };

//# sourceMappingURL=file-upload-variants.js.map