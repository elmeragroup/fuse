// src/components/file-upload/accept.ts
const ANY = { _tag: "any" };
/**
* Parse an `accept` attribute value.
*
* @param accept - The attribute's value, or `undefined` when the attribute is absent.
* @returns The rule, which accepts every file when `accept` holds no usable token.
*/
function parse(accept) {
	const mimeTypes = /* @__PURE__ */ new Set();
	const topLevelTypes = /* @__PURE__ */ new Set();
	const extensions = [];
	for (const raw of (accept ?? "").split(",")) {
		const token = raw.trim().toLowerCase();
		if (token.startsWith(".")) extensions.push(token);
		else if (token.endsWith("/*")) topLevelTypes.add(token.slice(0, -2));
		else if (token.includes("/")) mimeTypes.add(token);
	}
	if (mimeTypes.size === 0 && topLevelTypes.size === 0 && extensions.length === 0) return ANY;
	return {
		_tag: "listed",
		mimeTypes,
		topLevelTypes,
		extensions
	};
}
/**
* Whether a MIME type alone satisfies the rule, as a drag that reports item types but no
* names needs to know.
*
* @param rule - The parsed rule.
* @param mimeType - The type to test. An empty type matches only a rule that accepts every file.
* @returns `true` when the rule accepts every file or a MIME token matches `mimeType`.
*/
function matchesMimeType(rule, mimeType) {
	if (rule._tag === "any") return true;
	const type = mimeType.toLowerCase();
	if (rule.mimeTypes.has(type)) return true;
	const slash = type.indexOf("/");
	return slash > 0 && rule.topLevelTypes.has(type.slice(0, slash));
}
/**
* Whether the rule holds an extension token. When it does, a drag's MIME types cannot rule a
* file out, because only the name it reveals on drop can match.
*
* @param rule - The parsed rule.
* @returns `true` when at least one `.ext` token was parsed.
*/
function hasExtension(rule) {
	return rule._tag === "listed" && rule.extensions.length > 0;
}
/**
* Whether a file passes the rule, through its MIME type or its name.
*
* @param rule - The parsed rule.
* @param file - The file's `name` and `type`.
* @returns `true` when the rule accepts the file.
*/
function matchesFile(rule, file) {
	if (rule._tag === "any" || matchesMimeType(rule, file.type)) return true;
	const name = file.name.toLowerCase();
	return rule.extensions.some((extension) => name.endsWith(extension));
}
export { hasExtension, matchesFile, matchesMimeType, parse };

//# sourceMappingURL=accept.js.map