"use client";
import { createContext, use, useMemo } from "react";
// src/components/file-upload/file-upload-context.ts
/** The Root's context. `FileUpload.Root` provides it. */
const FileUploadContext = createContext(null);
/**
* The enclosing Root's context, for a part.
*
* @param part - The part's name, such as `FileUpload.Trigger`, for the error message.
* @returns The context value.
* @throws When no `FileUpload.Root` encloses the caller, which is a defect in the tree.
*/
function useFileUploadContext(part) {
	const context = use(FileUploadContext);
	if (context === null) throw new Error(`${part} must be used within FileUpload.Root.`);
	return context;
}
/**
* The enclosing `FileUpload.Root`'s state and actions, for a custom child such as a button that
* adds files from another source. The result keeps its identity until the state changes.
*
* @returns `state.dragging` and `state.disabled`, and the `open` and `add` actions.
* @throws When no `FileUpload.Root` encloses the caller.
*/
function useFileUpload() {
	const { state, actions } = useFileUploadContext("useFileUpload");
	return useMemo(() => ({
		state,
		actions
	}), [state, actions]);
}
export { FileUploadContext, useFileUpload, useFileUploadContext };

//# sourceMappingURL=file-upload-context.js.map