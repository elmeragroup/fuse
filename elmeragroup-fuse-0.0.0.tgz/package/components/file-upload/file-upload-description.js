"use client";
import { cn } from "../../styles/cn.js";
import { useMergedRefs } from "../../hooks/use-merged-refs.js";
import { definedProps } from "../../internal/defined-props.js";
import { useFileUploadContext } from "./file-upload-context.js";
import { fileUploadVariants } from "./file-upload-variants.js";
import { useId, useLayoutEffect, useRef, useState } from "react";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
// src/components/file-upload/file-upload-description.tsx
const styles = fileUploadVariants();
/**
* A hint about what the FileUpload takes, such as "Up to 3 files, 10 MB each". While it is
* mounted, it describes every `FileUpload.Trigger` in the Root, by the id its element ends up
* with: the consumer's `id`, one from a `render` element, or a generated one.
*/
function FileUploadDescription({ className, render, ref, ...props }) {
	const { meta } = useFileUploadContext("FileUpload.Description");
	const generatedId = useId();
	const { registerDescription } = meta;
	const [element, setElement] = useState(null);
	const mergedRef = useMergedRefs(ref, setElement);
	const registration = useRef(null);
	useLayoutEffect(() => {
		const id = element?.id ?? "";
		if (registration.current?.id === id) return;
		registration.current?.release();
		registration.current = id === "" ? null : {
			id,
			release: registerDescription(id)
		};
	});
	useLayoutEffect(() => () => {
		registration.current?.release();
		registration.current = null;
	}, []);
	return useRender({
		defaultTagName: "p",
		render,
		ref: mergedRef,
		props: {
			"data-slot": "file-upload-description",
			...mergeProps({
				id: generatedId,
				className: cn(styles.description(), className)
			}, definedProps(props))
		}
	});
}
FileUploadDescription.displayName = "FileUpload.Description";
export { FileUploadDescription };

//# sourceMappingURL=file-upload-description.js.map