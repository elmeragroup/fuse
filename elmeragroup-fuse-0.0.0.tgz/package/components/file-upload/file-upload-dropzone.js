"use client";
import { cn } from "../../styles/cn.js";
import { isNode } from "../../internal/dom-node.js";
import { pressesRegion } from "../../internal/own-click.js";
import { dragVerdict, isFileDrag } from "./drag-verdict.js";
import { useFileUploadContext } from "./file-upload-context.js";
import { fileUploadVariants } from "./file-upload-variants.js";
import { read } from "./read-files.js";
import { useEffect, useId, useState } from "react";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
// src/components/file-upload/file-upload-dropzone.tsx
const styles = fileUploadVariants();
/**
* Whether an event happened in the zone's DOM. React bubbles events from portalled content, such
* as a dialog opened from inside the zone, through the zone, though their DOM sits elsewhere.
*/
function inZone(target, zone) {
	return isNode(target) && zone.contains(target);
}
/** `data-drop-target` while a drag that could drop is over the zone, and `data-disabled`. */
const stateAttributesMapping = { dropTarget: (value) => value ? { "data-drop-target": "" } : null };
/**
* The area files drop on. It writes `data-drop-target` while a file drag
* that could pass is over it, and the drag shows the not-allowed cursor when the drop is certain
* to be rejected: more than one file of a known type that passes `accept` on a single-file Root,
* or known types that all miss `accept`.
* A click on its empty surface opens the picker. That path is pointer only, so keep a
* `FileUpload.Trigger` inside for the keyboard. That click leaves with `defaultPrevented` set,
* so an enclosing Dropzone or pressable `DataTable` row skips it, and it still bubbles to
* document listeners. While the Root is disabled it writes `data-disabled` and leaves every
* drag to the document, which keeps a dropped file from opening in the tab.
*/
function FileUploadDropzone({ className, render, ...props }) {
	const { state, actions, meta } = useFileUploadContext("FileUpload.Dropzone");
	const zoneId = useId();
	const { setDropTarget } = meta;
	const [entered] = useState(() => /* @__PURE__ */ new Set());
	useEffect(() => {
		if (state.disabled) entered.clear();
	}, [entered, state.disabled]);
	useEffect(() => () => {
		entered.clear();
		setDropTarget(zoneId, false);
	}, [
		entered,
		setDropTarget,
		zoneId
	]);
	const onDragEnterOrOver = (event) => {
		if (state.disabled || !inZone(event.target, event.currentTarget) || !isFileDrag(event.dataTransfer)) return;
		event.preventDefault();
		event.stopPropagation();
		const verdict = dragVerdict(event.dataTransfer.items, meta.rules);
		event.dataTransfer.dropEffect = verdict === "reject" ? "none" : "copy";
		if (event.type === "dragenter") entered.add(event.target);
		setDropTarget(zoneId, verdict !== "reject");
	};
	const onDragLeave = (event) => {
		if (!inZone(event.target, event.currentTarget) || !isFileDrag(event.dataTransfer)) return;
		const zone = event.currentTarget;
		entered.delete(event.target);
		if (event.target === zone) {
			for (const target of entered) if (!isNode(target) || !zone.contains(target)) entered.delete(target);
		}
		if (entered.size === 0) setDropTarget(zoneId, false);
		if (!state.disabled) {
			event.preventDefault();
			event.stopPropagation();
		}
	};
	const onDrop = (event) => {
		if (!inZone(event.target, event.currentTarget) || !isFileDrag(event.dataTransfer)) return;
		entered.clear();
		setDropTarget(zoneId, false);
		if (state.disabled) return;
		event.preventDefault();
		event.stopPropagation();
		meta.receive(read(event.dataTransfer));
	};
	const onClick = (event) => {
		if (!event.defaultPrevented && !state.disabled && pressesRegion(event.target, event.currentTarget)) {
			event.preventDefault();
			actions.open();
		}
	};
	return useRender({
		defaultTagName: "div",
		render,
		state: {
			dropTarget: meta.dropTargets.has(zoneId),
			disabled: state.disabled
		},
		stateAttributesMapping,
		props: {
			"data-slot": "file-upload-dropzone",
			...mergeProps({
				className: cn(styles.dropzone(), className),
				onDragEnter: onDragEnterOrOver,
				onDragOver: onDragEnterOrOver,
				onDragLeave,
				onDrop,
				onClick
			}, props)
		}
	});
}
FileUploadDropzone.displayName = "FileUpload.Dropzone";
export { FileUploadDropzone };

//# sourceMappingURL=file-upload-dropzone.js.map