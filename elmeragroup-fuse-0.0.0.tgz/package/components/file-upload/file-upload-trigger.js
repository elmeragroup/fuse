"use client";
import { cn } from "../../styles/cn.js";
import { selfFocusRingClass } from "../../styles/utils.js";
import { ariaStateFaceClass } from "../../styles/state-face.js";
import { definedProps } from "../../internal/defined-props.js";
import { useFileUploadContext } from "./file-upload-context.js";
import { useLayoutEffect } from "react";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
import { useFieldRootContext } from "@base-ui/react/internals/field-root-context";
import { useLabelableContext, useLabelableId } from "@base-ui/react/internals/labelable-provider";
import { NOOP } from "@base-ui/react/internals/noop";
// src/components/file-upload/file-upload-trigger.tsx
/** The ids, deduplicated in first-seen order and space-joined, or `undefined` when there are none. */
function idList(...lists) {
	const ids = new Set(lists.flatMap((list) => list?.split(" ") ?? []).filter((id) => id !== ""));
	return ids.size === 0 ? void 0 : [...ids].join(" ");
}
/**
* The button that opens the picker, and the keyboard path to it. It renders
* `<button type="button">` with the shared focus ring; `render={<Button size="sm" />}` gives it
* the Fuse button look. It is disabled while the Root is disabled or its own `disabled` is set.
* It is described by the ids in its own `aria-describedby`, then, inside a `Field.Root`, the
* Field's `Field.Description` and `Field.Error` in the Field's order, then each mounted
* `FileUpload.Description`.
*
* Inside a `Field.Root`, render one `FileUpload.Trigger`; the Field's label, description and error
* belong to it. It is the Field's control, as `Select.Trigger` is: `Field.Label` points at it, so a
* click on the label opens the picker as it would for a native file input, and it is named by its
* own text and then the label ("Browse files Attachments"), as `DatePicker.Trigger` is, so the
* visible text stays in the name. Its own `aria-labelledby` replaces that name. Give it an `id`
* through its own `id` prop, not its `render` element, which the label does not follow. An invalid
* Field marks it `aria-invalid` while it is enabled; its own `aria-invalid` wins over the Field's.
* While `aria-invalid` is set, the Trigger paints the shared invalid border and ring, the one
* invalid face of the FileUpload: an enclosing `FileUpload.Dropzone` paints none.
*/
function FileUploadTrigger({ className, render, disabled, id: ownId, "aria-labelledby": ownLabelledBy, "aria-describedby": ownDescribedBy, "aria-invalid": ownInvalid, ...props }) {
	const { state, actions, meta } = useFileUploadContext("FileUpload.Trigger");
	const field = useFieldRootContext();
	const labelable = useLabelableContext();
	const inField = field.setValidityData !== NOOP;
	const controlId = useLabelableId({
		id: ownId,
		enabled: inField
	});
	const id = inField ? controlId : ownId;
	const { registerFieldTrigger } = meta;
	useLayoutEffect(() => inField ? registerFieldTrigger() : void 0, [inField, registerFieldTrigger]);
	const isDisabled = state.disabled || disabled === true;
	const labelledBy = ownLabelledBy ?? (inField && labelable.labelId !== void 0 && id !== void 0 ? `${id} ${labelable.labelId}` : void 0);
	const describedBy = idList(labelable.getDescriptionProps({ "aria-describedby": ownDescribedBy })["aria-describedby"], ...meta.descriptionIds);
	return useRender({
		defaultTagName: "button",
		render,
		props: {
			"data-slot": "file-upload-trigger",
			...mergeProps({
				type: "button",
				className: cn(selfFocusRingClass, ariaStateFaceClass, className),
				onClick: () => {
					if (!isDisabled) actions.open();
				}
			}, definedProps({
				...props,
				id,
				disabled: isDisabled,
				"aria-labelledby": labelledBy,
				"aria-describedby": describedBy,
				"aria-invalid": ownInvalid ?? (field.state.valid === false && !isDisabled ? true : void 0)
			}))
		}
	});
}
FileUploadTrigger.displayName = "FileUpload.Trigger";
export { FileUploadTrigger };

//# sourceMappingURL=file-upload-trigger.js.map