import { definedProps } from "../../internal/defined-props.js";
import { DatePickerGroup, DatePickerPopup, DatePickerTrigger, PickerPopupPane } from "../date-picker/picker-shell.js";
import { DateRangePickerDescription, DateRangePickerEndInput, DateRangePickerError, DateRangePickerFieldCalendar, DateRangePickerLabel, DateRangePickerSeparator, DateRangePickerStartInput } from "./date-range-picker-parts.js";
import { DateRangePickerRoot } from "./date-range-picker.js";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/date-range-picker/date-range-picker-field.tsx
/**
* Labeled date range picker composite over `DateRangePicker`'s parts, with the interim React Aria
* DateRangePicker's prop names: a label, the field box with the start and end segments and the
* calendar trigger, the merged error, the description, and the range calendar popup with an
* optional preset pane. Each end is a Field of its own under `startName` and `endName`. Values are
* Temporal values, which a client component builds. The composite itself holds no state, so a
* server component can render it without a value.
*
* @template P - The props, inferred: only their `granularity` and `timeZone` count.
* @template T - The ends' kind, inferred as `DateInput.Root`'s is.
*/
function DateRangePickerField({ label, description, errorMessage, value, defaultValue, onChange, presetGroup, shouldForceLeadingZeros = true, isOpen, onBlur, isDisabled = false, isReadOnly = false, isRequired = false, isInvalid = false, container, className, ...props }) {
	return /* @__PURE__ */ jsxs(DateRangePickerRoot, {
		...definedProps({
			...props,
			value,
			defaultValue,
			onValueChange: onChange,
			open: isOpen,
			onFocusLeave: onBlur,
			className
		}),
		disabled: isDisabled,
		readOnly: isReadOnly,
		required: isRequired,
		invalid: isInvalid,
		children: [
			label ? /* @__PURE__ */ jsx(DateRangePickerLabel, { children: label }) : null,
			/* @__PURE__ */ jsxs(DatePickerGroup, { children: [
				/* @__PURE__ */ jsx(DateRangePickerStartInput, { shouldForceLeadingZeros }),
				/* @__PURE__ */ jsx(DateRangePickerSeparator, {}),
				/* @__PURE__ */ jsx(DateRangePickerEndInput, { shouldForceLeadingZeros }),
				/* @__PURE__ */ jsx(DatePickerTrigger, { className: "ms-auto" })
			] }),
			/* @__PURE__ */ jsx(DateRangePickerError, { children: errorMessage }),
			description ? /* @__PURE__ */ jsx(DateRangePickerDescription, { children: description }) : null,
			/* @__PURE__ */ jsx(DatePickerPopup, {
				...definedProps({ container }),
				children: /* @__PURE__ */ jsx(PickerPopupPane, {
					presets: presetGroup,
					children: /* @__PURE__ */ jsx(DateRangePickerFieldCalendar, { shouldForceLeadingZeros })
				})
			})
		]
	});
}
DateRangePickerField.displayName = "DateRangePickerField";
export { DateRangePickerField };

//# sourceMappingURL=date-range-picker-field.js.map