import { createContext, use } from "react";
// src/components/date-range-picker/date-range-picker-context.ts
/** An end with no message. */
const NO_MESSAGES = [];
/** A range with both ends empty. */
const EMPTY_ENDS = {
	start: null,
	end: null
};
/**
* A range's key, which a held selection and the calendar's view belong to.
*
* @param ends - The ends.
* @returns `start..end`, each end's ISO text or empty.
*/
function rangeKey(ends) {
	return `${ends.start?.toString() ?? ""}..${ends.end?.toString() ?? ""}`;
}
const DateRangePickerRootContext = createContext(void 0);
/**
* The enclosing range Root.
*
* @param part - The part asking, named in the error.
* @returns The Root's context.
* @throws Error naming the part outside `DateRangePicker.Root`, a composition defect.
*/
function useRangeRootContext(part) {
	const value = use(DateRangePickerRootContext);
	if (value === void 0) throw new Error(`${part} must be rendered inside DateRangePicker.Root.`);
	return value;
}
export { DateRangePickerRootContext, EMPTY_ENDS, NO_MESSAGES, rangeKey, useRangeRootContext };

//# sourceMappingURL=date-range-picker-context.js.map