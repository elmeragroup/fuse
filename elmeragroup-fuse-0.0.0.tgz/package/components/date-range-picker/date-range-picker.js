"use client";
import { createChangeEventDetails } from "../calendar/calendar-change-details.js";
import { checkBounds } from "../../temporal/bounds.js";
import { boundDay } from "../calendar/calendar-dates.js";
import { useRangeProp } from "../calendar/calendar-input.js";
import { valueError } from "../date-field/date-input-validation.js";
import { useValueKind } from "../date-field/use-value-kind.js";
import { useStableCallback } from "../../hooks/use-stable-callback.js";
import { datePickerVariants } from "../date-picker/date-picker-variants.js";
import { presetRange } from "../date-picker/picker-value.js";
import { isRenderableNode } from "../../internal/is-renderable-node.js";
import { usePresetRegistry } from "../date-picker/picker-shell.js";
import { useCalendarViewKey, usePickerRoot, usePickerRootElement, usePickerRules, usePresetReader } from "../date-picker/picker-root.js";
import { usePickerTimeBinding } from "../date-picker/picker-time-input.js";
import { usePickerSession } from "../date-picker/use-picker-session.js";
import { DateRangePickerRootContext, EMPTY_ENDS, NO_MESSAGES, rangeKey } from "./date-range-picker-context.js";
import { DateRangePickerDescription, DateRangePickerError, DateRangePickerLabel } from "./date-range-picker-parts.js";
import { awaitsTime, clearTime, draftOfRange, editInput, editTime, kindWitnessOf, pickRange, shownEnds, wholeRange } from "./range-draft.js";
import { Children, Fragment, isValidElement, useCallback, useId, useLayoutEffect, useMemo, useRef, useState } from "react";
import { jsx } from "react/jsx-runtime";
// src/components/date-range-picker/date-range-picker.tsx
const styles = datePickerVariants({ range: true });
/** The Root its prop errors name. */
const OWNER = "DateRangePicker.Root";
/**
* Which parts a Root's children render, read during render from the element tree the Root is given,
* so the server writes the same names and descriptions as the client. The scan looks only through
* host elements and fragments, which render their children as given: a component decides what it
* renders (a `Show` with `when={false}` renders nothing), so the scan stops at every component,
* nested Roots included, and a part inside one registers after mount instead.
*/
function scanRangeParts(children) {
	const found = {
		label: false,
		description: false,
		error: false,
		errorText: false
	};
	const visit = (node) => {
		Children.forEach(node, (child) => {
			if (!isValidElement(child)) return;
			if (child.type === DateRangePickerLabel) found.label = true;
			if (child.type === DateRangePickerDescription) found.description = true;
			if (child.type === DateRangePickerError) {
				found.error = true;
				found.errorText ||= isRenderableNode(child.props.children);
			}
			if (typeof child.type === "string" || child.type === Fragment) visit(child.props.children);
		});
	};
	visit(children);
	return found;
}
/** Whether the end comes before the start, compared as the bounds compare. */
function isReversed(ends) {
	return ends.start !== null && ends.end !== null && checkBounds(ends.end, {
		min: ends.start,
		max: void 0
	}) === "underflow";
}
/**
* A date range picker: a start and an end input and a range calendar in a popup, over one range.
* Its parts are `Label`, `Group`, `StartInput`, `Separator`, `EndInput`, `Trigger`, `Error`,
* `Description`, `Popup`, `Calendar`, `StartTimeInput` and `EndTimeInput` (each end's time in the
* popup) and the preset pane (`Presets`, `PresetItem`).
*
* Each input is a Base UI Field of its own, under `startName` and `endName`: a `Form` reads both ISO
* values, holds errors under either name and focuses the input whose error it returns. The label,
* the description and the merged error live on the Root, outside those two Fields, and the Root
* wires them to both inputs and the group. An end before its start is invalid on the end ("Start
* date must be before end date."), as React Aria reports it.
*
* Values are Temporal values, as DatePicker's. Picking a range in the calendar keeps each end's
* time and zone.
*
* @template P - The props, inferred: only their `granularity` and `timeZone` count.
* @template T - The ends' kind, inferred as `DateInput.Root`'s is.
* @throws TypeError naming the prop and the fix when a value or bound is a string rather than a
*   Temporal object, or a time `granularity` meets a PlainDate value: host defects.
*/
function DateRangePickerRoot(props) {
	const { value: valueProp, defaultValue, onValueChange, open: openProp, defaultOpen = false, onOpenChange, shouldCloseOnSelect = true, minValue, maxValue, isDateUnavailable, granularity, hourCycle, hideTimeZone = false, timeZone, firstDayOfWeek, visibleMonths = 1, pageBehavior = "visible", disabled: disabledProp = false, readOnly = false, required = false, invalid: invalidProp = false, startName, endName, form, size = "default", "aria-label": ariaLabel, onFocusLeave, className, render, children, ...elementProps } = props;
	const controlled = valueProp !== void 0;
	const parsedValue = useRangeProp(valueProp, OWNER, "value");
	const parsedDefault = useRangeProp(defaultValue, OWNER, "defaultValue");
	const [own, setOwn] = useState(parsedDefault);
	const committed = (controlled ? parsedValue : own) ?? EMPTY_ENDS;
	const committedKey = rangeKey(committed);
	const unavailable = isDateUnavailable;
	const [viewKey, markPicked] = useCalendarViewKey(committedKey);
	const rules = usePickerRules(OWNER, minValue, maxValue, unavailable);
	const publishedDeps = {
		committed,
		onValueChange,
		controlled,
		parsedDefault
	};
	const commitDeps = useRef(publishedDeps);
	useLayoutEffect(() => {
		commitDeps.current = publishedDeps;
	});
	const presetPanes = usePresetRegistry();
	/** Report a whole range, or `null` for one that lost an end, and apply it unless canceled. */
	function commitRange(range, reason, event, trigger) {
		const deps = commitDeps.current;
		const details = createChangeEventDetails(reason, event, trigger, { getValidationError: () => {
			if (range === null) return null;
			return valueError(range.start, rules) ?? valueError(range.end, rules) ?? (isReversed(range) ? "rangeReversed" : null);
		} });
		deps.onValueChange?.(range, details);
		if (details.isCanceled) return false;
		if (!deps.controlled) setOwn(range);
		commitDeps.current = {
			...deps,
			committed: range ?? EMPTY_ENDS
		};
		if (reason !== "preset-press") presetPanes.valueCommitted();
		return true;
	}
	const session = usePickerSession({
		open: openProp,
		defaultOpen,
		onOpenChange,
		basis: committedKey,
		finalize(held, origin) {
			const range = wholeRange(held, kind);
			if (range === null) return true;
			if (!commitRange(range, origin.reason, origin.event, origin.trigger)) return false;
			markPicked(rangeKey(range));
			return true;
		},
		onReset() {
			if (!commitDeps.current.controlled) setOwn(commitDeps.current.parsedDefault);
			presetPanes.valueCommitted();
		}
	});
	const { generation, hold, release, held } = session;
	const committedDraft = useMemo(() => draftOfRange(committed), [committed]);
	const draft = held?.value ?? committedDraft;
	const [messagesOf, setMessagesOf] = useState({
		start: NO_MESSAGES,
		end: NO_MESSAGES
	});
	const [inputInvalid, setInputInvalid] = useState({
		start: false,
		end: false
	});
	const scanned = scanRangeParts(children);
	const [registered, setRegistered] = useState(() => /* @__PURE__ */ new Set());
	const registerPart = useCallback((part) => {
		setRegistered((current) => current.has(part) ? current : new Set(current).add(part));
		return () => setRegistered((current) => {
			if (!current.has(part)) return current;
			const next = new Set(current);
			next.delete(part);
			return next;
		});
	}, []);
	const { hasPresets, registerPresets } = presetPanes;
	const invalid = invalidProp || inputInvalid.start || inputInvalid.end;
	const messages = useMemo(() => [.../* @__PURE__ */ new Set([...messagesOf.start, ...messagesOf.end])], [messagesOf]);
	const hasLabel = scanned.label || registered.has("label");
	const hasDescription = scanned.description || registered.has("description");
	const errorShown = scanned.error && invalid && (scanned.errorText || messages.length > 0) || registered.has("error");
	const baseId = useId();
	const labelId = `${baseId}-label`;
	const descriptionId = `${baseId}-description`;
	const errorId = `${baseId}-error`;
	const nameId = `${baseId}-name`;
	const describedBy = [hasDescription ? descriptionId : void 0, errorShown ? errorId : void 0].filter((id) => id !== void 0).join(" ") || void 0;
	const resolvedKind = useValueKind({
		value: kindWitnessOf(draft),
		defaultValue: parsedDefault?.start ?? parsedDefault?.end ?? null,
		granularity,
		timeZone
	}, OWNER);
	const { kind } = resolvedKind;
	const readPreset = usePresetReader(presetRange, kind, (range, event, trigger) => {
		if (!commitRange(range, "preset-press", event, trigger)) return false;
		release();
		return true;
	});
	const ends = useMemo(() => held === null ? committed : shownEnds(held.value, kind), [
		held,
		committed,
		kind
	]);
	const reversed = isReversed(ends);
	const root = usePickerRoot({
		props: {
			granularity,
			hourCycle,
			hideTimeZone,
			timeZone,
			firstDayOfWeek,
			visibleMonths,
			pageBehavior,
			disabled: disabledProp,
			readOnly,
			required,
			form,
			size,
			ariaLabel,
			onFocusLeave
		},
		rules,
		kind: resolvedKind,
		session,
		labelledBy: hasLabel ? labelId : void 0,
		describedBy,
		invalid,
		range: true,
		registerPresets,
		readPreset
	});
	const published = {
		draft,
		origin: held?.finalizeOnClose ?? null,
		shouldCloseOnSelect
	};
	const latest = useRef(published);
	useLayoutEffect(() => {
		latest.current = published;
	});
	/** Publish a draft a gesture made to the gestures that follow, before the Root renders it. */
	function publish(next, origin) {
		latest.current = {
			...latest.current,
			draft: next,
			origin
		};
	}
	/** Hold a draft, and publish it. */
	function holdDraft(next, origin, basis) {
		hold(next, origin, basis);
		publish(next, origin);
	}
	/**
	* Apply a draft a gesture made: a whole range commits, and so does a whole range that just lost
	* an end, as `null`, which React Aria reports too; a range filled one end at a time reports
	* nothing until it is whole, and the draft is held over the empty range meanwhile. The committed
	* range is whole or empty.
	*
	* @returns The whole range it committed, `null` for a draft that is not whole, or `"canceled"`
	*   when the commit was canceled.
	*/
	function apply(next, reason, event, trigger) {
		const range = wholeRange(next, kind);
		if ((range !== null || commitDeps.current.committed.start !== null) && !commitRange(range, reason, event, trigger)) return "canceled";
		if (range === null) holdDraft(next, null, rangeKey(EMPTY_ENDS));
		else {
			release();
			publish(draftOfRange(range), null);
		}
		return range;
	}
	const inputChange = useStableCallback((endpoint, next, details) => {
		if (apply(editInput(latest.current.draft, endpoint, next), details.reason, details.event, details.trigger) === "canceled") details.cancel();
	});
	const selectRange = useStableCallback((range, details) => {
		const state = latest.current;
		const next = pickRange(state.draft, range, kind);
		const { committed: current } = commitDeps.current;
		if (kind.kind !== "PlainDate" && current.start === null && current.end === null && awaitsTime(next) && !state.shouldCloseOnSelect) {
			holdDraft(next, {
				reason: details.reason,
				event: details.event,
				trigger: details.trigger
			});
			return;
		}
		const applied = apply(next, details.reason, details.event, details.trigger);
		if (applied === "canceled") {
			details.cancel();
			return;
		}
		if (applied !== null) markPicked(rangeKey(applied));
		if (state.shouldCloseOnSelect && (details.reason === "day-press" || details.reason === "keyboard")) root.requestOpen(false, details.reason, details.event, details.trigger);
	});
	const timeChange = useStableCallback((endpoint, time, details) => {
		const { draft: current, origin } = latest.current;
		if (time === null) {
			const cleared = clearTime(current, endpoint);
			if (cleared === void 0) details.cancel();
			else if (cleared !== current) holdDraft(cleared, origin);
			return;
		}
		const next = editTime(current, endpoint, time, kind);
		if (awaitsTime(next)) {
			holdDraft(next, origin);
			return;
		}
		const applied = apply(next, details.reason, details.event, details.trigger);
		if (applied === "canceled") {
			details.cancel();
			return;
		}
		if (applied !== null) markPicked(rangeKey(applied));
	});
	const startBinding = usePickerTimeBinding(draft.start, kind, (time, details) => timeChange("start", time, details));
	const endBinding = usePickerTimeBinding(draft.end, kind, (time, details) => timeChange("end", time, details));
	const timeBindings = useMemo(() => ({
		start: startBinding,
		end: endBinding
	}), [startBinding, endBinding]);
	const reportMessages = useCallback((endpoint, next) => {
		setMessagesOf((current) => current[endpoint].join("\n") === next.join("\n") ? current : {
			...current,
			[endpoint]: next
		});
	}, [setMessagesOf]);
	const reportInputInvalid = useCallback((endpoint, next) => {
		setInputInvalid((current) => current[endpoint] === next ? current : {
			...current,
			[endpoint]: next
		});
	}, [setInputInvalid]);
	const calendarRange = useMemo(() => ends.start === null || ends.end === null ? null : {
		start: boundDay(ends.start),
		end: boundDay(ends.end)
	}, [ends]);
	const endpointLabelledBy = hasLabel ? labelId : ariaLabel === void 0 ? void 0 : nameId;
	const { inputSettings, calendarSettings, timeSettings } = root;
	const context = useMemo(() => ({
		ends,
		calendarRange,
		calendarKey: `${generation}:${viewKey}`,
		generation,
		endpointLabelledBy,
		inputSettings,
		calendarSettings,
		timeSettings,
		timeBindings,
		invalidProp,
		invalid,
		reversed,
		names: {
			start: startName,
			end: endName
		},
		labelId,
		descriptionId,
		errorId,
		messages,
		describedBy,
		hasPresets,
		registerPart,
		inputChange,
		selectRange,
		reportMessages,
		reportInputInvalid
	}), [
		ends,
		calendarRange,
		generation,
		viewKey,
		endpointLabelledBy,
		inputSettings,
		calendarSettings,
		timeSettings,
		timeBindings,
		invalidProp,
		invalid,
		reversed,
		startName,
		endName,
		labelId,
		descriptionId,
		errorId,
		messages,
		describedBy,
		hasPresets,
		registerPart,
		inputChange,
		selectRange,
		reportMessages,
		reportInputInvalid
	]);
	const element = usePickerRootElement({
		root,
		slot: "date-range-picker",
		className,
		classes: styles.root(),
		render,
		elementProps,
		children,
		extra: !hasLabel && ariaLabel !== void 0 ? /* @__PURE__ */ jsx("span", {
			id: nameId,
			hidden: true,
			children: ariaLabel
		}) : null,
		resetRef: session.resetRef
	});
	return /* @__PURE__ */ jsx(DateRangePickerRootContext, {
		value: context,
		children: element
	});
}
export { DateRangePickerRoot };

//# sourceMappingURL=date-range-picker.js.map