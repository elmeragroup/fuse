"use client";
import { cn } from "../../styles/cn.js";
import { useLocalizedStrings } from "../../hooks/use-localized-strings.js";
import { definedProps } from "../../internal/defined-props.js";
import { fieldVariants } from "../field/field-variants.js";
import { SEGMENT_SELECTOR } from "../date-field/date-input-context.js";
import { datePickerVariants } from "../date-picker/date-picker-variants.js";
import { stateClassName } from "../date-picker/picker-class-name.js";
import { isRenderableNode } from "../../internal/is-renderable-node.js";
import { datePickerStrings } from "../date-picker/intl/index.js";
import { DefaultCalendarChildren, NO_STATE } from "../date-picker/picker-shell.js";
import { PickerDateInput } from "../date-picker/picker-input.js";
import { PickerTimeInput } from "../date-picker/picker-time-input.js";
import { NO_MESSAGES, useRangeRootContext } from "./date-range-picker-context.js";
import { RangeCalendarRoot } from "../range-calendar/range-calendar.js";
import { useCallback, useLayoutEffect, useRef } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
import { Field } from "@base-ui/react/field";
import { useFieldRootContext } from "@base-ui/react/internals/field-root-context";
import { useFormContext } from "@base-ui/react/internals/form-context";
// src/components/date-range-picker/date-range-picker-parts.tsx
const styles = datePickerVariants({ range: true });
const fieldSlots = fieldVariants();
/**
* The picker's visible label. It names the group, both inputs' segments ("month, Start Date,
* Period"), the trigger and the popup; pressing it focuses the first segment. Its text sits in a span
* whose id the Root owns, which every name points at, so an `id` of your own on the label (directly
* or on its `render` element) keeps the names whole, on the server too.
*/
function DateRangePickerLabel({ className, render, children, ...props }) {
	const root = useRangeRootContext("DateRangePicker.Label");
	const { registerPart } = root;
	useLayoutEffect(() => registerPart("label"), [registerPart]);
	return useRender({
		defaultTagName: "span",
		render,
		props: {
			"data-slot": "field-label",
			...mergeProps({
				className: stateClassName(className, NO_STATE, fieldSlots.label()),
				children: /* @__PURE__ */ jsx("span", {
					id: root.labelId,
					children
				}),
				onClick(event) {
					event.currentTarget.closest("[data-slot=\"date-range-picker\"]")?.querySelector(SEGMENT_SELECTOR)?.focus();
				}
			}, definedProps(props))
		}
	});
}
/**
* Supporting copy, which describes the group and both inputs. Its text sits in a span whose id the
* Root owns, as the label's.
*/
function DateRangePickerDescription({ className, render, children, ...props }) {
	const root = useRangeRootContext("DateRangePicker.Description");
	const { registerPart } = root;
	useLayoutEffect(() => registerPart("description"), [registerPart]);
	return useRender({
		defaultTagName: "div",
		render,
		props: {
			"data-slot": "field-description",
			...mergeProps({
				className: stateClassName(className, NO_STATE, fieldSlots.description()),
				children: /* @__PURE__ */ jsx("span", {
					id: root.descriptionId,
					children
				})
			}, definedProps(props))
		}
	});
}
/**
* The merged error of both ends: each end's own message (missing, incomplete, out of bounds,
* unavailable, an end before its start) and the errors a `Form` holds under `startName` and
* `endName`, once each, while the picker is invalid. Children that render anything replace them;
* `null`, `false` and `""` keep them. Renders nothing while the picker is valid. While it renders, the group and both inputs are
* described by its text, which sits in a span whose id the Root owns.
*/
function DateRangePickerError({ className, render, children, ...props }) {
	const root = useRangeRootContext("DateRangePicker.Error");
	const content = (isRenderableNode(children) ? children : null) ?? (root.messages.length > 0 ? root.messages.join(" ") : null);
	const shown = root.invalid && content !== null;
	const { registerPart } = root;
	useLayoutEffect(() => shown ? registerPart("error") : void 0, [shown, registerPart]);
	const element = useRender({
		defaultTagName: "div",
		render,
		enabled: shown,
		props: {
			"data-slot": "field-error",
			...mergeProps({
				role: "alert",
				className: stateClassName(className, NO_STATE, fieldSlots.error()),
				children: /* @__PURE__ */ jsx("span", {
					id: root.errorId,
					children: content
				})
			}, definedProps(props))
		}
	});
	return shown ? element : null;
}
/** Reads its Field's messages and the Form's errors under its name, and reports them to the Root. */
function EndpointMessagesReport({ endpoint, report, otherEnd, reversed }) {
	const field = useFieldRootContext();
	const { validation } = field;
	const shownInvalid = field.state.valid === false;
	const committedValue = field.validityData.value;
	const lastOtherEnd = useRef(otherEnd);
	useLayoutEffect(() => {
		if (lastOtherEnd.current === otherEnd) return;
		lastOtherEnd.current = otherEnd;
		if (shownInvalid || reversed) validation.commit(committedValue);
	}, [
		otherEnd,
		shownInvalid,
		reversed,
		validation,
		committedValue
	]);
	const { errors } = useFormContext();
	const name = field.name;
	const formError = name !== void 0 && Object.hasOwn(errors, name) ? errors[name] : void 0;
	const formMessages = formError === void 0 ? [] : Array.isArray(formError) ? formError : [formError];
	const key = (formMessages.length > 0 ? formMessages : field.state.valid === false ? field.validityData.errors : []).join("\n");
	useLayoutEffect(() => {
		report(endpoint, key === "" ? NO_MESSAGES : key.split("\n"));
	}, [
		report,
		endpoint,
		key
	]);
	useLayoutEffect(() => () => report(endpoint, NO_MESSAGES), [report, endpoint]);
	return null;
}
function DateRangePickerEndpoint({ endpoint, ...props }) {
	const root = useRangeRootContext(endpoint === "start" ? "DateRangePicker.StartInput" : "DateRangePicker.EndInput");
	const strings = useLocalizedStrings(datePickerStrings);
	const reversedMessage = strings.format("rangeReversed");
	const reversed = endpoint === "end" && root.reversed;
	const name = root.names[endpoint];
	const { reportMessages, reportInputInvalid } = root;
	const reportInvalid = useCallback((invalid) => reportInputInvalid(endpoint, invalid), [reportInputInvalid, endpoint]);
	return /* @__PURE__ */ jsxs(Field.Root, {
		className: "contents",
		...definedProps({ name }),
		invalid: root.invalidProp,
		disabled: root.inputSettings.disabled,
		validate: () => reversed ? reversedMessage : null,
		children: [/* @__PURE__ */ jsx(EndpointMessagesReport, {
			endpoint,
			report: reportMessages,
			otherEnd: root.ends[endpoint === "start" ? "end" : "start"]?.toString() ?? "",
			reversed
		}), /* @__PURE__ */ jsx(PickerDateInput, {
			"aria-label": strings.format(endpoint === "start" ? "startDate" : "endDate"),
			...definedProps({
				"aria-labelledby": root.endpointLabelledBy,
				"aria-describedby": root.describedBy
			}),
			...definedProps(props),
			onInvalidChange: reportInvalid,
			value: root.ends[endpoint],
			onValueChange: (value, details) => root.inputChange(endpoint, value, details),
			...root.inputSettings,
			invalid: root.invalidProp || reversed
		})]
	}, root.generation);
}
/**
* The start's segments, a `DateInput.Root` in a Base UI Field of its own under `startName`, named
* "Start Date" and the picker's label.
*/
function DateRangePickerStartInput(props) {
	return /* @__PURE__ */ jsx(DateRangePickerEndpoint, {
		endpoint: "start",
		...props
	});
}
/** The end's segments, in a Field of their own under `endName`, named "End Date" and the label. */
function DateRangePickerEndInput(props) {
	return /* @__PURE__ */ jsx(DateRangePickerEndpoint, {
		endpoint: "end",
		...props
	});
}
function DateRangePickerTimeInput({ endpoint, ...props }) {
	const root = useRangeRootContext(endpoint === "start" ? "DateRangePicker.StartTimeInput" : "DateRangePicker.EndTimeInput");
	return /* @__PURE__ */ jsx(PickerTimeInput, {
		...props,
		binding: root.timeBindings[endpoint],
		settings: root.timeSettings,
		label: endpoint === "start" ? "startTime" : "endTime",
		resetKey: root.generation
	});
}
/**
* The start's time, edited in the popup under the calendar, as `DatePicker.TimeInput` edits the
* single picker's: a time-only `DateInput.Root` named "Start time", rendered only while the range has
* a time to show. A time typed for an end of a whole range changes that end's time. In an empty
* picker it waits for the end's day, and a range picked in the calendar (with
* `shouldCloseOnSelect={false}`) commits once both ends have a time, or when the popup closes, each
* end without a typed time at midnight. It is a Field of its own and submits nothing.
*/
function DateRangePickerStartTimeInput(props) {
	return /* @__PURE__ */ jsx(DateRangePickerTimeInput, {
		endpoint: "start",
		...props
	});
}
/** The end's time in the popup, named "End time", as `StartTimeInput` is the start's. */
function DateRangePickerEndTimeInput(props) {
	return /* @__PURE__ */ jsx(DateRangePickerTimeInput, {
		endpoint: "end",
		...props
	});
}
/**
* The en dash between the inputs. Hidden from assistive technology: the segments already say
* "Start Date" and "End Date".
*/
function DateRangePickerSeparator({ className, render, ...props }) {
	return useRender({
		defaultTagName: "span",
		render,
		props: {
			"data-slot": "date-range-picker-separator",
			...mergeProps({
				"aria-hidden": true,
				className: stateClassName(className, NO_STATE, styles.separator()),
				children: "–"
			}, definedProps(props))
		}
	});
}
/**
* The picker's calendar, a `RangeCalendar.Root` on the range's days. A completed range reports its
* reason and, pressed or chosen by key, closes the popup. Escape on a half-picked range drops it and
* keeps the popup open. With a preset pane, focus leaving the calendar drops a half-picked range
* (`commitBehavior` `"reset"`); without one it completes it (`"select"`). Without children it renders
* the month buttons, the heading and the months.
*/
function DateRangePickerCalendar({ className, children, commitBehavior, ...props }) {
	const root = useRangeRootContext("DateRangePicker.Calendar");
	return /* @__PURE__ */ jsx(RangeCalendarRoot, {
		...definedProps(props),
		commitBehavior: commitBehavior ?? (root.hasPresets ? "reset" : "select"),
		value: root.calendarRange,
		onValueChange: root.selectRange,
		...root.calendarSettings,
		className: cn(styles.calendar(), className),
		children: children ?? /* @__PURE__ */ jsx(DefaultCalendarChildren, {})
	}, root.calendarKey);
}
/**
* DateRangePickerField's popup column: the calendar, and both ends' time inputs side by side under
* it while the range has a time. A date-only range's popup holds the calendar alone, with no column
* around it. Private to the composite: a composition places the time input parts itself.
*/
function DateRangePickerFieldCalendar({ shouldForceLeadingZeros }) {
	if (useRangeRootContext("DateRangePickerField").timeSettings === null) return /* @__PURE__ */ jsx(DateRangePickerCalendar, {});
	return /* @__PURE__ */ jsxs("div", {
		className: styles.timeColumn(),
		children: [/* @__PURE__ */ jsx(DateRangePickerCalendar, {}), /* @__PURE__ */ jsxs("div", {
			className: styles.timeInputs(),
			children: [/* @__PURE__ */ jsx(DateRangePickerStartTimeInput, { shouldForceLeadingZeros }), /* @__PURE__ */ jsx(DateRangePickerEndTimeInput, { shouldForceLeadingZeros })]
		})]
	});
}
export { DateRangePickerCalendar, DateRangePickerDescription, DateRangePickerEndInput, DateRangePickerEndTimeInput, DateRangePickerError, DateRangePickerFieldCalendar, DateRangePickerLabel, DateRangePickerSeparator, DateRangePickerStartInput, DateRangePickerStartTimeInput };

//# sourceMappingURL=date-range-picker-parts.js.map