"use client";
import { cn } from "../../styles/cn.js";
import { mergeClassName } from "../../styles/merge-class-name.js";
import { definedProps } from "../../internal/defined-props.js";
import { ScrollAreaBar } from "../scroll-area/scroll-area.js";
import { attachmentVariants } from "./attachment-variants.js";
import { createContext, useContext } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { ScrollArea } from "@base-ui/react/scroll-area";
// src/components/attachment/attachment.tsx
const styles = attachmentVariants();
/** Whether a part sits inside `Attachment.Group`, whose list owns its roots as list items. */
const AttachmentGroupContext = createContext(false);
/** The enclosing root's orientation. Outside a root an action takes the row's look. */
const AttachmentOrientationContext = createContext("horizontal");
/**
* The orientation of the `Attachment.Root` around the caller, `horizontal` outside one.
*
* @returns The enclosing root's orientation.
*/
function useAttachmentOrientation() {
	return useContext(AttachmentOrientationContext);
}
/**
* One file or image. `orientation="horizontal"` lays the media beside the content, and
* `"vertical"` stacks a tile with the media on top. `size` sets the padding and type. Inside
* `Attachment.Group` it is a list item. It publishes `--inner-corner`, its corner less its border
* and padding, for parts that round with `rounded-inner`. A root holding an `Attachment.Trigger`
* takes a hover fill.
*/
function AttachmentRoot({ className, state = "done", size = "default", orientation = "horizontal", ...props }) {
	const inGroup = useContext(AttachmentGroupContext);
	return /* @__PURE__ */ jsx(AttachmentOrientationContext.Provider, {
		value: orientation,
		children: /* @__PURE__ */ jsx("div", {
			"data-slot": "attachment",
			"data-state": state,
			"data-size": size,
			"data-orientation": orientation,
			...definedProps({ role: inGroup ? "listitem" : void 0 }),
			className: cn(attachmentVariants({
				size,
				orientation
			}).root(), className),
			...props
		})
	});
}
/**
* A horizontally scrolling list of attachments. Name it with `aria-label` or `aria-labelledby`,
* which land on the list; each `Attachment.Root` inside is one of its items. Scrolling snaps to
* each attachment, and an edge fades while more attachments lie past it, on the side right-to-left
* text starts from too. Base UI measures those edges from its `DirectionProvider`, so a
* right-to-left app wraps itself in one besides setting `dir`. The scrollbar shows on hover, and
* the scrolling viewport takes keyboard focus while it overflows.
*/
function AttachmentGroup({ className, children, "aria-label": ariaLabel, "aria-labelledby": ariaLabelledBy, ...props }) {
	return /* @__PURE__ */ jsx(AttachmentGroupContext.Provider, {
		value: true,
		children: /* @__PURE__ */ jsxs(ScrollArea.Root, {
			"data-slot": "attachment-group",
			className: mergeClassName(className, styles.group()),
			...props,
			children: [/* @__PURE__ */ jsx(ScrollArea.Viewport, {
				"data-slot": "attachment-group-viewport",
				"data-focus-ring-control": "",
				className: styles.groupViewport(),
				children: /* @__PURE__ */ jsx(ScrollArea.Content, {
					"data-slot": "attachment-group-list",
					role: "list",
					...definedProps({
						"aria-label": ariaLabel,
						"aria-labelledby": ariaLabelledBy
					}),
					className: styles.groupList(),
					children
				})
			}), /* @__PURE__ */ jsx(ScrollAreaBar, { orientation: "horizontal" })]
		})
	});
}
AttachmentRoot.displayName = "Attachment.Root";
AttachmentGroup.displayName = "Attachment.Group";
export { AttachmentGroup, AttachmentRoot, useAttachmentOrientation };

//# sourceMappingURL=attachment.js.map