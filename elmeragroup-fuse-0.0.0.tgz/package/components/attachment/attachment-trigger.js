"use client";
import { cn } from "../../styles/cn.js";
import { definedProps } from "../../internal/defined-props.js";
import { attachmentVariants } from "./attachment-variants.js";
import { ariaDisabledGuard } from "../../internal/aria-disabled-guard.js";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
// src/components/attachment/attachment-trigger.tsx
const styles = attachmentVariants();
/**
* The attachment's primary action as one control over the whole root, under its
* `Attachment.Actions`. It renders `<button type="button">`, so it never submits a form it sits
* in. Give it an `aria-label`, such as "Preview report.pdf", since it holds no text of its own.
* `render={<a href="…" />}` makes it a link. A trigger composes it as it composes `Button`:
* `<Dialog.Trigger render={<Attachment.Trigger aria-label="Preview report.pdf" />} />`. Place it
* before `Attachment.Actions`, so it comes first in tab order. A link takes no `disabled`, so mark
* an unavailable one `aria-disabled="true"`: it then cancels its own activation. Client only
* because polymorphism is `useRender`.
*/
function AttachmentTrigger({ className, render, ...props }) {
	return useRender({
		defaultTagName: "button",
		props: {
			"data-slot": "attachment-trigger",
			...mergeProps({ className: cn(styles.trigger(), className) }, definedProps(props), ariaDisabledGuard)
		},
		render
	});
}
AttachmentTrigger.displayName = "Attachment.Trigger";
export { AttachmentTrigger };

//# sourceMappingURL=attachment-trigger.js.map