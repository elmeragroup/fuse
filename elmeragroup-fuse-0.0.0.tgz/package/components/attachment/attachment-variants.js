import { cn } from "../../styles/cn.js";
import { tv } from "../../styles/tv.js";
import { selfFocusRingClass, withinFocusRingClass, withinFocusRingControlClass } from "../../styles/utils.js";
import { nativeStateFaceClass } from "../../styles/state-face.js";
import { itemDefaultShellClass, itemShellClass, itemSmShellClass, rowShellClass } from "../../styles/inner-corner/item.js";
// src/components/attachment/attachment-variants.ts
/**
* Keeps a `hidden` part hidden. Fuse ships no preflight, so a slot's own `display` utility beats
* the user agent's `[hidden]` rule. `hidden="until-found"` stays with the browser.
*/
const hiddenGuardClass = cn("[&[hidden]:not([hidden=until-found])]:hidden");
/**
* The Attachment recipe. `root` takes Item's shell, so a part that rounds with `rounded-inner`
* sits concentric inside it. Each size also writes the shell's block and inline padding to
* `--attachment-inset-y` and `--attachment-inset-x`, which a vertical tile's floating actions read.
* The other parts are separate components that never see the root's props, so they style off
* the root's `data-size`, `data-orientation` and `data-state` through the `attachment` group.
*
* `variant` is the media's axis and changes only the `media` slot. Package-private: the facade
* exports the parts, not the recipe.
*/
const attachmentVariants = tv({
	slots: {
		root: cn(itemShellClass, "group/attachment relative box-border flex max-w-full min-w-0 shrink-0 border-border bg-card text-card-foreground transition-colors duration-100", "data-[state=error]:border-error/30 data-[state=idle]:border-dashed", "has-enabled-trigger:enabled-hover:bg-muted", hiddenGuardClass),
		media: cn("relative flex aspect-square w-10 shrink-0 items-center justify-center overflow-hidden rounded-inner bg-muted text-foreground", "group-data-[orientation=vertical]/attachment:w-full group-data-[orientation=horizontal]/attachment:group-data-[size=sm]/attachment:w-8 group-data-[orientation=horizontal]/attachment:group-data-[size=xs]/attachment:w-7", "[&_svg]:pointer-events-none [&_svg:not([class*='size-'])]:size-4 group-data-[orientation=vertical]/attachment:[&_svg:not([class*='size-'])]:size-6 group-data-[orientation=horizontal]/attachment:group-data-[size=xs]/attachment:[&_svg:not([class*='size-'])]:size-3.5", "*:data-[slot=loader]:p-0", "group-data-[state=error]/attachment:bg-error/10 group-data-[state=error]/attachment:text-error", "has-data-[slot=attachment-aspect-ratio]:aspect-auto", hiddenGuardClass),
		aspectRatio: "w-full",
		content: cn("flex max-w-full min-w-0 flex-1 flex-col gap-0.5", hiddenGuardClass),
		title: cn("leading-tight font-medium block max-w-full min-w-0 truncate group-data-[state=processing]/attachment:shimmer group-data-[state=uploading]/attachment:shimmer", hiddenGuardClass),
		description: cn("text-xs leading-tight block max-w-full min-w-0 truncate text-muted-foreground group-data-[state=error]/attachment:text-error", hiddenGuardClass),
		actions: cn("relative z-20 flex shrink-0 items-center gap-1", "group-data-[orientation=vertical]/attachment:absolute group-data-[orientation=vertical]/attachment:end-[calc(var(--attachment-inset-x)+--spacing(1))] group-data-[orientation=vertical]/attachment:top-[calc(var(--attachment-inset-y)+--spacing(1))]", hiddenGuardClass),
		trigger: cn("absolute -inset-px z-10 box-border cursor-pointer rounded-[inherit] border-0 bg-transparent p-0 text-inherit", "font-[family-name:inherit] text-[length:inherit] leading-[inherit] font-[weight:inherit]", selfFocusRingClass, nativeStateFaceClass),
		group: cn("relative flex min-w-0 flex-col rounded-md", withinFocusRingClass, hiddenGuardClass),
		groupViewport: cn("min-w-0 snap-x snap-mandatory scroll-px-1 overscroll-x-contain rounded-[inherit]", "[--attachment-fade:to_right] rtl:[--attachment-fade:to_left]", "data-has-overflow-x:[mask-image:linear-gradient(var(--attachment-fade),transparent_0,black_min(2.5rem,var(--scroll-area-overflow-x-start,0px)),black_calc(100%_-_min(2.5rem,var(--scroll-area-overflow-x-end,0px))),transparent_100%)]", withinFocusRingControlClass),
		groupList: cn("flex w-max gap-(--surface-gap-sm) p-1 *:data-[slot=attachment]:flex-none *:data-[slot=attachment]:snap-start", hiddenGuardClass)
	},
	variants: {
		size: {
			default: { root: [itemDefaultShellClass, "text-sm gap-(--surface-gap-md) [--attachment-inset-x:var(--surface-pad-md)] [--attachment-inset-y:var(--surface-pad-md)]"] },
			sm: { root: [itemSmShellClass, "text-xs gap-(--surface-gap-sm) [--attachment-inset-x:var(--surface-pad-md)] [--attachment-inset-y:var(--row-px)]"] },
			xs: { root: [rowShellClass, "text-xs gap-(--surface-gap-sm) [--attachment-inset-x:var(--row-px)] [--attachment-inset-y:var(--row-py)]"] }
		},
		orientation: {
			horizontal: { root: "min-w-40 items-center" },
			vertical: { root: "w-[calc(8.5rem+2*var(--attachment-inset-x)+2px)] flex-col" }
		},
		variant: {
			icon: {},
			image: { media: "outline-black/10 opacity-60 outline outline-1 -outline-offset-1 group-data-[state=done]/attachment:opacity-100 group-data-[state=idle]/attachment:opacity-100 *:[img]:size-full *:[img]:object-cover" }
		}
	},
	defaultVariants: {
		size: "default",
		orientation: "horizontal",
		variant: "icon"
	}
});
export { attachmentVariants };

//# sourceMappingURL=attachment-variants.js.map