"use client";
import { definedProps } from "../../internal/defined-props.js";
import { Button } from "../button/button.js";
import { useAttachmentOrientation } from "./attachment.js";
import { jsx } from "react/jsx-runtime";
// src/components/attachment/attachment-action.tsx
/**
* An icon button for one action on the attachment, such as remove, retry or download. Name it
* with `aria-label`, such as "Remove report.pdf". It defaults to `size="icon-xs"`, and to the
* `secondary` variant on a vertical tile, so its icon stays visible on any photo, or `ghost` in a
* row. A `variant` you pass wins. Every other prop goes to `Button`.
*/
function AttachmentAction({ variant, size = "icon-xs", "aria-label": ariaLabel, ...props }) {
	const orientation = useAttachmentOrientation();
	return /* @__PURE__ */ jsx(Button, {
		"data-slot": "attachment-action",
		variant: variant ?? (orientation === "vertical" ? "secondary" : "ghost"),
		size,
		"aria-label": ariaLabel,
		...definedProps(props)
	});
}
AttachmentAction.displayName = "Attachment.Action";
export { AttachmentAction };

//# sourceMappingURL=attachment-action.js.map