"use client";
import { cn } from "../../styles/cn.js";
import { definedProps } from "../../internal/defined-props.js";
import { Button } from "../button/button.js";
import { Camera } from "../../icons/generated/camera.js";
import { Folder } from "../../icons/generated/folder.js";
import { Paperclip } from "../../icons/generated/paperclip.js";
import { FileUploadRoot } from "../file-upload/file-upload.js";
import { FileUploadTrigger } from "../file-upload/file-upload-trigger.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
// src/components/file-trigger/file-trigger.tsx
/**
* The Root's render: its children alone, with no element around them. The button and the hidden
* input then sit in the surrounding element, so a parent that styles its direct children, such as
* `ButtonGroup` joining borders and corners, styles the button itself. `display: contents` would
* not do: it hides a wrapper from layout, but child selectors still see the wrapper. With no
* element, the Root registers nothing on the DOM, so FileTrigger takes no paste and installs no
* document drop guard, both of which FileUpload ties to the area its Root element covers.
*/
function childrenOnly(props) {
	return /* @__PURE__ */ jsx(Fragment, { children: props.children });
}
/**
* A Fuse Button that opens the file picker: a `FileUpload.Root` with only a Trigger, so a pick
* runs the same `accept` and count check as FileUpload. `onSelect` receives the files that pass,
* in a new array for each pick, and `onReject` the rest, each with its `reason`. It renders no
* wrapper: the button and its hidden input are children of the surrounding element.
* Client — the Root owns the hidden input and the callbacks.
*/
function FileTrigger({ accept, multiple, directory, capture, disabled, onSelect, onReject, withIcon = true, variant = "default", size = "sm", className, children, ...props }) {
	const Icon = capture ? Camera : directory ? Folder : Paperclip;
	return /* @__PURE__ */ jsx(FileUploadRoot, {
		render: childrenOnly,
		...definedProps({
			accept,
			multiple,
			directory,
			capture,
			disabled,
			onSelect,
			onReject
		}),
		children: /* @__PURE__ */ jsxs(FileUploadTrigger, {
			render: /* @__PURE__ */ jsx(Button, {
				variant,
				size
			}),
			"data-slot": "file-trigger",
			className: cn(withIcon && "gap-x-2", className),
			...props,
			children: [withIcon ? /* @__PURE__ */ jsx(Icon, { "aria-hidden": true }) : null, children]
		})
	});
}
FileTrigger.displayName = "FileTrigger";
export { FileTrigger };

//# sourceMappingURL=file-trigger.js.map