"use client";
import { panelHeightTransition } from "../../styles/panel-height.js";
import { selfFocusRingClass } from "../../styles/utils.js";
import { mergeClassName } from "../../styles/merge-class-name.js";
import { jsx } from "react/jsx-runtime";
import { Collapsible } from "@base-ui/react/collapsible";
// src/components/collapsible/collapsible.tsx
/**
* Client single-disclosure primitive. Visually unstyled passthrough apart from the shared
* open/close height transition on `Content` (`styles/panel-height.ts`), which consumers can
* override through `className`; Accordion is the styled sibling.
*/
function CollapsibleRoot(props) {
	return /* @__PURE__ */ jsx(Collapsible.Root, {
		"data-slot": "collapsible",
		...props
	});
}
function CollapsibleTrigger({ className, ...props }) {
	return /* @__PURE__ */ jsx(Collapsible.Trigger, {
		"data-slot": "collapsible-trigger",
		className: mergeClassName(className, selfFocusRingClass),
		...props
	});
}
function CollapsibleContent({ className, ...props }) {
	return /* @__PURE__ */ jsx(Collapsible.Panel, {
		"data-slot": "collapsible-content",
		className: mergeClassName(className, panelHeightTransition, "h-(--collapsible-panel-height)"),
		...props
	});
}
CollapsibleRoot.displayName = "Collapsible.Root";
CollapsibleTrigger.displayName = "Collapsible.Trigger";
CollapsibleContent.displayName = "Collapsible.Content";
export { CollapsibleContent, CollapsibleRoot, CollapsibleTrigger };

//# sourceMappingURL=collapsible.js.map