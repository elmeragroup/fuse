import { cn } from "../../styles/cn.js";
import { tv } from "../../styles/tv.js";
import { selfFocusRingClass } from "../../styles/utils.js";
import { dataStateFaceClass, nativeStateFaceClass } from "../../styles/state-face.js";
import { controlSize } from "../../styles/control-size.js";
// src/components/button/button-variants.ts
const buttonVariants = tv({
	base: cn("group/button font-medium box-border inline-flex shrink-0 cursor-pointer items-center justify-center rounded-(--radius-button) border border-transparent p-0 whitespace-nowrap transition-[color,background-color,border-color,box-shadow,translate,opacity] select-none [--button-px-floor:var(--button-label-px-min,0px)] in-data-[slot=button-group]:rounded-md in-data-[slot=button-group]:[--button-px-floor:0px] enabled-active:not-aria-[haspopup]:translate-y-px [&_svg]:pointer-events-none [&_svg]:shrink-0 [&_svg:not([class*='size-'])]:size-4 data-[pending-indicator]:[&>svg:not([data-icon=inline-end])]:hidden", selfFocusRingClass, nativeStateFaceClass, dataStateFaceClass),
	variants: {
		variant: {
			default: "bg-primary text-primary-foreground enabled-hover:bg-primary/80",
			outline: "border-[length:var(--button-outline-width,1px)] border-button-outline bg-transparent shadow-[0_1px_max(0px,4px-2*var(--button-outline-width,1px))_min(0px,2px-2*var(--button-outline-width,1px))_rgb(0_0_0/0.05)] aria-expanded:bg-muted aria-expanded:text-foreground enabled-hover:bg-muted enabled-hover:text-foreground",
			secondary: "bg-secondary text-secondary-foreground aria-expanded:bg-secondary aria-expanded:text-secondary-foreground enabled-hover:bg-secondary-hover",
			ghost: "aria-expanded:bg-muted aria-expanded:text-foreground enabled-hover:bg-muted enabled-hover:text-foreground",
			destructive: "border-error/20 bg-error/10 text-error enabled-hover:border-error enabled-hover:bg-error/20",
			success: "border-success/20 bg-success/10 text-success enabled-hover:border-success enabled-hover:bg-success/20",
			link: "text-primary underline-offset-4 enabled-hover:underline"
		},
		size: {
			default: controlSize({
				size: "md",
				fit: "label",
				class: "px-[max(var(--control-px-button-md),var(--button-px-floor))] has-data-[icon=inline-end]:pr-(--control-px-button-icon-md) has-data-[icon=inline-start]:pl-(--control-px-button-icon-md)"
			}),
			xs: controlSize({
				size: "xs",
				fit: "label",
				class: "px-[max(var(--control-px-button-xs),var(--button-px-floor))] has-data-[icon=inline-end]:pr-(--control-px-button-icon-xs) has-data-[icon=inline-start]:pl-(--control-px-button-icon-xs) [&_svg:not([class*='size-'])]:size-3"
			}),
			sm: controlSize({
				size: "sm",
				fit: "label",
				class: "px-[max(var(--control-px-button-sm),var(--button-px-floor))] has-data-[icon=inline-end]:pr-(--control-px-button-icon-sm) has-data-[icon=inline-start]:pl-(--control-px-button-icon-sm)"
			}),
			lg: controlSize({
				size: "lg",
				fit: "label",
				class: "px-[max(var(--control-px-button-lg),var(--button-px-floor))] has-data-[icon=inline-end]:pr-(--control-px-button-icon-lg) has-data-[icon=inline-start]:pl-(--control-px-button-icon-lg)"
			}),
			icon: controlSize({
				size: "md",
				fit: "square"
			}),
			"icon-xs": controlSize({
				size: "xs",
				fit: "square",
				class: "[&_svg:not([class*='size-'])]:size-3"
			}),
			"icon-sm": controlSize({
				size: "sm",
				fit: "square"
			}),
			"icon-inline": "hit-area-[max(0.25rem,calc((24px_-_100%)/2))] aspect-square h-lh w-auto align-top font-[family-name:inherit] text-[length:inherit] leading-[inherit] font-[weight:inherit]",
			"icon-lg": controlSize({
				size: "lg",
				fit: "square"
			})
		}
	},
	defaultVariants: {
		variant: "default",
		size: "default"
	}
});
export { buttonVariants };

//# sourceMappingURL=button-variants.js.map