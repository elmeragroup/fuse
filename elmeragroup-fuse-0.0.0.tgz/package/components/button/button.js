"use client";
import { cn } from "../../styles/cn.js";
import { useMergedRefs } from "../../hooks/use-merged-refs.js";
import { usePredictedEvents } from "../../hooks/use-predicted-events.js";
import { SpinnerGap } from "../../icons/generated/spinner-gap.js";
import { definedProps } from "../../internal/defined-props.js";
import { buttonVariants } from "./button-variants.js";
import { jsx, jsxs } from "react/jsx-runtime";
import { Button as Button$1 } from "@base-ui/react/button";
// src/components/button/button.tsx
/**
* Triggers an action. Mark a leading or trailing icon child with `data-icon="inline-start"` or
* `data-icon="inline-end"`, on your own icon components too, so that side takes the icon
* padding instead of the wider label padding. The attribute must reach the rendered element.
*/
function Button({ className, variant, size, isVisuallyDisabled = false, disabled = false, isPending = false, pendingIndicator, predictionZoneSize = 30, onIntent, onMouseDown, children, ref, ...props }) {
	const { ref: predictedRef } = usePredictedEvents({
		predictionZoneSize,
		onIntent,
		enabled: !disabled && !isPending && !isVisuallyDisabled && onIntent !== void 0
	});
	const mergedRef = useMergedRefs(ref, onIntent === void 0 ? null : predictedRef);
	const showsIndicator = isPending && pendingIndicator !== null && pendingIndicator !== false;
	return /* @__PURE__ */ jsxs(Button$1, {
		"data-slot": "button",
		"data-size": size ?? "default",
		"data-pending": isPending || void 0,
		"data-pending-indicator": showsIndicator || void 0,
		disabled: disabled || isPending,
		...definedProps({
			focusableWhenDisabled: isPending || void 0,
			"aria-busy": isPending || void 0
		}),
		...definedProps({ "aria-disabled": isVisuallyDisabled || void 0 }),
		className: cn(buttonVariants({
			variant,
			size
		}), className),
		onMouseDown: (event) => {
			if (isVisuallyDisabled) event.preventDefault();
			onMouseDown?.(event);
		},
		...definedProps(props),
		ref: mergedRef,
		children: [showsIndicator ? /* @__PURE__ */ jsx("span", {
			"data-slot": "button-pending-indicator",
			"data-icon": "inline-start",
			"aria-hidden": true,
			className: "pointer-events-none inline-flex shrink-0 items-center justify-center",
			children: pendingIndicator ?? /* @__PURE__ */ jsx(SpinnerGap, { className: "animate-spin" })
		}) : null, children]
	});
}
Button.displayName = "Button";
export { Button };

//# sourceMappingURL=button.js.map