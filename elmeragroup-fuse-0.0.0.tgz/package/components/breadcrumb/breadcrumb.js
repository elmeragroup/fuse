"use client";
import { cn } from "../../styles/cn.js";
import { useLocalizedStrings } from "../../hooks/use-localized-strings.js";
import { CaretRight } from "../../icons/generated/caret-right.js";
import { DotsThree } from "../../icons/generated/dots-three.js";
import { breadcrumbVariants } from "./breadcrumb-variants.js";
import { breadcrumbStrings } from "./intl/index.js";
import { jsx, jsxs } from "react/jsx-runtime";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
// src/components/breadcrumb/breadcrumb.tsx
const styles = breadcrumbVariants();
/**
* Client breadcrumb trail. `Breadcrumb.Link` is the library
* exemplar for `useRender` + `state.slot → data-slot`. Landmark and ellipsis copy
* come from the provider dictionary.
*/
function BreadcrumbRoot({ className, label, "aria-label": ariaLabel, ...props }) {
	const strings = useLocalizedStrings(breadcrumbStrings);
	return /* @__PURE__ */ jsx("nav", {
		"data-slot": "breadcrumb",
		"aria-label": ariaLabel ?? label ?? strings.format("landmark"),
		className: cn(className),
		...props
	});
}
function BreadcrumbList({ className, ...props }) {
	return /* @__PURE__ */ jsx("ol", {
		"data-slot": "breadcrumb-list",
		className: cn(styles.list(), className),
		...props
	});
}
function BreadcrumbItem({ className, ...props }) {
	return /* @__PURE__ */ jsx("li", {
		"data-slot": "breadcrumb-item",
		className: cn(styles.item(), className),
		...props
	});
}
function BreadcrumbLink({ className, render, ...props }) {
	return useRender({
		defaultTagName: "a",
		props: mergeProps({ className: cn(styles.link(), className) }, props),
		render,
		state: { slot: "breadcrumb-link" }
	});
}
function BreadcrumbPage({ className, ...props }) {
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "breadcrumb-page",
		role: "link",
		"aria-disabled": "true",
		"aria-current": "page",
		className: cn(styles.page(), className),
		...props
	});
}
function BreadcrumbSeparator({ children, className, ...props }) {
	return /* @__PURE__ */ jsx("li", {
		"data-slot": "breadcrumb-separator",
		role: "presentation",
		"aria-hidden": "true",
		className: cn(styles.separator(), className),
		...props,
		children: children ?? /* @__PURE__ */ jsx(CaretRight, {})
	});
}
function BreadcrumbEllipsis({ className, label, ...props }) {
	const strings = useLocalizedStrings(breadcrumbStrings);
	return /* @__PURE__ */ jsxs("span", {
		"data-slot": "breadcrumb-ellipsis",
		className: cn(styles.ellipsis(), className),
		...props,
		children: [/* @__PURE__ */ jsx(DotsThree, { "aria-hidden": "true" }), /* @__PURE__ */ jsx("span", {
			className: "sr-only",
			children: label ?? strings.format("more")
		})]
	});
}
BreadcrumbRoot.displayName = "Breadcrumb.Root";
BreadcrumbList.displayName = "Breadcrumb.List";
BreadcrumbItem.displayName = "Breadcrumb.Item";
BreadcrumbLink.displayName = "Breadcrumb.Link";
BreadcrumbPage.displayName = "Breadcrumb.Page";
BreadcrumbSeparator.displayName = "Breadcrumb.Separator";
BreadcrumbEllipsis.displayName = "Breadcrumb.Ellipsis";
export { BreadcrumbEllipsis, BreadcrumbItem, BreadcrumbLink, BreadcrumbList, BreadcrumbPage, BreadcrumbRoot, BreadcrumbSeparator };

//# sourceMappingURL=breadcrumb.js.map