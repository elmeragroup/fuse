// src/components/breadcrumb/intl/fi-FI.ts
/** Default localized copy for the `breadcrumb.*` rows. */
const fiFI = {
	landmark: "Murupolku",
	more: "Lisää"
};
export { fiFI };

//# sourceMappingURL=fi-FI.js.map