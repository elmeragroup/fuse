// src/components/breadcrumb/intl/en-US.ts
/** Default localized copy for the `breadcrumb.*` rows. */
const enUS = {
	landmark: "Breadcrumb",
	more: "More"
};
export { enUS };

//# sourceMappingURL=en-US.js.map