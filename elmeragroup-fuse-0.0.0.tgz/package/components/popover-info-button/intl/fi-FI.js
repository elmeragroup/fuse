// src/components/popover-info-button/intl/fi-FI.ts
/** Default localized copy for popoverInfoButton.moreInformation. */
const fiFI = { moreInformation: "Lisätietoja" };
export { fiFI };

//# sourceMappingURL=fi-FI.js.map