// src/components/popover-info-button/intl/en-US.ts
/** Default localized copy for popoverInfoButton.moreInformation. */
const enUS = { moreInformation: "More information" };
export { enUS };

//# sourceMappingURL=en-US.js.map