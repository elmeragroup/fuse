"use client";
import { cn } from "../../styles/cn.js";
import { tv } from "../../styles/tv.js";
import { iconCrossfadeHidden, iconCrossfadeShown, iconCrossfadeTransition, selfFocusRingClass } from "../../styles/utils.js";
import { racDisabledStateFaceClass } from "../../styles/state-face.js";
import { definedProps } from "../../internal/defined-props.js";
import { CheckCircle } from "../../icons/generated/check-circle.js";
import { Badge } from "../badge/badge.js";
import { checkboxCardContentShellClass } from "../../styles/inner-corner/card.js";
import { Card } from "../card/card.js";
import { useCheckedResetSync } from "../../hooks/use-checked-reset-sync.js";
import { Circle } from "../../icons/generated/circle.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
import { Field } from "@base-ui/react/field";
import { Checkbox } from "@base-ui/react/checkbox";
// src/components/checkbox-card/checkbox-card.tsx
const checkboxCardStyles = tv({
	base: "shadow-xs border-border",
	variants: {
		variant: {
			default: "bg-card",
			muted: "bg-muted"
		},
		isDisabled: { true: racDisabledStateFaceClass }
	},
	defaultVariants: { variant: "default" }
});
/**
* Selectable marketing or product card over the base-ui Checkbox primitive. Client
* component, because it wires Field.Item, the label and the checkbox primitive. It needs a
* `Field.Root` ancestor, and a checkbox-group ancestor for `value` membership. Native form
* reset, including React's reset after a form action, keeps the current state and what the form
* submits in step; an uncontrolled card does not return to `defaultChecked`.
*/
function CheckboxCard({ children, title, tags, description, variant = "default", rightContent, isDisabled, value, inputRef, ...other }) {
	const syncedInputRef = useCheckedResetSync(inputRef);
	return /* @__PURE__ */ jsx(Field.Item, { children: /* @__PURE__ */ jsx(Card.Root, {
		className: checkboxCardStyles({
			variant,
			isDisabled
		}),
		children: /* @__PURE__ */ jsxs(Card.Content, {
			className: cn(checkboxCardContentShellClass, "flex items-center justify-between gap-3"),
			children: [/* @__PURE__ */ jsxs(Field.Label, {
				className: "group flex grow cursor-pointer items-center gap-3 bg-clip-padding outline-hidden has-disabled:cursor-not-allowed",
				children: [/* @__PURE__ */ jsx(Checkbox.Root, {
					inputRef: syncedInputRef,
					value,
					disabled: isDisabled,
					className: cn("flex shrink-0 items-center rounded-full text-foreground outline-hidden select-none", selfFocusRingClass),
					render: (props, state) => /* @__PURE__ */ jsxs("span", {
						...props,
						className: cn(props.className, "relative inline-grid size-6"),
						children: [/* @__PURE__ */ jsx(Circle, {
							"aria-hidden": true,
							className: cn("col-start-1 row-start-1 size-6 text-foreground", iconCrossfadeTransition, state.checked ? iconCrossfadeHidden : iconCrossfadeShown)
						}), /* @__PURE__ */ jsx(CheckCircle, {
							"aria-hidden": true,
							weight: "fill",
							className: cn("col-start-1 row-start-1 size-6 text-success", iconCrossfadeTransition, state.checked ? iconCrossfadeShown : iconCrossfadeHidden)
						})]
					}),
					...definedProps(other)
				}), /* @__PURE__ */ jsxs("div", { children: [
					/* @__PURE__ */ jsxs("div", {
						className: "flex flex-1 flex-col",
						children: [tags && tags.length > 0 ? /* @__PURE__ */ jsx("div", {
							className: "flex items-center gap-2",
							children: tags.map((tag) => /* @__PURE__ */ jsx(Badge, { children: tag }, tag))
						}) : null, /* @__PURE__ */ jsx("div", {
							className: "text-lg font-medium text-balance text-foreground",
							children: title
						})]
					}),
					/* @__PURE__ */ jsx("div", {
						className: "text-sm text-pretty text-foreground",
						children: description
					}),
					children
				] })]
			}), rightContent ? /* @__PURE__ */ jsx(Fragment, { children: rightContent }) : null]
		})
	}) });
}
CheckboxCard.displayName = "CheckboxCard";
export { CheckboxCard };

//# sourceMappingURL=checkbox-card.js.map