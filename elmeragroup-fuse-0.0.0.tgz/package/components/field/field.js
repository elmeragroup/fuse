"use client";
import { cn } from "../../styles/cn.js";
import { useMergedRefs } from "../../hooks/use-merged-refs.js";
import { documentOrder } from "../../internal/dom-node.js";
import { mergeClassName } from "../../styles/merge-class-name.js";
import { definedProps } from "../../internal/defined-props.js";
import { FieldSetDisabledContext } from "../../internal/field-set-disabled.js";
import { Separator } from "../separator/separator.js";
import { fieldLegendVariants, fieldVariants } from "./field-variants.js";
import { createContext, use, useEffect, useId, useLayoutEffect, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { useRender } from "@base-ui/react/use-render";
import { Field } from "@base-ui/react/field";
import { Fieldset } from "@base-ui/react/fieldset";
// src/components/field/field.tsx
const DescriptionOwnerContext = createContext(null);
const fieldDescriptionOwner = { _tag: "field" };
/**
* A vertical root sets its label 4px from its control at both densities, the stack every labeled
* composite renders, so a field built from parts lines up with a `TextField` beside it.
*/
function FieldRoot({ className, orientation = "vertical", ...props }) {
	return /* @__PURE__ */ jsx(DescriptionOwnerContext.Provider, {
		value: fieldDescriptionOwner,
		children: /* @__PURE__ */ jsx(Field.Root, {
			"data-slot": "field",
			"data-orientation": orientation,
			className: mergeClassName(className, fieldVariants({ orientation }).root()),
			...props
		})
	});
}
/**
* Outside a `Field.Root`, the set is described by the `Field.Description` parts it holds, after
* the consumer's own `aria-describedby`. Inside a root, they describe the root's control instead.
* A disabled set, or one inside a disabled set, as Base UI resolves it, also disables the parts
* that are not a Field themselves, such as a date picker's trigger and calendar
* (`internal/field-set-disabled.ts`).
*/
function FieldSet({ className, ref, "aria-describedby": consumerDescribedBy, ...props }) {
	const owner = use(DescriptionOwnerContext);
	const disabled = use(FieldSetDisabledContext) || props.disabled === true;
	const [descriptionIds, setDescriptionIds] = useState("");
	const [{ fieldsetOwner, sync }] = useState(() => {
		const elements = /* @__PURE__ */ new Set();
		const sync = () => setDescriptionIds([...elements].sort(documentOrder).map((element) => element.id).join(" "));
		return {
			fieldsetOwner: {
				_tag: "fieldset",
				add: (element) => {
					elements.add(element);
					sync();
					return () => {
						elements.delete(element);
						sync();
					};
				}
			},
			sync
		};
	});
	const [fieldset, setFieldset] = useState(null);
	const mergedRef = useMergedRefs(ref, setFieldset);
	const ownsDescriptions = owner?._tag !== "field";
	useEffect(() => {
		if (!fieldset || !ownsDescriptions) return;
		const observer = new MutationObserver(sync);
		observer.observe(fieldset, {
			childList: true,
			subtree: true,
			attributeFilter: ["id"]
		});
		return () => observer.disconnect();
	}, [
		fieldset,
		ownsDescriptions,
		sync
	]);
	const describedBy = [consumerDescribedBy, descriptionIds].filter(Boolean).join(" ");
	return /* @__PURE__ */ jsx(DescriptionOwnerContext.Provider, {
		value: ownsDescriptions ? fieldsetOwner : owner,
		children: /* @__PURE__ */ jsx(FieldSetDisabledContext, {
			value: disabled,
			children: /* @__PURE__ */ jsx(Fieldset.Root, {
				ref: mergedRef,
				"data-slot": "field-set",
				className: mergeClassName(className, fieldSetClassName),
				...definedProps({
					...props,
					"aria-describedby": describedBy || void 0
				})
			})
		})
	});
}
function FieldLegend({ className, variant = "legend", ...props }) {
	return /* @__PURE__ */ jsx(Fieldset.Legend, {
		"data-slot": "field-legend",
		"data-variant": variant,
		className: mergeClassName(className, fieldLegendVariants({ variant })),
		...definedProps(props)
	});
}
function FieldGroup({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "field-group",
		className: cn("group/field-group @container/field-group flex w-full flex-col gap-(--surface-gap-xl) *:data-[slot=checkbox-group]:gap-(--surface-gap-md) *:data-[slot=field-group]:gap-(--surface-gap-lg) *:data-[slot=radio-group]:gap-(--surface-gap-md)", className),
		...props
	});
}
function FieldContent({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "field-content",
		className: cn("group/field-content leading-snug flex flex-1 flex-col gap-1", className),
		...props
	});
}
const fieldSetClassName = fieldVariants().set();
const fieldTitleClassName = fieldVariants().title();
const fieldLabelClassName = fieldVariants().label();
const fieldDescriptionClassName = fieldVariants().description();
const fieldErrorClassName = fieldVariants().error();
/**
* A label whose direct child is a `Checkbox` renders as a choice row: centered with a pointer
* cursor. The heading weight is the same as any other label; a consumer `font-*` class wins through
* the merge.
*/
function FieldLabel({ className, ...props }) {
	return /* @__PURE__ */ jsx(Field.Label, {
		"data-slot": "field-label",
		"data-field-heading": "",
		className: mergeClassName(className, fieldLabelClassName),
		...definedProps(props)
	});
}
function FieldTitle({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "field-title",
		"data-field-heading": "",
		className: cn(fieldTitleClassName, className),
		...props
	});
}
function FieldControl(props) {
	return /* @__PURE__ */ jsx(Field.Control, {
		"data-slot": "field-control",
		...definedProps(props)
	});
}
const unownedDescriptionState = {
	disabled: false,
	touched: false,
	dirty: false,
	valid: null,
	filled: false,
	focused: false
};
/**
* Supporting copy. Inside a `Field.Root` it describes the field's control. Outside any root it
* renders the same paragraph, and inside a `Field.Set` it describes that fieldset, so a
* description can follow a `Field.Legend` without a root around the set.
*/
function FieldDescription({ className, ...props }) {
	const owner = use(DescriptionOwnerContext);
	const descriptionClassName = mergeClassName(className, fieldDescriptionClassName);
	if (owner?._tag === "field") return /* @__PURE__ */ jsx(Field.Description, {
		"data-slot": "field-description",
		className: descriptionClassName,
		...definedProps(props)
	});
	return /* @__PURE__ */ jsx(UnownedDescription, {
		registry: owner?._tag === "fieldset" ? owner : void 0,
		className: descriptionClassName,
		...props
	});
}
function UnownedDescription({ registry, className, style, render, ref, id, ...props }) {
	const generatedId = useId();
	const [element, setElement] = useState(null);
	useLayoutEffect(() => element ? registry?.add(element) : void 0, [registry, element]);
	return useRender({
		defaultTagName: "p",
		render,
		ref: ref ? [ref, setElement] : setElement,
		state: unownedDescriptionState,
		props: {
			"data-slot": "field-description",
			className: typeof className === "function" ? className(unownedDescriptionState) : className,
			style: typeof style === "function" ? style(unownedDescriptionState) : style,
			...definedProps(props),
			id: id ?? generatedId
		}
	});
}
function FieldItem(props) {
	return /* @__PURE__ */ jsx(Field.Item, {
		"data-slot": "field-item",
		...definedProps(props)
	});
}
function FieldSeparator({ children, className, ...props }) {
	return /* @__PURE__ */ jsxs("div", {
		"data-slot": "field-separator",
		"data-content": children ? "true" : "false",
		className: cn("text-sm relative -my-2 h-5 group-data-[variant=outline]/field-group:-mb-2", className),
		...props,
		children: [/* @__PURE__ */ jsx(Separator, { className: "absolute inset-0 top-1/2" }), children ? /* @__PURE__ */ jsx("span", {
			className: "relative mx-auto block w-fit bg-background px-2 text-muted-foreground",
			"data-slot": "field-separator-content",
			children
		}) : null]
	});
}
/**
* The field's error message, announced as an alert. Place it directly after the control,
* ahead of any `Field.Description`, so the message sits right under a field in error, as
* the labeled composites place theirs.
*
* Children are shown as given: the caller decides when the field is in error, and a `match`
* narrows that to one validity state. Without children it falls through to Base UI's own
* message, and renders nothing while the field has none: an error from `Form`'s `errors` under
* the field's name, a `validate` result or the native constraint message, which is in the
* browser's language. Several messages render as a list.
*/
function FieldError({ className, children, ...props }) {
	const errorClassName = mergeClassName(className, fieldErrorClassName);
	if (!children) return /* @__PURE__ */ jsx(Field.Error, {
		role: "alert",
		"data-slot": "field-error",
		className: errorClassName,
		...definedProps(props)
	});
	return /* @__PURE__ */ jsx(Field.Error, {
		match: true,
		role: "alert",
		"data-slot": "field-error",
		className: errorClassName,
		...definedProps(props),
		children
	});
}
FieldRoot.displayName = "Field.Root";
FieldLabel.displayName = "Field.Label";
FieldDescription.displayName = "Field.Description";
FieldError.displayName = "Field.Error";
FieldControl.displayName = "Field.Control";
FieldItem.displayName = "Field.Item";
FieldContent.displayName = "Field.Content";
FieldGroup.displayName = "Field.Group";
FieldSet.displayName = "Field.Set";
FieldLegend.displayName = "Field.Legend";
FieldSeparator.displayName = "Field.Separator";
FieldTitle.displayName = "Field.Title";
export { FieldContent, FieldControl, FieldDescription, FieldError, FieldGroup, FieldItem, FieldLabel, FieldLegend, FieldRoot, FieldSeparator, FieldSet, FieldTitle };

//# sourceMappingURL=field.js.map