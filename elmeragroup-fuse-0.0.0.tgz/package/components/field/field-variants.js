import { cn } from "../../styles/cn.js";
import { tv } from "../../styles/tv.js";
import { fieldLabelCardShellClass } from "../../styles/inner-corner/field-label.js";
import { labelTypeClass } from "../../styles/label-type.js";
// src/components/field/field-variants.ts
/**
* Runtime-free Field recipes. Not exported from the public entry, since there is no proven
* recipe-borrowing use; the workspace-only recipe catalog re-exports them for the Figma component
* sync. `fieldVariants` holds a slot per part but Legend, and `orientation` is the Root axis. The
* Title and the Label share their heading classes: `title` puts its centering before them, and
* `label` its composition arms. `description` and `error` are the other text parts. `set` stacks a
* `Field.Set`'s parts, closer around a checkbox or radio group. `field.tsx` resolves the slots of
* the parts without an axis once at module scope. `fieldLegendVariants` is Legend's own recipe,
* whose `variant` sets its text size. The headings, the description and the error read the label
* type pair, as a label-variant legend does.
*/
const headingClass = cn(labelTypeClass, "font-medium flex w-fit gap-2 group-data-disabled/field:opacity-50");
const fieldVariants = tv({
	slots: {
		root: "group/field flex w-full data-invalid:text-error",
		title: ["items-center", headingClass],
		label: [
			fieldLabelCardShellClass,
			"group/field-label peer/field-label has-data-checked:border-primary/30",
			"has-[>[data-slot=field]]:w-full has-[>[data-slot=field]]:flex-col",
			"has-[>[data-slot=checkbox]]:cursor-pointer has-[>[data-slot=checkbox]]:items-center",
			headingClass
		],
		description: [labelTypeClass, "font-normal text-left text-pretty text-muted-foreground group-has-data-horizontal/field:text-balance last:mt-0 [&>a]:underline [&>a]:underline-offset-4 [&>a:hover]:text-primary [[data-variant=legend]+&]:-mt-1.5"],
		error: [labelTypeClass, "font-normal text-error"],
		set: "flex flex-col gap-(--surface-gap-xl) has-[>[data-slot=checkbox-group]]:gap-(--surface-gap-md) has-[>[data-slot=radio-group]]:gap-(--surface-gap-md)"
	},
	variants: { orientation: {
		vertical: { root: "flex-col gap-1 [&>.sr-only]:w-auto [&>:where(:not([data-slot=checkbox],[data-slot=switch]))]:w-full" },
		horizontal: { root: "flex-row items-center gap-(--surface-gap-md) has-[>[data-slot=field-content]]:items-start *:data-field-heading:flex-auto has-[>[data-slot=field-content]]:[&>[role=checkbox],[role=radio]]:mt-px" },
		responsive: { root: "@md/field-group:flex-row @md/field-group:items-center @md/field-group:gap-(--surface-gap-md) @md/field-group:[&>:where(:not([data-slot=checkbox],[data-slot=switch]))]:w-auto @md/field-group:has-[>[data-slot=field-content]]:items-start @md/field-group:*:data-field-heading:flex-auto @md/field-group:has-[>[data-slot=field-content]]:[&>[role=checkbox],[role=radio]]:mt-px flex-col gap-1 [&>.sr-only]:w-auto [&>:where(:not([data-slot=checkbox],[data-slot=switch]))]:w-full" }
	} },
	defaultVariants: { orientation: "vertical" }
});
const fieldLegendVariants = tv({
	base: "font-medium mb-3 text-balance",
	variants: { variant: {
		legend: "text-base",
		label: labelTypeClass
	} },
	defaultVariants: { variant: "legend" }
});
export { fieldLegendVariants, fieldVariants };

//# sourceMappingURL=field-variants.js.map