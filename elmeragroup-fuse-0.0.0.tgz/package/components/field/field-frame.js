import { cn } from "../../styles/cn.js";
import { iconCrossfadeHidden, iconCrossfadeShown, iconCrossfadeTransition } from "../../styles/utils.js";
import { SpinnerGap } from "../../icons/generated/spinner-gap.js";
import { definedProps } from "../../internal/defined-props.js";
import { Check } from "../../icons/generated/check.js";
import { FieldDescription, FieldError, FieldLabel, FieldLegend, FieldRoot, FieldSet } from "./field.js";
import { fieldFrameVariants } from "./field-frame-variants.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
// src/components/field/field-frame.tsx
const fieldFrameSlots = fieldFrameVariants();
const legendDescriptionSlots = fieldFrameVariants({ legendDescription: true });
/**
* A label frame's root class. Its 4px stack restates the vertical `Field.Root`'s, since TextField's
* public recipe composes this slot as its `base`.
*/
const fieldFrameRootClass = fieldFrameSlots.root();
/**
* The heading row's own layout. Composites append their own classes (TextareaField the
* counter gap) through {@link FieldFrameClassNames.labelRow}.
*/
const fieldFrameLabelRowClass = fieldFrameSlots.labelRow();
/**
* Default `Field.Description` class. `text-pretty` lives here, not on TextField's public
* slot: Field.Description already paints it, and PhoneNumberField must not import
* TextField's recipe to re-state it.
*/
const fieldFrameDescriptionClass = fieldFrameSlots.description();
/**
* Package-private heading/description/error frame for every labeled composite.
* `heading="legend"` is the fieldset skeleton CheckboxGroup and
* RadioGroup used to rebuild beside this module.
*
* It is not exported through `package.json#exports` and has no client directive. It owns
* no state. Most consumers are client modules, but SelectField, AutocompleteField and
* ComboboxField are server components that render it, so FieldFrame must stay hook-free, and a
* directive would only widen the client graph.
*
* Keep exactly one `Field.Root` per composite so a nested root cannot break label wiring.
*/
function FieldFrame({ heading = "label", label, isLabelHidden = false, status, isPending = false, isSuccess = false, description, errorMessage, isErrorMessageAlwaysShown = true, isDescriptionBeside = false, variant, isEmpty = false, invalid, disabled, name, className, classNames, children }) {
	const hasCrossfade = isPending || isSuccess;
	const hasStatus = status != null || hasCrossfade;
	const legendDescription = heading === "legend" && Boolean(label) && !isLabelHidden && Boolean(description);
	const headingClass = cn(isLabelHidden && "sr-only", legendDescription && legendDescriptionSlots.label(), classNames?.label);
	const descriptionNode = description ? /* @__PURE__ */ jsx(FieldDescription, {
		className: cn(legendDescription ? legendDescriptionSlots.description() : fieldFrameDescriptionClass, classNames?.description),
		children: description
	}) : null;
	const leadingDescription = heading === "legend" ? descriptionNode : null;
	const trailingDescription = heading === "legend" ? null : descriptionNode;
	const errorNode = /* @__PURE__ */ jsx(FieldError, {
		match: isErrorMessageAlwaysShown ? void 0 : false,
		children: errorMessage
	});
	const body = /* @__PURE__ */ jsxs(Fragment, { children: [
		leadingDescription,
		children,
		isDescriptionBeside ? null : errorNode,
		trailingDescription
	] });
	const content = classNames?.content === void 0 ? body : /* @__PURE__ */ jsx("div", {
		className: classNames.content,
		children: body
	});
	const headingRow = label || hasStatus ? /* @__PURE__ */ jsxs("div", {
		className: cn(fieldFrameLabelRowClass, isLabelHidden && !hasStatus && "sr-only", classNames?.labelRow),
		children: [
			label ? heading === "legend" ? /* @__PURE__ */ jsx(FieldLegend, {
				variant: "label",
				className: headingClass,
				children: label
			}) : /* @__PURE__ */ jsx(FieldLabel, {
				className: headingClass,
				children: label
			}) : null,
			status,
			hasCrossfade ? /* @__PURE__ */ jsxs("div", {
				className: "relative size-3.5",
				children: [/* @__PURE__ */ jsx(SpinnerGap, {
					"aria-hidden": true,
					className: cn("animate-spin absolute inset-0 m-auto size-3", iconCrossfadeTransition, isSuccess ? iconCrossfadeHidden : iconCrossfadeShown)
				}), /* @__PURE__ */ jsx(Check, {
					"aria-hidden": true,
					className: cn("absolute inset-0 m-auto size-3.5", iconCrossfadeTransition, isSuccess ? iconCrossfadeShown : iconCrossfadeHidden)
				})]
			}) : null
		]
	}) : null;
	const framed = /* @__PURE__ */ jsxs(Fragment, { children: [
		headingRow,
		content,
		isDescriptionBeside ? errorNode : null
	] });
	return /* @__PURE__ */ jsx(FieldRoot, {
		...definedProps({
			"data-variant": variant,
			"data-empty": isEmpty ? "" : void 0,
			name,
			invalid,
			disabled
		}),
		className: cn(heading === "label" ? fieldFrameRootClass : null, className),
		children: heading === "legend" ? /* @__PURE__ */ jsx(FieldSet, { children: framed }) : framed
	});
}
FieldFrame.displayName = "FieldFrame";
export { FieldFrame };

//# sourceMappingURL=field-frame.js.map