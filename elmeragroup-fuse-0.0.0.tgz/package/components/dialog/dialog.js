"use client";
import { cn } from "../../styles/cn.js";
import { selfFocusRingClass } from "../../styles/utils.js";
import { useLocalizedStrings } from "../../hooks/use-localized-strings.js";
import { mergeClassName } from "../../styles/merge-class-name.js";
import { definedProps } from "../../internal/defined-props.js";
import { useOverlayRootOverride } from "../../internal/overlay-exclusion.js";
import { overlayCloseStrings } from "../overlay/intl/index.js";
import { OverlayCloseButton, OverlayFooterCloseButton } from "../overlay/overlay-close-button.js";
import { overlayCornerCloseClass } from "../overlay/overlay-corner-close-class.js";
import { OverlayPortal } from "../overlay/overlay-portal.js";
import { dialogContentVariants, dialogVariants } from "./dialog-variants.js";
import { jsx, jsxs } from "react/jsx-runtime";
import { Dialog } from "@base-ui/react/dialog";
// src/components/dialog/dialog.tsx
const slots = dialogVariants();
function DialogRoot(props) {
	const override = useOverlayRootOverride();
	return /* @__PURE__ */ jsx(Dialog.Root, {
		...props,
		...override
	});
}
function DialogTrigger({ className, ...props }) {
	return /* @__PURE__ */ jsx(Dialog.Trigger, {
		"data-slot": "dialog-trigger",
		className: mergeClassName(className, selfFocusRingClass),
		...props
	});
}
function DialogPortal(props) {
	return /* @__PURE__ */ jsx(Dialog.Portal, {
		"data-slot": "dialog-portal",
		...props
	});
}
function DialogClose({ className, ...props }) {
	return /* @__PURE__ */ jsx(Dialog.Close, {
		"data-slot": "dialog-close",
		className: mergeClassName(className, selfFocusRingClass),
		...props
	});
}
function DialogOverlay({ className, ...props }) {
	return /* @__PURE__ */ jsx(Dialog.Backdrop, {
		"data-slot": "dialog-overlay",
		className: mergeClassName(className, slots.overlay()),
		...props
	});
}
/**
* The Dialog popup. It publishes `--inner-corner`, its corner less its padding, for parts that
* round with `rounded-inner`.
*/
function DialogContent({ className, children, showCloseButton = true, size, container, closeLabel, ...props }) {
	return /* @__PURE__ */ jsxs(OverlayPortal, {
		portal: DialogPortal,
		container,
		children: [/* @__PURE__ */ jsx(DialogOverlay, {}), /* @__PURE__ */ jsxs(Dialog.Popup, {
			"data-slot": "dialog-content",
			className: mergeClassName(className, dialogContentVariants({ size })),
			...definedProps(props),
			children: [children, showCloseButton ? /* @__PURE__ */ jsx(Dialog.Close, {
				"data-slot": "dialog-close",
				render: /* @__PURE__ */ jsx(OverlayCloseButton, {
					label: closeLabel,
					className: overlayCornerCloseClass
				})
			}) : null]
		})]
	});
}
function DialogHeader({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "dialog-header",
		className: cn(slots.header(), className),
		...props
	});
}
function DialogFooter({ className, showCloseButton = false, closeLabel, children, ...props }) {
	const strings = useLocalizedStrings(overlayCloseStrings);
	const label = closeLabel ?? strings.format("close");
	return /* @__PURE__ */ jsxs("div", {
		"data-slot": "dialog-footer",
		className: cn(slots.footer(), className),
		...props,
		children: [children, showCloseButton ? /* @__PURE__ */ jsx(Dialog.Close, { render: /* @__PURE__ */ jsx(OverlayFooterCloseButton, { label }) }) : null]
	});
}
function DialogTitle({ className, isFocusable = false, tabIndex, ...props }) {
	return /* @__PURE__ */ jsx(Dialog.Title, {
		"data-slot": "dialog-title",
		className: mergeClassName(className, dialogVariants({ isFocusable }).title()),
		...props,
		tabIndex: isFocusable ? -1 : tabIndex
	});
}
function DialogDescription({ className, ...props }) {
	return /* @__PURE__ */ jsx(Dialog.Description, {
		"data-slot": "dialog-description",
		className: mergeClassName(className, slots.description()),
		...props
	});
}
DialogRoot.displayName = "Dialog.Root";
DialogTrigger.displayName = "Dialog.Trigger";
DialogPortal.displayName = "Dialog.Portal";
DialogClose.displayName = "Dialog.Close";
DialogOverlay.displayName = "Dialog.Overlay";
DialogContent.displayName = "Dialog.Content";
DialogHeader.displayName = "Dialog.Header";
DialogFooter.displayName = "Dialog.Footer";
DialogTitle.displayName = "Dialog.Title";
DialogDescription.displayName = "Dialog.Description";
export { DialogClose, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogOverlay, DialogPortal, DialogRoot, DialogTitle, DialogTrigger };

//# sourceMappingURL=dialog.js.map