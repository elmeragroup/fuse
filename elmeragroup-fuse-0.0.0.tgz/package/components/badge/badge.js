import { cn } from "../../styles/cn.js";
import { badgeVariants } from "./badge-variants.js";
import { jsx } from "react/jsx-runtime";
// src/components/badge/badge.tsx
/**
* Non-interactive status pill. Renders an inline-flex `<span>`, so it is phrasing content and
* sits inside a sentence's `<p>`, such as `Item.Description`. Server component — it owns no
* state, no handlers, and no browser APIs.
*/
function Badge({ className, variant, size, ...props }) {
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "badge",
		className: cn(badgeVariants({
			variant,
			size
		}), className),
		...props
	});
}
Badge.displayName = "Badge";
export { Badge };

//# sourceMappingURL=badge.js.map