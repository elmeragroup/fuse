import { definedProps } from "../../internal/defined-props.js";
import { FieldFrame } from "../field/field-frame.js";
import { ComboboxContent, ComboboxInput, ComboboxRoot } from "../combobox/combobox.js";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/combobox-field/combobox-field.tsx
/**
* Labeled combobox composite over Field and the `Combobox` parts: the label, the input with its
* options, then the error and the description, laid out like `TextField`, with the label 4px from
* the input. The input fills the field's width, and the selected option is the value. The props
* the field does not name itself go to `Combobox.Root`, including `id`, which the label points
* at; a `ref` goes to the input. Single selection; use the `Combobox` namespace for multiple
* selection, chips or a custom layout, such as a label row with an info button or a horizontal
* field.
*
* Server-renderable: it owns no state, and its parts are client modules.
*
* @template Items - The `items` array, flat or of groups.
* @template Filtered - The `filteredItems` array, flat or of groups.
* @template Value - One item of `items`, which is the selected value and what
* `itemToStringValue` receives. `items` decides it; without `items`, `filteredItems` does; when
* neither is given, `value`, `defaultValue` or an annotated callback sets it.
*/
function ComboboxField({ label, description, errorMessage, isInvalid = false, isRequired = false, isDisabled = false, name, placeholder, showTrigger = true, showClear = false, className, inputClassName, ref, children, ...props }) {
	return /* @__PURE__ */ jsx(FieldFrame, {
		className,
		name,
		invalid: isInvalid,
		disabled: isDisabled,
		label,
		description,
		errorMessage,
		children: /* @__PURE__ */ jsxs(ComboboxRoot, {
			...definedProps(props),
			required: isRequired,
			disabled: isDisabled,
			children: [/* @__PURE__ */ jsx(ComboboxInput, {
				ref,
				...definedProps({
					placeholder,
					className: inputClassName
				}),
				showTrigger,
				showClear
			}), /* @__PURE__ */ jsx(ComboboxContent, { children })]
		})
	});
}
ComboboxField.displayName = "ComboboxField";
export { ComboboxField };

//# sourceMappingURL=combobox-field.js.map