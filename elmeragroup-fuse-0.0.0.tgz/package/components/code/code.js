import { cn } from "../../styles/cn.js";
import { definedProps } from "../../internal/defined-props.js";
import { jsx } from "react/jsx-runtime";
import { parse, render } from "sugar-high/core";
import { tokenize } from "sugar-high/lang/javascript";
// src/components/code/code.tsx
/**
* The JavaScript/JSX highlighter, composed from sugar-high's granular entries. The
* package root would bundle every language preset; `Code` has no `lang` API, so the
* JavaScript tokenizer is the whole requirement.
*
* The preset is called without parse-level overrides: its own defaults carry JSX, regex
* and template scanning, and its packaged types do not accept `parse`'s options object.
* Mirrors apps/docs/src/components/docs-code-block.tsx — delete both copies when
* sugar-high fixes its tokenize types.
*/
function highlight(source) {
	return render(parse(source, { tokenize: (code) => tokenize(code, void 0) }));
}
/**
* Syntax-highlighted code block. Server component — it owns no
* state, no handlers, and no browser APIs.
*
* It is always a tab stop, so keyboard users can scroll a long block. Named through
* `aria-label` or `aria-labelledby`, it is also a `region` landmark; an unnamed region would
* announce nothing useful, so without a name it keeps no role.
*
* The inner `<code>` receives highlighter HTML via `dangerouslySetInnerHTML`. That
* markup is `sugar-high` output over the caller-supplied `code` string;
* the highlighter escapes token text. Do not pass pre-built HTML.
*/
function Code({ className, code, ...props }) {
	return /* @__PURE__ */ jsx("pre", {
		"data-slot": "code",
		tabIndex: 0,
		...definedProps({ role: props["aria-label"] !== void 0 || props["aria-labelledby"] !== void 0 ? "region" : void 0 }),
		className: cn("text-xs leading-relaxed max-h-160 overflow-auto font-mono", className),
		...props,
		children: /* @__PURE__ */ jsx("code", { dangerouslySetInnerHTML: { __html: highlight(code) } })
	});
}
Code.displayName = "Code";
export { Code };

//# sourceMappingURL=code.js.map