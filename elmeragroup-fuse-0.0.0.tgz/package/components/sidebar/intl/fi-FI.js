// src/components/sidebar/intl/fi-FI.ts
/** Default localized copy for the `sidebar.*` rows. */
const fiFI = {
	toggle: "Näytä tai piilota sivupalkki",
	title: "Sivupalkki",
	description: "Näyttää sivupalkin."
};
export { fiFI };

//# sourceMappingURL=fi-FI.js.map