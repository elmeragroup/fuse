// src/components/sidebar/intl/en-US.ts
/** Default localized copy for the `sidebar.*` rows. */
const enUS = {
	toggle: "Toggle sidebar",
	title: "Sidebar",
	description: "Displays the sidebar."
};
export { enUS };

//# sourceMappingURL=en-US.js.map