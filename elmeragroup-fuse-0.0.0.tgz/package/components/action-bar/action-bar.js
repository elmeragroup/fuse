"use client";
import { cn } from "../../styles/cn.js";
import { useLocalizedStrings } from "../../hooks/use-localized-strings.js";
import { useMergedRefs } from "../../hooks/use-merged-refs.js";
import { X } from "../../icons/generated/x.js";
import { containsAcrossShadowRoots, isFocusRoot, isHTMLElement, isNode } from "../../internal/dom-node.js";
import { deepActiveElement } from "../../internal/active-element.js";
import { mergeClassName } from "../../styles/merge-class-name.js";
import { Button } from "../button/button.js";
import { actionBarVariants } from "./action-bar-variants.js";
import { actionBarStrings } from "./intl/index.js";
import { createContext, useContext, useLayoutEffect, useRef, useState } from "react";
import { Fragment as Fragment$1, jsx, jsxs } from "react/jsx-runtime";
import { useOpenChangeComplete } from "@base-ui/react/internals/useOpenChangeComplete";
import { useTransitionStatus } from "@base-ui/react/internals/useTransitionStatus";
import { Toolbar } from "@base-ui/react/toolbar";
// src/components/action-bar/action-bar.tsx
const slots = actionBarVariants();
/** The count the parts inside the bar read. While the bar leaves, it keeps the last count above zero. */
const ActionBarCountContext = createContext(0);
function isInside(container, node) {
	return container !== null && isNode(node) && containsAcrossShadowRoots(container, node);
}
/**
* A toolbar of actions on a selection, such as the checked rows of a `DataTable`, that floats at
* the bottom of its nearest positioned ancestor while `count` is above zero. Give that ancestor
* `position: relative`, or another position, and keep the bar its last child so it paints over
* the rows.
*
* The bar is one Tab stop whose items the arrow keys move between, as in `Toolbar`. It is named
* "Bulk actions" from the locale dictionary unless it gets an `aria-label` or `aria-labelledby`.
* A visually hidden live region beside it announces the count politely each time it changes,
* including the first selection, and stays empty while nothing is selected.
*
* When `count` returns to zero while focus is inside the bar, as after Clear, focus returns to the
* element it came from, such as the row checkbox, when that element is still in the document;
* otherwise it falls to the document body. The leaving bar is `inert` until it unmounts.
*/
function ActionBarRoot({ count, offset = 16, className, ref, onFocus, "aria-label": ariaLabel, ...props }) {
	const strings = useLocalizedStrings(actionBarStrings);
	const open = count > 0;
	const toolbarRef = useRef(null);
	const mergedRef = useMergedRefs(toolbarRef, ref);
	const returnFocusRef = useRef(null);
	const [shownCount, setShownCount] = useState(count);
	if (open && count !== shownCount) setShownCount(count);
	const { mounted, setMounted, transitionStatus } = useTransitionStatus(open);
	useOpenChangeComplete({
		open,
		ref: toolbarRef,
		onComplete() {
			if (!open) setMounted(false);
		}
	});
	useLayoutEffect(() => {
		if (open) return;
		const toolbar = toolbarRef.current;
		const root = toolbar?.getRootNode();
		if (root === void 0 || !isFocusRoot(root)) return;
		const active = deepActiveElement(root);
		if (!isInside(toolbar, active)) return;
		const target = returnFocusRef.current;
		returnFocusRef.current = null;
		if (target?.isConnected === true) target.focus();
		else if (isHTMLElement(active)) active.blur();
	}, [open]);
	const handleFocus = (event) => {
		if (isHTMLElement(event.relatedTarget) && !isInside(toolbarRef.current, event.relatedTarget)) returnFocusRef.current = event.relatedTarget;
		onFocus?.(event);
	};
	const label = props["aria-labelledby"] === void 0 ? ariaLabel ?? strings.format("label") : ariaLabel;
	return /* @__PURE__ */ jsxs(Fragment$1, { children: [/* @__PURE__ */ jsx("span", {
		"data-slot": "action-bar-status",
		role: "status",
		className: "sr-only",
		children: open ? strings.format("selected", { count }) : ""
	}), mounted ? /* @__PURE__ */ jsx("div", {
		"data-slot": "action-bar-positioner",
		className: slots.positioner(),
		style: { "--action-bar-offset": `${String(offset)}px` },
		inert: !open,
		children: /* @__PURE__ */ jsx(ActionBarCountContext.Provider, {
			value: shownCount,
			children: /* @__PURE__ */ jsx(Toolbar.Root, {
				"data-slot": "action-bar",
				"data-starting-style": transitionStatus === "starting" ? "" : void 0,
				"data-ending-style": transitionStatus === "ending" ? "" : void 0,
				"aria-label": label,
				className: mergeClassName(className, slots.root()),
				onFocus: handleFocus,
				...props,
				ref: mergedRef
			})
		})
	}) : null] });
}
/**
* The selection count, "3 selected" from the locale dictionary unless it has children. It is not
* itself a live region: `ActionBar.Root` announces the count.
*/
function ActionBarCount({ className, children, ...props }) {
	const strings = useLocalizedStrings(actionBarStrings);
	const count = useContext(ActionBarCountContext);
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "action-bar-count",
		className: cn(slots.count(), className),
		...props,
		children: children ?? strings.format("selected", { count })
	});
}
/**
* The button that clears the selection: an extra-small ghost icon button with an X, named "Clear
* selection" from the locale dictionary unless it gets an `aria-label`. It clears nothing itself;
* empty the selection in `onClick`, and the bar leaves. Children replace the icon. For a tooltip,
* pass it to `Tooltip.Trigger`'s `render`.
*/
function ActionBarClear({ "aria-label": ariaLabel, children, ...props }) {
	const strings = useLocalizedStrings(actionBarStrings);
	const label = ariaLabel ?? strings.format("clear");
	return /* @__PURE__ */ jsx(Toolbar.Button, {
		"data-slot": "action-bar-clear",
		"aria-label": label,
		render: /* @__PURE__ */ jsx(Button, {
			variant: "ghost",
			size: "icon-xs",
			"aria-label": label
		}),
		...props,
		children: children ?? /* @__PURE__ */ jsx(X, { "aria-hidden": "true" })
	});
}
/**
* An action on the selection, in the bar's arrow-key order: an extra-small ghost `Button` unless
* `render` gives another control. Lead with an icon marked `data-icon="inline-start"` and put the
* words in `ActionBar.ButtonLabel`, so a narrow bar shows the icon alone.
*/
function ActionBarButton(props) {
	return /* @__PURE__ */ jsx(Toolbar.Button, {
		"data-slot": "action-bar-button",
		render: /* @__PURE__ */ jsx(Button, {
			variant: "ghost",
			size: "xs"
		}),
		...props
	});
}
/**
* An `ActionBar.Button`'s words. They are visually hidden while the bar's positioner is narrower
* than 28rem, so the button shows its icon alone and keeps the words as its accessible name.
*/
function ActionBarButtonLabel({ className, ...props }) {
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "action-bar-button-label",
		className: cn(slots.buttonLabel(), className),
		...props
	});
}
/** Toolbar's hairline between the bar's items, such as between the count and the actions. */
function ActionBarSeparator({ className, ...props }) {
	return /* @__PURE__ */ jsx(Toolbar.Separator, {
		"data-slot": "action-bar-separator",
		className: mergeClassName(className, slots.separator()),
		...props
	});
}
ActionBarRoot.displayName = "ActionBar.Root";
ActionBarCount.displayName = "ActionBar.Count";
ActionBarClear.displayName = "ActionBar.Clear";
ActionBarButton.displayName = "ActionBar.Button";
ActionBarButtonLabel.displayName = "ActionBar.ButtonLabel";
ActionBarSeparator.displayName = "ActionBar.Separator";
export { ActionBarButton, ActionBarButtonLabel, ActionBarClear, ActionBarCount, ActionBarRoot, ActionBarSeparator };

//# sourceMappingURL=action-bar.js.map