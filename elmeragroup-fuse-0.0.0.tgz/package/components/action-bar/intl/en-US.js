import { countOf } from "../../../intl/count-of.js";
// src/components/action-bar/intl/en-US.ts
/** Default localized copy for the `actionBar.*` rows: the bar's name, the count and Clear's name. */
const enUS = {
	label: "Bulk actions",
	selected: (vars) => countOf("en-US", Number(vars?.count), {
		one: "selected",
		other: "selected"
	}),
	clear: "Clear selection"
};
export { enUS };

//# sourceMappingURL=en-US.js.map