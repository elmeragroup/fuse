import { countOf } from "../../../intl/count-of.js";
// src/components/action-bar/intl/fi-FI.ts
/** Default localized copy for the `actionBar.*` rows: the bar's name, the count and Clear's name. */
const fiFI = {
	label: "Joukkotoiminnot",
	selected: (vars) => countOf("fi-FI", Number(vars?.count), {
		one: "valittu",
		other: "valittua"
	}),
	clear: "Tyhjennä valinta"
};
export { fiFI };

//# sourceMappingURL=fi-FI.js.map