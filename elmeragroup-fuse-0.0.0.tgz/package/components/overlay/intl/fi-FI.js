// src/components/overlay/intl/fi-FI.ts
/** Default localized copy for the family-owned `overlay.close` row. */
const fiFI = { close: "Sulje" };
export { fiFI };

//# sourceMappingURL=fi-FI.js.map