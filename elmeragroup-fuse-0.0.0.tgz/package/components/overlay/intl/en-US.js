// src/components/overlay/intl/en-US.ts
/** Default localized copy for the family-owned `overlay.close` row. */
const enUS = { close: "Close" };
export { enUS };

//# sourceMappingURL=en-US.js.map