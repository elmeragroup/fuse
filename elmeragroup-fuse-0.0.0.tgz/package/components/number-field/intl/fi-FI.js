// src/components/number-field/intl/fi-FI.ts
/** Default localized copy for the `numberField.*` rows. */
const fiFI = {
	increase: "Lisää",
	decrease: "Vähennä",
	roleDescription: "Numerokenttä"
};
export { fiFI };

//# sourceMappingURL=fi-FI.js.map