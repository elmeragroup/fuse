// src/components/number-field/intl/en-US.ts
/** Default localized copy for the `numberField.*` rows. */
const enUS = {
	increase: "Increase",
	decrease: "Decrease",
	roleDescription: "Number field"
};
export { enUS };

//# sourceMappingURL=en-US.js.map