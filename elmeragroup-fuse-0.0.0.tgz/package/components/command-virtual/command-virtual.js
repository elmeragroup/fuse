"use client";
import { cn } from "../../styles/cn.js";
import { useMergedRefs } from "../../hooks/use-merged-refs.js";
import { cssLengthToPx } from "../../theme/css-values.js";
import { CommandCompositionError } from "../command/command-error.js";
import { CommandListTargetContext, CommandRowContext, CommandSearchContext } from "../command/command-list-context.js";
import { DENSE_ROW_METRICS } from "./row-metrics.js";
import { withHighlightedRow } from "./virtual-highlight.js";
import { memo, use, useImperativeHandle, useLayoutEffect, useMemo, useState } from "react";
import { jsx } from "react/jsx-runtime";
import { Autocomplete } from "@base-ui/react";
import { defaultRangeExtractor, useVirtualizer } from "@tanstack/react-virtual";
// src/components/command-virtual/command-virtual.tsx
/**
* `fuse.css` declares the metrics as unregistered custom properties, so the browser reports each
* one as written, as a `rem` length such as ` 2rem`. The virtualizer needs pixels.
*/
function readRowMetrics(element) {
	const style = getComputedStyle(element);
	const rootFontSize = Number.parseFloat(getComputedStyle(document.documentElement).fontSize);
	const metric = (name) => cssLengthToPx(style.getPropertyValue(name).trim(), rootFontSize);
	return {
		row: metric("--row-h") ?? DENSE_ROW_METRICS.row,
		pad: metric("--surface-gap-sm") ?? DENSE_ROW_METRICS.pad
	};
}
/**
* One window row. The virtualizer re-renders the list on every scroll event, so a row renders
* again only when its own inputs change: a row that stays in the window keeps its element, its
* context value and its `style`, and Base UI's memoized item skips it too.
*/
const VirtualRow = memo(function VirtualRow({ rows, item, index, start, setSize, measureElement }) {
	const row = useMemo(() => ({
		index,
		ref: measureElement,
		style: {
			position: "absolute",
			top: 0,
			left: 0,
			width: "100%",
			transform: `translateY(${String(start)}px)`
		},
		setSize
	}), [
		index,
		measureElement,
		start,
		setSize
	]);
	return /* @__PURE__ */ jsx(CommandRowContext.Provider, {
		value: row,
		children: rows(item, index)
	});
});
/**
* The render element of a virtualized search's `Command.List`, as in
* `<Command.List render={<CommandVirtual.List />}>`. It renders only the rows in view plus the
* highlighted one, through the row function that `Command.List` passes as `children`. It
* registers its virtualizer with the search, which scrolls it when the highlight jumps out of
* view. It keys each row by its position, so the row function's element sets no `key`. It is its
* own scroll element, so keep it out of a `ScrollArea`. It measures each row, so rows of any
* height stack without gaps. It pads the rows with the density's small surface gap, and pads and
* estimates them again when a `data-density` attribute on the document root or an ancestor
* changes. It throws outside `Command.List`'s `render`, and in a search without
* `virtualized`.
*/
function CommandVirtualList({ className, children: rows, estimateSize, overscan = 8, ref, ...props }) {
	if (!use(CommandListTargetContext) || rows === void 0) throw new CommandCompositionError("CommandVirtual.List", "virtual-list-outside-list");
	const search = use(CommandSearchContext);
	if (search === null || !search.virtualized) throw new CommandCompositionError("CommandVirtual.List", "virtual-list-without-virtualized");
	const items = Autocomplete.useFilteredItems();
	const [scrollElement, setScrollElement] = useState(null);
	const mergedRef = useMergedRefs(ref, setScrollElement);
	const [metrics, setMetrics] = useState(DENSE_ROW_METRICS);
	useLayoutEffect(() => {
		if (scrollElement === null) return;
		const update = () => {
			const next = readRowMetrics(scrollElement);
			setMetrics((current) => current.row === next.row && current.pad === next.pad ? current : next);
		};
		update();
		const observer = new MutationObserver(update);
		observer.observe(document.documentElement, {
			attributes: true,
			attributeFilter: ["data-density"],
			subtree: true
		});
		return () => {
			observer.disconnect();
		};
	}, [scrollElement]);
	const { highlightedIndex } = search;
	const virtualizer = useVirtualizer({
		count: items.length,
		getScrollElement: () => scrollElement,
		estimateSize: estimateSize ?? (() => metrics.row),
		overscan,
		paddingStart: metrics.pad,
		paddingEnd: metrics.pad,
		scrollPaddingStart: metrics.pad,
		scrollPaddingEnd: metrics.pad,
		rangeExtractor: (range) => withHighlightedRow(defaultRangeExtractor(range), highlightedIndex, range.count)
	});
	useImperativeHandle(search.scroller, () => virtualizer, [virtualizer]);
	return /* @__PURE__ */ jsx("div", {
		ref: mergedRef,
		className: cn(className, "py-0"),
		...props,
		children: items.length === 0 ? null : /* @__PURE__ */ jsx("div", {
			role: "presentation",
			className: "relative h-(--command-virtual-height) w-full",
			style: { "--command-virtual-height": `${String(virtualizer.getTotalSize())}px` },
			children: /* @__PURE__ */ jsx(CommandListTargetContext.Provider, {
				value: false,
				children: virtualizer.getVirtualItems().map((virtualItem) => {
					const item = items[virtualItem.index];
					if (item === void 0) return null;
					return /* @__PURE__ */ jsx(VirtualRow, {
						rows,
						item,
						index: virtualItem.index,
						start: virtualItem.start,
						setSize: items.length,
						measureElement: virtualizer.measureElement
					}, virtualItem.key);
				})
			})
		})
	});
}
CommandVirtualList.displayName = "CommandVirtual.List";
export { CommandVirtualList };

//# sourceMappingURL=command-virtual.js.map