"use client";
import { createContext } from "react";
// src/components/command/command-list-context.ts
/** The row a virtual list is rendering, or `null` in an ordinary list. */
const CommandRowContext = createContext(null);
/**
* `true` inside the element `Command.List` renders from its `render` value, which receives the
* row function as `children`. `CommandVirtual.List` checks it to throw a named error anywhere else.
*/
const CommandListTargetContext = createContext(false);
/** The enclosing search's state, or `null` outside a search. */
const CommandSearchContext = createContext(null);
export { CommandListTargetContext, CommandRowContext, CommandSearchContext };

//# sourceMappingURL=command-list-context.js.map