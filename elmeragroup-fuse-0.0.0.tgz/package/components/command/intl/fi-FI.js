// src/components/command/intl/fi-FI.ts
/** Default localized copy for the command palette's names, placeholder, empty state and key hints. */
const fiFI = {
	dialogLabel: "Komentopaletti",
	inputLabel: "Hae komentoja",
	placeholder: "Kirjoita komento tai hae…",
	empty: "Ei tuloksia.",
	back: "Takaisin",
	navigate: "Siirry",
	select: "Valitse"
};
export { fiFI };

//# sourceMappingURL=fi-FI.js.map