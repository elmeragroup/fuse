// src/components/command/intl/en-US.ts
/** Default localized copy for the command palette's names, placeholder, empty state and key hints. */
const enUS = {
	dialogLabel: "Command palette",
	inputLabel: "Search commands",
	placeholder: "Type a command or search…",
	empty: "No results.",
	back: "Back",
	navigate: "Navigate",
	select: "Select"
};
export { enUS };

//# sourceMappingURL=en-US.js.map