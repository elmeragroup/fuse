"use client";
import { useLocale } from "../../intl/locale-context.js";
import { CommandCompositionError } from "./command-error.js";
import { CommandSearchContext } from "./command-list-context.js";
import { highlightScrollAlign } from "./highlight-scroll.js";
import { useLayoutEffect, useMemo, useRef, useState } from "react";
import { jsx } from "react/jsx-runtime";
import { Autocomplete } from "@base-ui/react";
// src/components/command/command-search.tsx
/**
* Whether an entry is a group, by the predicate Base UI uses, `isGroup` in its
* `internals/resolveValueLabel`. A group is a non-null object whose `items` is an array. An object
* with a null prototype counts too, as it does for Base UI.
*/
function isItemGroup(entry) {
	return typeof entry === "object" && entry !== null && "items" in entry && Array.isArray(entry.items);
}
/**
* Throws the named error for an `items` list that disagrees with `grouped`, or for `virtualized`
* beside `grouped`. It reads the first entry, as Base UI does.
*/
function assertGrouping(part, grouped, virtualized, entries) {
	if (grouped && virtualized) throw new CommandCompositionError(part, "virtualized-grouped");
	if (entries === void 0 || entries.length === 0) return;
	const isGroup = isItemGroup(entries[0]);
	if (isGroup && !grouped) throw new CommandCompositionError(part, "groups-without-grouped");
	if (!isGroup && grouped) throw new CommandCompositionError(part, "grouped-without-groups");
}
/**
* One search, which is Base UI's Autocomplete, always open, with its list inline and the first
* match always highlighted. Each new session of the palette sends an uncontrolled query back to
* `defaultValue` and the highlight back to the first match. A virtualized search tracks the
* highlighted row and scrolls its virtual list when the highlight jumps out of view.
*/
function CommandSearch({ part, session, grouped = false, virtualized = false, value, defaultValue, onValueChange, onItemHighlighted, autoHighlight, keepHighlight, children, ...props }) {
	assertGrouping(part, grouped, virtualized, props.items ?? props.filteredItems);
	const { locale } = useLocale();
	const [ownQuery, setOwnQuery] = useState(defaultValue ?? "");
	const [resetting, setResetting] = useState(false);
	const [seenSession, setSeenSession] = useState(session);
	if (seenSession !== session) {
		setSeenSession(session);
		setOwnQuery(defaultValue ?? "");
		setResetting(true);
	}
	const actionsRef = useRef(null);
	useLayoutEffect(() => {
		if (resetting) actionsRef.current?.unmount();
	}, [resetting]);
	const scroller = useRef(null);
	const [highlightedIndex, setHighlightedIndex] = useState(void 0);
	const state = useMemo(() => ({
		virtualized,
		highlightedIndex,
		scroller
	}), [virtualized, highlightedIndex]);
	return /* @__PURE__ */ jsx(CommandSearchContext.Provider, {
		value: state,
		children: /* @__PURE__ */ jsx(Autocomplete.Root, {
			inline: true,
			open: !resetting,
			onOpenChangeComplete: (isOpen) => {
				if (!isOpen) setResetting(false);
			},
			actionsRef,
			autoHighlight,
			keepHighlight,
			virtualized,
			value: value ?? ownQuery,
			onValueChange: (next, details) => {
				setOwnQuery(next);
				onValueChange?.(next, details);
			},
			onItemHighlighted: (item, details) => {
				onItemHighlighted?.(item, details);
				if (!virtualized) return;
				setHighlightedIndex(item === void 0 ? void 0 : details.index);
				const list = scroller.current;
				if (item === void 0 || list === null) return;
				const align = highlightScrollAlign(details.reason, details.index, list.options.count);
				if (align !== void 0) queueMicrotask(() => {
					list.scrollToIndex(details.index, { align });
				});
			},
			...props,
			locale,
			children
		})
	});
}
export { CommandSearch };

//# sourceMappingURL=command-search.js.map