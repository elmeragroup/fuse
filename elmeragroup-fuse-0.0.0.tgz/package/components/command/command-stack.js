"use client";
import { createContext, useCallback, useMemo, useState } from "react";
// src/components/command/command-stack.ts
const CommandStackContext = createContext(null);
const CommandPageContext = createContext(null);
const CommandFocusRequestContext = createContext(null);
/** Whether a stack holds a page below the one on top. */
function canGoBack(stack) {
	return stack !== null && stack.stack.length > 1;
}
/**
* The stack's state. `pages` controls it, or else it keeps its own, starting from `defaultPages`.
* When a different page comes on top while the palette stays showing, the stack requests focus
* for that page's input, which takes focus once it mounts, even after Suspense. A top that
* changes as the dialog opens or closes requests nothing, so the dialog's `initialFocus` decides.
* That holds when the opening also mounts `Command.Content`, which registers only after the
* render that mounts it, so `showing` alone cannot tell that render from an inline palette's.
* Closing the palette drops the request, so a stack reset while the palette is closed requests
* nothing.
*/
function useStack(pages, defaultPages, onPagesChange, showing, open) {
	const [ownStack, setOwnStack] = useState(defaultPages ?? []);
	const stack = pages ?? ownStack;
	const top = stack.at(-1);
	const [seenTop, setSeenTop] = useState(top);
	const [seenShowing, setSeenShowing] = useState(showing);
	const [seenOpen, setSeenOpen] = useState(open);
	const [focusPage, setFocusPage] = useState(void 0);
	if (seenTop !== top || seenShowing !== showing || seenOpen !== open) {
		setSeenTop(top);
		setSeenShowing(showing);
		setSeenOpen(open);
		setFocusPage(seenTop !== top && seenShowing && showing && seenOpen === open ? top : void 0);
	}
	const clearFocusPage = useCallback((page) => {
		setFocusPage((current) => current === page ? void 0 : current);
	}, []);
	return {
		context: useMemo(() => {
			const change = (next) => {
				if (pages === void 0) setOwnStack(next);
				onPagesChange?.(next);
			};
			return {
				stack,
				push: (page) => {
					change([...stack, page]);
				},
				pop: () => {
					if (stack.length > 1) change(stack.slice(0, -1));
				}
			};
		}, [
			stack,
			pages,
			onPagesChange
		]),
		focusRequest: useMemo(() => ({
			page: focusPage,
			clear: clearFocusPage
		}), [focusPage, clearFocusPage]),
		reset: () => {
			if (pages === void 0) {
				const first = defaultPages ?? [];
				setOwnStack(first);
				setSeenTop(first.at(-1));
			}
		}
	};
}
export { CommandFocusRequestContext, CommandPageContext, CommandStackContext, canGoBack, useStack };

//# sourceMappingURL=command-stack.js.map