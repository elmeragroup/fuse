"use client";
import { cn } from "../../styles/cn.js";
import { useLocalizedStrings } from "../../hooks/use-localized-strings.js";
import { useMergedRefs } from "../../hooks/use-merged-refs.js";
import { mergeClassName } from "../../styles/merge-class-name.js";
import { definedProps } from "../../internal/defined-props.js";
import { overlayModalPopupClass } from "../overlay/overlay-classes.js";
import { useOverlayRootOverride } from "../../internal/overlay-exclusion.js";
import { overlayCloseStrings } from "../overlay/intl/index.js";
import { OverlayPortal } from "../overlay/overlay-portal.js";
import { DialogOverlay, DialogPortal, DialogTrigger } from "../dialog/dialog.js";
import { InputGroupAddon, InputGroupButton, InputGroupPlainInput, InputGroupRoot } from "../input-group/input-group.js";
import { menuGroupLabelClass } from "../overlay/menu-row-classes.js";
import { CaretRight } from "../../icons/generated/caret-right.js";
import { CommandCompositionError } from "./command-error.js";
import { CommandListTargetContext, CommandRowContext, CommandSearchContext } from "./command-list-context.js";
import { ArrowLeft } from "../../icons/generated/arrow-left.js";
import { MagnifyingGlass } from "../../icons/generated/magnifying-glass.js";
import { isBackspaceOnEmpty } from "../../internal/is-backspace-on-empty.js";
import { commandContentShellClass, commandListShellClass } from "../../styles/inner-corner/command.js";
import { Kbd } from "../kbd/kbd.js";
import { commandVariants } from "./command-variants.js";
import { CommandHint } from "./command-markup.js";
import { CommandSearch } from "./command-search.js";
import { CommandFocusRequestContext, CommandPageContext, CommandStackContext, canGoBack, useStack } from "./command-stack.js";
import { commandStrings } from "./intl/index.js";
import { Fragment, createContext, use, useCallback, useLayoutEffect, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { Dialog } from "@base-ui/react/dialog";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
import { Autocomplete } from "@base-ui/react";
// src/components/command/command.tsx
const styles = commandVariants();
const CommandPaletteContext = createContext(null);
/** Returns the enclosing Root's palette state, and throws a named error outside a Root. */
function usePalette(part) {
	const palette = use(CommandPaletteContext);
	if (palette === null) throw new CommandCompositionError(part, "outside-root");
	return palette;
}
/** Returns the enclosing Root's stack, and throws a named error outside a Root with a stack. */
function useEnclosingStack(part) {
	const stack = use(CommandStackContext);
	if (stack === null) throw new CommandCompositionError(part, "outside-stack");
	return stack;
}
/**
* The palette's state. Every palette starts here, and the Root renders no element. It holds the
* dialog's open state for `Command.Trigger` and `Command.Content`, and takes Base UI Dialog Root's
* `open`, `defaultOpen`, `onOpenChange` and the rest. Without a stack, the Root is the search.
* That search is Base UI's Autocomplete, always open, with its list inline and the first match
* always highlighted. It takes every Autocomplete prop, such as `items`, `value`, `filter` and
* `virtualized`, and filters in the locale of `LocaleProvider`. With `defaultPages`, or `pages`
* and `onPagesChange`, the Root holds a stack of page ids instead, and each `Command.Page` holds
* its own search.
*
* Pass `grouped` when `items` are groups, and the callbacks receive one item of a group. Each
* opening of the dialog starts fresh, even one that interrupts the close animation. An
* uncontrolled query goes back to `defaultValue`, an uncontrolled stack goes back to
* `defaultPages`, the highlight goes back to the first match, and `Command.Content`'s children
* mount fresh. The Trigger and anything else outside `Command.Content` keep their state.
*
* @template Item - The item of a flat search.
* @template Groups - The whole `items` array of a grouped search.
* @template Grouped - Whether the search's `items` are groups.
*/
function CommandRoot({ open, defaultOpen, onOpenChange, onOpenChangeComplete, modal, disablePointerDismissal, actionsRef, pages, defaultPages, onPagesChange, grouped = false, autoHighlight = "always", keepHighlight = true, children, ...search }) {
	const [handle] = useState(() => Dialog.createHandle());
	const [session, setSession] = useState(0);
	const [hasContent, setHasContent] = useState(false);
	const registerContent = useCallback(() => {
		setHasContent(true);
		return () => {
			setHasContent(false);
		};
	}, []);
	const [ownOpen, setOwnOpen] = useState(defaultOpen ?? false);
	const isOpen = open ?? ownOpen;
	const stack = useStack(pages, defaultPages, onPagesChange, !hasContent || isOpen, isOpen);
	const startSession = () => {
		setSession((count) => count + 1);
		stack.reset();
	};
	const [phase, setPhase] = useState(isOpen ? "open" : "closed");
	if (phase === "open" !== isOpen) {
		if (isOpen && phase === "closing") startSession();
		setPhase(isOpen ? "open" : hasContent ? "closing" : "closed");
	}
	const hasStack = pages !== void 0 || defaultPages !== void 0;
	const palette = {
		handle,
		registerContent,
		session,
		dialog: {
			...definedProps({
				modal,
				disablePointerDismissal,
				actionsRef
			}),
			open: isOpen,
			onOpenChange: (next, details) => {
				onOpenChange?.(next, details);
				if (!details.isCanceled) setOwnOpen(next);
			},
			onOpenChangeComplete: (next) => {
				onOpenChangeComplete?.(next);
				if (!next) {
					setPhase((current) => current === "closing" ? "closed" : current);
					startSession();
				}
			}
		}
	};
	return /* @__PURE__ */ jsx(CommandPaletteContext.Provider, {
		value: palette,
		children: hasStack ? /* @__PURE__ */ jsx(CommandStackContext.Provider, {
			value: stack.context,
			children: /* @__PURE__ */ jsx(CommandFocusRequestContext.Provider, {
				value: stack.focusRequest,
				children
			})
		}) : /* @__PURE__ */ jsx(CommandStackContext.Provider, {
			value: null,
			children: /* @__PURE__ */ jsx(CommandPageContext.Provider, {
				value: null,
				children: /* @__PURE__ */ jsx(CommandSearch, {
					part: "Command.Root",
					session,
					grouped,
					autoHighlight,
					keepHighlight,
					...search,
					children
				})
			})
		})
	});
}
/**
* One page of a Root's stack, such as a list of customers that opens one customer's actions. It
* holds its own search, with the same props as a Root without a stack, and renders only while its
* id is on top of the stack. So going back mounts the parent fresh, with an empty query and the
* first match highlighted. To keep the parent's query, hold it above `Command.Root` and pass it to
* the page as `value` with `onValueChange`. It throws outside a Root with a stack.
*
* @template Item - The item of a flat search.
* @template Groups - The whole `items` array of a grouped search.
* @template Grouped - Whether the search's `items` are groups.
*/
function CommandPage({ id, label, grouped = false, autoHighlight = "always", keepHighlight = true, children, ...search }) {
	const stack = useEnclosingStack("Command.Page");
	const { session } = usePalette("Command.Page");
	if (stack.stack.at(-1) !== id) return null;
	return /* @__PURE__ */ jsx(CommandPageContext.Provider, {
		value: {
			id,
			label
		},
		children: /* @__PURE__ */ jsx(CommandSearch, {
			part: "Command.Page",
			session,
			grouped,
			autoHighlight,
			keepHighlight,
			...search,
			children
		})
	});
}
/**
* The button that opens `Command.Content`, as Dialog's own trigger does. Closing the palette
* returns focus to it. Place it inside `Command.Root`, anywhere outside `Command.Content`.
*/
function CommandTrigger(props) {
	const { handle } = usePalette("Command.Trigger");
	return /* @__PURE__ */ jsx(DialogTrigger, {
		"data-slot": "command-trigger",
		handle,
		...props
	});
}
/**
* The palette as a modal. It renders the Dialog's portal and overlay around a palette-wide popup
* near the top of the viewport, with no close button. Only this part renders a dialog, so a
* palette without it renders none, and a palette inline in a dialog of your own leaves that
* dialog's parts bound to that dialog. Its name defaults to the locale dictionary's, and a
* `Dialog.Title` inside it names it instead. Escape closes it from any page. An opening that
* interrupts the close animation keeps the popup and mounts its children fresh. Content that a
* `render` element or function writes itself keeps its state then, so pass the palette's parts as
* children.
* It may mount late, such as on the first opening from a code-split chunk, but keep it mounted
* while the Root lives: the end of its close animation is what resets an uncontrolled query and
* stack.
*/
function CommandContent({ className, container, "aria-label": ariaLabel, children, ...props }) {
	const strings = useLocalizedStrings(commandStrings);
	const { handle, dialog, registerContent, session } = usePalette("Command.Content");
	const override = useOverlayRootOverride();
	useLayoutEffect(registerContent, [registerContent]);
	const sessionChildren = children === void 0 ? void 0 : /* @__PURE__ */ jsx(Fragment, { children }, session);
	return /* @__PURE__ */ jsx(Dialog.Root, {
		handle,
		...dialog,
		...override,
		children: /* @__PURE__ */ jsxs(OverlayPortal, {
			portal: DialogPortal,
			container,
			children: [/* @__PURE__ */ jsx(DialogOverlay, {}), /* @__PURE__ */ jsx(Dialog.Popup, {
				"data-slot": "command-content",
				"aria-label": ariaLabel ?? strings.format("dialogLabel"),
				className: mergeClassName(className, overlayModalPopupClass, commandContentShellClass, styles.content()),
				...definedProps({
					...props,
					children: sessionChildren
				})
			})]
		})
	});
}
/**
* The palette's search field, an InputGroup around Base UI's Autocomplete input. Its name is
* `aria-label`, else the enclosing `Command.Page`'s `label`, else the locale dictionary's. Its
* placeholder defaults to the dictionary's. On a page above the first, Backspace in the empty
* input goes back a page, and does nothing while an input method is composing text. When a
* different page comes on top while the palette shows, that page's input takes focus as it
* mounts, even after Suspense. An input that mounts when the page loads or the dialog opens
* leaves focus where it is, or to the dialog's `initialFocus`. A stack change that keeps the
* input's page on top leaves focus alone.
*/
function CommandInput({ className, children, ref, onKeyDown, placeholder, "aria-label": ariaLabel, ...props }) {
	const strings = useLocalizedStrings(commandStrings);
	const stack = use(CommandStackContext);
	const page = use(CommandPageContext);
	const focusRequest = use(CommandFocusRequestContext);
	const inputRef = useRef(null);
	const mergedRef = useMergedRefs(ref, inputRef);
	const pageId = page?.id;
	const [focusOnMount] = useState(() => pageId !== void 0 && focusRequest?.page === pageId);
	const clearFocusPage = focusRequest?.clear;
	useLayoutEffect(() => {
		if (focusOnMount && pageId !== void 0) {
			inputRef.current?.focus();
			clearFocusPage?.(pageId);
		}
	}, [
		focusOnMount,
		pageId,
		clearFocusPage
	]);
	return /* @__PURE__ */ jsxs(InputGroupRoot, {
		"data-slot": "command-input",
		className: cn(styles.input(), className),
		children: [/* @__PURE__ */ jsx(Autocomplete.Input, {
			ref: mergedRef,
			"aria-label": ariaLabel ?? page?.label ?? strings.format("inputLabel"),
			placeholder: placeholder ?? strings.format("placeholder"),
			render: /* @__PURE__ */ jsx(InputGroupPlainInput, {}),
			onKeyDown: (event) => {
				onKeyDown?.(event);
				if (!event.defaultPrevented && canGoBack(stack) && isBackspaceOnEmpty(event)) {
					event.preventDefault();
					stack.pop();
				}
			},
			...definedProps(props)
		}), children ?? /* @__PURE__ */ jsx(InputGroupAddon, { children: canGoBack(stack) ? /* @__PURE__ */ jsx(CommandBack, {}) : /* @__PURE__ */ jsx(MagnifyingGlass, {}) })]
	});
}
/**
* An InputGroup button that goes back a page. It renders nothing on the first page or in a
* palette without a stack. Place it in an `InputGroup.Addon` among `Command.Input`'s children.
*/
function CommandBack({ label, "aria-label": ariaLabel, onClick, ...props }) {
	const strings = useLocalizedStrings(commandStrings);
	const stack = use(CommandStackContext);
	if (!canGoBack(stack)) return null;
	return /* @__PURE__ */ jsx(InputGroupButton, {
		"data-slot": "command-back",
		size: "icon-sm",
		variant: "ghost",
		"aria-label": ariaLabel ?? label ?? strings.format("back"),
		onClick: (event) => {
			onClick?.(event);
			if (!event.defaultPrevented) stack.pop();
		},
		...props,
		children: /* @__PURE__ */ jsx(ArrowLeft, {})
	});
}
/**
* Renders `Command.List`'s `render` value with Base UI's listbox props and the row function as
* `children`. It uses Base UI's `useRender`, which takes an element, a function, or the lazy
* element React passes when a Server Component sets the `render` prop. It marks its subtree as
* `Command.List`'s render target, which `CommandVirtual.List` checks.
*/
function CommandListRowsTarget({ render, rows, listProps, state }) {
	const renderState = { ...state };
	const element = useRender({
		render,
		state: renderState,
		props: mergeProps(listProps, { children: rows })
	});
	return /* @__PURE__ */ jsx(CommandListTargetContext.Provider, {
		value: true,
		children: element
	});
}
/**
* The scrolling list of results. It pads its rows with the small surface gap, `--surface-gap-sm`,
* and publishes the palette's `rounded-xl` less that padding as `--inner-corner`. Given a `render`
* value and a row function, it passes the row function to the rendered element as `children`,
* with Base UI's listbox props and no rendered rows. The element then decides which rows mount,
* as `CommandVirtual.List` does. Given other children, `render` keeps Base UI's meaning, with or
* without `virtualized`, so a virtualizer of your own can pass indexed `Command.Item` elements. A
* virtualized search throws on a row function without a `render` value, since the list would
* mount every row without the index that Base UI's navigation reads.
*/
function CommandList({ className, ...props }) {
	const search = use(CommandSearchContext);
	const { render, children: rows, ...listProps } = props;
	const hasRowFunction = typeof rows === "function";
	if (render !== void 0 && hasRowFunction) return /* @__PURE__ */ jsx(Autocomplete.List, {
		"data-slot": "command-list",
		className: mergeClassName(className, styles.list(), commandListShellClass),
		render: (renderProps, state) => /* @__PURE__ */ jsx(CommandListRowsTarget, {
			render,
			rows,
			listProps: renderProps,
			state
		}),
		...listProps
	});
	if (search?.virtualized === true && hasRowFunction) throw new CommandCompositionError("Command.List", "virtualized-list-without-render");
	return /* @__PURE__ */ jsx(Autocomplete.List, {
		"data-slot": "command-list",
		className: mergeClassName(className, styles.list(), commandListShellClass),
		...props
	});
}
/**
* The message shown while no item matches, the locale dictionary's by default. Base UI keeps it
* mounted as a polite live region and renders its children only while the list is empty. Place
* it beside `Command.List`, not inside it.
*/
function CommandEmpty({ className, children, ...props }) {
	const strings = useLocalizedStrings(commandStrings);
	return /* @__PURE__ */ jsx(Autocomplete.Empty, {
		"data-slot": "command-empty",
		className: mergeClassName(className, styles.empty()),
		...props,
		children: children ?? strings.format("empty")
	});
}
/**
* A polite live region for the search's state, such as "Searching…", an error or the number of
* results. Screen readers announce each change of its children. It announces only while it stays
* mounted, so render the message as its children and leave it empty when there is nothing to say.
* Place it between `Command.Input` and `Command.List`.
*/
function CommandStatus({ className, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete.Status, {
		"data-slot": "command-status",
		className: mergeClassName(className, styles.status()),
		...props
	});
}
/** A group of results. Pass the group's own `items` when the Root's items are grouped. */
function CommandGroup({ className, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete.Group, {
		"data-slot": "command-group",
		className: mergeClassName(className),
		...props
	});
}
/** A group's visible name, which also names the group for assistive technology. */
function CommandLabel({ className, ...props }) {
	return /* @__PURE__ */ jsx(Autocomplete.GroupLabel, {
		"data-slot": "command-label",
		className: mergeClassName(className, menuGroupLabelClass),
		...props
	});
}
/** Renders the filtered items of the enclosing Root, Page or Group through its child function. */
function CommandCollection(props) {
	return /* @__PURE__ */ jsx(Autocomplete.Collection, { ...props });
}
/** The row's placement under the item's own style, which wins where both set a property. */
function withRowStyle(rowStyle, style) {
	if (style === void 0) return rowStyle;
	if (typeof style === "function") return (state) => ({
		...rowStyle,
		...style(state)
	});
	return {
		...rowStyle,
		...style
	};
}
/** The props a virtual list's row adds to an item, or none in an ordinary list. */
function rowProps(row, style) {
	if (row === null) return style === void 0 ? {} : { style };
	return {
		index: row.index,
		"data-index": row.index,
		"aria-setsize": row.setSize,
		"aria-posinset": row.index + 1,
		style: withRowStyle(row.style, style)
	};
}
/**
* One result row. Its `onClick` runs on a click, and on Enter while the row is highlighted. Base
* UI's `data-highlighted` is its only highlight. Give it a `value` when the search has no `items`.
* When it shows a `Command.Shortcut`, put the same shortcut in its `aria-keyshortcuts`. In a
* virtual list it takes its index, position and measurement from the list.
*/
function CommandItem({ className, ref, style, ...props }) {
	const row = use(CommandRowContext);
	const mergedRef = useMergedRefs(ref, row?.ref);
	return /* @__PURE__ */ jsx(Autocomplete.Item, {
		"data-slot": "command-item",
		ref: mergedRef,
		...rowProps(row, style),
		className: mergeClassName(className, styles.item()),
		...props
	});
}
/**
* A row that opens a page of the Root's stack on click or Enter, with a chevron at its end. Call
* `preventDefault()` in `onClick` to keep the page closed. It throws outside a Root with a stack.
*/
function CommandPageTrigger({ page, onClick, children, ...props }) {
	const stack = useEnclosingStack("Command.PageTrigger");
	return /* @__PURE__ */ jsxs(CommandItem, {
		"data-slot": "command-page-trigger",
		onClick: (event) => {
			onClick?.(event);
			if (!event.defaultPrevented) stack.push(page);
		},
		...props,
		children: [children, /* @__PURE__ */ jsx(CaretRight, { className: styles.trailing() })]
	});
}
/** Renders a key hint preset's caps, then its label or the locale dictionary's. */
function KeyHint({ keys, defaultLabel, children, ...props }) {
	return /* @__PURE__ */ jsxs(CommandHint, {
		...props,
		children: [keys.map((key) => /* @__PURE__ */ jsx(Kbd, { children: key }, key)), /* @__PURE__ */ jsx("span", { children: children ?? defaultLabel })]
	});
}
/** The hint for the arrow keys, which move the highlight. */
function CommandNavigateHint(props) {
	const strings = useLocalizedStrings(commandStrings);
	return /* @__PURE__ */ jsx(KeyHint, {
		keys: ["↑", "↓"],
		defaultLabel: strings.format("navigate"),
		...props
	});
}
/** The hint for Enter, which runs the highlighted row. */
function CommandSelectHint(props) {
	const strings = useLocalizedStrings(commandStrings);
	return /* @__PURE__ */ jsx(KeyHint, {
		keys: ["↵"],
		defaultLabel: strings.format("select"),
		...props
	});
}
/** The hint for Escape, which closes `Command.Content`. Its label is the overlays' `close` word. */
function CommandCloseHint(props) {
	const strings = useLocalizedStrings(overlayCloseStrings);
	return /* @__PURE__ */ jsx(KeyHint, {
		keys: ["Esc"],
		defaultLabel: strings.format("close"),
		...props
	});
}
/**
* The hint for Backspace, which goes back a page from an empty input. It renders only while the
* Root's stack has a page to go back to.
*/
function CommandBackHint(props) {
	const strings = useLocalizedStrings(commandStrings);
	const stack = use(CommandStackContext);
	if (!canGoBack(stack)) return null;
	return /* @__PURE__ */ jsx(KeyHint, {
		keys: ["⌫"],
		defaultLabel: strings.format("back"),
		...props
	});
}
CommandRoot.displayName = "Command.Root";
CommandTrigger.displayName = "Command.Trigger";
CommandContent.displayName = "Command.Content";
CommandInput.displayName = "Command.Input";
CommandBack.displayName = "Command.Back";
CommandList.displayName = "Command.List";
CommandEmpty.displayName = "Command.Empty";
CommandStatus.displayName = "Command.Status";
CommandGroup.displayName = "Command.Group";
CommandLabel.displayName = "Command.Label";
CommandCollection.displayName = "Command.Collection";
CommandItem.displayName = "Command.Item";
CommandPage.displayName = "Command.Page";
CommandPageTrigger.displayName = "Command.PageTrigger";
CommandNavigateHint.displayName = "Command.NavigateHint";
CommandSelectHint.displayName = "Command.SelectHint";
CommandCloseHint.displayName = "Command.CloseHint";
CommandBackHint.displayName = "Command.BackHint";
export { CommandBack, CommandBackHint, CommandCloseHint, CommandCollection, CommandContent, CommandEmpty, CommandGroup, CommandInput, CommandItem, CommandLabel, CommandList, CommandNavigateHint, CommandPage, CommandPageTrigger, CommandRoot, CommandSelectHint, CommandStatus, CommandTrigger };

//# sourceMappingURL=command.js.map