import { cn } from "../../styles/cn.js";
import { KbdGroup } from "../kbd/kbd.js";
import { commandVariants } from "./command-variants.js";
import { jsx } from "react/jsx-runtime";
// src/components/command/command-markup.tsx
const styles = commandVariants();
/**
* The strip under the list for key hints. It pads its content so the hints' text lines up with
* the rows' text. It is a server component.
*/
function CommandFooter({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "command-footer",
		className: cn(styles.footer(), className),
		...props
	});
}
/**
* One key hint, made of its `Kbd` caps and a label, such as the cap for `↵` and "Open". A hint
* repeats what the palette's own roles already tell assistive technology, so it is `aria-hidden`.
* It is a server component.
*/
function CommandHint({ className, ...props }) {
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "command-hint",
		"aria-hidden": true,
		className: cn(styles.hint(), className),
		...props
	});
}
/**
* A row's keyboard shortcut, the caps of one combination at the row's end. It is decorative, so
* it is `aria-hidden`. Put the same shortcut on the row in `aria-keyshortcuts`, such as
* `aria-keyshortcuts="Control+N"`. It is a server component.
*/
function CommandShortcut({ className, ...props }) {
	return /* @__PURE__ */ jsx(KbdGroup, {
		"data-slot": "command-shortcut",
		"aria-hidden": true,
		className: cn(styles.trailing(), className),
		...props
	});
}
CommandFooter.displayName = "Command.Footer";
CommandHint.displayName = "Command.Hint";
CommandShortcut.displayName = "Command.Shortcut";
export { CommandFooter, CommandHint, CommandShortcut };

//# sourceMappingURL=command-markup.js.map