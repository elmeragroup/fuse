"use client";
import { cn } from "../../styles/cn.js";
import { mergeClassName } from "../../styles/merge-class-name.js";
import { definedProps } from "../../internal/defined-props.js";
import { Check } from "../../icons/generated/check.js";
import { FieldFrame } from "../field/field-frame.js";
import { useCheckedResetSync } from "../../hooks/use-checked-reset-sync.js";
import { Minus } from "../../icons/generated/minus.js";
import { isTextNode } from "../../internal/is-text-node.js";
import { selectionGroupOrientationVariants } from "../selection-item/selection-item-variants.js";
import { SelectionGroupLayout, SelectionItemGroup } from "../selection-item/selection-item.js";
import { checkboxVariants } from "./checkbox-variants.js";
import { jsx, jsxs } from "react/jsx-runtime";
import { Checkbox as Checkbox$1 } from "@base-ui/react/checkbox";
import { CheckboxGroup as CheckboxGroup$1 } from "@base-ui/react/checkbox-group";
// src/components/checkbox/checkbox.tsx
const slots = checkboxVariants();
/**
* Unlabeled 16px checkbox over the base-ui primitive. Client component, because base-ui
* Checkbox owns the checked state. The indicator is internal: Phosphor regular `Minus`
* when indeterminate, `Check` otherwise. Labeled usage composes `Field.Root` and
* `Field.Label`, or `CheckboxItem`. A disabled checkbox dims to 50% on its own, also
* outside a field. The box rounds with `rounded-md` capped at 4px in every theme. Native form
* reset, including React's reset after a form action, keeps the current state and what the form
* submits in step; an uncontrolled checkbox does not return to `defaultChecked`.
*/
function Checkbox({ className, inputRef, ...props }) {
	const syncedInputRef = useCheckedResetSync(inputRef);
	return /* @__PURE__ */ jsx(Checkbox$1.Root, {
		inputRef: syncedInputRef,
		"data-slot": "checkbox",
		className: mergeClassName(className, slots.root()),
		...definedProps(props),
		children: /* @__PURE__ */ jsx(Checkbox$1.Indicator, {
			"data-slot": "checkbox-indicator",
			className: slots.indicator(),
			render: (indicatorProps, state) => /* @__PURE__ */ jsx("span", {
				...indicatorProps,
				children: state.indeterminate ? /* @__PURE__ */ jsx(Minus, {}) : /* @__PURE__ */ jsx(Check, {})
			})
		})
	});
}
/**
* Labeled checkbox group composite over Field and base-ui CheckboxGroup. Client component,
* because it wires Field validity and the group primitive. Native form reset, including
* React's reset after a form action, keeps the selection and what the form submits in step for
* Fuse members; an uncontrolled group does not return to `defaultValue`.
*/
function CheckboxGroup({ label, isLabelHidden = false, description, errorMessage, orientation = "vertical", value, defaultValue, onChange, allValues, isDisabled, isInvalid, name, id, className, children }) {
	return /* @__PURE__ */ jsx(FieldFrame, {
		heading: "legend",
		label,
		isLabelHidden,
		description,
		errorMessage,
		name,
		invalid: isInvalid,
		disabled: isDisabled,
		children: /* @__PURE__ */ jsx(CheckboxGroup$1, {
			"data-slot": "checkbox-group",
			"data-direction": orientation,
			...definedProps({
				id,
				value,
				defaultValue,
				onValueChange: onChange,
				allValues,
				disabled: isDisabled
			}),
			className: cn(selectionGroupOrientationVariants({ orientation }).group(), className),
			children: /* @__PURE__ */ jsx(SelectionGroupLayout, {
				orientation,
				children
			})
		})
	});
}
/**
* Stacked-card group: `CheckboxGroup` wrapping children in the private
* SelectionItem list (`role="list"`). `orientation` is forwarded to the labeled
* outer group and to that list: vertical remains connected `flex-col gap-0`;
* horizontal is `flex-row flex-wrap`, gapped by `--surface-gap-lg`, with individually rounded cards.
*/
function CheckboxItemGroup({ orientation = "vertical", ...props }) {
	return /* @__PURE__ */ jsx(CheckboxGroup, {
		...props,
		orientation,
		children: /* @__PURE__ */ jsx(SelectionItemGroup, {
			orientation,
			children: props.children
		})
	});
}
/**
* Inline "checkbox + trailing note" row. The note is
* visual-only; it does not become an accessible description.
*/
function CheckboxDescription({ children, describedBy }) {
	return /* @__PURE__ */ jsxs("div", {
		className: "flex items-start gap-2",
		children: [children, isTextNode(describedBy) ? /* @__PURE__ */ jsx("small", {
			className: "text-sm text-muted-foreground",
			children: describedBy
		}) : describedBy]
	});
}
Checkbox.displayName = "Checkbox";
CheckboxGroup.displayName = "CheckboxGroup";
CheckboxItemGroup.displayName = "CheckboxItemGroup";
CheckboxDescription.displayName = "CheckboxDescription";
export { Checkbox, CheckboxDescription, CheckboxGroup, CheckboxItemGroup };

//# sourceMappingURL=checkbox.js.map