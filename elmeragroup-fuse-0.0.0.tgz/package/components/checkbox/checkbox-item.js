import { SelectionItemShell } from "../selection-item/selection-item.js";
import { Checkbox } from "./checkbox.js";
import { SelectionItem } from "../selection-item/index.js";
import { jsx } from "react/jsx-runtime";
// src/components/checkbox/checkbox-item.tsx
/**
* Labeled selection row over `SelectionItem.Shell`. Server-compatible: it renders the
* client `SelectionItem.Shell`, which wires Field.Item and the label. The namespace
* aliases `Title`, `Description`, `Content`, `Actions` and `SubSection` are the exact
* `SelectionItem.*` objects, so the shell's partition recognises either spelling.
* Other attributes, such as `id`, `data-testid` or a `data-*` hook, land on the row's
* `Field.Item` root, the element that carries the row's `data-slot`.
*/
function CheckboxItem({ value, parent, isDisabled, isReadOnly, controlPosition = "start", className, isSubSectionSelectable, children, ...props }) {
	return /* @__PURE__ */ jsx(SelectionItemShell, {
		dataSlot: "checkbox-item",
		isDisabled,
		controlPosition,
		className,
		isSubSectionSelectable,
		control: parent === true ? /* @__PURE__ */ jsx(Checkbox, {
			parent: true,
			disabled: isDisabled,
			readOnly: isReadOnly
		}) : /* @__PURE__ */ jsx(Checkbox, {
			value,
			disabled: isDisabled,
			readOnly: isReadOnly
		}),
		...props,
		children
	});
}
CheckboxItem.displayName = "CheckboxItem";
CheckboxItem.Title = SelectionItem.Title;
CheckboxItem.Description = SelectionItem.Description;
CheckboxItem.Content = SelectionItem.Content;
CheckboxItem.Actions = SelectionItem.Actions;
CheckboxItem.SubSection = SelectionItem.SubSection;
export { CheckboxItem };

//# sourceMappingURL=checkbox-item.js.map