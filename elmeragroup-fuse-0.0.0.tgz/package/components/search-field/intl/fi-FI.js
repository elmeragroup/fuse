// src/components/search-field/intl/fi-FI.ts
/** Default localized copy for the `searchField.clear` row. */
const fiFI = { clear: "Tyhjennä haku" };
export { fiFI };

//# sourceMappingURL=fi-FI.js.map