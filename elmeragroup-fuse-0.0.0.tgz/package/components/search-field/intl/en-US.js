// src/components/search-field/intl/en-US.ts
/** Default localized copy for the `searchField.clear` row. */
const enUS = { clear: "Clear search" };
export { enUS };

//# sourceMappingURL=en-US.js.map