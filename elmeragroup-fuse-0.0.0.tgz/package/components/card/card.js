import { cn } from "../../styles/cn.js";
import { cardDescriptionVariants, cardSectionVariants, cardTitleVariants, cardVariants } from "./card-variants.js";
import { CardSectionButton } from "./card-section-button.js";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/card/card.tsx
/**
* The Card surface. It publishes `--inner-corner`, its corner less its border, and its header,
* content and footer publish it less their padding too. The root and its sections write their
* `direction` as `data-direction`: a vertical card pads its sections, a horizontal one pads itself.
* The root writes its `size` as `data-size` and publishes its tier to the sections it holds.
* Its 1px edge is the theme's `--card-border`: `--border` in neutral themes and a zero-alpha
* colour in branded ones. A border colour class still wins. It casts Tailwind's `shadow-xs` in
* the theme's `--card-shadow`: 5% black in neutral themes and zero alpha in branded ones. A
* shadow size class replaces it, and a shadow colour class tints it.
*/
function CardRoot({ className, direction, size = "default", ...props }) {
	const { base } = cardVariants({
		direction,
		size
	});
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "card",
		"data-direction": direction ?? "vertical",
		"data-size": size,
		className: cn(base(), className),
		...props
	});
}
function CardHeader({ className, direction, ...props }) {
	const { cardHeader } = cardVariants({ direction });
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "card-header",
		"data-direction": direction ?? "vertical",
		className: cn(cardHeader(), className),
		...props
	});
}
function CardTag({ className, direction, ...props }) {
	const { cardTag } = cardVariants({ direction });
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "card-tag",
		className: cn(cardTag(), className),
		...props
	});
}
function CardTitle({ children, className, direction, level = 3, size = "2xl", icon, ...props }) {
	const { cardTitle } = cardVariants({ direction });
	const Heading = `h${level}`;
	return /* @__PURE__ */ jsxs(Heading, {
		"data-slot": "card-title",
		className: cn(cardTitleVariants({ size }), cardTitle({ className: icon ? "flex items-center gap-x-1.5 [&>svg]:size-5" : void 0 }), className),
		...props,
		children: [icon ?? null, children]
	});
}
function CardDescription({ className, direction, size = "sm", ...props }) {
	const { cardDescription } = cardVariants({ direction });
	return /* @__PURE__ */ jsx("p", {
		"data-slot": "card-description",
		className: cn(cardDescriptionVariants({ size }), cardDescription(), className),
		...props
	});
}
function CardAction({ className, direction, ...props }) {
	const { cardAction } = cardVariants({ direction });
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "card-action",
		className: cn(cardAction(), className),
		...props
	});
}
/**
* A card's body. Inside a `Card.Section` it is the section's content column, beside a
* `Card.SectionMedia`, and drops its own padding, since the section pads.
*/
function CardContent({ className, direction, ...props }) {
	const { cardContent } = cardVariants({ direction });
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "card-content",
		"data-direction": direction ?? "vertical",
		className: cn(cardContent(), className),
		...props
	});
}
function CardFooter({ className, direction, ...props }) {
	const { cardFooter } = cardVariants({ direction });
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "card-footer",
		"data-direction": direction ?? "vertical",
		className: cn(cardFooter(), className),
		...props
	});
}
/**
* One of a vertical card's stacked sections of equal weight. Sections form the card's body under
* one optional `Card.Header`: a `Card.Content` or `Card.Footer` beside them takes no divider, so
* put that content in a section instead. A section pads every side with the card's tier, a 1px
* `--card-section-divider` line separates it from the part above, and the first and last
* sections round with the card's corners. A `Card.SectionMedia` as its first child makes it a
* two-column grid with the media centred beside a `Card.Content`, the unpadded content column.
* A horizontal card pads itself, so sections take no `direction` and belong in a vertical card.
* A whole section that acts is a `Card.SectionButton`.
*/
function CardSection({ className, ...props }) {
	const { section } = cardSectionVariants();
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "card-section",
		className: cn(section(), className),
		...props
	});
}
/**
* The icon column of a `Card.Section` or `Card.SectionButton`. The section becomes a two-column
* grid, this column and the content, with the icon centred on the section's height. An `svg` is
* sized to `5`. It is a `span`, so it is phrasing content inside a section button.
*/
function CardSectionMedia({ className, ...props }) {
	const { media } = cardSectionVariants();
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "card-section-media",
		className: cn(media(), className),
		...props
	});
}
CardRoot.displayName = "Card.Root";
CardHeader.displayName = "Card.Header";
CardTag.displayName = "Card.Tag";
CardTitle.displayName = "Card.Title";
CardDescription.displayName = "Card.Description";
CardAction.displayName = "Card.Action";
CardContent.displayName = "Card.Content";
CardFooter.displayName = "Card.Footer";
CardSection.displayName = "Card.Section";
CardSectionMedia.displayName = "Card.SectionMedia";
const Card = {
	Root: CardRoot,
	Header: CardHeader,
	Tag: CardTag,
	Title: CardTitle,
	Description: CardDescription,
	Action: CardAction,
	Content: CardContent,
	Footer: CardFooter,
	Section: CardSection,
	SectionButton: CardSectionButton,
	SectionMedia: CardSectionMedia
};
export { Card };

//# sourceMappingURL=card.js.map