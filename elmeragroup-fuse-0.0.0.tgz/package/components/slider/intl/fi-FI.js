// src/components/slider/intl/fi-FI.ts
/**
* Default localized copy for the `slider.*` rows: a range thumb's name, joined to the
* slider's own name when it has one.
*/
const fiFI = {
	rangeStart: (vars) => named(vars, "Minimi", "minimi"),
	rangeEnd: (vars) => named(vars, "Maksimi", "maksimi"),
	rangeThumb: (vars) => named(vars, `Arvo ${String(vars?.position)}`, `arvo ${String(vars?.position)}`)
};
function named(vars, alone, joined) {
	const name = String(vars?.name ?? "").trim();
	return name === "" ? alone : `${name}, ${joined}`;
}
export { fiFI };

//# sourceMappingURL=fi-FI.js.map