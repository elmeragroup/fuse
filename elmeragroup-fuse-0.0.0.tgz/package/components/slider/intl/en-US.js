// src/components/slider/intl/en-US.ts
/**
* Default localized copy for the `slider.*` rows: a range thumb's name, joined to the
* slider's own name when it has one.
*/
const enUS = {
	rangeStart: (vars) => named(vars, "Minimum", "minimum"),
	rangeEnd: (vars) => named(vars, "Maximum", "maximum"),
	rangeThumb: (vars) => named(vars, `Value ${String(vars?.position)}`, `value ${String(vars?.position)}`)
};
function named(vars, alone, joined) {
	const name = String(vars?.name ?? "").trim();
	return name === "" ? alone : `${name}, ${joined}`;
}
export { enUS };

//# sourceMappingURL=en-US.js.map