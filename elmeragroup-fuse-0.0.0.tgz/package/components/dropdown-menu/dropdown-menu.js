"use client";
import { cn } from "../../styles/cn.js";
import { selfFocusRingClass } from "../../styles/utils.js";
import { mergeClassName } from "../../styles/merge-class-name.js";
import { OverlayPortal } from "../overlay/overlay-portal.js";
import { Check } from "../../icons/generated/check.js";
import { CaretRight } from "../../icons/generated/caret-right.js";
import { dropdownMenuVariants } from "./dropdown-menu-variants.js";
import { jsx, jsxs } from "react/jsx-runtime";
import { Menu } from "@base-ui/react/menu";
// src/components/dropdown-menu/dropdown-menu.tsx
const dropdownMenuSlots = dropdownMenuVariants();
/** Shared item face. Module-private — Item and LinkItem render it. */
const dropdownMenuItemClassName = dropdownMenuSlots.item();
/** CheckboxItem's and RadioItem's face: the item with room for the trailing indicator. */
const dropdownMenuCheckableItemClassName = dropdownMenuSlots.checkableItem();
const dropdownMenuItemIndicatorClassName = dropdownMenuSlots.itemIndicator();
const dropdownMenuSeparatorClassName = dropdownMenuSlots.separator();
function DropdownMenuPortal(props) {
	return /* @__PURE__ */ jsx(Menu.Portal, {
		"data-slot": "dropdown-menu-portal",
		...props
	});
}
/**
* The one menu popup. Content and SubContent are the same
* `Portal > Positioner > Popup` with different defaults, a different `data-slot`, and a
* different popup-chrome extra. SubContent calls this helper directly, keeping one popup
* and one class string. Both callers resolve their own positioner defaults.
*/
function DropdownMenuPopup({ className, popupClassName, dataSlot, align, alignOffset, side, sideOffset, container, ...props }) {
	return /* @__PURE__ */ jsx(OverlayPortal, {
		portal: DropdownMenuPortal,
		container,
		children: /* @__PURE__ */ jsx(Menu.Positioner, {
			className: dropdownMenuSlots.positioner(),
			align,
			alignOffset,
			side,
			sideOffset,
			children: /* @__PURE__ */ jsx(Menu.Popup, {
				"data-slot": dataSlot,
				className: mergeClassName(className, popupClassName),
				...props
			})
		})
	});
}
function DropdownMenuRoot(props) {
	return /* @__PURE__ */ jsx(Menu.Root, { ...props });
}
function DropdownMenuTrigger({ className, ...props }) {
	return /* @__PURE__ */ jsx(Menu.Trigger, {
		"data-slot": "dropdown-menu-trigger",
		className: mergeClassName(className, selfFocusRingClass),
		...props
	});
}
/** The root menu's popup: the shared surface and motion with this menu's chrome. */
const dropdownMenuContentClassName = dropdownMenuSlots.content();
/**
* The menu popup. It pads its items and publishes `--inner-corner`, so a custom block placed
* in it with `rounded-inner` rounds like the items.
*/
function DropdownMenuContent({ align = "start", alignOffset = 0, side = "bottom", sideOffset = 4, ...props }) {
	return /* @__PURE__ */ jsx(DropdownMenuPopup, {
		dataSlot: "dropdown-menu-content",
		popupClassName: dropdownMenuContentClassName,
		align,
		alignOffset,
		side,
		sideOffset,
		...props
	});
}
function DropdownMenuGroup(props) {
	return /* @__PURE__ */ jsx(Menu.Group, {
		"data-slot": "dropdown-menu-group",
		...props
	});
}
function DropdownMenuLabel({ className, inset, ...props }) {
	return /* @__PURE__ */ jsx(Menu.GroupLabel, {
		"data-slot": "dropdown-menu-label",
		"data-inset": inset ? true : void 0,
		className: mergeClassName(className, dropdownMenuSlots.label()),
		...props
	});
}
function DropdownMenuItem({ className, inset, variant = "default", ...props }) {
	return /* @__PURE__ */ jsx(Menu.Item, {
		"data-slot": "dropdown-menu-item",
		"data-inset": inset ? true : void 0,
		"data-variant": variant,
		className: mergeClassName(className, dropdownMenuItemClassName),
		...props
	});
}
function DropdownMenuLinkItem({ className, ...props }) {
	return /* @__PURE__ */ jsx(Menu.LinkItem, {
		"data-slot": "dropdown-menu-link-item",
		className: mergeClassName(className, dropdownMenuItemClassName),
		...props
	});
}
function DropdownMenuCheckboxItem({ className, children, checked, inset, ...props }) {
	return /* @__PURE__ */ jsxs(Menu.CheckboxItem, {
		"data-slot": "dropdown-menu-checkbox-item",
		"data-inset": inset ? true : void 0,
		className: mergeClassName(className, dropdownMenuCheckableItemClassName),
		checked,
		...props,
		children: [/* @__PURE__ */ jsx("span", {
			className: dropdownMenuItemIndicatorClassName,
			"data-slot": "dropdown-menu-checkbox-item-indicator",
			children: /* @__PURE__ */ jsx(Menu.CheckboxItemIndicator, { children: /* @__PURE__ */ jsx(Check, {}) })
		}), children]
	});
}
function DropdownMenuRadioGroup(props) {
	return /* @__PURE__ */ jsx(Menu.RadioGroup, {
		"data-slot": "dropdown-menu-radio-group",
		...props
	});
}
function DropdownMenuRadioItem({ className, children, inset, ...props }) {
	return /* @__PURE__ */ jsxs(Menu.RadioItem, {
		"data-slot": "dropdown-menu-radio-item",
		"data-inset": inset ? true : void 0,
		className: mergeClassName(className, dropdownMenuCheckableItemClassName),
		...props,
		children: [/* @__PURE__ */ jsx("span", {
			className: dropdownMenuItemIndicatorClassName,
			"data-slot": "dropdown-menu-radio-item-indicator",
			children: /* @__PURE__ */ jsx(Menu.RadioItemIndicator, { children: /* @__PURE__ */ jsx(Check, {}) })
		}), children]
	});
}
function DropdownMenuSeparator({ className, ...props }) {
	return /* @__PURE__ */ jsx(Menu.Separator, {
		"data-slot": "dropdown-menu-separator",
		className: mergeClassName(className, dropdownMenuSeparatorClassName),
		...props
	});
}
function DropdownMenuShortcut({ className, ...props }) {
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "dropdown-menu-shortcut",
		className: cn(dropdownMenuSlots.shortcut(), className),
		...props
	});
}
function DropdownMenuSub(props) {
	return /* @__PURE__ */ jsx(Menu.SubmenuRoot, {
		closeParentOnEsc: true,
		...props
	});
}
function DropdownMenuSubTrigger({ className, inset, children, ...props }) {
	return /* @__PURE__ */ jsxs(Menu.SubmenuTrigger, {
		"data-slot": "dropdown-menu-sub-trigger",
		"data-inset": inset ? true : void 0,
		className: mergeClassName(className, dropdownMenuSlots.subTrigger()),
		...props,
		children: [children, /* @__PURE__ */ jsx(CaretRight, { className: dropdownMenuSlots.subTriggerCaret() })]
	});
}
/** A submenu's popup: the shared surface and motion with the submenu's chrome. */
const dropdownMenuSubContentClassName = dropdownMenuSlots.subContent();
/**
* A submenu popup. Like `DropdownMenu.Content`, it pads its items and publishes
* `--inner-corner` for parts that round with `rounded-inner`.
*/
function DropdownMenuSubContent({ align = "start", alignOffset = -3, side = "right", sideOffset = 0, ...props }) {
	return /* @__PURE__ */ jsx(DropdownMenuPopup, {
		dataSlot: "dropdown-menu-sub-content",
		popupClassName: dropdownMenuSubContentClassName,
		align,
		alignOffset,
		side,
		sideOffset,
		...props
	});
}
DropdownMenuRoot.displayName = "DropdownMenu.Root";
DropdownMenuTrigger.displayName = "DropdownMenu.Trigger";
DropdownMenuPortal.displayName = "DropdownMenu.Portal";
DropdownMenuContent.displayName = "DropdownMenu.Content";
DropdownMenuGroup.displayName = "DropdownMenu.Group";
DropdownMenuLabel.displayName = "DropdownMenu.Label";
DropdownMenuItem.displayName = "DropdownMenu.Item";
DropdownMenuLinkItem.displayName = "DropdownMenu.LinkItem";
DropdownMenuCheckboxItem.displayName = "DropdownMenu.CheckboxItem";
DropdownMenuRadioGroup.displayName = "DropdownMenu.RadioGroup";
DropdownMenuRadioItem.displayName = "DropdownMenu.RadioItem";
DropdownMenuSeparator.displayName = "DropdownMenu.Separator";
DropdownMenuShortcut.displayName = "DropdownMenu.Shortcut";
DropdownMenuSub.displayName = "DropdownMenu.Sub";
DropdownMenuSubTrigger.displayName = "DropdownMenu.SubTrigger";
DropdownMenuSubContent.displayName = "DropdownMenu.SubContent";
export { DropdownMenuCheckboxItem, DropdownMenuContent, DropdownMenuGroup, DropdownMenuItem, DropdownMenuLabel, DropdownMenuLinkItem, DropdownMenuPortal, DropdownMenuRadioGroup, DropdownMenuRadioItem, DropdownMenuRoot, DropdownMenuSeparator, DropdownMenuShortcut, DropdownMenuSub, DropdownMenuSubContent, DropdownMenuSubTrigger, DropdownMenuTrigger };

//# sourceMappingURL=dropdown-menu.js.map