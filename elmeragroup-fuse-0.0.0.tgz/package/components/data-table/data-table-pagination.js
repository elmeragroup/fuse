"use client";
import { cn } from "../../styles/cn.js";
import { useLocalizedStrings } from "../../hooks/use-localized-strings.js";
import { definedProps } from "../../internal/defined-props.js";
import { Button } from "../button/button.js";
import { FieldLabel, FieldRoot } from "../field/field.js";
import { CaretRight } from "../../icons/generated/caret-right.js";
import { CaretLeft } from "../../icons/generated/caret-left.js";
import { CaretDoubleLeft } from "../../icons/generated/caret-double-left.js";
import { CaretDoubleRight } from "../../icons/generated/caret-double-right.js";
import { pageStatus } from "./data-table-pagination-status.js";
import { dataTableStrings } from "./intl/index.js";
import { SelectContent, SelectItem, SelectRoot, SelectTrigger, SelectValue } from "../select/select.js";
import { dataTableVariants } from "./data-table-variants.js";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/data-table/data-table-pagination.tsx
const { pagination, pageSize, pageStatus: pageStatusClass, pageControls } = dataTableVariants();
const DEFAULT_PAGE_SIZES = [
	10,
	25,
	50,
	100
];
function pageSizeChoices(pageSizes, current) {
	return [.../* @__PURE__ */ new Set([...pageSizes, current])].toSorted((left, right) => left - right);
}
/**
* Rows-per-page select, page status, and first, previous, next and last buttons for a paginated
* table. The page status is a polite `role="status"` region, so each page change is announced, and
* an unavailable move stays focusable with `aria-disabled`, so focus never drops when a press
* reaches the first or last page. Changing the page size calls `table.setPageSize` and keeps the
* page index; resetting to the first page on a size change is the state owner's job, for example
* in `onPaginationChange`.
*/
function DataTablePagination({ table, total, pageSizes = DEFAULT_PAGE_SIZES, rowsPerPageLabel, pageSizeOpen, defaultPageSizeOpen, onPageSizeOpenChange, formatStatus, firstPageLabel, previousPageLabel, nextPageLabel, lastPageLabel, className, ...props }) {
	const strings = useLocalizedStrings(dataTableStrings);
	const state = table.atoms.pagination.get();
	const status = pageStatus(state.pageIndex, total ?? {
		kind: "known",
		pageCount: table.getPageCount()
	});
	const statusText = formatStatus?.(status) ?? (status.kind === "known" ? strings.format("pageOf", {
		page: status.page,
		pageCount: status.pageCount
	}) : strings.format("page", { page: status.page }));
	const sizes = pageSizeChoices(pageSizes, state.pageSize);
	const moves = [
		{
			key: "first",
			label: firstPageLabel ?? strings.format("goToFirstPage"),
			Icon: CaretDoubleLeft,
			target: status.canPrevious ? 0 : void 0
		},
		{
			key: "previous",
			label: previousPageLabel ?? strings.format("goToPreviousPage"),
			Icon: CaretLeft,
			target: status.canPrevious ? status.page - 2 : void 0
		},
		{
			key: "next",
			label: nextPageLabel ?? strings.format("goToNextPage"),
			Icon: CaretRight,
			target: status.canNext ? status.page : void 0
		},
		{
			key: "last",
			label: lastPageLabel ?? strings.format("goToLastPage"),
			Icon: CaretDoubleRight,
			target: status.kind === "known" && status.canNext ? status.pageCount - 1 : void 0
		}
	];
	return /* @__PURE__ */ jsxs("div", {
		"data-slot": "data-table-pagination",
		className: cn(pagination(), className),
		...props,
		children: [
			/* @__PURE__ */ jsxs(FieldRoot, {
				orientation: "horizontal",
				className: pageSize(),
				children: [/* @__PURE__ */ jsx(FieldLabel, { children: rowsPerPageLabel ?? strings.format("rowsPerPage") }), /* @__PURE__ */ jsxs(SelectRoot, {
					items: sizes.map((size) => ({
						value: size,
						label: String(size)
					})),
					value: state.pageSize,
					onValueChange: (size) => {
						if (size !== null) table.setPageSize(size);
					},
					...definedProps({
						open: pageSizeOpen,
						defaultOpen: defaultPageSizeOpen,
						onOpenChange: onPageSizeOpenChange
					}),
					children: [/* @__PURE__ */ jsx(SelectTrigger, {
						size: "sm",
						children: /* @__PURE__ */ jsx(SelectValue, {})
					}), /* @__PURE__ */ jsx(SelectContent, { children: sizes.map((size) => /* @__PURE__ */ jsx(SelectItem, {
						value: size,
						children: size
					}, size)) })]
				})]
			}),
			/* @__PURE__ */ jsx("span", {
				"data-slot": "data-table-page-status",
				role: "status",
				className: pageStatusClass(),
				children: statusText
			}),
			/* @__PURE__ */ jsx("div", {
				"data-slot": "data-table-page-controls",
				className: pageControls(),
				children: moves.map(({ key, label, Icon, target }) => /* @__PURE__ */ jsx(Button, {
					variant: "outline",
					size: "icon-sm",
					"aria-label": label,
					disabled: target === void 0,
					focusableWhenDisabled: true,
					onClick: target === void 0 ? void 0 : () => {
						table.setPageIndex(target);
					},
					children: /* @__PURE__ */ jsx(Icon, {})
				}, key))
			})
		]
	});
}
DataTablePagination.displayName = "DataTable.Pagination";
export { DataTablePagination };

//# sourceMappingURL=data-table-pagination.js.map