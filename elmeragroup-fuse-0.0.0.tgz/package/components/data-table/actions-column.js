import { RowActionsCell, RowActionsHeader } from "./data-table-row-actions.js";
import { jsx } from "react/jsx-runtime";
// src/components/data-table/actions-column.tsx
/**
* Build the row-actions column: `DataTable.RowActions` in each cell, right-aligned, with a
* per-row accessible name. The header names the column "Actions" for assistive technology without
* visible text, the column shrinks to the trigger, and sorting and hiding are disabled. Clicks in
* the open menu do not press a pressable row.
*
* @template TData - The row data type, inferred from the column helper.
* @template TColumn - The column definition type the helper returns.
* @param columnHelper - A column helper for the table.
* @param options - The row's name and its menu items.
* @returns A display column with the id `"actions"`.
*/
function actionsColumn(columnHelper, { getRowName, items }) {
	return columnHelper.display({
		id: "actions",
		enableSorting: false,
		enableHiding: false,
		header: () => /* @__PURE__ */ jsx(RowActionsHeader, {}),
		cell: ({ row }) => /* @__PURE__ */ jsx(RowActionsCell, {
			name: getRowName(row.original),
			children: items(row.original)
		})
	});
}
export { actionsColumn };

//# sourceMappingURL=actions-column.js.map