"use client";
import { fuseTableContexts } from "./data-table-contexts.js";
import { ContentTable, RowCells } from "./data-table.js";
import { cellValueText } from "./data-table-format.js";
import { DataTableCurrency, DataTableDate, DataTableDateTime, DataTableNumber, DataTableText } from "./data-table-cells.js";
import { DataTableColumnToggle } from "./data-table-column-toggle.js";
import { DataTablePagination } from "./data-table-pagination.js";
import { DataTableSortButton } from "./data-table-sort-button.js";
import { jsx } from "react/jsx-runtime";
// src/components/data-table/data-table-registered.tsx
/**
* The context table with the `App*` wrappers and the current registry's `Row`. Only the parts that
* render through them read it; the rest read `fuseTableContexts.useTableContext()` uncast. Reading
* `Row` from the table in context, not from the factory that built the part, keeps a part rendered
* under another Fuse table's `AppTable` consistent with that table.
*/
function useAppContextTable() {
	return fuseTableContexts.useTableContext();
}
/**
* `table.Row`: `DataTable.Row` with every cell rendered through `table.AppCell`, so a column
* definition can use the registered cells. It renders inside `table.Content`'s row takeover, whose
* store subscription re-renders every row, so it subscribes to nothing itself.
*/
function RegisteredRow({ row, ...props }) {
	const table = useAppContextTable();
	return /* @__PURE__ */ jsx(RowCells, {
		row,
		renderCell: (cell) => /* @__PURE__ */ jsx(table.AppCell, {
			cell,
			children: (appCell) => /* @__PURE__ */ jsx(appCell.FlexRender, {})
		}),
		...props
	});
}
/**
* `table.Content`: `DataTable.Content` with every header rendered through `table.AppHeader` and
* every cell through `table.AppCell`, so a column definition can use `header.SortButton` and the
* registered cells. The row model depends on every state slice, so it subscribes to all of them
* and stays current when the app's `useFuseTable` selector narrows `table.state`.
*/
function RegisteredContent({ children, ...props }) {
	const table = useAppContextTable();
	return /* @__PURE__ */ jsx(table.Subscribe, {
		source: table.store,
		selector: (state) => state,
		children: () => /* @__PURE__ */ jsx(ContentTable, {
			table,
			renderHeader: (header) => /* @__PURE__ */ jsx(table.AppHeader, {
				header,
				children: (appHeader) => /* @__PURE__ */ jsx(appHeader.FlexRender, {})
			}),
			renderRow: children ?? ((row) => /* @__PURE__ */ jsx(table.Row, { row })),
			...props
		})
	});
}
/**
* `table.Pagination`: `DataTable.Pagination`, subscribed to the pagination state and the page
* count. Filtering changes the count without a pagination update when the page index is already 0.
*/
function RegisteredPagination(props) {
	const table = fuseTableContexts.useTableContext();
	return /* @__PURE__ */ jsx(table.Subscribe, {
		source: table.store,
		selector: (state) => ({
			pagination: state.pagination,
			pageCount: table.getPageCount()
		}),
		children: () => /* @__PURE__ */ jsx(DataTablePagination, {
			table,
			...props
		})
	});
}
/** `table.ColumnToggle`: `DataTable.ColumnToggle`, subscribed to the visibility state. */
function RegisteredColumnToggle(props) {
	const table = fuseTableContexts.useTableContext();
	return /* @__PURE__ */ jsx(table.Subscribe, {
		source: table.atoms.columnVisibility,
		children: () => /* @__PURE__ */ jsx(DataTableColumnToggle, {
			table,
			...props
		})
	});
}
/** `header.SortButton`: `DataTable.SortButton` for the header in context, subscribed to sorting. */
function RegisteredSortButton(props) {
	const table = fuseTableContexts.useTableContext();
	const header = fuseTableContexts.useHeaderContext();
	return /* @__PURE__ */ jsx(table.Subscribe, {
		source: table.atoms.sorting,
		children: () => /* @__PURE__ */ jsx(DataTableSortButton, {
			column: header.column,
			...props
		})
	});
}
/**
* Parse the cell in context. `getValue()` is TanStack's untyped boundary: a registered cell is
* typed on every column whatever its value type, so the value is only known here, at runtime.
*/
function useCellValue() {
	const value = fuseTableContexts.useCellContext().getValue();
	if (value instanceof Date) return {
		kind: "date",
		value
	};
	switch (typeof value) {
		case "number": return {
			kind: "number",
			value
		};
		case "string": return {
			kind: "text",
			value
		};
		case "boolean":
		case "bigint": return {
			kind: "text",
			value: String(value)
		};
		default: return {
			kind: "text",
			value: ""
		};
	}
}
/** A cell value of another kind than the cell formats, as its raw text. */
function RawText({ cell, className }) {
	return /* @__PURE__ */ jsx(DataTableText, {
		value: cellValueText(cell),
		className
	});
}
/** `cell.TextCell`: the cell value as text. */
function TextCell(props) {
	return /* @__PURE__ */ jsx(DataTableText, {
		value: cellValueText(useCellValue()),
		...props
	});
}
/**
* `cell.NumberCell`: `DataTable.Number` over the cell value; any other value renders as raw text.
* The registered cells are exported so an app can tweak one with a pure wrapper,
* `(props) => <NumberCell maximumFractionDigits={0} {...props} />`, and register it under the same
* key. Render them only inside `table.AppCell`, as the registry does.
*/
function NumberCell(props) {
	const cell = useCellValue();
	return cell.kind === "number" ? /* @__PURE__ */ jsx(DataTableNumber, {
		value: cell.value,
		...props
	}) : /* @__PURE__ */ jsx(RawText, {
		cell,
		className: props.className
	});
}
/** `cell.CurrencyCell`: `DataTable.Currency` over the cell value; any other value renders as raw text. */
function CurrencyCell(props) {
	const cell = useCellValue();
	return cell.kind === "number" ? /* @__PURE__ */ jsx(DataTableCurrency, {
		value: cell.value,
		...props
	}) : /* @__PURE__ */ jsx(RawText, {
		cell,
		className: props.className
	});
}
/** `cell.DateCell`: `DataTable.Date` over the cell value; any other value renders as raw text. */
function DateCell(props) {
	const cell = useCellValue();
	return cell.kind === "date" ? /* @__PURE__ */ jsx(DataTableDate, {
		value: cell.value,
		...props
	}) : /* @__PURE__ */ jsx(RawText, {
		cell,
		className: props.className
	});
}
/** `cell.DateTimeCell`: `DataTable.DateTime` over the cell value; any other value renders as raw text. */
function DateTimeCell(props) {
	const cell = useCellValue();
	return cell.kind === "date" ? /* @__PURE__ */ jsx(DataTableDateTime, {
		value: cell.value,
		...props
	}) : /* @__PURE__ */ jsx(RawText, {
		cell,
		className: props.className
	});
}
RegisteredContent.displayName = "table.Content";
RegisteredRow.displayName = "table.Row";
RegisteredPagination.displayName = "table.Pagination";
RegisteredColumnToggle.displayName = "table.ColumnToggle";
RegisteredSortButton.displayName = "header.SortButton";
TextCell.displayName = "cell.TextCell";
NumberCell.displayName = "cell.NumberCell";
CurrencyCell.displayName = "cell.CurrencyCell";
DateCell.displayName = "cell.DateCell";
DateTimeCell.displayName = "cell.DateTimeCell";
export { CurrencyCell, DateCell, DateTimeCell, NumberCell, RegisteredColumnToggle, RegisteredContent, RegisteredPagination, RegisteredRow, RegisteredSortButton, TextCell };

//# sourceMappingURL=data-table-registered.js.map