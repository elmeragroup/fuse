"use client";
import { useLocalizedStrings } from "../../hooks/use-localized-strings.js";
import { Checkbox } from "../checkbox/checkbox.js";
import { dataTableStrings } from "./intl/index.js";
import { jsx } from "react/jsx-runtime";
// src/components/data-table/data-table-selection.tsx
/**
* The header checkbox that selects every row on the current page. It is page-scoped because, with
* server paging, "all" cannot mean rows that have not loaded. It shows the indeterminate state
* while some but not all page rows are selected.
*/
function DataTableSelectAll({ table, label, ...props }) {
	const strings = useLocalizedStrings(dataTableStrings);
	const all = table.getIsAllPageRowsSelected();
	return /* @__PURE__ */ jsx(Checkbox, {
		"data-slot": "data-table-select-all",
		"aria-label": label ?? strings.format("selectAllOnPage"),
		checked: all,
		indeterminate: !all && table.getIsSomePageRowsSelected(),
		onCheckedChange: (checked) => {
			table.toggleAllPageRowsSelected(checked);
		},
		...props
	});
}
/** A row's selection checkbox. It is disabled when the row cannot be selected. */
function DataTableSelectRow({ row, label, disabled, ...props }) {
	return /* @__PURE__ */ jsx(Checkbox, {
		"data-slot": "data-table-select-row",
		"aria-label": label,
		checked: row.getIsSelected(),
		disabled: disabled === true || !row.getCanSelect(),
		onCheckedChange: (checked) => {
			row.toggleSelected(checked);
		},
		...props
	});
}
DataTableSelectAll.displayName = "DataTable.SelectAll";
DataTableSelectRow.displayName = "DataTable.SelectRow";
export { DataTableSelectAll, DataTableSelectRow };

//# sourceMappingURL=data-table-selection.js.map