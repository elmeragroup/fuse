"use client";
import { useLocalizedStrings } from "../../hooks/use-localized-strings.js";
import { Button } from "../button/button.js";
import { DotsThree } from "../../icons/generated/dots-three.js";
import { dataTableStrings } from "./intl/index.js";
import { DropdownMenuContent, DropdownMenuRoot, DropdownMenuTrigger } from "../dropdown-menu/dropdown-menu.js";
import { dataTableVariants } from "./data-table-variants.js";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/data-table/data-table-row-actions.tsx
const { actionsCell } = dataTableVariants();
/**
* A row's actions menu: a ghost icon button holding the `DotsThree` icon, named by `label`, that
* opens `children` in a `DropdownMenu` aligned to the trigger's end. Props other than `label` and
* `children` land on the trigger. Clicks inside the open menu do not press a pressable row.
*/
function DataTableRowActions({ label, children, ...props }) {
	return /* @__PURE__ */ jsxs(DropdownMenuRoot, { children: [/* @__PURE__ */ jsx(DropdownMenuTrigger, {
		"data-slot": "data-table-row-actions",
		render: /* @__PURE__ */ jsx(Button, {
			variant: "ghost",
			size: "icon-sm",
			"aria-label": label
		}),
		...props,
		children: /* @__PURE__ */ jsx(DotsThree, { "aria-hidden": "true" })
	}), /* @__PURE__ */ jsx(DropdownMenuContent, {
		align: "end",
		children
	})] });
}
/**
* Package-private header of the `actionsColumn` column: the localized word "Actions", visually
* hidden, so the `<th>` has a name without visible text. Its `data-slot` shrinks the column.
*/
function RowActionsHeader() {
	const strings = useLocalizedStrings(dataTableStrings);
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "data-table-actions-header",
		className: "sr-only",
		children: strings.format("actions")
	});
}
/**
* Package-private cell of the `actionsColumn` column: `DataTable.RowActions`, right-aligned, whose
* label the locale dictionary builds from the row's name.
*/
function RowActionsCell({ name, children }) {
	const strings = useLocalizedStrings(dataTableStrings);
	return /* @__PURE__ */ jsx("div", {
		className: actionsCell(),
		children: /* @__PURE__ */ jsx(DataTableRowActions, {
			label: strings.format("actionsFor", { name }),
			children
		})
	});
}
DataTableRowActions.displayName = "DataTable.RowActions";
export { DataTableRowActions, RowActionsCell, RowActionsHeader };

//# sourceMappingURL=data-table-row-actions.js.map