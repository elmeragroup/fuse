"use client";
import { CaretDown } from "../../icons/generated/caret-down.js";
import { cn } from "../../styles/cn.js";
import { Button } from "../button/button.js";
import { CaretUp } from "../../icons/generated/caret-up.js";
import { dataTableVariants } from "./data-table-variants.js";
import { CaretUpDown } from "../../icons/generated/caret-up-down.js";
import { Fragment, jsx, jsxs } from "react/jsx-runtime";
// src/components/data-table/data-table-sort-button.tsx
const { sortButton, sortIcon } = dataTableVariants();
const SORT_ICONS = {
	asc: CaretUp,
	desc: CaretDown,
	none: CaretUpDown
};
/**
* A column header's sort toggle: a ghost button with the label and a direction icon that calls
* the column's sorting handler. A column that cannot sort renders the plain label. The `<th>` owns
* `aria-sort`, which `DataTable.Header` sets, so the button does not repeat it.
*/
function DataTableSortButton({ column, children, className, variant = "ghost", ...props }) {
	const toggle = column.getToggleSortingHandler();
	if (!column.getCanSort() || toggle === void 0) return /* @__PURE__ */ jsx(Fragment, { children });
	const Icon = SORT_ICONS[column.getIsSorted() || "none"];
	return /* @__PURE__ */ jsxs(Button, {
		"data-slot": "data-table-sort-button",
		variant,
		size: "sm",
		className: cn(sortButton(), className),
		onClick: toggle,
		...props,
		children: [children, /* @__PURE__ */ jsx(Icon, {
			"aria-hidden": "true",
			"data-icon": "inline-end",
			className: sortIcon()
		})]
	});
}
DataTableSortButton.displayName = "DataTable.SortButton";
export { DataTableSortButton };

//# sourceMappingURL=data-table-sort-button.js.map