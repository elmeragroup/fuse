"use client";
import { cn } from "../../styles/cn.js";
import { useLocale } from "../../intl/locale-context.js";
import { dataTableVariants } from "./data-table-variants.js";
import { formatCurrencyCell, formatDateCell, formatNumberCell } from "./data-table-format.js";
import { jsx } from "react/jsx-runtime";
// src/components/data-table/data-table-cells.tsx
const { cellNumber } = dataTableVariants();
/** A text cell. */
function DataTableText({ value, className }) {
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "data-table-text",
		className,
		children: value
	});
}
/** A number cell, formatted for the active locale with tabular figures. */
function DataTableNumber({ value, className, ...options }) {
	const { locale } = useLocale();
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "data-table-number",
		className: cn(cellNumber(), className),
		children: formatNumberCell(locale, value, options)
	});
}
/** An amount in a currency, formatted for the active locale with tabular figures. */
function DataTableCurrency({ value, currency, className, ...options }) {
	const { locale } = useLocale();
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "data-table-currency",
		className: cn(cellNumber(), className),
		children: formatCurrencyCell(locale, value, currency, options)
	});
}
/**
* A date, formatted for the active locale. `dateStyle` defaults to `"medium"`, and `timeZone` to
* the `LocaleProvider` zone.
*/
function DataTableDate({ value, className, dateStyle = "medium", ...options }) {
	const { locale, timeZone } = useLocale();
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "data-table-date",
		className,
		children: formatDateCell(locale, value, {
			dateStyle,
			...options,
			timeZone: options.timeZone ?? timeZone
		})
	});
}
/**
* A date and time, formatted for the active locale. `dateStyle` defaults to `"medium"`,
* `timeStyle` to `"short"` and `timeZone` to the `LocaleProvider` zone.
*/
function DataTableDateTime({ value, className, dateStyle = "medium", timeStyle = "short", ...options }) {
	const { locale, timeZone } = useLocale();
	return /* @__PURE__ */ jsx("span", {
		"data-slot": "data-table-date-time",
		className,
		children: formatDateCell(locale, value, {
			dateStyle,
			timeStyle,
			...options,
			timeZone: options.timeZone ?? timeZone
		})
	});
}
DataTableText.displayName = "DataTable.Text";
DataTableNumber.displayName = "DataTable.Number";
DataTableCurrency.displayName = "DataTable.Currency";
DataTableDate.displayName = "DataTable.Date";
DataTableDateTime.displayName = "DataTable.DateTime";
export { DataTableCurrency, DataTableDate, DataTableDateTime, DataTableNumber, DataTableText };

//# sourceMappingURL=data-table-cells.js.map