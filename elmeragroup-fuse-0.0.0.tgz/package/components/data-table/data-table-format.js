import { numberFormat } from "../../internal/intl-cache.js";
import { canonicalSpaces } from "../../intl/canonical-spaces.js";
import { formatDateTime } from "../../intl/date-time-join.js";
// src/components/data-table/data-table-format.ts
/**
* Locale formatting for the default cells. TanStack types every registered cell on every column
* regardless of its value type, so `<cell.NumberCell />` compiles on a string column. A registered
* cell therefore parses `getValue()` into a {@link CellValue} first, and a cell handed a value of
* another kind renders its raw text instead of throwing.
*/
/**
* The raw text of a parsed cell value.
*
* @param cell - The parsed value.
* @returns A number or date as `String()` renders it, or the text itself.
*/
function cellValueText(cell) {
	return cell.kind === "text" ? cell.value : String(cell.value);
}
/**
* Format a number for the locale.
*
* @param locale - The active supported locale.
* @param value - The number.
* @param options - Digits, grouping and notation.
* @returns The formatted number, with every space written as U+00A0.
*/
function formatNumberCell(locale, value, options) {
	return canonicalSpaces(numberFormat(locale, options).format(value));
}
/**
* Format an amount in a currency for the locale.
*
* @param locale - The active supported locale.
* @param value - The amount.
* @param currency - The ISO 4217 code, such as `"NOK"`.
* @param options - Digits, grouping and currency display.
* @returns The formatted amount, with every space written as U+00A0.
*/
function formatCurrencyCell(locale, value, currency, options) {
	const currencyOptions = {
		...options,
		style: "currency",
		currency
	};
	return canonicalSpaces(numberFormat(locale, currencyOptions).format(value));
}
/**
* Format a date, or a date and time, for the locale.
*
* @param locale - The active supported locale.
* @param value - The date. An invalid date renders as `"Invalid Date"`, which `Intl` would throw on.
* @param options - Date and time styles and the time zone.
* @returns The formatted date, with every space written as U+00A0. A date and a time join through
* `formatDateTime`, which writes CLDR 48's join, so Node and every browser engine write the same
* text.
*/
function formatDateCell(locale, value, options) {
	return Number.isNaN(value.getTime()) ? String(value) : canonicalSpaces(formatDateTime(locale, options, value.getTime()));
}
export { cellValueText, formatCurrencyCell, formatDateCell, formatNumberCell };

//# sourceMappingURL=data-table-format.js.map