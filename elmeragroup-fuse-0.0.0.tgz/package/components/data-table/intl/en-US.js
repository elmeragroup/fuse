// src/components/data-table/intl/en-US.ts
/** Default localized copy for the `dataTable.*` rows. */
const enUS = {
	noResults: "No results.",
	rowsPerPage: "Rows per page",
	pageOf: (vars) => `Page ${String(vars?.page)} of ${String(vars?.pageCount)}`,
	page: (vars) => `Page ${String(vars?.page)}`,
	goToFirstPage: "Go to first page",
	goToPreviousPage: "Go to previous page",
	goToNextPage: "Go to next page",
	goToLastPage: "Go to last page",
	columns: "Columns",
	selectAllOnPage: "Select all rows on this page",
	actions: "Actions",
	actionsFor: (vars) => `Actions for ${String(vars?.name)}`
};
export { enUS };

//# sourceMappingURL=en-US.js.map