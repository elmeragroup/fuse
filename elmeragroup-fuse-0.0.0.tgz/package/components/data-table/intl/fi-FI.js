// src/components/data-table/intl/fi-FI.ts
/** Default localized copy for the `dataTable.*` rows. */
const fiFI = {
	noResults: "Ei tuloksia.",
	rowsPerPage: "Rivejä sivulla",
	pageOf: (vars) => `Sivu ${String(vars?.page)}/${String(vars?.pageCount)}`,
	page: (vars) => `Sivu ${String(vars?.page)}`,
	goToFirstPage: "Siirry ensimmäiselle sivulle",
	goToPreviousPage: "Siirry edelliselle sivulle",
	goToNextPage: "Siirry seuraavalle sivulle",
	goToLastPage: "Siirry viimeiselle sivulle",
	columns: "Sarakkeet",
	selectAllOnPage: "Valitse kaikki tämän sivun rivit",
	actions: "Toiminnot",
	actionsFor: (vars) => `Toiminnot: ${String(vars?.name)}`
};
export { fiFI };

//# sourceMappingURL=fi-FI.js.map