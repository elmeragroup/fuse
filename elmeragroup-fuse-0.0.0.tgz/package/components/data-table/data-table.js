"use client";
import { cn } from "../../styles/cn.js";
import { useLocalizedStrings } from "../../hooks/use-localized-strings.js";
import { definedProps } from "../../internal/defined-props.js";
import { pressesRegion } from "../../internal/own-click.js";
import { dataTableStrings } from "./intl/index.js";
import { Skeleton } from "../skeleton/skeleton.js";
import { Table } from "../table/table.js";
import { dataTableVariants } from "./data-table-variants.js";
import { Fragment } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/data-table/data-table.tsx
const { emptyCell, head, skeleton, row: rowClass } = dataTableVariants();
function ariaSort(column) {
	if (column.getCanSort?.() !== true) return;
	const sorted = column.getIsSorted?.();
	return sorted === "asc" ? "ascending" : sorted === "desc" ? "descending" : "none";
}
/** Header rows over any header renderer. */
function HeaderRows({ headerGroups, renderHeader, ...props }) {
	return /* @__PURE__ */ jsx(Table.Header, {
		"data-slot": "data-table-header",
		...props,
		children: headerGroups.map((group) => /* @__PURE__ */ jsx(Table.Row, { children: group.headers.map((header) => {
			const sort = ariaSort(header.column);
			return /* @__PURE__ */ jsx(Table.Head, {
				colSpan: header.colSpan,
				className: head(),
				...definedProps({ "aria-sort": sort }),
				children: header.isPlaceholder ? null : renderHeader(header)
			}, header.id);
		}) }, group.id))
	});
}
/** Skeleton rows never exceed this, whatever the page size. */
const MAX_SKELETON_ROWS = 10;
/** Skeleton rows for a table without pagination. */
const DEFAULT_SKELETON_ROWS = 5;
/**
* The number of skeleton rows a loading table shows.
*
* @param pageSize - The table's page size, or `undefined` without `rowPaginationFeature`.
* @returns The page size clamped to one through ten, or five without a page size.
*/
function skeletonRowCount(pageSize) {
	if (pageSize === void 0 || Number.isNaN(pageSize)) return DEFAULT_SKELETON_ROWS;
	return Math.min(MAX_SKELETON_ROWS, Math.max(1, Math.floor(pageSize)));
}
/** The number of columns a full-width row spans: the visible leaf columns. */
function visibleColumnCount(table) {
	return (table.getVisibleLeafColumns?.() ?? table.getAllLeafColumns()).length;
}
/** The page size, or `undefined` for a table without `rowPaginationFeature`. */
function pageSizeOf(table) {
	return table.atoms.pagination?.get().pageSize;
}
/** The body of a table's current row model over any row renderer. */
function BodyRows({ table, loading, empty, renderRow, ...props }) {
	const strings = useLocalizedStrings(dataTableStrings);
	const { rows } = table.getRowModel();
	const columnCount = visibleColumnCount(table);
	let content;
	if (rows.length > 0) content = rows.map((row) => /* @__PURE__ */ jsx(Fragment, { children: renderRow(row) }, row.id));
	else if (loading) content = Array.from({ length: skeletonRowCount(pageSizeOf(table)) }, (_, index) => /* @__PURE__ */ jsx(Table.Row, {
		"data-slot": "data-table-skeleton-row",
		children: Array.from({ length: columnCount }, (_cell, column) => /* @__PURE__ */ jsx(Table.Cell, { children: /* @__PURE__ */ jsx(Skeleton, { className: skeleton() }) }, column))
	}, index));
	else content = /* @__PURE__ */ jsx(Table.Row, {
		"data-slot": "data-table-empty-row",
		children: /* @__PURE__ */ jsx(Table.Cell, {
			colSpan: Math.max(1, columnCount),
			className: emptyCell(),
			children: empty ?? strings.format("noResults")
		})
	});
	return /* @__PURE__ */ jsx(Table.Body, {
		"data-slot": "data-table-body",
		...props,
		children: content
	});
}
/** Package-private row over any cell renderer. The registered parts pass `table.AppCell`. */
function RowCells({ row, renderCell, onPress, onClick, className, ...props }) {
	const cells = row.getVisibleCells?.() ?? row.getAllCells();
	return /* @__PURE__ */ jsx(Table.Row, {
		"data-slot": "data-table-row",
		...definedProps({ "data-state": row.getIsSelected?.() === true ? "selected" : void 0 }),
		className: cn(rowClass({ pressable: onPress !== void 0 }), className),
		onClick: (event) => {
			onClick?.(event);
			if (onPress !== void 0 && !event.defaultPrevented && pressesRegion(event.target, event.currentTarget)) onPress(event);
		},
		...props,
		children: cells.map((cell) => /* @__PURE__ */ jsx(Table.Cell, { children: renderCell(cell) }, cell.id))
	});
}
/**
* Package-private whole table over any header and row renderer: `DataTable.Content` passes
* `table.FlexRender` and `DataTable.Row`, the registered `table.Content` passes `table.AppHeader`
* and `table.Row`. While `loading` the table carries `aria-busy`.
*/
function ContentTable({ table, loading, empty, renderHeader, renderRow, ...props }) {
	return /* @__PURE__ */ jsxs(Table.Root, {
		...definedProps({ "aria-busy": loading === true || void 0 }),
		...props,
		children: [/* @__PURE__ */ jsx(HeaderRows, {
			headerGroups: table.getHeaderGroups(),
			renderHeader
		}), /* @__PURE__ */ jsx(BodyRows, {
			table,
			loading,
			empty,
			renderRow
		})]
	});
}
/**
* Every header group of a table as `<thead>` rows. Each `<th>` takes the header's `colSpan`,
* renders nothing for a placeholder, and carries `aria-sort` (`ascending`, `descending` or `none`)
* only when its column can sort.
*
* @template TGroup - The header group type of the table's `getHeaderGroups()`.
*/
function DataTableHeader({ table, ...props }) {
	return /* @__PURE__ */ jsx(HeaderRows, {
		headerGroups: table.getHeaderGroups(),
		renderHeader: (header) => /* @__PURE__ */ jsx(table.FlexRender, { header }),
		...props
	});
}
/**
* The rows of a table's current row model. With no rows it renders skeleton rows while `loading`
* (page-size many, at most ten), or else one row whose cell spans the visible leaf columns and
* shows `empty`.
*/
function DataTableBody({ table, children, ...props }) {
	return /* @__PURE__ */ jsx(BodyRows, {
		table,
		renderRow: children ?? ((row) => /* @__PURE__ */ jsx(DataTableRow, {
			table,
			row
		})),
		...props
	});
}
/**
* A whole table on Fuse `Table`: the shared content table with `table.FlexRender` headers and
* `DataTable.Row` rows. While `loading` the table carries `aria-busy`. Pass `children` to render
* each row yourself.
*
* @template TGroup - The header group type of the table's `getHeaderGroups()`.
* @template TRow - The row type of the table's row model.
* @template TCell - The cell type a row's `getAllCells()` returns.
*/
function DataTableContent({ table, loading = false, children, ...props }) {
	return /* @__PURE__ */ jsx(ContentTable, {
		table,
		loading,
		renderHeader: (header) => /* @__PURE__ */ jsx(table.FlexRender, { header }),
		renderRow: children ?? ((row) => /* @__PURE__ */ jsx(DataTableRow, {
			table,
			row
		})),
		...props
	});
}
/**
* One table row with its visible cells. A selected row carries `data-state="selected"`.
*/
function DataTableRow({ table, ...props }) {
	return /* @__PURE__ */ jsx(RowCells, {
		renderCell: (cell) => /* @__PURE__ */ jsx(table.FlexRender, { cell }),
		...props
	});
}
DataTableContent.displayName = "DataTable.Content";
DataTableHeader.displayName = "DataTable.Header";
DataTableBody.displayName = "DataTable.Body";
DataTableRow.displayName = "DataTable.Row";
export { ContentTable, DataTableBody, DataTableContent, DataTableHeader, DataTableRow, RowCells, skeletonRowCount };

//# sourceMappingURL=data-table.js.map