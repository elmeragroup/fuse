"use client";
import { useLocalizedStrings } from "../../hooks/use-localized-strings.js";
import { definedProps } from "../../internal/defined-props.js";
import { Button } from "../button/button.js";
import { dataTableStrings } from "./intl/index.js";
import { DropdownMenuCheckboxItem, DropdownMenuContent, DropdownMenuRoot, DropdownMenuTrigger } from "../dropdown-menu/dropdown-menu.js";
import { SlidersHorizontal } from "../../icons/generated/sliders-horizontal.js";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/data-table/data-table-column-toggle.tsx
/**
* A menu of checkbox items that shows and hides every column whose `getCanHide()` is true.
* `open`, `defaultOpen` and `onOpenChange` go to the menu; the other props go to its trigger.
*/
function DataTableColumnToggle({ table, getLabel, label, variant = "outline", open, defaultOpen, onOpenChange, ...props }) {
	const strings = useLocalizedStrings(dataTableStrings);
	return /* @__PURE__ */ jsxs(DropdownMenuRoot, {
		...definedProps({
			open,
			defaultOpen,
			onOpenChange
		}),
		children: [/* @__PURE__ */ jsxs(DropdownMenuTrigger, {
			"data-slot": "data-table-column-toggle",
			render: /* @__PURE__ */ jsx(Button, {
				variant,
				size: "sm"
			}),
			...props,
			children: [/* @__PURE__ */ jsx(SlidersHorizontal, {
				"aria-hidden": "true",
				"data-icon": "inline-start"
			}), label ?? strings.format("columns")]
		}), /* @__PURE__ */ jsx(DropdownMenuContent, {
			align: "end",
			children: table.getAllLeafColumns().filter((column) => column.getCanHide()).map((column) => /* @__PURE__ */ jsx(DropdownMenuCheckboxItem, {
				checked: column.getIsVisible(),
				onCheckedChange: (checked) => {
					column.toggleVisibility(checked);
				},
				children: getLabel?.(column) ?? column.id
			}, column.id))
		})]
	});
}
DataTableColumnToggle.displayName = "DataTable.ColumnToggle";
export { DataTableColumnToggle };

//# sourceMappingURL=data-table-column-toggle.js.map