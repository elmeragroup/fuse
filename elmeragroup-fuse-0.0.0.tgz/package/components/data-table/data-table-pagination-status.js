// src/components/data-table/data-table-pagination-status.ts
function knownPageCount(pageCount) {
	return Number.isFinite(pageCount) && pageCount > 1 ? Math.floor(pageCount) : 1;
}
/**
* Resolve the controls for a page. The total is the only source of Next and Last: TanStack's
* `getCanNextPage()` reads the `-1` unknown-count sentinel as "always another page".
*
* @param pageIndex - The zero-based current page index.
* @param total - The known page count or the unknown total's `hasMore`.
* @returns The one-based page, the page count when known, and which moves are available. Last is
* available exactly when the total is known and Next is.
*/
function pageStatus(pageIndex, total) {
	const index = Number.isFinite(pageIndex) && pageIndex > 0 ? Math.floor(pageIndex) : 0;
	if (total.kind === "unknown") return {
		kind: "unknown",
		page: index + 1,
		canPrevious: index > 0,
		canNext: total.hasMore
	};
	const pageCount = knownPageCount(total.pageCount);
	return {
		kind: "known",
		page: index + 1,
		pageCount,
		canPrevious: index > 0,
		canNext: index < pageCount - 1
	};
}
export { pageStatus };

//# sourceMappingURL=data-table-pagination-status.js.map