"use client";
import { fuseTableContexts } from "./data-table-contexts.js";
import { CurrencyCell, DateCell, DateTimeCell, NumberCell, RegisteredColumnToggle, RegisteredContent, RegisteredPagination, RegisteredRow, RegisteredSortButton, TextCell } from "./data-table-registered.js";
import { createTableHook } from "@tanstack/react-table";
// src/components/data-table/create-fuse-table-hook.ts
/**
* Erased to the registry constraint: the parts are typed over every stock feature, which TypeScript
* cannot compare with the app's `TFeatures`, so the factory retypes them with one cast.
*/
const FUSE_TABLE_COMPONENTS = {
	Content: RegisteredContent,
	Row: RegisteredRow,
	Pagination: RegisteredPagination,
	ColumnToggle: RegisteredColumnToggle
};
const FUSE_HEADER_COMPONENTS = { SortButton: RegisteredSortButton };
const FUSE_CELL_COMPONENTS = {
	TextCell,
	NumberCell,
	CurrencyCell,
	DateCell,
	DateTimeCell
};
/** Fuse's parts first, then the app's, so the app wins by key at runtime, as `Merge` describes. */
function mergeRegistry(fuse, app) {
	return {
		...fuse,
		...app ?? {}
	};
}
/**
* Bind an app's table features, default options and components into one `useFuseTable` hook, with
* Fuse's parts registered: `table.Content`, `table.Row`, `table.Pagination`,
* `table.ColumnToggle`, `header.SortButton` and the default cells `TextCell`, `NumberCell`,
* `CurrencyCell`, `DateCell` and `DateTimeCell`.
*
* It wraps TanStack's `createTableHook` and passes `features` and every default option through
* untouched; Fuse adds no features of its own. The app's components are registered after Fuse's,
* so registering `cellComponents: { NumberCell }` replaces Fuse's `NumberCell`, props included. A
* registered part appears in the types only when its feature is in `features`: `Pagination` needs
* `rowPaginationFeature`, `ColumnToggle` `columnVisibilityFeature` and `SortButton`
* `rowSortingFeature`. Render the registered table parts inside `<table.AppTable>`.
*
* @example
* ```tsx
* export const { useAppTable: useFuseTable, createAppColumnHelper } = createFuseTableHook({
*   features: tableFeatures({ rowPaginationFeature, rowSortingFeature }),
*   enableSortingRemoval: false,
*   cellComponents: { OrderIdCell },
* });
* ```
*
* @template TFeatures - The app's `tableFeatures({...})` object.
* @template TTableComponents - The app's table components.
* @template TCellComponents - The app's cell components.
* @template THeaderComponents - The app's header components.
* @param options - Features, default table options and the app's components.
* @returns TanStack's table hook result, typed with Fuse's parts merged under the app's.
*/
function createFuseTableHook(options) {
	const fuseTableComponents = FUSE_TABLE_COMPONENTS;
	const fuseHeaderComponents = FUSE_HEADER_COMPONENTS;
	return createTableHook({
		...options,
		tableContext: fuseTableContexts.tableContext,
		cellContext: fuseTableContexts.cellContext,
		headerContext: fuseTableContexts.headerContext,
		tableComponents: mergeRegistry(fuseTableComponents, options.tableComponents),
		cellComponents: mergeRegistry(FUSE_CELL_COMPONENTS, options.cellComponents),
		headerComponents: mergeRegistry(fuseHeaderComponents, options.headerComponents)
	});
}
export { createFuseTableHook };

//# sourceMappingURL=create-fuse-table-hook.js.map