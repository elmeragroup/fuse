"use client";
import { CaretDown } from "../../icons/generated/caret-down.js";
import { accordionVariants } from "./accordion-variants.js";
import { createContext, useContext, useMemo } from "react";
import { Accordion } from "@base-ui/react/accordion";
import { jsx, jsxs } from "react/jsx-runtime";
// src/components/accordion/accordion.tsx
const AccordionContext = createContext(null);
function useAccordion() {
	const context = useContext(AccordionContext);
	if (context === null) throw new Error("useAccordion must be used within Accordion.Root");
	return context;
}
/**
* Client accordion over `@base-ui/react/accordion`. Root owns
* open-item state; `variant` / `radius` publish through module-private context so
* parts style themselves.
*/
function AccordionRoot$1({ className, variant = "default", radius = "none", ...props }) {
	const { base } = accordionVariants({
		variant,
		radius
	});
	const variants = useMemo(() => ({
		variant,
		radius
	}), [variant, radius]);
	return /* @__PURE__ */ jsx(AccordionContext.Provider, {
		value: variants,
		children: /* @__PURE__ */ jsx(Accordion.Root, {
			"data-slot": "accordion",
			className: base({ className }),
			...props
		})
	});
}
/**
* One accordion item. A rounded item publishes `--inner-corner`, its corner less its border and
* padding, and a card item's panel rounds with it. A `card` item draws its 1px edge in the theme's
* `--card-border`: `--border` in neutral themes and a zero-alpha colour in branded ones. A border
* colour class still wins.
*/
function AccordionItem({ className, ...props }) {
	const variants = useAccordion();
	const { item } = accordionVariants(variants);
	return /* @__PURE__ */ jsx(Accordion.Item, {
		"data-slot": "accordion-item",
		className: item({ className }),
		...props
	});
}
function AccordionHeader({ className, ...props }) {
	const variants = useAccordion();
	const { header } = accordionVariants(variants);
	return /* @__PURE__ */ jsx(Accordion.Header, {
		"data-slot": "accordion-header",
		className: header({ className }),
		...props
	});
}
/**
* The item's toggle button. `indicator` follows the children: it defaults to a caret that
* rotates while the item is open, `null` renders none, and any other node renders as given.
* The variant places any indicator, default or custom, in the same position. The rotation
* belongs to the default caret only; a custom indicator, or a leading icon passed as a child,
* styles its open state from the trigger's `data-panel-open` (`in-data-[panel-open]:rotate-90`).
* With no indicator the children pack at the start.
*/
function AccordionTrigger({ className, children, indicator, ...props }) {
	const variants = useAccordion();
	const slots = accordionVariants({
		...variants,
		hasIndicator: indicator !== null
	});
	return /* @__PURE__ */ jsxs(Accordion.Trigger, {
		"data-slot": "accordion-trigger",
		className: slots.trigger({ className }),
		...props,
		children: [children, indicator === void 0 ? /* @__PURE__ */ jsx(CaretDown, {
			"aria-hidden": "true",
			className: slots.icon()
		}) : indicator === null ? null : /* @__PURE__ */ jsx("span", {
			"data-slot": "accordion-indicator",
			className: slots.indicator(),
			children: indicator
		})]
	});
}
function AccordionContent({ className, children, ...props }) {
	const variants = useAccordion();
	const { content, contentInner } = accordionVariants(variants);
	return /* @__PURE__ */ jsx(Accordion.Panel, {
		"data-slot": "accordion-content",
		className: content(),
		...props,
		children: /* @__PURE__ */ jsx("div", {
			className: contentInner({ className }),
			children
		})
	});
}
AccordionRoot$1.displayName = "Accordion.Root";
AccordionItem.displayName = "Accordion.Item";
AccordionHeader.displayName = "Accordion.Header";
AccordionTrigger.displayName = "Accordion.Trigger";
AccordionContent.displayName = "Accordion.Content";
export { AccordionContent, AccordionHeader, AccordionItem, AccordionRoot$1 as AccordionRoot, AccordionTrigger };

//# sourceMappingURL=accordion.js.map