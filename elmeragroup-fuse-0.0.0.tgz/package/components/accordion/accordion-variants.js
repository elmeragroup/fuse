import { cn } from "../../styles/cn.js";
import { accordionCardItemLgShellClass, accordionCardItemShellClass, accordionCardItemXlShellClass, accordionItemLgShellClass, accordionItemShellClass, accordionItemXlShellClass } from "../../styles/inner-corner/accordion.js";
import { panelHeightTransition } from "../../styles/panel-height.js";
import { tv } from "../../styles/tv.js";
import { selfFocusRingClass } from "../../styles/utils.js";
import { dataStateFaceClass, nativeStateFaceClass } from "../../styles/state-face.js";
// src/components/accordion/accordion-variants.ts
/**
* PUBLIC slot recipe. Consumers borrow it from
* `@elmeragroup/fuse/accordion`. Context-passed `variant` / `radius` stay on Root;
* parts call this with the published axes for their own slot.
*
* Height on `content` is the approved layout exception, owned once by the shared
* `panelHeightTransition` constant (`styles/panel-height.ts`) against base-ui's
* `--accordion-panel-height` — not a control size.
*
* The trigger is a native button that Base UI also marks `data-disabled`, and a consumer may
* announce it `aria-disabled`, so it composes the `native` and `data` state faces (both
* carry the `aria-disabled` arm) and gates its hover underline behind `enabled-hover:`.
*
* `hasIndicator` packs the trigger's children at the start when `Accordion.Trigger` renders
* no trailing indicator, so a leading icon sits beside the label instead of across the row.
*
* `icon` styles and places the default caret, and consumers borrow it for their own carets.
* `indicator` repeats the icon's placement on the wrapper of a custom indicator, so either
* one sits in the same spot. `infodropdown` packs the trigger at the start, so both slots pin
* to the right edge there.
*
* The `card` item draws its 1px edge in `--card-border`, which branded themes make transparent;
* add `border-border` where a borrowed item must keep a visible edge.
*/
const accordionVariants = tv({
	slots: {
		base: "",
		item: "p-(--surface-pad-md)",
		header: "flex",
		trigger: cn("group/accordion-trigger font-medium flex flex-1 cursor-pointer items-center justify-between gap-2 bg-transparent text-inherit enabled-hover:underline", selfFocusRingClass, nativeStateFaceClass, dataStateFaceClass),
		indicator: "flex shrink-0 items-center",
		icon: "size-4 shrink-0 transition-transform duration-200 group-data-[panel-open]/accordion-trigger:rotate-180",
		content: cn(panelHeightTransition, "h-(--accordion-panel-height)"),
		contentInner: "pt-[calc(var(--surface-gap-lg)+--spacing(1.5))]"
	},
	variants: {
		variant: {
			default: {
				base: "space-y-3",
				item: [accordionItemShellClass, "bg-primary-soft text-primary-soft-foreground [--ring:var(--primary-soft-foreground)]"]
			},
			card: {
				base: "space-y-3",
				item: [accordionCardItemShellClass, "border-card-border bg-card text-foreground"],
				content: "rounded-inner bg-card text-foreground",
				icon: "text-foreground"
			},
			infodropdown: {
				base: "border-b border-border",
				trigger: "relative justify-start",
				indicator: "absolute right-0",
				icon: "absolute right-0 text-foreground",
				content: "pl-7",
				contentInner: "pt-1.5"
			}
		},
		hasIndicator: {
			true: {},
			false: { trigger: "justify-start" }
		},
		radius: {
			none: {},
			lg: { item: [accordionItemLgShellClass, "overflow-hidden"] },
			xl: { item: [accordionItemXlShellClass, "overflow-hidden"] }
		}
	},
	compoundVariants: [{
		variant: "card",
		radius: "lg",
		class: { item: accordionCardItemLgShellClass }
	}, {
		variant: "card",
		radius: "xl",
		class: { item: accordionCardItemXlShellClass }
	}],
	defaultVariants: {
		variant: "default",
		radius: "none",
		hasIndicator: true
	}
});
export { accordionVariants };

//# sourceMappingURL=accordion-variants.js.map