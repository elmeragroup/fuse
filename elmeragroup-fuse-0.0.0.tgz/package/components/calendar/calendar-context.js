import { useCalendarSelector } from "./calendar-store.js";
import { createContext, use } from "react";
// src/components/calendar/calendar-context.ts
/**
* Every day flag, in the order `dayFlags` writes them. The `CalendarDayFlag` union is read from
* this list, so the order holds every flag by construction.
*/
const DAY_FLAGS = [
	"selected",
	"selection-start",
	"selection-end",
	"in-range",
	"highlighted",
	"invalid"
];
/**
* A day's flags in their fixed order, as one primitive.
*
* @param flags - The flags that hold, in any order, repeats allowed.
* @returns The flags.
*/
function dayFlags(flags) {
	const present = new Set(flags);
	return DAY_FLAGS.filter((flag) => present.has(flag)).join(" ");
}
/** A day with no flags. */
const NO_DAY_FLAGS = dayFlags([]);
/** The one mapping between a flag and its render-state field. */
const DAY_FLAG_FIELDS = {
	selected: "selected",
	"selection-start": "selectionStart",
	"selection-end": "selectionEnd",
	"in-range": "inRange",
	highlighted: "highlighted",
	invalid: "invalid"
};
/**
* A day's flags as the booleans of its render state: `selected`, `selectionStart`,
* `selectionEnd`, `inRange`, `highlighted` and `invalid`. The one decoder of `CalendarDayFlags`;
* the gridcell calls it once per day and shares the result with its button.
*
* @param flags - The day's flags.
* @returns One boolean for each flag.
*/
function dayFlagState(flags) {
	const present = new Set(flags.split(" "));
	return Object.fromEntries(DAY_FLAGS.map((flag) => [DAY_FLAG_FIELDS[flag], present.has(flag)]));
}
/**
* The `stateAttributesMapping` entries that write each flag that holds as a bare `data-<flag>`
* attribute from a `CalendarDayFlagState`. A part whose `useRender` state spreads the flag state,
* such as the day button, passes these so every flag reaches the DOM under the same name.
*/
const DAY_FLAG_STATE_ATTRIBUTES = Object.fromEntries(DAY_FLAGS.map((flag) => [DAY_FLAG_FIELDS[flag], (value) => value ? { [`data-${flag}`]: "" } : null]));
/**
* A selection owner over a Root's store. Its `useDayFlags` and `useDayNamePrefix` subscribe each
* day to its own answer through `useCalendarSelector`, so the store's initial state answers on the
* server and while a part hydrates, for every Root alike.
*
* @template S - The Root's state.
* @param store - The Root's store.
* @param model - The per-day answers and the selection inputs.
* @returns The owner the parts read.
*/
function createSelectionOwner(store, model) {
	return {
		useDayFlags(date, iso) {
			return useCalendarSelector(store, (state) => model.dayFlags(state, date, iso));
		},
		useDayNamePrefix(date, iso) {
			return useCalendarSelector(store, (state) => model.dayNamePrefix(state, date, iso));
		},
		dayDescriptionId: model.dayDescriptionId,
		multiselectable: model.multiselectable,
		select: model.select,
		hover: model.hover
	};
}
const CalendarRootContext = createContext(void 0);
const CalendarMonthContext = createContext(void 0);
const CalendarDayContext = createContext(void 0);
/**
* The enclosing calendar Root.
*
* @param part - The part asking, named in the error.
* @returns The Root's context.
* @throws Error naming the part when it renders outside a calendar Root, a composition defect.
*/
function useCalendarRootContext(part) {
	const value = use(CalendarRootContext);
	if (value === void 0) throw new Error(`${part} must be rendered inside Calendar.Root or RangeCalendar.Root.`);
	return value;
}
/**
* The enclosing `Calendar.Month`.
*
* @param part - The part asking, named in the error.
* @returns The month's context.
* @throws Error naming the part when it renders outside `Calendar.Month`, a composition defect.
*/
function useCalendarMonthContext(part) {
	const value = use(CalendarMonthContext);
	if (value === void 0) throw new Error(`${part} must be rendered inside Calendar.Month.`);
	return value;
}
/**
* The enclosing `Calendar.DayGridCell`.
*
* @param part - The part asking, named in the error.
* @returns The cell's context.
* @throws Error naming the part when it renders outside `Calendar.DayGridCell`, a composition defect.
*/
function useCalendarDayContext(part) {
	const value = use(CalendarDayContext);
	if (value === void 0) throw new Error(`${part} must be rendered inside Calendar.DayGridCell.`);
	return value;
}
export { CalendarDayContext, CalendarMonthContext, CalendarRootContext, DAY_FLAG_STATE_ATTRIBUTES, NO_DAY_FLAGS, createSelectionOwner, dayFlagState, dayFlags, useCalendarDayContext, useCalendarMonthContext, useCalendarRootContext };

//# sourceMappingURL=calendar-context.js.map