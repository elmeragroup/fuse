"use client";
import { cn } from "../../styles/cn.js";
import { useLocalizedStrings } from "../../hooks/use-localized-strings.js";
import { definedProps } from "../../internal/defined-props.js";
import { Button } from "../button/button.js";
import { CaretRight } from "../../icons/generated/caret-right.js";
import { useCalendarSelector, useCalendarStateField } from "./calendar-store.js";
import { CalendarDayContext, CalendarMonthContext, DAY_FLAG_STATE_ATTRIBUTES, NO_DAY_FLAGS, dayFlagState, useCalendarDayContext, useCalendarMonthContext, useCalendarRootContext } from "./calendar-context.js";
import { canPage, dayStatus, focusMoveForKey, lastVisibleMonth } from "./calendar-dates.js";
import { calendarVariants } from "./calendar-variants.js";
import { CaretLeft } from "../../icons/generated/caret-left.js";
import { monthWeeks } from "../../temporal/month-grid.js";
import { referenceDay } from "../../temporal/reference-day.js";
import { formatDayName, formatDayNumber, formatMonth, formatMonthRange, formatWeekday, formatWeekdayName } from "./calendar-format.js";
import { calendarStrings } from "./intl/index.js";
import { useId, useLayoutEffect, useMemo, useRef } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
// src/components/calendar/calendar-parts.tsx
const styles = calendarVariants();
/**
* The row above the months: the month buttons around the visible-range heading. It is layout
* only; put the parts in it in the order they should read.
*/
function CalendarHeader({ className, render, ...props }) {
	return useRender({
		defaultTagName: "div",
		render,
		props: {
			"data-slot": "calendar-header",
			...mergeProps({ className: cn(styles.header(), className) }, props)
		}
	});
}
const MONTH_BUTTONS = {
	decrement: {
		slot: "calendar-decrement-month",
		step: -1,
		labelKey: "previous",
		Icon: CaretLeft
	},
	increment: {
		slot: "calendar-increment-month",
		step: 1,
		labelKey: "next",
		Icon: CaretRight
	}
};
function CalendarMonthButton({ direction, className, size = "icon", "aria-label": ariaLabel, children, ...props }) {
	const button = MONTH_BUTTONS[direction];
	const { store, settings, actions } = useCalendarRootContext(direction === "decrement" ? "Calendar.DecrementMonth" : "Calendar.IncrementMonth");
	const strings = useLocalizedStrings(calendarStrings);
	const { bounds, disabled: calendarDisabled } = settings;
	const pageable = useCalendarSelector(store, (state) => state.visible === null ? false : canPage(state.visible, button.step, bounds));
	const { Icon } = button;
	return /* @__PURE__ */ jsx(Button, {
		"data-slot": button.slot,
		...mergeProps({
			variant: "ghost",
			disabled: calendarDisabled || !pageable,
			focusableWhenDisabled: true,
			onClick: (event) => actions.page(button.step, event.nativeEvent, event.currentTarget)
		}, definedProps(props)),
		size,
		"aria-label": ariaLabel ?? strings.format(button.labelKey),
		className: cn(styles.nav(), className),
		children: children ?? /* @__PURE__ */ jsx(Icon, {
			"aria-hidden": "true",
			className: "rtl:-scale-x-100"
		})
	});
}
/** Pages back: the visible months move back one page, and focus moves with them. */
function CalendarDecrementMonth(props) {
	return /* @__PURE__ */ jsx(CalendarMonthButton, {
		direction: "decrement",
		...props
	});
}
/** Pages forward: the visible months move on one page, and focus moves with them. */
function CalendarIncrementMonth(props) {
	return /* @__PURE__ */ jsx(CalendarMonthButton, {
		direction: "increment",
		...props
	});
}
/**
* The visible months as one heading, such as "October 2026" or "October – December 2026", and
* the calendar's one live region: a month button's page is announced politely. It stays quiet
* until the user first pages, so the months a calendar opens or hydrates on are not announced,
* and while keyboard focus is on a day, since the newly focused day and its grid name say the
* same. Render one per calendar.
*/
function CalendarVisibleRangeHeading({ className, render, ...props }) {
	const { store, settings } = useCalendarRootContext("Calendar.VisibleRangeHeading");
	const { locale } = settings;
	const visible = useCalendarStateField(store, "visible");
	const text = useMemo(() => visible === null ? "" : formatMonthRange(locale, visible.start, lastVisibleMonth(visible)), [locale, visible]);
	const quiet = useCalendarSelector(store, (state) => !state.paged || state.gridFocused);
	return useRender({
		defaultTagName: "h2",
		render,
		props: {
			"data-slot": "calendar-visible-range-heading",
			...mergeProps({
				"aria-live": quiet ? "off" : "polite",
				"aria-atomic": true,
				className: cn(styles.visibleRangeHeading(), className),
				children: text
			}, props)
		}
	});
}
/** The default month: heading, weekday row and weeks. */
function DefaultMonth({ month, single }) {
	return /* @__PURE__ */ jsxs(CalendarMonth, {
		value: month,
		children: [/* @__PURE__ */ jsx(CalendarMonthHeading, { className: single ? "sr-only" : void 0 }), /* @__PURE__ */ jsxs(CalendarDayGrid, { children: [/* @__PURE__ */ jsx(CalendarDayGridHeader, {}), /* @__PURE__ */ jsx(CalendarDayGridBody, {})] })]
	});
}
/** The most weeks a month spans, which a placeholder grid reserves. */
const PLACEHOLDER_WEEKS = 6;
/**
* A month the calendar cannot name yet: one with neither a value nor a default value shows today's
* months, and only the client's first effect reads the clock, never a render, so the server and the
* hydrating render write this instead. It is the default month's frame, the weekday row over six
* weeks of empty days, hidden from assistive technology. Six weeks are the most a month spans, so
* the popup or page never grows when today's months replace it, and shrinks by a row or two for a
* month of four or five weeks; hydration matches either way. Its weekday row is the real
* `DayGridHeader` over the reference day's month: any month names the same weekdays.
*/
function PlaceholderMonth({ single }) {
	const month = useMemo(() => referenceDay().toPlainYearMonth(), []);
	return /* @__PURE__ */ jsxs(CalendarMonth, {
		value: month,
		"aria-hidden": true,
		children: [single ? null : /* @__PURE__ */ jsx("div", {
			"data-slot": "calendar-month-heading",
			className: styles.monthHeading(),
			children: "\xA0"
		}), /* @__PURE__ */ jsxs("table", {
			"data-slot": "calendar-day-grid",
			role: "presentation",
			className: styles.dayGrid(),
			children: [/* @__PURE__ */ jsx(CalendarDayGridHeader, {}), /* @__PURE__ */ jsx("tbody", {
				"data-slot": "calendar-day-grid-body",
				className: styles.dayGridBody(),
				children: Array.from({ length: PLACEHOLDER_WEEKS }, (_, row) => /* @__PURE__ */ jsx("tr", {
					"data-slot": "calendar-day-grid-row",
					className: styles.dayGridRow(),
					children: Array.from({ length: 7 }, (_, column) => /* @__PURE__ */ jsx("td", {
						"data-slot": "calendar-day-grid-cell",
						className: styles.dayGridCell(),
						children: /* @__PURE__ */ jsx("span", {
							"data-slot": "calendar-day-button",
							"data-outside-month": "",
							className: styles.day()
						})
					}, column))
				}, row))
			})]
		})]
	});
}
/**
* The visible months in a row that wraps, so a narrow host stacks them. A calendar with neither
* a value nor a default value writes placeholder months on the server and in the hydrating render,
* the default month's frame with six weeks of empty days, until its first effect has read today
* and shows today's months; `children` renders the months from then on.
*/
function CalendarMonths({ className, render, children, ...props }) {
	const { store, settings } = useCalendarRootContext("Calendar.Months");
	const visible = useCalendarStateField(store, "visible");
	const months = useMemo(() => visible === null ? [] : Array.from({ length: visible.count }, (_, index) => visible.start.add({ months: index })), [visible]);
	const renderMonth = children ?? ((month) => /* @__PURE__ */ jsx(DefaultMonth, {
		month,
		single: months.length === 1
	}, month.toString()));
	return useRender({
		defaultTagName: "div",
		render,
		props: {
			"data-slot": "calendar-months",
			...mergeProps({
				className: cn(styles.months(), className),
				children: visible === null ? Array.from({ length: settings.visibleMonths }, (_, index) => /* @__PURE__ */ jsx(PlaceholderMonth, { single: settings.visibleMonths === 1 }, index)) : months.map((month, index) => renderMonth(month, index))
			}, props)
		}
	});
}
/** One visible month: its heading and day grid. */
function CalendarMonth({ value, className, render, children, ...props }) {
	const headingId = useId();
	const context = useMemo(() => ({
		month: value,
		headingId
	}), [value, headingId]);
	const element = useRender({
		defaultTagName: "div",
		render,
		props: {
			"data-slot": "calendar-month",
			...mergeProps({
				className: cn(styles.month(), className),
				children
			}, props)
		}
	});
	return /* @__PURE__ */ jsx(CalendarMonthContext, {
		value: context,
		children: element
	});
}
/**
* The month's name, such as "October 2026", which names its grid. A one-month calendar shows the
* same words in `VisibleRangeHeading`, so hide this one visually there with `className="sr-only"`
* rather than leaving it out. The name sits in a span whose id the `Month` owns and the grid
* points at, so an `id` on the heading, passed directly or on its `render` element, stays the
* heading's own and the grid keeps its name. Children replace the name inside that span.
*/
function CalendarMonthHeading({ className, render, children, ...props }) {
	const { settings } = useCalendarRootContext("Calendar.MonthHeading");
	const { month, headingId } = useCalendarMonthContext("Calendar.MonthHeading");
	return useRender({
		defaultTagName: "div",
		render,
		props: {
			"data-slot": "calendar-month-heading",
			...mergeProps({
				className: cn(styles.monthHeading(), className),
				children: /* @__PURE__ */ jsx("span", {
					id: headingId,
					children: children ?? formatMonth(settings.locale, month)
				})
			}, props)
		}
	});
}
/**
* One month's days, a `grid`. Its name is the calendar's own name and the month, "Delivery,
* October 2026" for a Root named "Delivery", as React Aria names its grids; a Root named by
* `aria-labelledby` names the grid by that element and the `MonthHeading`.
*/
function CalendarDayGrid({ className, render, ...props }) {
	const { settings, actions, selection } = useCalendarRootContext("Calendar.DayGrid");
	const { month, headingId } = useCalendarMonthContext("Calendar.DayGrid");
	const own = { onBlur(event) {
		actions.blurTo(event.target, event.relatedTarget);
	} };
	if (settings.ariaLabel === void 0) own["aria-labelledby"] = [settings.ariaLabelledBy, headingId].filter(Boolean).join(" ");
	else own["aria-label"] = `${settings.ariaLabel}, ${formatMonth(settings.locale, month)}`;
	if (settings.disabled) own["aria-disabled"] = true;
	if (settings.readOnly) own["aria-readonly"] = true;
	if (selection.multiselectable) own["aria-multiselectable"] = true;
	return useRender({
		defaultTagName: "table",
		render,
		props: {
			"data-slot": "calendar-day-grid",
			...mergeProps({
				role: "grid",
				...own,
				className: cn(styles.dayGrid(), className)
			}, props)
		}
	});
}
/**
* The weekday names above the days. Hidden from assistive technology, since every day's name
* already says its weekday.
*/
function CalendarDayGridHeader({ className, render, children, ...props }) {
	return useRender({
		defaultTagName: "thead",
		render,
		props: {
			"data-slot": "calendar-day-grid-header",
			...mergeProps({
				"aria-hidden": true,
				className: cn(styles.dayGridHeader(), className),
				children: children ?? /* @__PURE__ */ jsx(CalendarDayGridHeaderRow, {})
			}, props)
		}
	});
}
/** The weekday names in the locale's week order, from `firstDayOfWeek`. */
function CalendarDayGridHeaderRow({ className, render, children, ...props }) {
	const { settings } = useCalendarRootContext("Calendar.DayGridHeaderRow");
	const { month } = useCalendarMonthContext("Calendar.DayGridHeaderRow");
	const days = useMemo(() => monthWeeks(month, settings.firstDay)[0] ?? [], [month, settings.firstDay]);
	const renderDay = children ?? ((day) => /* @__PURE__ */ jsx(CalendarDayGridHeaderCell, { value: day }, day.dayOfWeek));
	return useRender({
		defaultTagName: "tr",
		render,
		props: {
			"data-slot": "calendar-day-grid-header-row",
			...mergeProps({
				className: cn(styles.dayGridHeaderRow(), className),
				children: days.map((day, index) => renderDay(day, index))
			}, props)
		}
	});
}
/**
* A weekday's column label: the locale's short name where it fits a column ("Mon"), its narrow
* form otherwise. Children replace the label.
*/
function CalendarDayGridHeaderCell({ value, className, render, children, ...props }) {
	const { settings } = useCalendarRootContext("Calendar.DayGridHeaderCell");
	return useRender({
		defaultTagName: "th",
		render,
		props: {
			"data-slot": "calendar-day-grid-header-cell",
			...mergeProps({
				scope: "col",
				abbr: formatWeekdayName(settings.locale, value),
				className: cn(styles.dayGridHeaderCell(), className),
				children: children ?? formatWeekday(settings.locale, value)
			}, props)
		}
	});
}
/** The month's weeks, four to six of them, each starting on `firstDayOfWeek`. */
function CalendarDayGridBody({ className, render, children, ...props }) {
	const { settings } = useCalendarRootContext("Calendar.DayGridBody");
	const { month } = useCalendarMonthContext("Calendar.DayGridBody");
	const weeks = useMemo(() => monthWeeks(month, settings.firstDay).flatMap((week) => week.slice(0, 1)), [month, settings.firstDay]);
	const renderWeek = children ?? ((week) => /* @__PURE__ */ jsx(CalendarDayGridRow, { value: week }, week.toString()));
	return useRender({
		defaultTagName: "tbody",
		render,
		props: {
			"data-slot": "calendar-day-grid-body",
			...mergeProps({
				className: cn(styles.dayGridBody(), className),
				children: weeks.map((week, index) => renderWeek(week, index))
			}, props)
		}
	});
}
/** One week's seven days. */
function CalendarDayGridRow({ value, className, render, children, ...props }) {
	const days = useMemo(() => Array.from({ length: 7 }, (_, index) => value.add({ days: index })), [value]);
	const renderDay = children ?? ((day) => /* @__PURE__ */ jsx(CalendarDayGridCell, {
		value: day,
		children: /* @__PURE__ */ jsx(CalendarDayButton, {})
	}, day.toString()));
	return useRender({
		defaultTagName: "tr",
		render,
		props: {
			"data-slot": "calendar-day-grid-row",
			...mergeProps({
				className: cn(styles.dayGridRow(), className),
				children: days.map((day, index) => renderDay(day, index))
			}, props)
		}
	});
}
/**
* One day's `gridcell`. It carries `aria-selected` when the selection owner's flags for the day hold
* `selected`, and `aria-disabled` for a day the user cannot select. Each flag that holds is also a
* bare attribute, so a range's band can be painted across cells: `data-selected`,
* `data-selection-start`, `data-selection-end`, `data-in-range`, `data-highlighted` and
* `data-invalid`. A disabled day holds no flags. It works out the day's standing and flags once and
* shares them with its `DayButton`.
*/
function CalendarDayGridCell({ value, className, render, children, ...props }) {
	const { settings, selection } = useCalendarRootContext("Calendar.DayGridCell");
	const { month } = useCalendarMonthContext("Calendar.DayGridCell");
	const iso = value.toString();
	const outsideMonth = value.month !== month.month || value.year !== month.year;
	const { disabled, unavailable } = dayStatus(value, outsideMonth, settings);
	const ownerFlags = selection.useDayFlags(value, iso);
	const flags = useMemo(() => dayFlagState(disabled ? NO_DAY_FLAGS : ownerFlags), [disabled, ownerFlags]);
	const context = useMemo(() => ({
		date: value,
		iso,
		outsideMonth,
		disabled,
		unavailable,
		flags
	}), [
		value,
		iso,
		outsideMonth,
		disabled,
		unavailable,
		flags
	]);
	const own = {
		role: "gridcell",
		children
	};
	if (flags.selected) own["aria-selected"] = true;
	if (disabled || unavailable) own["aria-disabled"] = true;
	const element = useRender({
		defaultTagName: "td",
		render,
		state: flags,
		stateAttributesMapping: DAY_FLAG_STATE_ATTRIBUTES,
		props: {
			"data-slot": "calendar-day-grid-cell",
			...mergeProps({
				...own,
				className: cn(styles.dayGridCell(), className)
			}, props)
		}
	});
	return /* @__PURE__ */ jsx(CalendarDayContext, {
		value: context,
		children: element
	});
}
const DAY_STATE_ATTRIBUTES = {
	...DAY_FLAG_STATE_ATTRIBUTES,
	outsideMonth: (value) => value ? { "data-outside-month": "" } : null
};
/**
* One day's button. Its name is the full date as React Aria writes it, "Monday, October 12, 2026",
* with "Today, " before it on today, " selected" after it on the selected day, and ", First
* available date" or ", Last available date" on the bounds. Children replace the day number.
*
* Keyboard: Arrow Left and Right step a day in the writing direction, Arrow Up and Down a week,
* Home and End go to the month's first and last day, Page Up and Page Down a month, with Shift a
* year. Focus stays inside the bounds and moves between visible months without paging; past them
* the view pages. Enter and Space select, once however long they are held. Any other modifier, and
* Shift with any other key, is left to the browser.
*
* Only a day the user may select is selected: one that is not disabled, not unavailable, in a
* calendar that is not read-only.
*/
function CalendarDayButton({ className, render, children, ...props }) {
	const { store, settings, actions, selection } = useCalendarRootContext("Calendar.DayButton");
	const { date, iso, outsideMonth, disabled, unavailable, flags } = useCalendarDayContext("Calendar.DayButton");
	const strings = useLocalizedStrings(calendarStrings);
	const tabbable = useCalendarSelector(store, (state) => !outsideMonth && state.focused?.toString() === iso);
	const requested = useCalendarSelector(store, (state) => !outsideMonth && state.focusRequest && state.focused?.toString() === iso);
	const current = useCalendarSelector(store, (state) => state.today?.toString() === iso);
	const { selected, invalid } = flags;
	const prefix = selection.useDayNamePrefix(date, iso);
	const selectable = !disabled && !unavailable && !settings.readOnly;
	const ref = useRef(null);
	useLayoutEffect(() => {
		if (requested && !disabled) ref.current?.focus();
	}, [requested, disabled]);
	const { locale, bounds } = settings;
	let name = formatDayName(locale, date);
	if (prefix !== "" && !disabled) name = `${prefix}, ${name}`;
	if (current) name = strings.format(selected ? "todayDateSelected" : "todayDate", { date: name });
	else if (selected) name = strings.format("dateSelected", { date: name });
	if (bounds.min?.equals(date) === true) name = `${name}, ${strings.format("minimumDate")}`;
	else if (bounds.max?.equals(date) === true) name = `${name}, ${strings.format("maximumDate")}`;
	const state = useMemo(() => ({
		...flags,
		disabled,
		unavailable,
		current,
		outsideMonth
	}), [
		flags,
		disabled,
		unavailable,
		current,
		outsideMonth
	]);
	const own = {
		type: "button",
		"aria-label": name,
		disabled,
		tabIndex: tabbable && !disabled ? 0 : -1,
		children: children ?? formatDayNumber(locale, date),
		onFocus() {
			actions.focusDay(date);
		},
		onPointerEnter(event) {
			if (!disabled) selection.hover(date, event.nativeEvent);
		},
		onClick(event) {
			if (selectable) selection.select(date, "day-press", event.nativeEvent, event.currentTarget);
		},
		onKeyDown(event) {
			if (event.altKey || event.ctrlKey || event.metaKey) return;
			if (event.key === "Enter" || event.key === " ") {
				event.preventDefault();
				if (selectable && !event.repeat) selection.select(date, "keyboard", event.nativeEvent, event.currentTarget);
				return;
			}
			const button = event.currentTarget;
			const move = focusMoveForKey(event.key, event.shiftKey, () => {
				return button.ownerDocument.defaultView?.getComputedStyle(button).direction === "rtl" ? "rtl" : "ltr";
			});
			if (move !== void 0) {
				event.preventDefault();
				actions.move(move, event.nativeEvent, event.currentTarget);
			}
		},
		onKeyUp(event) {
			if (event.key === " ") event.preventDefault();
		}
	};
	if (disabled || unavailable) own["aria-disabled"] = true;
	if (invalid) own["aria-invalid"] = true;
	const { dayDescriptionId } = selection;
	if (dayDescriptionId !== void 0 && tabbable && selectable) own["aria-describedby"] = dayDescriptionId;
	return useRender({
		defaultTagName: "button",
		render,
		ref,
		state,
		stateAttributesMapping: DAY_STATE_ATTRIBUTES,
		props: {
			"data-slot": "calendar-day-button",
			...mergeProps({
				...own,
				className: cn(styles.day(), className)
			}, props)
		}
	});
}
export { CalendarDayButton, CalendarDayGrid, CalendarDayGridBody, CalendarDayGridCell, CalendarDayGridHeader, CalendarDayGridHeaderCell, CalendarDayGridHeaderRow, CalendarDayGridRow, CalendarDecrementMonth, CalendarHeader, CalendarIncrementMonth, CalendarMonth, CalendarMonthHeading, CalendarMonths, CalendarVisibleRangeHeading };

//# sourceMappingURL=calendar-parts.js.map