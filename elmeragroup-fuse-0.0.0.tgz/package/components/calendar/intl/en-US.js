// src/components/calendar/intl/en-US.ts
/**
* Default localized copy for the `calendar.*` rows: the month buttons' names and the parts a day
* button's name adds to its date. The rows copy React Aria's `@react-aria/calendar` strings, so a
* screen reader hears the same names on the interim tier and on this one.
*/
const enUS = {
	previous: "Previous",
	next: "Next",
	todayDate: (vars) => `Today, ${String(vars?.date)}`,
	todayDateSelected: (vars) => `Today, ${String(vars?.date)} selected`,
	dateSelected: (vars) => `${String(vars?.date)} selected`,
	minimumDate: "First available date",
	maximumDate: "Last available date"
};
export { enUS };

//# sourceMappingURL=en-US.js.map