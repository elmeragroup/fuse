// src/components/calendar/intl/fi-FI.ts
/**
* Default localized copy for the `calendar.*` rows: the month buttons' names and the parts a day
* button's name adds to its date, copied from React Aria's `@react-aria/calendar` strings.
*/
const fiFI = {
	previous: "Edellinen",
	next: "Seuraava",
	todayDate: (vars) => `Tänään, ${String(vars?.date)}`,
	todayDateSelected: (vars) => `Tänään, ${String(vars?.date)} valittu`,
	dateSelected: (vars) => `${String(vars?.date)} valittu`,
	minimumDate: "Ensimmäinen varattavissa oleva päivämäärä",
	maximumDate: "Viimeinen varattavissa oleva päivämäärä"
};
export { fiFI };

//# sourceMappingURL=fi-FI.js.map