// src/components/calendar/calendar-change-details.ts
/**
* Details for a change, with a working `cancel()`.
*
* @template TReason - The gestures that can cause the change.
* @template TExtras - The callback's own fields, such as `getValidationError`.
* @param reason - The gesture.
* @param event - The DOM event.
* @param trigger - The element the gesture happened on.
* @param extras - The callback's own fields.
* @returns The details.
*/
function createChangeEventDetails(reason, event, trigger, extras) {
	let canceled = false;
	return {
		...extras,
		reason,
		event,
		trigger,
		cancel() {
			canceled = true;
		},
		get isCanceled() {
			return canceled;
		}
	};
}
export { createChangeEventDetails };

//# sourceMappingURL=calendar-change-details.js.map