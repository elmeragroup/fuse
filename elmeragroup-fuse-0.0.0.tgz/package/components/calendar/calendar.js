"use client";
import { cn } from "../../styles/cn.js";
import { useLocale } from "../../intl/locale-context.js";
import { createChangeEventDetails } from "./calendar-change-details.js";
import { createCalendarStore, useCalendarSelector } from "./calendar-store.js";
import { CalendarRootContext, NO_DAY_FLAGS, createSelectionOwner, dayFlags } from "./calendar-context.js";
import { dayValidationError } from "./calendar-dates.js";
import { useCalendarBounds, useCalendarSettings, useDayProp, useVisibleMonthCount } from "./calendar-input.js";
import { calendarVariants } from "./calendar-variants.js";
import { initialSharedState, useCalendarNavigation } from "./use-calendar-navigation.js";
import { useLayoutEffect, useMemo, useRef, useState } from "react";
import { jsx } from "react/jsx-runtime";
import { mergeProps } from "@base-ui/react/merge-props";
import { useRender } from "@base-ui/react/use-render";
// src/components/calendar/calendar.tsx
const styles = calendarVariants();
const SELECTED = dayFlags(["selected"]);
const SELECTED_INVALID = dayFlags(["selected", "invalid"]);
/**
* A calendar that selects one day: the months, their day grids and the buttons that page them.
* It is a `group` named by `aria-label` or `aria-labelledby`, and each grid's name starts with
* that name. Values are `Temporal.PlainDate`s; it reads `globalThis.Temporal`, so a host without
* native Temporal imports `@elmeragroup/fuse/temporal-polyfill` once.
*
* Today is marked from the first client effect on and moves at midnight; a server render marks
* no today. A calendar with neither `value` nor `defaultValue` opens on today's month, which only
* that effect reads: the server and the hydrating render write each visible month's frame with six
* weeks of empty days in its place (`Calendar.Months`), so it hydrates without a mismatch, and the
* grid never grows when today's months arrive, only shrinks for a month of fewer weeks.
*
* @throws TypeError naming the prop and the fix when `value`, `defaultValue`, `minValue` or
*   `maxValue` is a string rather than a Temporal object, a host defect.
*/
function CalendarRoot({ value: valueProp, defaultValue, onValueChange, visibleMonths: visibleMonthsProp = 1, pageBehavior = "visible", minValue, maxValue, isDateUnavailable, disabled = false, readOnly = false, firstDayOfWeek: firstDayProp, onVisibleRangeChange, className, render, ref: refProp, ...props }) {
	const { locale, timeZone } = useLocale();
	const controlled = valueProp !== void 0;
	const value = useDayProp(valueProp, "Calendar.Root", "value");
	const defaultDay = useDayProp(defaultValue, "Calendar.Root", "defaultValue");
	const bounds = useCalendarBounds(minValue, maxValue, "Calendar.Root");
	const visibleMonths = useVisibleMonthCount(visibleMonthsProp, "Calendar.Root");
	const settings = useCalendarSettings({
		locale,
		bounds,
		isDateUnavailable,
		disabled,
		readOnly,
		firstDayOfWeek: firstDayProp,
		visibleMonths,
		pageBehavior,
		ariaLabel: props["aria-label"],
		ariaLabelledBy: props["aria-labelledby"]
	});
	const [store] = useState(() => {
		const initial = controlled ? value : defaultDay;
		return createCalendarStore({
			...initialSharedState(initial, settings),
			value: initial
		});
	});
	useLayoutEffect(() => {
		const state = store.get();
		if (controlled && !(state.value === value || state.value !== null && value?.equals(state.value) === true)) store.set({
			...state,
			value
		});
	}, [
		store,
		controlled,
		value
	]);
	const latest = useRef({
		settings,
		onValueChange,
		controlled
	});
	useLayoutEffect(() => {
		latest.current = {
			settings,
			onValueChange,
			controlled
		};
	});
	const rootRef = useRef(null);
	const { actions } = useCalendarNavigation(store, settings, timeZone, onVisibleRangeChange, rootRef);
	const selection = useMemo(() => createSelectionOwner(store, {
		dayFlags(state, date) {
			if (state.value === null || !state.value.equals(date)) return NO_DAY_FLAGS;
			return dayValidationError(state.value, settings) === null ? SELECTED : SELECTED_INVALID;
		},
		select(date, reason, event, trigger) {
			const { onValueChange: report, controlled: isControlled } = latest.current;
			const details = createChangeEventDetails(reason, event, trigger, { getValidationError: () => dayValidationError(date, latest.current.settings) });
			report?.(date, details);
			if (details.isCanceled) return;
			const state = store.get();
			store.set({
				...state,
				value: isControlled ? state.value : date,
				focused: date
			});
		},
		hover: () => void 0,
		dayNamePrefix: () => "",
		dayDescriptionId: void 0,
		multiselectable: false
	}), [store, settings]);
	const invalid = useCalendarSelector(store, (state) => state.value !== null && dayValidationError(state.value, settings) !== null);
	const context = useMemo(() => ({
		store,
		settings,
		actions,
		selection
	}), [
		store,
		settings,
		actions,
		selection
	]);
	const state = useMemo(() => ({
		disabled,
		readonly: readOnly,
		invalid
	}), [
		disabled,
		readOnly,
		invalid
	]);
	const element = useRender({
		defaultTagName: "div",
		render,
		ref: refProp === void 0 ? rootRef : [rootRef, refProp],
		state,
		props: {
			"data-slot": "calendar",
			...mergeProps({
				role: "group",
				className: cn(styles.root(), className)
			}, props)
		}
	});
	return /* @__PURE__ */ jsx(CalendarRootContext, {
		value: context,
		children: element
	});
}
export { CalendarRoot };

//# sourceMappingURL=calendar.js.map