import { cn } from "../../styles/cn.js";
import { tv } from "../../styles/tv.js";
import { selfFocusRingClass } from "../../styles/utils.js";
import { calendarShellClass } from "../../styles/inner-corner/calendar.js";
// src/components/calendar/calendar-variants.ts
/**
* The calendar parts' slotted recipe, shared by Calendar and RangeCalendar. Module-private: no
* entry re-exports it. Every slot is invariant; a day's state reaches its button as data
* attributes, which the `day` and `dayGridCell` slots style, so a day re-renders only when its own
* state changes and never resolves the recipe per render. Every day attribute, the selection
* flags (`data-selected`, `data-invalid`, and in a range `data-in-range`, `data-selection-start`,
* `data-selection-end`, `data-highlighted`) included, is present and empty, which its variant
* matches: Fuse's presence-not-"false" `data-selected` and `data-disabled`, plain Tailwind
* presence for the rest.
*/
const calendarVariants = tv({ slots: {
	root: cn("text-sm shadow-md w-fit border border-border bg-card bg-clip-padding text-card-foreground", calendarShellClass),
	header: "flex w-full items-center gap-1 px-1 pb-4",
	nav: "shrink-0",
	visibleRangeHeading: "text-lg font-medium mx-2 flex-1 text-center",
	months: "flex flex-wrap justify-center gap-6",
	month: "flex flex-col gap-2",
	monthHeading: "text-sm font-medium text-center",
	dayGrid: "border-collapse",
	dayGridHeader: "",
	dayGridHeaderRow: "",
	dayGridHeaderCell: "text-sm font-medium size-9 p-0 text-muted-foreground",
	dayGridBody: "",
	dayGridRow: "",
	dayGridCell: cn("p-0", "data-in-range:bg-primary/20 data-in-range:data-invalid:bg-error/10", "forced-colors:data-in-range:bg-[Highlight] forced-colors:data-in-range:data-invalid:bg-[Mark]", "data-selection-end:rounded-e-full data-selection-start:rounded-s-full", "data-in-range:first:rounded-s-full data-in-range:last:rounded-e-full"),
	day: cn("text-sm flex size-9 cursor-default items-center justify-center rounded-full text-foreground forced-color-adjust-none", selfFocusRingClass, "enabled-hover:not-aria-disabled:not-data-selected:bg-muted", "data-outside-month:invisible", "data-current:font-semibold", "data-selected:not-data-in-range:bg-primary data-selected:not-data-in-range:text-primary-foreground", "data-selection-start:bg-primary data-selection-start:text-primary-foreground", "data-selection-end:bg-primary data-selection-end:text-primary-foreground", "data-in-range:not-data-selection-start:not-data-selection-end:enabled-hover:bg-primary/30", "data-selected:data-invalid:not-data-in-range:bg-error data-selected:data-invalid:not-data-in-range:text-error-foreground", "data-selection-start:data-invalid:bg-error data-selection-start:data-invalid:text-error-foreground", "data-selection-end:data-invalid:bg-error data-selection-end:data-invalid:text-error-foreground", "forced-colors:data-selected:bg-[Highlight] forced-colors:data-selected:text-[HighlightText]", "forced-colors:data-selected:not-data-in-range:bg-[Highlight] forced-colors:data-selected:not-data-in-range:text-[HighlightText]", "forced-colors:data-selection-start:bg-[Highlight] forced-colors:data-selection-start:text-[HighlightText]", "forced-colors:data-selection-end:bg-[Highlight] forced-colors:data-selection-end:text-[HighlightText]", "data-unavailable:text-muted-foreground data-unavailable:line-through", "data-disabled:text-muted-foreground forced-colors:data-disabled:text-[GrayText]")
} });
export { calendarVariants };

//# sourceMappingURL=calendar-variants.js.map