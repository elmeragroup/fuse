import { isThemeDevelopment } from "../../theme/validate-theme.js";
import { parseTemporal, valueKind } from "../../temporal/temporal-value.js";
import { boundDay, visibleMonthCount } from "./calendar-dates.js";
import { firstDayOfWeek } from "../../temporal/week-info.js";
import { useEffect, useMemo } from "react";
// src/components/calendar/calendar-input.ts
const ISO_WEEKDAY = {
	mon: 1,
	tue: 2,
	wed: 3,
	thu: 4,
	fri: 5,
	sat: 6,
	sun: 7
};
/**
* The error for text that reached a date prop past its types: from plain JavaScript, or from a
* server component, whose Temporal props React serializes to their ISO text. It names the kind
* the text prints, when one does, so the fix can be copied.
*/
function textPropError(owner, prop, text) {
	const parsed = parseTemporal(text);
	const example = parsed._tag === "ok" ? `, such as Temporal.${valueKind(parsed.value).kind}.from("${text}")` : ": a Temporal.PlainDate, PlainDateTime or ZonedDateTime";
	return /* @__PURE__ */ new TypeError(`${owner} ${prop}: received the string "${text}", but date props take a Temporal object${example}. A Temporal value passed from a server component arrives as its ISO text, so build the value in a client component.`);
}
/**
* The text a date prop prints, the key its parse is memoized by, so a parent passing a new object
* for the same value re-renders nothing below. It is the one guard against text: it refuses a
* string here, during render and before any memo, so a string throws whatever rendered before it,
* the equal Temporal value included, and whether or not the prop is controlled.
*
* @param input - The prop.
* @param owner - The Root, named in the error.
* @param prop - The prop, named in the error.
* @returns Its text, or the prop itself when absent.
* @throws TypeError naming the Root, the prop and the fix when the input is a string, a host defect.
*/
function printedProp(input, owner, prop) {
	const received = input;
	if (typeof received === "string") throw textPropError(owner, prop, received);
	return input == null ? input : String(input);
}
/**
* The text a date prop printed, read as this runtime's Temporal value of the same kind, so a value
* from another implementation is accepted. `printedProp` has refused a string before this runs.
*
* @param text - The prop's text, from `printedProp`.
* @param owner - The Root, named in the error.
* @param prop - The prop, named in the error.
* @returns The value.
* @throws TypeError naming the Root, the prop and the text when no kind reads it: a host defect.
*/
function parseTemporalProp(text, owner, prop) {
	const parsed = parseTemporal(text);
	if (parsed._tag === "err") throw new TypeError(`${owner} ${prop}: ${parsed.error.message}`);
	return parsed.value;
}
/**
* A Temporal prop parsed once per printed value, so a parent passing a new object for the same
* value re-renders nothing below.
*
* @param input - The prop.
* @param owner - The Root, named in the error.
* @param prop - The prop, named in the error.
* @returns The value, or `null` without one.
* @throws TypeError as `printedProp` and `parseTemporalProp` do.
*/
function useTemporalProp(input, owner, prop) {
	const key = printedProp(input, owner, prop);
	return useMemo(() => key == null ? null : parseTemporalProp(key, owner, prop), [
		key,
		owner,
		prop
	]);
}
/**
* The day a calendar date prop names, parsed once per printed value: a date-time or zoned value
* names its own wall-clock day.
*
* @param input - The prop.
* @param owner - The Root, named in the error.
* @param prop - The prop, named in the error.
* @returns The day, or `null` without one.
* @throws TypeError as `useTemporalProp` does.
*/
function useDayProp(input, owner, prop) {
	const value = useTemporalProp(input, owner, prop);
	return useMemo(() => value === null ? null : boundDay(value), [value]);
}
/**
* A range prop's ends, parsed once per printed value: one object while they hold, so a parent
* passing new objects for the same range changes nothing.
*
* @param input - The prop.
* @param owner - The Root, named in the error.
* @param prop - The prop, named in the error with the end.
* @returns The ends, or `null` without a range.
* @throws TypeError as `useTemporalProp` does, naming the end.
*/
function useRangeProp(input, owner, prop) {
	const start = useTemporalProp(input?.start, owner, `${prop}.start`);
	const end = useTemporalProp(input?.end, owner, `${prop}.end`);
	const present = input != null;
	return useMemo(() => present ? {
		start,
		end
	} : null, [
		present,
		start,
		end
	]);
}
/**
* The first and last selectable days from `minValue` and `maxValue`, parsed once per printed value.
*
* @param minValue - The Root's `minValue`.
* @param maxValue - The Root's `maxValue`.
* @param owner - The Root, named in a parse error.
* @returns The bounds.
* @throws TypeError as `useTemporalProp` does.
*/
function useCalendarBounds(minValue, maxValue, owner) {
	const min = useDayProp(minValue, owner, "minValue") ?? void 0;
	const max = useDayProp(maxValue, owner, "maxValue") ?? void 0;
	return useMemo(() => ({
		min,
		max
	}), [min, max]);
}
/**
* The weekday each grid row starts on: the prop's, or the locale's.
*
* @param locale - The locale.
* @param prop - The Root's `firstDayOfWeek`.
* @returns The ISO weekday.
*/
function resolveFirstDay(locale, prop) {
	return prop === void 0 ? firstDayOfWeek(locale) : ISO_WEEKDAY[prop];
}
/**
* The months a Root shows for its `visibleMonths`: whole and at least one, with a development
* warning naming the Root when the prop is not. The warning comes from an effect, once per value,
* rather than on every render the prop stays wrong.
*
* @param requested - The Root's `visibleMonths`.
* @param owner - The Root, named in the warning.
* @returns The months to show.
*/
function useVisibleMonthCount(requested, owner) {
	const count = visibleMonthCount(requested);
	useEffect(() => {
		if (count !== requested && isThemeDevelopment()) console.warn(`${owner}: visibleMonths ${String(requested)} is not a whole number from 1, so it shows ${String(count)}.`);
	}, [
		count,
		requested,
		owner
	]);
	return count;
}
/**
* A Root's settings for the shared parts, keeping its identity while every field keeps its value,
* so the parts re-render only when a setting changes.
*
* @param input - The resolved props, with the bounds and `isDateUnavailable` in force.
* @returns The settings.
*/
function useCalendarSettings(input) {
	const { locale, bounds, isDateUnavailable, disabled, readOnly, firstDayOfWeek: firstDayProp, visibleMonths, pageBehavior, ariaLabel, ariaLabelledBy } = input;
	return useMemo(() => ({
		locale,
		bounds,
		isDateUnavailable,
		disabled,
		readOnly,
		firstDay: resolveFirstDay(locale, firstDayProp),
		visibleMonths,
		pageBehavior,
		ariaLabel,
		ariaLabelledBy
	}), [
		locale,
		bounds,
		isDateUnavailable,
		disabled,
		readOnly,
		firstDayProp,
		visibleMonths,
		pageBehavior,
		ariaLabel,
		ariaLabelledBy
	]);
}
export { parseTemporalProp, printedProp, useCalendarBounds, useCalendarSettings, useDayProp, useRangeProp, useTemporalProp, useVisibleMonthCount };

//# sourceMappingURL=calendar-input.js.map