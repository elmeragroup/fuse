import { useSyncExternalStore } from "react";
// src/components/calendar/calendar-store.ts
/**
* A store holding `initial`.
*
* @template S - The state.
* @param initial - The first state.
* @returns The store.
*/
function createCalendarStore(initial) {
	let state = initial;
	const listeners = /* @__PURE__ */ new Set();
	return {
		get: () => state,
		initial,
		subscribe(listener) {
			listeners.add(listener);
			return () => {
				listeners.delete(listener);
			};
		},
		set(next) {
			if (next === state) return;
			state = next;
			for (const listener of listeners) listener();
		}
	};
}
/**
* One field of a store's state by reference, re-rendering the caller only when that field's
* reference changes. Taking a key rather than a selector means the snapshot is always a stored
* reference: a selector that built a new object would never settle, re-rendering until React
* throws. For a field the store keeps by reference across unrelated changes, such as `visible`,
* which every write either carries over or replaces when the months change. The server and
* hydration read the initial state, as `useCalendarSelector` does.
*
* @template S - The state.
* @template K - The field's key.
* @param store - The store.
* @param key - The field to read.
* @returns The field of the current state.
*/
function useCalendarStateField(store, key) {
	return useSyncExternalStore(store.subscribe, () => store.get()[key], () => store.initial[key]);
}
/**
* One answer about a store's state, re-rendering the caller only when the answer changes. The
* server and hydration answer from the initial state, so a late-hydrating part matches the server
* HTML; React then renders it again with the live answer.
*
* @template S - The state.
* @template R - The answer, a primitive so equal answers compare equal.
* @param store - The store.
* @param select - Reads the answer from a state. It may close over render values.
* @returns The answer for the current state.
*/
function useCalendarSelector(store, select) {
	return useSyncExternalStore(store.subscribe, () => select(store.get()), () => select(store.initial));
}
export { createCalendarStore, useCalendarSelector, useCalendarStateField };

//# sourceMappingURL=calendar-store.js.map