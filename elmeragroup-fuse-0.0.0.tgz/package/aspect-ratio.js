export { AspectRatio } from "./components/aspect-ratio/aspect-ratio.js";
