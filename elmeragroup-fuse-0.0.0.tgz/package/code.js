export { Code } from "./components/code/code.js";
