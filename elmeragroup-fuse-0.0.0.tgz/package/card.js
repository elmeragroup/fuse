import { cardVariants } from "./components/card/card-variants.js";
import { Card } from "./components/card/card.js";
export { Card, cardVariants };
