export { FileTrigger } from "./components/file-trigger/file-trigger.js";
