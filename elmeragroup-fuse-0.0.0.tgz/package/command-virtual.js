export { CommandVirtual } from "./components/command-virtual/index.js";
