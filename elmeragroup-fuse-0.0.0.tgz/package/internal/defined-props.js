// src/internal/defined-props.ts
/**
* Drops the keys whose value is `undefined`, so spreading the result cannot override a
* default the receiving component wires itself.
*
* Base UI's `mergeProps` assigns every present non-handler key, so a wrapper that forwards
* an optional prop as `aria-labelledby={props["aria-labelledby"]}` would otherwise replace
* the automatic label, description or role with `undefined`. Spread the result of this
* helper wherever consumer props land on a part that owns such wiring.
*
* @template T - The props object to filter.
* @param props - Props that may carry present-but-undefined keys.
* @returns A copy of `props` without the `undefined` keys.
*/
function definedProps(props) {
	return Object.fromEntries(Object.entries(props).filter((entry) => entry[1] !== void 0));
}
export { definedProps };

//# sourceMappingURL=defined-props.js.map