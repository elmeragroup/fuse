import { isFocusRoot } from "./dom-node.js";
// src/internal/active-element.ts
/**
* The element that has focus, read from `root` and down through every open shadow root on the
* way. A document or shadow root reports only the host for focus inside a shadow root below it,
* so a plain `activeElement` read names the host, never the focused control.
*
* @param root - The document or shadow root to read from.
* @returns The focused element, or null when nothing in `root` has focus.
*/
function deepActiveElement(root) {
	let active = root.activeElement;
	while (active?.shadowRoot?.activeElement) active = active.shadowRoot.activeElement;
	return active;
}
/**
* Whether `node` itself has focus. Read from the node's own root, so it holds inside a closed
* shadow root, which a read from the document cannot enter, and in a same-origin iframe.
*
* @param node - The element to check.
* @returns `true` when `node` is the focused element.
*/
function hasFocus(node) {
	const root = node.getRootNode();
	return isFocusRoot(root) && deepActiveElement(root) === node;
}
/**
* The focused element as seen from `node`. Read from the node's own root first, since a read from
* the document cannot enter a closed shadow root and names only its host. When that root holds no
* focus, the document's deep read finds focus outside it.
*
* @param node - The element to read from.
* @returns The focused element, or null when nothing has focus.
*/
function activeElementFrom(node) {
	const root = node.getRootNode();
	return (isFocusRoot(root) ? deepActiveElement(root) : null) ?? deepActiveElement(node.ownerDocument);
}
export { activeElementFrom, deepActiveElement, hasFocus };

//# sourceMappingURL=active-element.js.map