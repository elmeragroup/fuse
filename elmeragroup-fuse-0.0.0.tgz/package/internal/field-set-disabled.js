"use client";
import { createContext, use } from "react";
import { useFieldRootContext } from "@base-ui/react/internals/field-root-context";
// src/internal/field-set-disabled.ts
const FieldSetDisabledContext = createContext(false);
/**
* The one owner of a Root's disabled state: its own `disabled`, an enclosing `Field.Root`'s, or
* the nearest enclosing `Field.Set`'s (or one around it).
*
* @param own - The Root's `disabled` prop.
* @returns Whether the Root is disabled.
*/
function useFieldDisabled(own) {
	const fieldDisabled = useFieldRootContext().disabled === true;
	const fieldSetDisabled = use(FieldSetDisabledContext);
	return own || fieldDisabled || fieldSetDisabled;
}
export { FieldSetDisabledContext, useFieldDisabled };

//# sourceMappingURL=field-set-disabled.js.map