import { badgeVariants } from "./components/badge/badge-variants.js";
import { Badge } from "./components/badge/badge.js";
export { Badge, badgeVariants };
