export { Collapsible } from "./components/collapsible/index.js";
