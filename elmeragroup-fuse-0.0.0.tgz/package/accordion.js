import { accordionVariants } from "./components/accordion/accordion-variants.js";
import { Accordion } from "./components/accordion/index.js";
export { Accordion, accordionVariants };
