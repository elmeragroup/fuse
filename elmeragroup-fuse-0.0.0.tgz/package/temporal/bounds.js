import { temporal } from "./temporal.js";
import { hasTime, isZoned } from "./temporal-value.js";
// src/temporal/bounds.ts
/** A plain bound as a wall clock: a PlainDate at its midnight. */
function plainWallClock(bound) {
	return hasTime(bound) ? bound : bound.toPlainDateTime();
}
/** `value` against `bound`: negative before it, zero at it, positive after it. */
function compareWithBound(value, bound) {
	const runtime = temporal();
	if (isZoned(value)) {
		const instant = isZoned(bound) ? bound : plainWallClock(bound).toZonedDateTime(value.timeZoneId, { disambiguation: "compatible" });
		return runtime.ZonedDateTime.compare(value, instant);
	}
	if (hasTime(value)) {
		const wallClock = isZoned(bound) ? bound.toPlainDateTime() : plainWallClock(bound);
		return runtime.PlainDateTime.compare(value, wallClock);
	}
	return runtime.PlainDate.compare(value, hasTime(bound) ? bound.toPlainDate() : bound);
}
/**
* Where a value falls against a minimum and maximum of any kind, by React Aria's rules: see this
* module's header for how each pair of kinds compares.
*
* @param value - The value, of this runtime's Temporal.
* @param bounds - The minimum and maximum, of this runtime's Temporal; each optional.
* @returns `"underflow"` before the minimum, `"overflow"` after the maximum, `"within"` otherwise.
*   The minimum is checked first, so a value outside reversed bounds reads as `"underflow"`.
*/
function checkBounds(value, bounds) {
	if (bounds.min !== void 0 && compareWithBound(value, bounds.min) < 0) return "underflow";
	if (bounds.max !== void 0 && compareWithBound(value, bounds.max) > 0) return "overflow";
	return "within";
}
export { checkBounds };

//# sourceMappingURL=bounds.js.map