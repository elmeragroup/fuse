"use client";
import { isThemeDevelopment } from "./validate-theme.js";
import { THEME_ATTRIBUTE_NAMES } from "./theme-attributes.js";
import { createContext, useInsertionEffect, useRef } from "react";
// src/theme/document-brand.ts
/** True below the ThemeProvider that owns the document's brand attributes. */
const DocumentWriterContext = createContext(false);
function readSnapshot(root) {
	return THEME_ATTRIBUTE_NAMES.map((name) => [name, root.getAttribute(name)]);
}
function differs(found, expected) {
	return found.some(([name, value]) => value !== expected[name]);
}
function disagrees(found, expected) {
	if (found.every(([, value]) => value === null)) return false;
	return differs(found, expected);
}
function mismatchMessage(found, expected) {
	return `ThemeProvider controlled theme does not match document brand attributes. Expected ${THEME_ATTRIBUTE_NAMES.map((name) => `${name}="${expected[name]}"`).join(" ")}, found ${found.map(([name, value]) => `${name}="${value}"`).join(" ")}. Recovering to the validated controlled theme.`;
}
function write(root, attributes) {
	for (const name of THEME_ATTRIBUTE_NAMES) root.setAttribute(name, attributes[name]);
}
/**
* Keeps the document element's brand attributes on a resolved theme. The first commit warns in
* development when server-rendered attributes disagree, then writes them. Every later commit
* restores attributes that differ, so host code that overwrote them is corrected even when
* only color-scheme props changed; a later commit whose document already matches writes nothing.
*
* @param attributes - The validated theme's `data-theme-*` attributes.
*/
function useDocumentBrand(attributes) {
	const diagnosed = useRef(false);
	useInsertionEffect(() => {
		const root = document.documentElement;
		const found = readSnapshot(root);
		if (!diagnosed.current) {
			diagnosed.current = true;
			if (isThemeDevelopment() && disagrees(found, attributes)) console.warn(mismatchMessage(found, attributes));
			write(root, attributes);
		} else if (differs(found, attributes)) write(root, attributes);
	});
}
export { DocumentWriterContext, useDocumentBrand };

//# sourceMappingURL=document-brand.js.map