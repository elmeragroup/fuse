// src/theme/color-scheme-types.ts
/** The color-scheme axis in host-facing order; `"system"` resolves against the media query. */
const COLOR_SCHEMES = [
	"light",
	"dark",
	"system"
];
export { COLOR_SCHEMES };

//# sourceMappingURL=color-scheme-types.js.map