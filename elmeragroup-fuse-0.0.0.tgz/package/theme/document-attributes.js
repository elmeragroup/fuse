import { densityAttributes } from "./density.js";
import { themeAttributes } from "./theme-attributes.js";
// src/theme/document-attributes.ts
/**
* Validates a document's theme and density and returns the attributes to spread on `<html>`.
* It is the one place a document gets both: ThemeProvider and ThemeScope stamp the theme and
* never density, which stays a document axis.
*
* @param input - The document's theme and density.
* @returns The `data-theme-*` attributes followed by `data-density`.
* @throws When the theme has an unknown or missing axis (in development, also a segment its
*   pinned brand does not span), or when the density is unknown.
*/
function documentAttributes({ theme, density }) {
	return {
		...themeAttributes(theme),
		...densityAttributes(density)
	};
}
export { documentAttributes };

//# sourceMappingURL=document-attributes.js.map