import { COLOR_SCHEMES } from "./color-scheme-types.js";
// src/theme/color-scheme.ts
const COLOR_SCHEME_BOOTSTRAP_MANIFEST_KEY = "__ELMERA_COLOR_SCHEME_BOOTSTRAP__";
const COLOR_SCHEME_BOOTSTRAP_SOURCE_DESCRIPTION = "elmera.colorScheme.bootstrapSource";
const COLOR_SCHEME_BOOTSTRAP_SOURCE_KEY = Symbol.for(COLOR_SCHEME_BOOTSTRAP_SOURCE_DESCRIPTION);
const COLOR_SCHEME_BOOTSTRAP_SOURCE_PROVIDER = "provider";
const COLOR_SCHEME_BOOTSTRAP_SOURCE_DUPLICATE = "duplicate";
const DEFAULT_COLOR_SCHEME_STORAGE_KEY = "elmera-color-scheme";
const DEFAULT_COLOR_SCHEME = "system";
const DEFAULT_ENABLE_SYSTEM = true;
function closedColorScheme(value) {
	return COLOR_SCHEMES.find((scheme) => scheme === value);
}
function resolveColorSchemeOptions({ storageKey = DEFAULT_COLOR_SCHEME_STORAGE_KEY, defaultColorScheme = DEFAULT_COLOR_SCHEME, enableSystem = true, forcedColorScheme } = {}) {
	return {
		storageKey,
		defaultColorScheme: closedColorScheme(defaultColorScheme) ?? "system",
		enableSystem,
		forcedColorScheme: closedColorScheme(forcedColorScheme)
	};
}
function colorSchemeManifestsEqual(left, right) {
	return left.storageKey === right.storageKey && left.defaultColorScheme === right.defaultColorScheme && left.enableSystem === right.enableSystem && left.forcedColorScheme === right.forcedColorScheme;
}
function readColorSchemeBootstrapManifest() {
	try {
		return globalThis[COLOR_SCHEME_BOOTSTRAP_MANIFEST_KEY];
	} catch {
		return;
	}
}
function serializeScriptData(value) {
	return JSON.stringify(value).replaceAll("<", "\\u003c").replaceAll("\u2028", "\\u2028").replaceAll("\u2029", "\\u2029");
}
function parseColorScheme(value, fallback) {
	return closedColorScheme(value) ?? fallback;
}
export { COLOR_SCHEME_BOOTSTRAP_MANIFEST_KEY, COLOR_SCHEME_BOOTSTRAP_SOURCE_DESCRIPTION, COLOR_SCHEME_BOOTSTRAP_SOURCE_DUPLICATE, COLOR_SCHEME_BOOTSTRAP_SOURCE_KEY, COLOR_SCHEME_BOOTSTRAP_SOURCE_PROVIDER, DEFAULT_COLOR_SCHEME, DEFAULT_COLOR_SCHEME_STORAGE_KEY, DEFAULT_ENABLE_SYSTEM, colorSchemeManifestsEqual, parseColorScheme, readColorSchemeBootstrapManifest, resolveColorSchemeOptions, serializeScriptData };

//# sourceMappingURL=color-scheme.js.map