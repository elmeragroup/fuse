"use client";
import { resolveColorSchemeOptions } from "./color-scheme.js";
import { InjectedColorSchemeScript } from "./color-scheme-script.js";
import { createBrowserColorSchemePlatform } from "./color-scheme-browser-platform.js";
import { diagnoseColorSchemeBootstrap } from "./color-scheme-diagnostics.js";
import { createColorSchemeRuntime } from "./color-scheme-runtime.js";
import { createContext, useEffect, useInsertionEffect, useRef, useState } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
// src/theme/color-scheme-root.tsx
/**
* The document's color-scheme runtime, provided by the one `ColorSchemeRoot`. Consumers
* subscribe to it themselves: the value never changes after mount, because a changed context
* value reaches Suspense boundaries that have not hydrated yet, and React client-renders a
* boundary it cannot hydrate on the spot, deleting the server's markers for streamed content.
*/
const ColorSchemeContext = createContext(void 0);
/** The runtime's `force`, for `ForceColorScheme`; `undefined` outside a `ColorSchemeRoot`. */
const ColorSchemeForceContext = createContext(void 0);
/** How many `ForceColorScheme` boundaries enclose a subtree. */
const ColorSchemeForceDepthContext = createContext(0);
/**
* Owns the document's color-scheme runtime: it creates it over the browser platform,
* configures it in the insertion phase of every commit, connects it after mount, runs the
* one-time bootstrap diagnostics and renders the injected script. Render it exactly once
* per document, above everything that reads the color scheme.
*
* @param props - The color-scheme options and the subtree.
* @returns The subtree inside the color-scheme contexts.
*/
function ColorSchemeRoot({ children, storageKey, defaultColorScheme, enableSystem, forcedColorScheme, disableTransitionOnChange = false, injectColorSchemeScript = false, nonce, scriptProps }) {
	const manifest = resolveColorSchemeOptions({
		storageKey,
		defaultColorScheme,
		enableSystem,
		forcedColorScheme
	});
	const config = {
		...manifest,
		disableTransitionOnChange,
		nonce
	};
	const [runtime] = useState(() => createColorSchemeRuntime(config, createBrowserColorSchemePlatform()));
	const diagnosed = useRef(false);
	useInsertionEffect(() => {
		runtime.configure(config);
		if (!diagnosed.current) {
			diagnosed.current = true;
			diagnoseColorSchemeBootstrap(manifest, injectColorSchemeScript);
		}
	});
	useEffect(() => runtime.connect(), [runtime]);
	return /* @__PURE__ */ jsx(ColorSchemeContext.Provider, {
		value: runtime,
		children: /* @__PURE__ */ jsxs(ColorSchemeForceContext.Provider, {
			value: runtime.force,
			children: [injectColorSchemeScript ? /* @__PURE__ */ jsx(InjectedColorSchemeScript, {
				...manifest,
				nonce,
				scriptProps
			}) : null, children]
		})
	});
}
export { ColorSchemeContext, ColorSchemeForceContext, ColorSchemeForceDepthContext, ColorSchemeRoot };

//# sourceMappingURL=color-scheme-root.js.map