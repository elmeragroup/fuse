import { disableColorSchemeTransitions } from "./disable-transition.js";
// src/theme/color-scheme-browser-platform.ts
const SCHEME_QUERY = "(prefers-color-scheme: dark)";
function attempt(operation, fallback) {
	try {
		return operation();
	} catch {
		return fallback;
	}
}
function noop() {}
function once(release) {
	let released = false;
	return () => {
		if (released) return;
		released = true;
		attempt(release, void 0);
	};
}
/**
* Creates the port over a browser-shaped host. It is the only owner of `window`, `document`,
* `localStorage` and `matchMedia` for the color-scheme runtime, and it absorbs every platform
* fault: a blocked or full storage area, a missing or throwing `matchMedia`, a legacy
* `MediaQueryList`, and `storage` events from another area. Globals are read at call time,
* so constructing it during a server render is inert.
*
* @param host - The window to adapt; defaults to `globalThis`.
* @returns A total {@link ColorSchemePlatform}.
*/
function createBrowserColorSchemePlatform(host = globalThis) {
	const area = () => host.localStorage;
	return {
		root: {
			read: () => attempt(() => host.document?.documentElement.getAttribute("data-theme") ?? null, null),
			write(value, transition) {
				const restore = transition === void 0 ? void 0 : disableColorSchemeTransitions(host, transition.nonce);
				try {
					attempt(() => host.document?.documentElement.setAttribute("data-theme", value), void 0);
				} finally {
					restore?.();
				}
			}
		},
		storage: {
			read: (key) => attempt(() => area()?.getItem(key) ?? null, null),
			write(key, value) {
				attempt(() => area()?.setItem(key, value), void 0);
			},
			subscribe(key, onChange) {
				const listener = (event) => {
					if (event.key !== null && event.key !== key) return;
					if (!attempt(() => event.storageArea === area(), false)) return;
					onChange(event.newValue);
				};
				return attempt(() => {
					if (host.addEventListener === void 0) return noop;
					host.addEventListener("storage", listener);
					return once(() => host.removeEventListener?.("storage", listener));
				}, noop);
			}
		},
		media: {
			matches: () => attempt(() => host.matchMedia?.(SCHEME_QUERY).matches === true, false),
			subscribe(onChange) {
				return attempt(() => {
					const query = host.matchMedia?.(SCHEME_QUERY);
					if (query === void 0) return noop;
					if (query.addEventListener !== void 0) {
						query.addEventListener("change", onChange);
						return once(() => query.removeEventListener?.("change", onChange));
					}
					if (query.addListener !== void 0) {
						query.addListener(onChange);
						return once(() => query.removeListener?.(onChange));
					}
					return noop;
				}, noop);
			}
		}
	};
}
export { createBrowserColorSchemePlatform };

//# sourceMappingURL=color-scheme-browser-platform.js.map