import { COLOR_SCHEME_BOOTSTRAP_SOURCE_DESCRIPTION, COLOR_SCHEME_BOOTSTRAP_SOURCE_DUPLICATE, COLOR_SCHEME_BOOTSTRAP_SOURCE_PROVIDER, DEFAULT_COLOR_SCHEME, DEFAULT_COLOR_SCHEME_STORAGE_KEY, resolveColorSchemeOptions, serializeScriptData } from "./color-scheme.js";
import { jsx } from "react/jsx-runtime";
// src/theme/color-scheme-script.tsx
function serializeScriptArgument(value) {
	if (value === void 0) return "undefined";
	return serializeScriptData(value);
}
function scriptPassthroughProps(scriptProps) {
	if (scriptProps === void 0) return {
		nonce: void 0,
		passthrough: {}
	};
	const { type: _type, src: _src, children: _children, dangerouslySetInnerHTML: _dangerouslySetInnerHTML, nonce: scriptNonce, ...passthrough } = scriptProps;
	return {
		nonce: scriptNonce,
		passthrough
	};
}
function applyClosedColorSchemeBootstrap(storageKey, defaultColorScheme, enableSystem, forcedColorScheme) {
	try {
		let preference = defaultColorScheme;
		if (preference !== "light" && preference !== "dark" && preference !== "system") preference = "system";
		const force = forcedColorScheme === "light" || forcedColorScheme === "dark" || forcedColorScheme === "system" ? forcedColorScheme : void 0;
		if (force !== void 0) preference = force;
		else try {
			const stored = localStorage.getItem(storageKey);
			if (stored === "light" || stored === "dark" || stored === "system") preference = stored;
		} catch {}
		let resolved = "light";
		if (preference === "light" || preference === "dark") resolved = preference;
		else if (enableSystem) try {
			resolved = window.matchMedia("(prefers-color-scheme: dark)").matches ? "dark" : "light";
		} catch {
			resolved = "light";
		}
		document.documentElement.setAttribute("data-theme", resolved);
		globalThis.__ELMERA_COLOR_SCHEME_BOOTSTRAP__ = {
			storageKey,
			defaultColorScheme,
			enableSystem,
			forcedColorScheme
		};
	} catch {}
}
function colorSchemeScriptSource(options = {}) {
	const { storageKey, defaultColorScheme, enableSystem, forcedColorScheme } = resolveColorSchemeOptions(options);
	return `(${applyClosedColorSchemeBootstrap.toString()})(${serializeScriptArgument(storageKey)},${serializeScriptArgument(defaultColorScheme)},${serializeScriptArgument(enableSystem)},${serializeScriptArgument(forcedColorScheme)})`;
}
function injectedColorSchemeScriptSource(options = {}) {
	const inner = colorSchemeScriptSource(options);
	const sourceKey = JSON.stringify(COLOR_SCHEME_BOOTSTRAP_SOURCE_DESCRIPTION);
	const provider = JSON.stringify(COLOR_SCHEME_BOOTSTRAP_SOURCE_PROVIDER);
	return `(function(){var h=typeof globalThis.__ELMERA_COLOR_SCHEME_BOOTSTRAP__!=="undefined";${inner};var m=globalThis.__ELMERA_COLOR_SCHEME_BOOTSTRAP__;if(m)Object.defineProperty(m,Symbol.for(${sourceKey}),{value:h?${JSON.stringify(COLOR_SCHEME_BOOTSTRAP_SOURCE_DUPLICATE)}:${provider}})})()`;
}
function ColorSchemeScriptMarkup({ nonce, scriptProps, source }) {
	const { nonce: scriptNonce, passthrough } = scriptPassthroughProps(scriptProps);
	return /* @__PURE__ */ jsx("script", {
		...passthrough,
		nonce: nonce ?? scriptNonce,
		dangerouslySetInnerHTML: { __html: source }
	});
}
const ColorSchemeScript = ({ storageKey = DEFAULT_COLOR_SCHEME_STORAGE_KEY, defaultColorScheme = DEFAULT_COLOR_SCHEME, enableSystem = true, forcedColorScheme, nonce, scriptProps }) => /* @__PURE__ */ jsx(ColorSchemeScriptMarkup, {
	nonce,
	scriptProps,
	source: colorSchemeScriptSource({
		storageKey,
		defaultColorScheme,
		enableSystem,
		forcedColorScheme
	})
});
function InjectedColorSchemeScript({ storageKey = DEFAULT_COLOR_SCHEME_STORAGE_KEY, defaultColorScheme = DEFAULT_COLOR_SCHEME, enableSystem = true, forcedColorScheme, nonce, scriptProps }) {
	return /* @__PURE__ */ jsx(ColorSchemeScriptMarkup, {
		nonce,
		scriptProps,
		source: injectedColorSchemeScriptSource({
			storageKey,
			defaultColorScheme,
			enableSystem,
			forcedColorScheme
		})
	});
}
export { ColorSchemeScript, InjectedColorSchemeScript, colorSchemeScriptSource, injectedColorSchemeScriptSource };

//# sourceMappingURL=color-scheme-script.js.map