import { colorSchemeManifestsEqual, parseColorScheme } from "./color-scheme.js";
// src/theme/color-scheme-runtime.ts
function noop() {}
function configsEqual(left, right) {
	return colorSchemeManifestsEqual(left, right) && left.disableTransitionOnChange === right.disableTransitionOnChange && left.nonce === right.nonce;
}
/**
* Creates the runtime. Construction makes no platform call, so it is safe during a server
* render, a StrictMode double render and a discarded state initializer.
*
* @param initialConfig - Stands in until the first `configure`, so an early `force` already
*   writes with the right `forcedColorScheme` and nonce.
* @param platform - The port the runtime reads and writes through.
* @returns The runtime.
*/
function createColorSchemeRuntime(initialConfig, platform) {
	let config = initialConfig;
	let preference = initialConfig.defaultColorScheme;
	let lifecycle = {
		_tag: "unhydrated",
		preferenceSource: "default",
		prefersDark: void 0
	};
	const forces = [];
	const listeners = /* @__PURE__ */ new Set();
	let notifyScheduled = false;
	const setColorScheme = (value) => {
		preference = parseColorScheme(value, config.defaultColorScheme);
		if (lifecycle._tag === "unhydrated") lifecycle = {
			...lifecycle,
			preferenceSource: "explicit"
		};
		platform.storage.write(config.storageKey, preference);
		reconcile();
		publish("event");
	};
	let snapshot = {
		colorScheme: preference,
		resolvedColorScheme: void 0,
		setColorScheme
	};
	const serverSnapshot = snapshot;
	function activeForce() {
		let winner;
		for (const entry of forces) if (winner === void 0 || entry.depth >= winner.depth) winner = entry;
		return winner?.value ?? config.forcedColorScheme;
	}
	function resolve() {
		const source = activeForce() ?? preference;
		if (source === "light" || source === "dark") return source;
		if (!config.enableSystem) return "light";
		return prefersDark() ? "dark" : "light";
	}
	function prefersDark() {
		if (lifecycle._tag === "hydrated") return lifecycle.prefersDark;
		if (lifecycle.prefersDark !== void 0) return lifecycle.prefersDark;
		const matches = platform.media.matches();
		lifecycle = {
			...lifecycle,
			prefersDark: matches
		};
		return matches;
	}
	function reconcile() {
		if (!(lifecycle._tag === "hydrated" || lifecycle.preferenceSource === "explicit" || activeForce() !== void 0)) return;
		const next = resolve();
		if (platform.root.read() === next) return;
		platform.root.write(next, config.disableTransitionOnChange ? { nonce: config.nonce } : void 0);
	}
	function notify() {
		for (const listener of listeners) listener();
	}
	function publish(phase) {
		const resolvedColorScheme = lifecycle._tag === "hydrated" ? resolve() : void 0;
		if (snapshot.colorScheme === preference && snapshot.resolvedColorScheme === resolvedColorScheme) return;
		snapshot = {
			colorScheme: preference,
			resolvedColorScheme,
			setColorScheme
		};
		if (phase === "event") {
			notify();
			return;
		}
		if (notifyScheduled) return;
		notifyScheduled = true;
		queueMicrotask(() => {
			notifyScheduled = false;
			notify();
		});
	}
	function hydratePreference() {
		preference = parseColorScheme(platform.storage.read(config.storageKey), config.defaultColorScheme);
	}
	function subscribeStorage() {
		return platform.storage.subscribe(config.storageKey, (newValue) => {
			preference = parseColorScheme(newValue, config.defaultColorScheme);
			reconcile();
			publish("event");
		});
	}
	function subscribeMedia(hydrated) {
		if (!config.enableSystem) return noop;
		return platform.media.subscribe(() => {
			hydrated.prefersDark = platform.media.matches();
			reconcile();
			publish("event");
		});
	}
	function unsubscribe(hydrated) {
		hydrated.subscriptions?.storage();
		hydrated.subscriptions?.media();
		hydrated.subscriptions = void 0;
	}
	function rehydrate(hydrated, previous, next) {
		if (previous.storageKey !== next.storageKey || previous.defaultColorScheme !== next.defaultColorScheme) hydratePreference();
		if (next.enableSystem && !previous.enableSystem) hydrated.prefersDark = platform.media.matches();
	}
	function resubscribe(hydrated, previous, next) {
		const current = hydrated.subscriptions;
		if (current === void 0) return;
		let { storage, media } = current;
		if (previous.storageKey !== next.storageKey) {
			storage();
			storage = subscribeStorage();
		}
		if (previous.enableSystem !== next.enableSystem) {
			media();
			media = subscribeMedia(hydrated);
		}
		hydrated.subscriptions = {
			storage,
			media
		};
	}
	function applyConfig(next) {
		const previous = config;
		config = next;
		if (lifecycle._tag === "unhydrated") {
			if (lifecycle.preferenceSource === "default") preference = next.defaultColorScheme;
			return;
		}
		rehydrate(lifecycle, previous, next);
		resubscribe(lifecycle, previous, next);
	}
	return {
		subscribe(listener) {
			listeners.add(listener);
			return () => {
				listeners.delete(listener);
			};
		},
		getSnapshot() {
			return snapshot;
		},
		getServerSnapshot() {
			return serverSnapshot;
		},
		configure(next) {
			if (!configsEqual(config, next)) applyConfig(next);
			reconcile();
			publish("commit");
		},
		connect() {
			if (lifecycle._tag === "hydrated") unsubscribe(lifecycle);
			const hydrated = {
				_tag: "hydrated",
				prefersDark: platform.media.matches(),
				subscriptions: void 0
			};
			hydratePreference();
			lifecycle = hydrated;
			hydrated.subscriptions = {
				storage: subscribeStorage(),
				media: subscribeMedia(hydrated)
			};
			reconcile();
			publish("event");
			return () => {
				if (lifecycle === hydrated) unsubscribe(hydrated);
			};
		},
		force(value, depth) {
			const entry = {
				value,
				depth
			};
			forces.push(entry);
			reconcile();
			publish("commit");
			return () => {
				const index = forces.indexOf(entry);
				if (index < 0) return;
				forces.splice(index, 1);
				reconcile();
				publish("commit");
			};
		}
	};
}
export { createColorSchemeRuntime };

//# sourceMappingURL=color-scheme-runtime.js.map