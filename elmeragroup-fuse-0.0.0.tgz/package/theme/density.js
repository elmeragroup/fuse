// src/theme/density.ts
/** The density axis in host-facing order: the `data-density` values a document can carry. */
const DENSITIES = ["dense", "comfortable"];
/**
* Validates a density and returns its `data-density` attribute. A document gets it together
* with its theme through `documentAttributes`; this stamps density alone, such as on a docs
* demo stage that previews the density metrics.
*
* @param density - The density to stamp.
* @returns The `data-density` attribute.
* @throws When `density` is not one of {@link DENSITIES}.
*/
function densityAttributes(density) {
	const value = DENSITIES.find((candidate) => candidate === density);
	if (value === void 0) throw new Error("Invalid density: unknown or missing density.");
	return { "data-density": value };
}
export { DENSITIES, densityAttributes };

//# sourceMappingURL=density.js.map