import { isThemeDevelopment } from "./validate-theme.js";
import { COLOR_SCHEME_BOOTSTRAP_SOURCE_DUPLICATE, COLOR_SCHEME_BOOTSTRAP_SOURCE_KEY, COLOR_SCHEME_BOOTSTRAP_SOURCE_PROVIDER, colorSchemeManifestsEqual, readColorSchemeBootstrapManifest } from "./color-scheme.js";
// src/theme/color-scheme-diagnostics.ts
const COLOR_SCHEME_BOOTSTRAP_MISSING_MESSAGE = "ThemeProvider did not find the color-scheme bootstrap manifest. Place ColorSchemeScript or colorSchemeScriptSource in the host document before paintable content.";
const COLOR_SCHEME_BOOTSTRAP_DUPLICATE_MESSAGE = "ThemeProvider injectColorSchemeScript is enabled, but a color-scheme bootstrap already ran. Disable injection when the host places the script.";
function colorSchemeBootstrapMismatchMessage(expected, found) {
	return `ThemeProvider color-scheme configuration does not match the bootstrap manifest. Expected ${JSON.stringify(expected)}, found ${JSON.stringify(found)}.`;
}
function readColorSchemeBootstrapSource(found) {
	try {
		const descriptor = Object.getOwnPropertyDescriptor(found, COLOR_SCHEME_BOOTSTRAP_SOURCE_KEY);
		if (descriptor?.value === "provider") return COLOR_SCHEME_BOOTSTRAP_SOURCE_PROVIDER;
		if (descriptor?.value === "duplicate") return COLOR_SCHEME_BOOTSTRAP_SOURCE_DUPLICATE;
		return;
	} catch {
		return;
	}
}
function diagnoseColorSchemeBootstrap(expected, injectColorSchemeScript) {
	if (!isThemeDevelopment()) return;
	const found = readColorSchemeBootstrapManifest();
	if (found === void 0) {
		console.warn(COLOR_SCHEME_BOOTSTRAP_MISSING_MESSAGE);
		return;
	}
	if (!colorSchemeManifestsEqual(expected, found)) console.warn(colorSchemeBootstrapMismatchMessage(expected, found));
	if (injectColorSchemeScript && readColorSchemeBootstrapSource(found) !== "provider") console.warn(COLOR_SCHEME_BOOTSTRAP_DUPLICATE_MESSAGE);
}
export { diagnoseColorSchemeBootstrap };

//# sourceMappingURL=color-scheme-diagnostics.js.map