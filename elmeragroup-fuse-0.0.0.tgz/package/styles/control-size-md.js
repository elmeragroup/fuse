import { tv } from "./tv.js";
// src/styles/control-size-md.ts
/**
* The md row of the control size (see `control-size.ts`), resolved once at module scope for
* the controls that have no size axis, such as Tabs triggers and Pagination links. The
* text-entry field boxes size through `field-size.ts` instead, whose `"default"` size reads the
* same md metrics. `controlMetrics` reads its md row from here, so each md literal has one owner.
*
* It sits in its own file, beside `control-size.ts`, because the docs token extraction
* lists every `--control-*` variable a component's reachable sources spell. A consumer
* that imports only this file lists no xs, sm or lg variables. The extraction is
* file-granular, so it still lists every md part here, including ones the consumer does
* not bind. Each slot is one metric family, so a consumer takes the parts it binds and
* keeps its own geometry for the rest.
*
* The type pair is spelled as the typed variable utilities `text-(length:--control-text)`
* and `leading-(--control-leading)`, not as arbitrary font-size and line-height properties.
* tailwind-merge groups the typed forms with `text-*` and `leading-*`, so a consumer's
* `text-sm` or `leading-5` in `className` removes them through `cn`, and only the consumer
* class reaches the element. That removal is the whole mechanism: Tailwind
* 4.3.3 orders these rules by property and emits `.text-(length:--control-text)` after
* `.text-sm`, so a recipe class left beside the consumer's would still win the cascade. An
* arbitrary property never reaches the merge, because tailwind-merge puts it in no
* font-size or line-height group, so `cn` kept both. The `length:` hint is required,
* because a bare variable on the `text` utility could also be a colour.
*/
const controlMd = tv({ slots: {
	height: "h-(--control-h-md)",
	minHeight: "min-h-(--control-h-md)",
	minWidth: "min-w-(--control-h-md)",
	square: "size-(--control-h-md)",
	gap: "gap-(--control-gap-md)",
	inset: "px-(--control-px-md)",
	iconInset: "px-(--control-px-icon-md)",
	iconEdge: "has-data-[icon=inline-end]:pr-(--control-px-icon-md) has-data-[icon=inline-start]:pl-(--control-px-icon-md)",
	type: "text-(length:--control-text) leading-(--control-leading)"
} })();
export { controlMd };

//# sourceMappingURL=control-size-md.js.map