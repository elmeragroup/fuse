import { twMergeConfig } from "./tw-merge-config.js";
import { clsx } from "clsx";
import { extendTailwindMerge } from "tailwind-merge";
// src/styles/cn.ts
const twMerge = extendTailwindMerge(twMergeConfig);
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
export { cn };

//# sourceMappingURL=cn.js.map