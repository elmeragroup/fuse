import { cn } from "./cn.js";
import { tv } from "./tv.js";
import { controlMd } from "./control-size-md.js";
// src/styles/control-size.ts
/**
* The metric parts of each control size, one slot per metric family.
* {@link controlSize} assembles the fits from these parts. `iconInset` is the icon inset on
* both sides, which a segmented ToggleGroup item takes in place of the label inset.
* Sidebar's sub-button reads the parts it binds.
*/
const controlMetrics = tv({
	slots: {
		height: "",
		minWidth: "",
		square: "",
		gap: "",
		inset: "",
		iconInset: "",
		iconEdge: "",
		type: ""
	},
	variants: { size: {
		xs: {
			height: "h-[max(var(--control-h-xs),24px)]",
			minWidth: "min-w-[max(var(--control-h-xs),24px)]",
			square: "size-[max(var(--control-h-xs),24px)]",
			gap: "gap-(--control-gap-xs)",
			inset: "px-(--control-px-xs)",
			iconInset: "px-(--control-px-icon-xs)",
			iconEdge: "has-data-[icon=inline-end]:pr-(--control-px-icon-xs) has-data-[icon=inline-start]:pl-(--control-px-icon-xs)",
			type: "text-xs"
		},
		sm: {
			height: "h-(--control-h-sm)",
			minWidth: "min-w-(--control-h-sm)",
			square: "size-(--control-h-sm)",
			gap: "gap-(--control-gap-sm)",
			inset: "px-(--control-px-sm)",
			iconInset: "px-(--control-px-icon-sm)",
			iconEdge: "has-data-[icon=inline-end]:pr-(--control-px-icon-sm) has-data-[icon=inline-start]:pl-(--control-px-icon-sm)",
			type: "text-sm"
		},
		md: {
			height: controlMd.height(),
			minWidth: controlMd.minWidth(),
			square: controlMd.square(),
			gap: controlMd.gap(),
			inset: controlMd.inset(),
			iconInset: controlMd.iconInset(),
			iconEdge: controlMd.iconEdge(),
			type: controlMd.type()
		},
		lg: {
			height: "h-(--control-h-lg)",
			minWidth: "min-w-(--control-h-lg)",
			square: "size-(--control-h-lg)",
			gap: "gap-(--control-gap-lg)",
			inset: "px-(--control-px-lg)",
			iconInset: "px-(--control-px-icon-lg)",
			iconEdge: "has-data-[icon=inline-end]:pr-(--control-px-icon-lg) has-data-[icon=inline-start]:pl-(--control-px-icon-lg)",
			type: controlMd.type()
		}
	} }
});
/**
* The `label` fit of one control size: height, gap, inset and type, then the icon edge
* unless the options omit it. {@link controlSize} builds its `label` and `min-square`
* fits from this, and a control that composes its own size axis takes it too, so a new
* label part reaches every label box.
*
* @param size - The control size.
* @param options - Whether the label includes the icon edge.
* @returns The label's size classes.
* @example
* controlLabel("sm", { iconEdge: "omit" })
*/
function controlLabel(size, options) {
	const parts = controlMetrics({ size });
	return cn(parts.height(), parts.gap(), parts.inset(), parts.type(), options.iconEdge === "include" && parts.iconEdge());
}
/** The three fits of one size, as compound variants of {@link controlSize}. */
function fitsOf(size) {
	const parts = controlMetrics({ size });
	const label = controlLabel(size, { iconEdge: "include" });
	return [
		{
			size,
			fit: "label",
			class: label
		},
		{
			size,
			fit: "min-square",
			class: cn(label, parts.minWidth())
		},
		{
			size,
			fit: "square",
			class: parts.square()
		}
	];
}
/**
* The size × fit recipe. Every class depends on both axes (a `square` takes the size's
* square and none of its label parts), so each axis value paints nothing alone and each
* cell is a compound variant assembled from the {@link controlMetrics} slots. Pass both
* axes: a call without them paints no size.
*
* @example
* controlSize({ size: "sm", fit: "label" })
*/
const controlSize = tv({
	variants: {
		size: {
			xs: "",
			sm: "",
			md: "",
			lg: ""
		},
		fit: {
			label: "",
			square: "",
			"min-square": ""
		}
	},
	compoundVariants: [
		...fitsOf("xs"),
		...fitsOf("sm"),
		...fitsOf("md"),
		...fitsOf("lg")
	]
});
export { controlLabel, controlMetrics, controlSize };

//# sourceMappingURL=control-size.js.map