import { cn } from "../cn.js";
import { publishShellBoundary } from "../corner-radius.js";
// src/styles/inner-corner/date-field.ts
/**
* A DateField's segment row. It pads the segments with the md control inset, inside the box border,
* whether it paints the box itself or sits in a picker's.
*/
const dateInputShellClass = cn("[--shell-inner:max(0px,var(--field-corner)-1px-var(--control-px-md))]", publishShellBoundary);
export { dateInputShellClass };

//# sourceMappingURL=date-field.js.map