import { cn } from "../cn.js";
import { publishShellBoundary } from "../corner-radius.js";
// src/styles/inner-corner/accordion.ts
/**
* A default Accordion item: `rounded-sm` and the medium surface padding.
*/
const accordionItemShellClass = cn("rounded-sm p-(--surface-pad-md) [--shell-inner:max(0px,--theme(--radius-sm)-var(--surface-pad-md))]", publishShellBoundary);
/**
* A card Accordion item: `rounded-lg` behind a 1px border and the medium surface padding.
*/
const accordionCardItemShellClass = cn("rounded-lg border p-(--surface-pad-md) [--shell-inner:max(0px,--theme(--radius-lg)-1px-var(--surface-pad-md))]", publishShellBoundary);
/**
* An Accordion item with the `lg` radius, unbordered, with the medium surface padding.
*/
const accordionItemLgShellClass = cn("rounded-lg p-(--surface-pad-md) [--shell-inner:max(0px,--theme(--radius-lg)-var(--surface-pad-md))]", publishShellBoundary);
/**
* An Accordion item with the `xl` radius, unbordered, with the medium surface padding.
*/
const accordionItemXlShellClass = cn("rounded-xl p-(--surface-pad-md) [--shell-inner:max(0px,--theme(--radius-xl)-var(--surface-pad-md))]", publishShellBoundary);
/**
* A card Accordion item with the `lg` radius.
*/
const accordionCardItemLgShellClass = cn("rounded-lg border p-(--surface-pad-md) [--shell-inner:max(0px,--theme(--radius-lg)-1px-var(--surface-pad-md))]", publishShellBoundary);
/**
* A card Accordion item with the `xl` radius.
*/
const accordionCardItemXlShellClass = cn("rounded-xl border p-(--surface-pad-md) [--shell-inner:max(0px,--theme(--radius-xl)-1px-var(--surface-pad-md))]", publishShellBoundary);
export { accordionCardItemLgShellClass, accordionCardItemShellClass, accordionCardItemXlShellClass, accordionItemLgShellClass, accordionItemShellClass, accordionItemXlShellClass };

//# sourceMappingURL=accordion.js.map