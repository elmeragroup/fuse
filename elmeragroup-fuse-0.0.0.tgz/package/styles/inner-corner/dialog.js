import { cn } from "../cn.js";
import { publishShellBoundary } from "../corner-radius.js";
// src/styles/inner-corner/dialog.ts
/**
* The Dialog popup, AlertDialog's too: `rounded-xl` and the large surface padding,
* `--surface-pad-lg`.
*/
const dialogShellClass = cn("rounded-xl p-(--surface-pad-lg) [--shell-inner:max(0px,--theme(--radius-xl)-var(--surface-pad-lg))]", publishShellBoundary);
export { dialogShellClass };

//# sourceMappingURL=dialog.js.map