import { cn } from "../cn.js";
import { fieldCornerClass, publishShellBoundary } from "../corner-radius.js";
// src/styles/inner-corner/field.ts
/**
* Every field box: the field corner, published less the 1px border.
*/
const fieldBoxShellClass = cn(fieldCornerClass, "[--shell-inner:max(0px,var(--field-corner)-1px)]", publishShellBoundary);
export { fieldBoxShellClass };

//# sourceMappingURL=field.js.map