import { cn } from "../cn.js";
import { publishShellBoundary } from "../corner-radius.js";
// src/styles/inner-corner/empty.ts
/**
* Empty: `rounded-lg` and the large surface padding, `--surface-pad-lg`, doubled from `md` up.
*/
const emptyShellClass = cn("md:p-[calc(2*var(--surface-pad-lg))] md:[--shell-inner:max(0px,--theme(--radius-lg)-2*var(--surface-pad-lg))] rounded-lg p-(--surface-pad-lg) [--shell-inner:max(0px,--theme(--radius-lg)-var(--surface-pad-lg))]", publishShellBoundary);
/**
* The bordered Empty variants: {@link emptyShellClass} behind a 1px border.
*/
const emptyBorderedShellClass = cn("md:[--shell-inner:max(0px,--theme(--radius-lg)-1px-2*var(--surface-pad-lg))] [--shell-inner:max(0px,--theme(--radius-lg)-1px-var(--surface-pad-lg))]", publishShellBoundary);
export { emptyBorderedShellClass, emptyShellClass };

//# sourceMappingURL=empty.js.map