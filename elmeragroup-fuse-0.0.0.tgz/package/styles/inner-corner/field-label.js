import { cn } from "../cn.js";
// src/styles/inner-corner/field-label.ts
/**
* A Field label that holds a Field: the label rounds `rounded-md` behind a 1px border and the Field
* pads inside it with the medium surface tier, `--surface-pad-md`. Both clear the relay.
*/
const fieldLabelCardShellClass = cn("has-[>[data-slot=field]]:rounded-md has-[>[data-slot=field]]:border has-[>[data-slot=field]]:[--inner-corner:var(--shell-inner)] has-[>[data-slot=field]]:[--shell-corner:initial] has-[>[data-slot=field]]:[--shell-inner:max(0px,--theme(--radius-md)-1px)] *:data-[slot=field]:p-(--surface-pad-md) *:data-[slot=field]:[--inner-corner:var(--shell-inner)] *:data-[slot=field]:[--shell-corner:initial] *:data-[slot=field]:[--shell-inner:max(0px,--theme(--radius-md)-1px-var(--surface-pad-md))]");
export { fieldLabelCardShellClass };

//# sourceMappingURL=field-label.js.map