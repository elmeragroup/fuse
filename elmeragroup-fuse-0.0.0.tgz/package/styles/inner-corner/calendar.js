import { cn } from "../cn.js";
import { fixedCornerClass, publishShellBoundary } from "../corner-radius.js";
// src/styles/inner-corner/calendar.ts
/**
* The standalone Calendar: its fixed corner behind a 1px border, padded with the small surface
* tier, `--surface-pad-sm`, around its control-sized cells.
*/
const calendarShellClass = cn(fixedCornerClass, "p-(--surface-pad-sm) [--shell-inner:max(0px,clamp(var(--radius)-1000*var(--radius-step,0px),4px,var(--radius)+1000*var(--radius-step,0px))-1px-var(--surface-pad-sm))]", publishShellBoundary);
export { calendarShellClass };

//# sourceMappingURL=calendar.js.map