import { cn } from "./cn.js";
// src/styles/corner-radius.ts
/**
* The field box corner: Input, Textarea, the Select trigger, NumberField, InputGroup, the
* Combobox chips box and the React Aria field group. It declares `--field-corner` for the parts
* inside the box and rounds with it. Branded themes round it with `--radius-field`, and
* neutral themes with `--radius`.
*/
const fieldCornerClass = cn("rounded-(--field-corner) [--field-corner:clamp(var(--radius)-1000*var(--radius-step,0px),var(--radius-field,var(--radius)),var(--radius)+1000*var(--radius-step,0px))]");
/**
* The corner of a compact button that sits in a toolbar, the xs Toggle. Branded themes round it with `rounded-md` capped at 10px, and
* neutral themes with `--radius`.
*/
const compactCornerClass = cn("rounded-[min(--theme(--radius-md),max(10px,var(--radius)-1000*var(--radius-step,0px)))]");
/**
* The corner of the Checkbox, `rounded-md` capped at 4px in every identity. At a large
* `--radius` the cap stops the box from rounding into a circle that reads as a Radio.
*/
const checkboxCornerClass = cn("rounded-[min(--theme(--radius-md),4px)]");
/**
* The corner of the standalone Calendar. Branded themes keep the reference's 4px whatever
* the brand radius, and neutral themes round it with `--radius`. The clamp's bounds meet at
* `--radius` at a 0px step and lie 4000px apart at a 2px step, where the preferred 4px
* applies.
*/
const fixedCornerClass = cn("rounded-[clamp(var(--radius)-1000*var(--radius-step,0px),4px,var(--radius)+1000*var(--radius-step,0px))]");
/**
* The public corner a shell publishes: its private post-padding corner, `--shell-inner`. Only
* the parts that carry the `--shell-corner` relay compose it alone; every other shell boundary
* composes {@link publishShellBoundary}. Each composes it beside a `--shell-inner` declaration,
* and only there, so a ThemeScope reset of `--inner-corner` is never undone by an inherited
* `--shell-inner`.
*/
const publishInnerCorner = cn("[--inner-corner:var(--shell-inner)]");
/**
* {@link publishInnerCorner} for an independent shell boundary: it also clears the private
* `--shell-corner` relay, so no relay from an outer shell reaches a part inside it.
*/
const publishShellBoundary = cn("[--shell-corner:initial]", publishInnerCorner);
export { checkboxCornerClass, compactCornerClass, fieldCornerClass, fixedCornerClass, publishInnerCorner, publishShellBoundary };

//# sourceMappingURL=corner-radius.js.map