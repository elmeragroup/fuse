// src/react-aria/date-picker/intl/fi-FI.ts
/** Default localized copy for the `datePicker.presets` row. */
const fiFI = { presets: "Päivämäärän pikavalinnat" };
export { fiFI };

//# sourceMappingURL=fi-FI.js.map