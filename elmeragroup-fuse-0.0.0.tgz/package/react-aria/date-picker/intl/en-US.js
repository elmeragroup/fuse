// src/react-aria/date-picker/intl/en-US.ts
/** Default localized copy for the `datePicker.presets` row. */
const enUS = { presets: "Date presets" };
export { enUS };

//# sourceMappingURL=en-US.js.map