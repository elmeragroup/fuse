"use client";
import { pickerVariants } from "../../styles/picker.js";
import { isRenderableNode } from "../../internal/is-renderable-node.js";
import { composeTailwindRenderProps } from "../internal/compose-tailwind-render-props.js";
import { Calendar as Calendar$1 } from "../calendar/calendar.js";
import { useFormErrors } from "../internal/form-errors.js";
import { DateInput as DateInput$1 } from "../date-field/date-field.js";
import { useCommittedMonthFocus } from "../internal/picker-focused-month.js";
import { PickerPresetGroup, PickerPresetItem } from "../internal/picker-presets.js";
import { PickerShell } from "../internal/picker-shell.js";
import { use } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { CalendarContext, DatePicker as DatePicker$1, DatePickerStateContext, FormValidationContext, useSlottedContext } from "react-aria-components";
// src/react-aria/date-picker/date-picker.tsx
/**
* The popover's calendar, month-synced to the picker's own committed value through the
* RAC `DatePickerStateContext`, where `state.value` is the committed value in both the
* controlled and the uncontrolled mode. The placeholder comes from the `CalendarContext`
* RAC fills, so a `placeholderValue` supplied through `DatePickerContext` counts too.
*/
function PickerCalendar({ className }) {
	const state = use(DatePickerStateContext);
	const calendar = useSlottedContext(CalendarContext);
	const focus = useCommittedMonthFocus(state?.value, calendar?.defaultFocusedValue);
	return /* @__PURE__ */ jsx(Calendar$1, {
		className,
		...focus
	});
}
function DatePicker({ className, container, description, errorMessage, isReadOnly, label, onChange, presetGroup, shouldForceLeadingZeros = true, size = "default", triggerPlacement = "end", ...props }) {
	const { base, calendar, input, pane } = pickerVariants({ hasPresets: isRenderableNode(presetGroup) });
	const { validationErrors, onChange: clearingOnChange } = useFormErrors([props.name], onChange);
	return /* @__PURE__ */ jsx(FormValidationContext.Provider, {
		value: validationErrors,
		children: /* @__PURE__ */ jsx(DatePicker$1, {
			...props,
			onChange: clearingOnChange,
			isReadOnly,
			shouldForceLeadingZeros,
			className: composeTailwindRenderProps(className, base()),
			children: /* @__PURE__ */ jsx(PickerShell, {
				container,
				size,
				description,
				errorMessage,
				isReadOnly,
				label,
				triggerPlacement,
				popover: /* @__PURE__ */ jsxs("div", {
					className: pane(),
					children: [presetGroup, /* @__PURE__ */ jsx(PickerCalendar, { className: calendar() })]
				}),
				children: /* @__PURE__ */ jsx(DateInput$1, { className: input() })
			})
		})
	});
}
/**
* The quick-choice pane beside the calendar: a radio group whose options are dates.
* Only one preset can be in effect at a time, which is why this is a `radiogroup` and
* not a row of buttons.
*
* In the picker popover it publishes `--inner-corner` for its presets, the popover corner less its
* border and padding.
*/
function DatePickerPresetGroup(props) {
	return /* @__PURE__ */ jsx(PickerPresetGroup, {
		"data-slot": "date-picker-preset-group",
		...props
	});
}
/**
* One preset, closing the picker on double-click when the caller opts in. Styled as a
* ghost `sm` button and named by its visible children — the library never synthesises
* copy from the item's `value`.
*/
function DatePickerPresetItem(props) {
	const state = use(DatePickerStateContext);
	return /* @__PURE__ */ jsx(PickerPresetItem, {
		"data-slot": "date-picker-preset-item",
		...props,
		state
	});
}
DatePicker.displayName = "DatePicker";
DatePickerPresetGroup.displayName = "DatePickerPresetGroup";
DatePickerPresetItem.displayName = "DatePickerPresetItem";
export { DatePicker, DatePickerPresetGroup, DatePickerPresetItem };

//# sourceMappingURL=date-picker.js.map