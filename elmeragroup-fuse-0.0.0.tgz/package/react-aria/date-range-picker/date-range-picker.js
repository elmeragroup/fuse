"use client";
import { pickerVariants } from "../../styles/picker.js";
import { isRenderableNode } from "../../internal/is-renderable-node.js";
import { composeTailwindRenderProps } from "../internal/compose-tailwind-render-props.js";
import { useFormErrors } from "../internal/form-errors.js";
import { DateInput as DateInput$1 } from "../date-field/date-field.js";
import { useCommittedMonthFocus } from "../internal/picker-focused-month.js";
import { PickerPresetGroup, PickerPresetItem } from "../internal/picker-presets.js";
import { PickerShell } from "../internal/picker-shell.js";
import { RangeCalendar as RangeCalendar$1 } from "../range-calendar/range-calendar.js";
import { use } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { DateRangePicker, DateRangePickerStateContext, FormValidationContext, RangeCalendarContext, useSlottedContext } from "react-aria-components";
// src/react-aria/date-range-picker/date-range-picker.tsx
/**
* The popover's range calendar, month-synced to the committed range through the RAC
* `DateRangePickerStateContext`. RAC focuses the start only when the grid mounts, so
* without this a preset that commits a range in another month with the dialog open would
* leave the grid on the old month. A range the grid commits itself keeps the month and focus
* the user finished on. The placeholder comes from the `RangeCalendarContext`
* RAC fills, so a `placeholderValue` supplied through `DateRangePickerContext` counts too.
*/
function PickerRangeCalendar({ className, commitBehavior }) {
	const state = use(DateRangePickerStateContext);
	const calendar = useSlottedContext(RangeCalendarContext);
	const focus = useCommittedMonthFocus(state?.value, calendar?.defaultFocusedValue);
	return /* @__PURE__ */ jsx(RangeCalendar$1, {
		className,
		commitBehavior,
		...focus
	});
}
function DateRangePicker$1({ className, container, description, errorMessage, isReadOnly, label, onChange, presetGroup, shouldForceLeadingZeros = true, size = "default", ...props }) {
	const hasPresets = isRenderableNode(presetGroup);
	const { base, calendar, input, pane, separator } = pickerVariants({
		range: true,
		hasPresets
	});
	const { validationErrors, onChange: clearingOnChange } = useFormErrors([props.startName, props.endName], onChange);
	return /* @__PURE__ */ jsx(FormValidationContext.Provider, {
		value: validationErrors,
		children: /* @__PURE__ */ jsx(DateRangePicker, {
			...props,
			onChange: clearingOnChange,
			isReadOnly,
			shouldForceLeadingZeros,
			className: composeTailwindRenderProps(className, base()),
			children: /* @__PURE__ */ jsxs(PickerShell, {
				container,
				size,
				description,
				errorMessage,
				isReadOnly,
				label,
				popover: /* @__PURE__ */ jsxs("div", {
					className: pane(),
					children: [presetGroup, /* @__PURE__ */ jsx(PickerRangeCalendar, {
						className: calendar(),
						commitBehavior: hasPresets ? "reset" : "select"
					})]
				}),
				range: true,
				children: [
					/* @__PURE__ */ jsx(DateInput$1, {
						className: input(),
						slot: "start"
					}),
					/* @__PURE__ */ jsx("span", {
						"aria-hidden": "true",
						className: separator(),
						children: "–"
					}),
					/* @__PURE__ */ jsx(DateInput$1, {
						className: input(),
						slot: "end"
					})
				]
			})
		})
	});
}
/**
* The quick-choice pane beside the range calendar: a radio group whose options are the
* caller's preset keys. Only one preset can be in effect at a time, which is why this is
* a `radiogroup` and not a row of buttons. The caller maps the chosen key to a range in
* `onChange`; the library never computes one.
*/
function DateRangePickerPresetGroup(props) {
	return /* @__PURE__ */ jsx(PickerPresetGroup, {
		"data-slot": "date-range-picker-preset-group",
		...props
	});
}
/**
* One preset, closing the picker on double-click when the caller opts in. Styled as a
* ghost `sm` button and named by its visible children — the library never synthesises
* range copy from the item's `value`.
*/
function DateRangePickerPresetItem(props) {
	const state = use(DateRangePickerStateContext);
	return /* @__PURE__ */ jsx(PickerPresetItem, {
		"data-slot": "date-range-picker-preset-item",
		...props,
		state
	});
}
DateRangePicker$1.displayName = "DateRangePicker";
DateRangePickerPresetGroup.displayName = "DateRangePickerPresetGroup";
DateRangePickerPresetItem.displayName = "DateRangePickerPresetItem";
export { DateRangePicker$1 as DateRangePicker, DateRangePickerPresetGroup, DateRangePickerPresetItem };

//# sourceMappingURL=date-range-picker.js.map