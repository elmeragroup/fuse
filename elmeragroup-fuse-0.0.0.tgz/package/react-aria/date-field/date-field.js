"use client";
import { cn } from "../../styles/cn.js";
import { definedProps } from "../../internal/defined-props.js";
import { composeTailwindRenderProps } from "../internal/compose-tailwind-render-props.js";
import { dateFieldVariants } from "../../styles/date-field.js";
import { Description, FieldError as FieldError$1, FieldGroupSurfaceContext, Label as Label$1, fieldGroupVariants } from "../internal/field.js";
import { useFormErrors } from "../internal/form-errors.js";
import { useContext } from "react";
import { jsx, jsxs } from "react/jsx-runtime";
import { DateField as DateField$1, DateFieldStateContext, DateInput as DateInput$1, DateSegment, FormValidationContext, composeRenderProps } from "react-aria-components";
// src/react-aria/date-field/date-field.tsx
function DateField({ label, description, errorMessage, shouldForceLeadingZeros = true, size = "default", className, onChange, ...props }) {
	const { base } = dateFieldVariants();
	const { validationErrors, onChange: clearingOnChange } = useFormErrors([props.name], onChange);
	return /* @__PURE__ */ jsx(FormValidationContext.Provider, {
		value: validationErrors,
		children: /* @__PURE__ */ jsxs(DateField$1, {
			...props,
			onChange: clearingOnChange,
			shouldForceLeadingZeros,
			className: composeTailwindRenderProps(className, base()),
			children: [
				label ? /* @__PURE__ */ jsx(Label$1, { children: label }) : null,
				/* @__PURE__ */ jsx(DateInput, { size }),
				/* @__PURE__ */ jsx(FieldError$1, { children: errorMessage }),
				description ? /* @__PURE__ */ jsx(Description, { children: description }) : null
			]
		})
	});
}
function DateInput({ className, size = "default", ...props }) {
	const state = useContext(DateFieldStateContext);
	const hasGroupSurface = useContext(FieldGroupSurfaceContext);
	const { input, segment } = dateFieldVariants({ surface: hasGroupSurface ? "group" : "own" });
	return /* @__PURE__ */ jsx(DateInput$1, {
		...props,
		...definedProps({ "data-size": hasGroupSurface ? void 0 : size }),
		className: composeRenderProps(className, (resolved, renderProps) => cn(hasGroupSurface ? input() : fieldGroupVariants({
			size,
			isFocusVisible: renderProps.isFocusVisible,
			isInvalid: renderProps.isInvalid,
			isDisabled: renderProps.isDisabled,
			isReadOnly: state?.isReadOnly ?? false,
			class: input()
		}), resolved)),
		children: (dateSegment) => /* @__PURE__ */ jsx(DateSegment, {
			segment: dateSegment,
			className: (values) => segment(values)
		})
	});
}
DateField.displayName = "DateField";
DateInput.displayName = "DateInput";
export { DateField, DateInput };

//# sourceMappingURL=date-field.js.map