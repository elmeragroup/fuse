"use client";
import { CaretRight } from "../../icons/generated/caret-right.js";
import { CaretLeft } from "../../icons/generated/caret-left.js";
import { Heading as Heading$1 } from "../../components/heading/heading.js";
import { Text as Text$1 } from "../../components/text/text.js";
import { calendarVariants, cellVariants } from "../../styles/calendar.js";
import { composeTailwindRenderProps } from "../internal/compose-tailwind-render-props.js";
import { Button as Button$1 } from "../internal/button.js";
import { CalendarGridHeader, LocaleCalendarGrid } from "../internal/calendar-grid.js";
import { jsx, jsxs } from "react/jsx-runtime";
import { Calendar as Calendar$1, CalendarCell, CalendarGridBody, Heading, Text, useLocale } from "react-aria-components";
// src/react-aria/calendar/calendar.tsx
/**
* The standalone Calendar card. It publishes `--inner-corner`, its corner less its border and
* padding, for parts that round with `rounded-inner`.
*/
function Calendar({ errorMessage, className, ...props }) {
	const { base, body, error } = calendarVariants();
	const { direction } = useLocale();
	return /* @__PURE__ */ jsxs(Calendar$1, {
		dir: direction,
		...props,
		className: composeTailwindRenderProps(className, base()),
		children: [
			/* @__PURE__ */ jsx(CalendarHeader, {}),
			/* @__PURE__ */ jsx(LocaleCalendarGrid, {
				className: body(),
				children: /* @__PURE__ */ jsx(CalendarGridBody, { children: (date) => /* @__PURE__ */ jsx(CalendarCell, {
					date,
					className: (values) => cellVariants(values)
				}) })
			}),
			errorMessage ? /* @__PURE__ */ jsx(Text$1, {
				className: error(),
				render: /* @__PURE__ */ jsx(Text, { slot: "errorMessage" }),
				children: errorMessage
			}) : null
		]
	});
}
/**
* Month navigation row. Reads `useLocale()` so caret icons flip in RTL.
* The month title is the public Heading rendered onto RAC Heading, at `size="lg"` and
* `font="default"` so the level 2 theme roles do not restyle it.
* Reused by RangeCalendar.
*/
function CalendarHeader() {
	const { direction } = useLocale();
	const { header, heading } = calendarVariants();
	return /* @__PURE__ */ jsxs("header", {
		className: header(),
		children: [
			/* @__PURE__ */ jsx(Button$1, {
				variant: "ghost",
				size: "icon",
				slot: "previous",
				children: direction === "rtl" ? /* @__PURE__ */ jsx(CaretRight, { "aria-hidden": true }) : /* @__PURE__ */ jsx(CaretLeft, { "aria-hidden": true })
			}),
			/* @__PURE__ */ jsx(Heading$1, {
				size: "lg",
				font: "default",
				className: heading(),
				render: /* @__PURE__ */ jsx(Heading, {})
			}),
			/* @__PURE__ */ jsx(Button$1, {
				variant: "ghost",
				size: "icon",
				slot: "next",
				children: direction === "rtl" ? /* @__PURE__ */ jsx(CaretLeft, { "aria-hidden": true }) : /* @__PURE__ */ jsx(CaretRight, { "aria-hidden": true })
			})
		]
	});
}
Calendar.displayName = "Calendar";
CalendarHeader.displayName = "CalendarHeader";
export { Calendar, CalendarGridHeader, CalendarHeader };

//# sourceMappingURL=calendar.js.map