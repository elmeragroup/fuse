import { cn } from "../../styles/cn.js";
import { composeRenderProps } from "react-aria-components";
// src/react-aria/internal/compose-tailwind-render-props.ts
/**
* RAC's `className` accepts a string or a render-prop function. This resolves either
* shape and merges the recipe classes underneath the caller's, so a consumer class
* always wins the Tailwind conflict. Package-private.
*
* It stays separate from `mergeClassName` because it always returns a callback, even for
* a string or omitted `className`. RAC's `useContextProps` merges context props in with
* `mergeProps`, where two strings concatenate but a callback replaces the context's
* `className`, so the callback keeps context-supplied classes off Fuse parts.
*/
function composeTailwindRenderProps(className, twClasses) {
	return composeRenderProps(className, (resolved) => cn(twClasses, resolved));
}
export { composeTailwindRenderProps };

//# sourceMappingURL=compose-tailwind-render-props.js.map