"use client";
import { cn } from "../../styles/cn.js";
import { tv } from "../../styles/tv.js";
import { stateFocusRingClass, stateFocusRingVisibleClass, stateInvalidFocusRingVisibleClass } from "../../styles/utils.js";
import { racDisabledStateFaceClass, racInvalidStateFaceClass } from "../../styles/state-face.js";
import { fieldReads, fieldSize } from "../../styles/field-size.js";
import { fieldBoxChromeClass } from "../../styles/field-box.js";
import { labelTypeClass } from "../../styles/label-type.js";
import { composeTailwindRenderProps } from "./compose-tailwind-render-props.js";
import { createContext } from "react";
import { jsx } from "react/jsx-runtime";
import { FieldError as FieldError$1, Group, Label as Label$1, Text, composeRenderProps } from "react-aria-components";
// src/react-aria/internal/field.tsx
/**
* Package-private field chrome for the interim React Aria tier. Its `size` axis writes the field
* size (`field-size.ts`) on the box, `"default"` the md control size and `"sm"` the sm one, and
* the box reads its height from it, as the input, the segment rows and the inner buttons inside
* it read theirs. Its shared `fieldBoxChromeClass` matches
* Input's border, fill, radius, and shadow in mixed forms. The RAC Group is not focusable,
* so it uses the shared state focus constants and receives disabled/invalid state through
* render props, which the rac-target state face turns into the shared disabled and invalid
* looks. A focused invalid group draws a solid error line inside the invalid halo through its
* compound.
* Descendant inputs borrow this surface instead of painting another fill.
*/
const fieldGroupVariants = tv({
	base: cn(fieldBoxChromeClass, fieldReads.height(), "group flex items-center overflow-hidden text-foreground", stateFocusRingClass),
	variants: {
		size: {
			default: fieldSize({ size: "default" }).box(),
			sm: fieldSize({ size: "sm" }).box()
		},
		isFocusVisible: {
			true: stateFocusRingVisibleClass,
			false: ""
		},
		isInvalid: {
			true: racInvalidStateFaceClass,
			false: ""
		},
		isDisabled: {
			true: racDisabledStateFaceClass,
			false: ""
		},
		isReadOnly: {
			true: "bg-muted",
			false: ""
		}
	},
	compoundVariants: [{
		isInvalid: true,
		isFocusVisible: true,
		class: stateInvalidFocusRingVisibleClass
	}],
	defaultVariants: {
		size: "default",
		isFocusVisible: false,
		isInvalid: false,
		isDisabled: false,
		isReadOnly: false
	}
});
/** Descendant segment rows borrow this group's field surface. */
const FieldGroupSurfaceContext = createContext(false);
function FieldGroup({ className, size, ...props }) {
	return /* @__PURE__ */ jsx(FieldGroupSurfaceContext.Provider, {
		value: true,
		children: /* @__PURE__ */ jsx(Group, {
			"data-slot": "field-group",
			"data-size": size,
			className: composeRenderProps(className, (resolved, renderProps) => cn(fieldGroupVariants({
				size,
				isFocusVisible: renderProps.isFocusVisible,
				isInvalid: renderProps.isInvalid,
				isDisabled: renderProps.isDisabled,
				isReadOnly: props.isReadOnly ?? false
			}), resolved)),
			...props
		})
	});
}
function Label({ className, ...props }) {
	return /* @__PURE__ */ jsx(Label$1, {
		"data-slot": "field-label",
		className: cn(labelTypeClass, "font-medium w-fit cursor-default", className),
		...props
	});
}
function Description({ className, ...props }) {
	return /* @__PURE__ */ jsx(Text, {
		"data-slot": "field-description",
		slot: "description",
		className: cn(labelTypeClass, "text-muted-foreground", className),
		...props
	});
}
function FieldError({ className, ...props }) {
	return /* @__PURE__ */ jsx(FieldError$1, {
		"data-slot": "field-error",
		render: (domProps) => /* @__PURE__ */ jsx("span", {
			...domProps,
			role: "alert"
		}),
		className: composeTailwindRenderProps(className, cn(labelTypeClass, "whitespace-break-spaces text-error")),
		...props
	});
}
FieldGroup.displayName = "ReactAriaInternal.FieldGroup";
Label.displayName = "ReactAriaInternal.Label";
Description.displayName = "ReactAriaInternal.Description";
FieldError.displayName = "ReactAriaInternal.FieldError";
export { Description, FieldError, FieldGroup, FieldGroupSurfaceContext, Label, fieldGroupVariants };

//# sourceMappingURL=field.js.map