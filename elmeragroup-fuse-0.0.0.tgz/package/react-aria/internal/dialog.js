"use client";
import { cn } from "../../styles/cn.js";
import { tv } from "../../styles/tv.js";
import { racDialogShellClass } from "../../styles/inner-corner/picker.js";
import { jsx } from "react/jsx-runtime";
import { Dialog as Dialog$1 } from "react-aria-components";
// src/react-aria/internal/dialog.tsx
/** Resolved once at module scope — the recipe has no axes (no per-render work). */
const dialogSlots = tv({ slots: {
	base: [racDialogShellClass, "relative max-h-[inherit] overflow-y-auto outline-none"],
	content: "flex flex-col gap-(--surface-gap-lg)"
} })();
const dialogBaseClass = dialogSlots.base();
const dialogContentClass = dialogSlots.content();
function DialogContent({ className, ...props }) {
	return /* @__PURE__ */ jsx("div", {
		"data-slot": "dialog-content",
		className: cn(dialogContentClass, className),
		...props
	});
}
/**
* The styled dialog. It renders no heading, and that is what keeps it nameable.
*
* RAC's `Dialog` (`Dialog.mjs:84-97`) hands `useDialog` only the `aria-labelledby` that
* arrived as a *prop*, and falls back to the `DialogContext` value — the name a
* `DialogTrigger`, `useDatePicker` or `useDateRangePicker` publishes — only when nothing
* resolves a `<Heading slot="title">`. `useDialog` resolves that slot through
* `useSlotId`, which drops the id when no element claims it. So a heading, even an empty
* one, wins the name race and can leave the dialog announced as nothing at all; rendering
* none lets the context name through.
*/
function Dialog({ children, className, ...props }) {
	return /* @__PURE__ */ jsx(Dialog$1, {
		"data-slot": "dialog",
		...props,
		className: cn(dialogBaseClass, className),
		children: /* @__PURE__ */ jsx(DialogContent, { children })
	});
}
Dialog.displayName = "ReactAriaInternal.Dialog";
DialogContent.displayName = "ReactAriaInternal.DialogContent";
export { Dialog };

//# sourceMappingURL=dialog.js.map