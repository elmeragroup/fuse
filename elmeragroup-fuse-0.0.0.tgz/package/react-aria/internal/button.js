"use client";
import { buttonVariants } from "../../components/button/button-variants.js";
import { composeTailwindRenderProps } from "./compose-tailwind-render-props.js";
import { jsx } from "react/jsx-runtime";
import { Button as Button$1 } from "react-aria-components";
// src/react-aria/internal/button.tsx
function Button({ className, variant, size, ...props }) {
	return /* @__PURE__ */ jsx(Button$1, {
		"data-slot": "button",
		className: composeTailwindRenderProps(className, buttonVariants({
			variant,
			size
		})),
		...props
	});
}
Button.displayName = "ReactAriaInternal.Button";
export { Button };

//# sourceMappingURL=button.js.map