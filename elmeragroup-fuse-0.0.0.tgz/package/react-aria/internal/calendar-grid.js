"use client";
import { weekdayStyle } from "../../components/calendar/weekday-style.js";
import { calendarVariants } from "../../styles/calendar.js";
import { jsx, jsxs } from "react/jsx-runtime";
import { CalendarGrid, CalendarGridHeader as CalendarGridHeader$1, CalendarHeaderCell, useLocale } from "react-aria-components";
// src/react-aria/internal/calendar-grid.tsx
/**
* Weekday column-header row. Reused by Calendar and RangeCalendar; the locale-aware grid
* renders it, so it stays beside the grid rather than in either composite.
*/
function CalendarGridHeader() {
	const { headerCell } = calendarVariants();
	return /* @__PURE__ */ jsx(CalendarGridHeader$1, { children: (day) => /* @__PURE__ */ jsx(CalendarHeaderCell, {
		className: headerCell(),
		children: day
	}) });
}
/**
* The weekday grid of both calendar composites, owning the locale wiring its siblings
* would otherwise each repeat: reads the active locale, selects the short or narrow
* weekday label style from it, and renders the shared `CalendarGridHeader`. Reused by
* RangeCalendar.
*/
function LocaleCalendarGrid({ className, children }) {
	const { locale } = useLocale();
	return /* @__PURE__ */ jsxs(CalendarGrid, {
		className,
		weekdayStyle: weekdayStyle(locale),
		children: [/* @__PURE__ */ jsx(CalendarGridHeader, {}), children]
	});
}
CalendarGridHeader.displayName = "CalendarGridHeader";
LocaleCalendarGrid.displayName = "LocaleCalendarGrid";
export { CalendarGridHeader, LocaleCalendarGrid };

//# sourceMappingURL=calendar-grid.js.map